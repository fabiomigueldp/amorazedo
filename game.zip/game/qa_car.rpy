label qa_car_setup:
    $ aa_state = aa_new_state()
    $ aa_state.update(bond="mantido", comfort_lie=qa_car_lie, truth=not qa_car_lie)
    jump s00

testsuite aa_car:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/car"
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu"
    teardown:
        exit

    testcase l0_h0_s0:
        $ qa_car_lie = False
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Abraçá-la e ficar ali, sem apressar a despedida."
        pause 0.3
        screenshot "l0_h0_s0_abraco.png"
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Dizer que sim e oferecer o ombro."
        advance until "Vanessa apoiou a cabeça no meu ombro. Deixei minha mão junto da dela. O carro saiu devagar."
        pause 0.3
        screenshot "l0_h0_s0_ombro.png"
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == True and aa_state["car_close"] == True
        assert eval aa_state["comfort_lie"] == False and aa_state["truth"] == True

    testcase l0_h0_s1:
        $ qa_car_lie = False
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Abraçá-la e ficar ali, sem apressar a despedida."
        pause 0.3
        screenshot "l0_h0_s1_abraco.png"
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Pedir que fiquem cada um no seu lugar por enquanto."
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == True and aa_state["car_close"] == False
        assert eval aa_state["comfort_lie"] == False and aa_state["truth"] == True

    testcase l0_h1_s0:
        $ qa_car_lie = False
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Dizer que prefiro esperar ao lado dela, sem abraçar."
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Dizer que sim e oferecer o ombro."
        advance until "Vanessa apoiou a cabeça no meu ombro. Deixei minha mão junto da dela. O carro saiu devagar."
        pause 0.3
        screenshot "l0_h1_s0_ombro.png"
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == False and aa_state["car_close"] == True
        assert eval aa_state["comfort_lie"] == False and aa_state["truth"] == True

    testcase l0_h1_s1:
        $ qa_car_lie = False
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Dizer que prefiro esperar ao lado dela, sem abraçar."
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Pedir que fiquem cada um no seu lugar por enquanto."
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == False and aa_state["car_close"] == False
        assert eval aa_state["comfort_lie"] == False and aa_state["truth"] == True

    testcase l1_h0_s0:
        $ qa_car_lie = True
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Abraçá-la e ficar ali, sem apressar a despedida."
        pause 0.3
        screenshot "l1_h0_s0_abraco.png"
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Dizer que sim e oferecer o ombro."
        advance until "Vanessa apoiou a cabeça no meu ombro. Deixei minha mão junto da dela. O carro saiu devagar."
        pause 0.3
        screenshot "l1_h0_s0_ombro.png"
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == True and aa_state["car_close"] == True
        assert eval aa_state["comfort_lie"] == True and aa_state["truth"] == False

    testcase l1_h0_s1:
        $ qa_car_lie = True
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Abraçá-la e ficar ali, sem apressar a despedida."
        pause 0.3
        screenshot "l1_h0_s1_abraco.png"
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Pedir que fiquem cada um no seu lugar por enquanto."
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == True and aa_state["car_close"] == False
        assert eval aa_state["comfort_lie"] == True and aa_state["truth"] == False

    testcase l1_h1_s0:
        $ qa_car_lie = True
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Dizer que prefiro esperar ao lado dela, sem abraçar."
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Dizer que sim e oferecer o ombro."
        advance until "Vanessa apoiou a cabeça no meu ombro. Deixei minha mão junto da dela. O carro saiu devagar."
        pause 0.3
        screenshot "l1_h1_s0_ombro.png"
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == False and aa_state["car_close"] == True
        assert eval aa_state["comfort_lie"] == True and aa_state["truth"] == False

    testcase l1_h1_s1:
        $ qa_car_lie = True
        run Start("qa_car_setup")
        advance until screen "choice"
        click "Dizer que continuo com ela e combinar a visita de amanhã."
        advance until screen "choice"
        assert eval aa_node == "cr00"
        click "Dizer que prefiro esperar ao lado dela, sem abraçar."
        advance until screen "choice"
        assert eval aa_node == "cr01"
        assert not screen "aa_phone_view"
        click "Pedir que fiquem cada um no seu lugar por enquanto."
        advance until "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
        assert eval aa_node == "e03"
        assert eval aa_state["car_hug"] == False and aa_state["car_close"] == False
        assert eval aa_state["comfort_lie"] == True and aa_state["truth"] == False
