# Momentos uses the phone's revealed archive. The interface never creates
# fictional posts, comments, followers, messages, or story decisions.
init python:
    AA_SOCIAL_ICON_ROOT = "gui/phone/social/"

    def aa_social_icon(name):
        return AA_SOCIAL_ICON_ROOT + name + ".svg"

    def aa_social_tab_open(tab):
        renpy.set_screen_variable("social_tab", tab, "aa_phone_hub")
        renpy.set_screen_variable("social_panel", None, "aa_phone_hub")
        renpy.set_screen_variable("social_target", None, "aa_phone_hub")
        renpy.set_screen_variable("selected_entry", None, "aa_phone_hub")
        renpy.set_screen_variable("social_query", "", "aa_phone_hub")
        aa_phone_reset_scroll()
        renpy.restart_interaction()

    def aa_social_profile_open(author):
        renpy.set_screen_variable("social_profile", author, "aa_phone_hub")
        renpy.set_screen_variable("social_profile_section", "posts", "aa_phone_hub")
        aa_social_tab_open("profile")

    def aa_social_panel_open(panel, post_id=None):
        renpy.set_screen_variable("social_panel", panel, "aa_phone_hub")
        renpy.set_screen_variable("social_target", post_id, "aa_phone_hub")
        aa_phone_reset_scroll()
        renpy.restart_interaction()

    def aa_social_panel_close():
        renpy.set_screen_variable("social_panel", None, "aa_phone_hub")
        renpy.set_screen_variable("social_target", None, "aa_phone_hub")
        aa_phone_reset_scroll()
        renpy.restart_interaction()

    def aa_social_toggle_like(ident):
        old = tuple(aa_phone_pref("social_likes", ()))
        aa_phone_set_pref("social_likes", tuple(key for key in old if key != ident)
                          if ident in old else old + (ident,))

    def aa_social_is_saved(post):
        return any(slide["id"] in aa_phone_preferences.favorites
                   for slide in aa_pm.social_slides(aa_phone_memory, post))

    def aa_social_toggle_save(post):
        ids = {slide["id"] for slide in aa_pm.social_slides(aa_phone_memory, post)}
        if aa_social_is_saved(post):
            aa_phone_set_pref("favorites", tuple(key for key in aa_phone_preferences.favorites if key not in ids))
        else:
            aa_phone_set_pref("favorites", aa_phone_preferences.favorites + (post["id"],))

    def aa_social_slide_change(post, delta):
        screen = renpy.get_screen("aa_phone_hub")
        if not screen:
            return
        slides = aa_pm.social_slides(aa_phone_memory, post)
        if len(slides) < 2:
            return
        positions = dict(screen.scope.get("social_slides", {}))
        positions[post["id"]] = min(len(slides) - 1, max(0, positions.get(post["id"], 0) + delta))
        renpy.set_screen_variable("social_slides", positions, "aa_phone_hub")
        renpy.restart_interaction()

    def aa_social_zoom(entry):
        renpy.set_screen_variable("social_zoom_image", entry["image"], "aa_phone_hub")
        renpy.set_screen_variable("photo_zoom", True, "aa_phone_hub")
        renpy.restart_interaction()

    def aa_social_caption(post):
        if post["kind"] in ("publicado", "publicado_depois"):
            return post["title"]
        return ""

    def aa_social_subtitle(post, slide):
        if slide["kind"] == "restaurante":
            return "Casa do Pátio"
        if post["kind"] == "comparacao":
            return "Publicação antiga"
        return ""

    def aa_social_search(posts, query):
        needle = aa_pm.fold(query.strip())
        if not needle:
            return posts
        return tuple(post for post in posts if needle in aa_pm.fold(" ".join(
            (aa_pm.social_author(post), post["title"], post["subtitle"])
            + tuple(post.get("paragraphs", ()))
            + tuple(slide["title"] for slide in aa_pm.social_slides(aa_phone_memory, post)))))

style aa_social_text is aa_hub_text:
    color "#f3f3f5"
    size 15
    line_spacing 2
style aa_social_muted is aa_social_text:
    color "#a8a8ad"
    size 12
style aa_social_button is button:
    background None
    hover_background Solid("#242427")
    selected_background None
    padding (0, 0)
    xminimum 44
    yminimum 44
    activate_sound None
style aa_social_button_text is aa_social_text:
    align (.5, .5)
    text_align .5
style aa_social_link is aa_social_text:
    color "#9dccff"

screen aa_social_icon_button(icon, action, label, size=24, selected=False):
    button:
        style "aa_social_button"
        xysize (44, 44)
        action action
        alt label
        selected selected
        add aa_social_icon(icon) xysize (size, size) align (.5, .5)

screen aa_social_avatar(author, size=38):
    use aa_phone_avatar(author, size)

screen aa_social_context(width):
    # Story commands are never rendered as feed content. Earlier scene entry
    # points keep short app labels and use their canonical story action.
    $ labels = {'Abrir o perfil de Yasmin.': 'Yasmin', 'Conferir pelo celular uma foto minha que Yasmin já curtiu.': 'Ver publicação', 'Preparar uma publicação com a foto dos copos.': 'Criar publicação'}
    for item in aa_phone_context_actions('social'):
        if item.caption in labels:
            textbutton labels[item.caption]:
                style 'aa_social_button' text_style 'aa_social_link'
                text_size aa_phone_size(14) padding (14, 9) xsize width
                action [Function(aa_phone_close), item.action]

screen aa_social_post(post, width, slide_index=0, interactive=True, detail=False, story_zoom=False):
    $ slides = aa_pm.social_slides(aa_phone_memory, post)
    $ slide_index = min(max(0, slide_index), len(slides) - 1) if slides else 0
    $ slide = slides[slide_index] if slides else post
    $ author = aa_pm.social_author(post)
    $ liked = post["id"] in aa_phone_pref("social_likes", ())
    $ saved = aa_social_is_saved(post)
    $ subtitle = aa_social_subtitle(post, slide)
    $ photo_height = (width * 5 + 2) // 4
    vbox:
        xsize width
        spacing 0
        hbox:
            xpos 12
            xsize (width - 24)
            ysize 50
            spacing 9
            if interactive:
                button:
                    style "aa_social_button"
                    xysize (42, 42)
                    action Function(aa_social_profile_open, author)
                    alt ("Abrir perfil de " + author)
                    use aa_social_avatar(author, 34)
            else:
                fixed:
                    xysize (42, 42)
                    fixed:
                        pos (4, 4)
                        xysize (34, 34)
                        use aa_social_avatar(author, 34)
            vbox:
                yalign .5
                xsize (width - 128)
                spacing 1
                text author style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(14)
                if subtitle:
                    text subtitle style "aa_social_muted" size aa_phone_size(11)
            if interactive:
                use aa_social_icon_button("more", Function(aa_social_panel_open, "more", post["id"]), "Opções da publicação", 19)
            elif post['id'] == 'publicacao_feka':
                use aa_social_icon_button('more', Function(aa_social_own_options), 'Opções da publicação', 19)
            else:
                fixed:
                    xysize (44, 44)
                    add aa_social_icon("more") xysize (18, 18) align (.5, .5)
        fixed:
            xysize (width, photo_height)
            add Solid("#111115")
            if interactive:
                button:
                    background None
                    hover_background None
                    xysize (width, photo_height)
                    padding (0, 0)
                    action (Function(aa_social_zoom, slide) if detail else Function(aa_phone_select, post, "social"))
                    alt ("Ampliar imagem de " if detail else "Abrir publicação de ") + author
                    add aa_phone_cover(slide["image"], width, photo_height)
            elif story_zoom:
                button:
                    background None
                    hover_background None
                    xysize (width, photo_height)
                    padding (0, 0)
                    action Show("aa_phone_image", asset=slide["image"], return_text="Voltar ao Momentos")
                    alt "Ampliar fotografia"
                    add aa_phone_cover(slide["image"], width, photo_height)
            else:
                add aa_phone_cover(slide["image"], width, photo_height)
            if len(slides) > 1:
                if interactive and slide_index > 0:
                    textbutton "‹":
                        style "aa_social_button"
                        text_size 28
                        text_color "#f3f3f5"
                        background aa_phone_round("received", 20)
                        xysize (36, 36)
                        xpos 8
                        yalign .5
                        action Function(aa_social_slide_change, post, -1)
                        alt "Imagem anterior"
                if interactive and slide_index < len(slides) - 1:
                    textbutton "›":
                        style "aa_social_button"
                        text_size 28
                        text_color "#f3f3f5"
                        background aa_phone_round("received", 20)
                        xysize (36, 36)
                        xpos (width - 44)
                        yalign .5
                        action Function(aa_social_slide_change, post, 1)
                        alt "Próxima imagem"
                frame:
                    background aa_phone_round("received", 11)
                    padding (7, 4)
                    xpos (width - 43)
                    ypos 10
                    text (str(slide_index + 1) + "/" + str(len(slides))) style "aa_social_text" size 11
        hbox:
            xpos 12
            xsize (width - 24)
            ysize 46
            spacing 0
            if interactive:
                use aa_social_icon_button("heart-filled" if liked else "heart", Function(aa_social_toggle_like, post["id"]), "Descurtir" if liked else "Curtir", 24, liked)
                use aa_social_icon_button("comment", Function(aa_social_panel_open, "comments", post["id"]), "Ver comentários", 24)
                use aa_social_icon_button("share", Function(aa_social_panel_open, "share", post["id"]), "Compartilhar", 24)
                null width (width - 200)
                use aa_social_icon_button("bookmark-filled" if saved else "bookmark", Function(aa_social_toggle_save, post), "Remover dos salvos" if saved else "Salvar publicação", 24, saved)
            else:
                for icon in ("heart", "comment", "share"):
                    add aa_social_icon(icon) xysize (23, 23) yalign .5
                    null width 15
                null width (width - 161)
                add aa_social_icon("bookmark") xysize (23, 23) yalign .5
        if len(slides) > 1:
            hbox:
                xalign .5
                spacing 5
                for index in range(len(slides)):
                    add Solid("#f4f4f6" if index == slide_index else "#68686e") xysize (5, 5)
            null height 8
        if liked:
            text "Você curtiu" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(12) xpos 12
        if post["kind"] == "comparacao":
            text "Curtido por Yasmin" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(12) xpos 12
        if aa_social_caption(post):
            text ('{b}' + author + '{/b}  ' + aa_social_caption(post)) style "aa_social_text" size aa_phone_size(13) xpos 12 xmaximum (width - 24)
        if "@Vanessa" in post.get("paragraphs", ()):
            text "@Vanessa" style "aa_social_link" size aa_phone_size(13) xpos 12
        if post["kind"] == "publicacao":
            text "Publicação de hoje" style "aa_social_muted" size aa_phone_size(11) xpos 12
        elif post["kind"] == "comparacao":
            text "Publicação antiga" style "aa_social_muted" size aa_phone_size(11) xpos 12
        null height 17
        add Solid("#28282c") xysize (width, 1)

screen aa_social_navbar(width, height, active):
    fixed:
        ypos (height - 82)
        xysize (width, 56)
        add Solid("#101013f5")
        add Solid("#35353a") xysize (width, 1)
        $ icons = (("home-filled" if active == "home" else "home", "home", "Feed"),
                 ("reels", "reels", "Reels"), ("dm", "dm", "Conversas"),
                 ("search-filled" if active == "search" else "search", "search", "Buscar"),
                 ("profile", "profile", "Perfil"))
        for index, (icon, target, label) in enumerate(icons):
            fixed:
                xpos int((index + .5) * width / 5) - 22
                ypos 5
                if target == "profile":
                    button:
                        style "aa_social_button"
                        xysize (44, 44)
                        action Function(aa_social_profile_open, "Feka")
                        alt label
                        fixed:
                            xysize (44, 44)
                            fixed:
                                pos (9, 9)
                                xysize (26, 26)
                                use aa_social_avatar("Feka", 26)
                            if active == target:
                                add aa_social_icon("profile-ring") xysize (34, 34) xpos 5 ypos 5
                else:
                    use aa_social_icon_button(icon, Function(aa_social_tab_open, target), label, 23, active == target)

screen aa_social_profile_shortcuts(width):
    $ posts = aa_pm.social_posts(aa_phone_memory)
    $ authors = tuple(name for name in ("Feka", "Yasmin") if any(aa_pm.social_author(p) == name for p in posts))
    if authors:
        vbox:
            xsize width
            spacing 0
            hbox:
                xpos 12
                xsize (width - 24)
                ysize 81
                spacing 12
                for author in authors:
                    button:
                        style "aa_social_button"
                        xysize (70, 78)
                        action Function(aa_social_profile_open, author)
                        alt ("Abrir perfil de " + author)
                        vbox:
                            xalign .5
                            spacing 3
                            use aa_social_avatar(author, 48)
                            text ("Você" if author == "Feka" else author) style "aa_social_text" size 11 xalign .5
            add Solid("#29292d") xysize (width, 1)

screen aa_social_grid(posts, width):
    $ tile = (width - 4) // 3
    for start in range(0, len(posts), 3):
        hbox:
            spacing 2
            for post in posts[start:start + 3]:
                button:
                    padding (0, 0)
                    background Solid("#17171b")
                    hover_background Solid("#303035")
                    xysize (tile, tile + 19)
                    action Function(aa_phone_select, post, "social")
                    alt ("Abrir publicação de " + aa_pm.social_author(post))
                    add Transform(post["image"], xysize=(tile, tile + 19), fit="cover")

screen aa_social_app(width, height, selected, tab, profile, profile_section, panel, target, query, slides, scroll):
    $ posts = aa_pm.social_posts(aa_phone_memory)
    $ body_bottom = height - 82
    $ own_options = target == 'publicacao_feka' and panel in ('more', 'edit_tags', 'delete')
    $ composer = panel == 'create' and aa_node == 'e08'
    fixed:
        xysize (width, height)
        if composer:
            use aa_social_composer(width, height)
        elif own_options:
            $ own_post = next((p for p in posts if p['id'] == 'publicacao_feka'), None)
            text 'Publicação' style 'aa_social_text' font 'fonts/Inter-SemiBold.ttf' size aa_phone_size(17) xalign .5 ypos 59
            if own_post:
                viewport:
                    ypos 99 xysize (width, body_bottom - 99)
                    use aa_social_post(own_post, width, 0, False)
        elif selected and not panel:
            fixed:
                xpos 5 ypos 48 xysize (width - 10, 47)
                use aa_social_icon_button("back", Function(aa_phone_back), "Voltar", 22)
                text "Publicação" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17) xalign .5 yalign .5
                fixed:
                    xpos (width - 54)
                    use aa_social_icon_button("more", Function(aa_social_panel_open, "more", selected["id"]), "Opções", 20)
            viewport:
                id "phone_scroll"
                xpos 0 ypos 99 xysize (width, body_bottom - 99)
                mousewheel True draggable True arrowkeys True pagekeys True
                yadjustment scroll
                vbox:
                    xsize width
                    $ index = slides.get(selected["id"], 0)
                    use aa_social_post(selected, width, index, True, True)
        elif panel:
            fixed:
                xpos 5 ypos 48 xysize (width - 10, 47)
                use aa_social_icon_button("back", Function(aa_social_panel_close), "Voltar", 22)
                text {"activity": "Atividade", "comments": "Comentários", "share": "Compartilhar", "more": "Opções", "create": "Criar"}.get(panel, "Momentos") style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17) xalign .5 yalign .5
            viewport:
                id "phone_scroll"
                xpos 0 ypos 100 xysize (width, body_bottom - 100)
                mousewheel True draggable True arrowkeys True
                yadjustment scroll
                vbox:
                    xsize width
                    spacing 10
                    if panel == "activity":
                        $ activity = tuple(item for item in reversed(aa_phone_memory) if item["kind"] in ("publicacao", "restaurante", "comparacao"))
                        if not activity:
                            text "Nenhuma atividade conhecida" style "aa_social_muted" size aa_phone_size(15) xpos 15 ypos 22
                        for item in activity:
                            button:
                                style "aa_social_button"
                                xsize width yminimum 65
                                padding (14, 9)
                                action Function(aa_phone_select, next((post for post in posts if item in aa_pm.social_slides(aa_phone_memory, post)), item), "social")
                                alt ("Abrir atividade de " + aa_pm.social_author(item))
                                hbox:
                                    spacing 10
                                    use aa_social_avatar(aa_pm.social_author(item), 40)
                                    text ("Yasmin curtiu sua publicação" if item["kind"] == "comparacao" else "Yasmin compartilhou Casa do Pátio" if item["kind"] == "restaurante" else "Publicação de Yasmin") style "aa_social_text" size aa_phone_size(13) xmaximum (width - 106) yalign .5
                                    add Transform(item["image"], xysize=(38, 48), fit="cover")
                            add Solid("#28282c") xysize (width, 1)
                    elif panel == "comments":
                        null height 12
                        text "Não há comentários disponíveis no arquivo." style "aa_social_muted" size aa_phone_size(14) xpos 14 xmaximum (width - 28)
                    elif panel == "share":
                        text "Enviar a publicação" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(16) xpos 14
                        textbutton "Abrir Mensagens do celular" style "aa_social_button" text_style "aa_social_link" text_size aa_phone_size(15) xfill True padding (14, 12) action Function(aa_phone_go, "messages")
                    elif panel == "more":
                        $ item = next((post for post in posts if any(slide["id"] == target for slide in aa_pm.social_slides(aa_phone_memory, post))), None)
                        if item:
                            if item["id"] == "publicacao_feka":
                                use aa_social_context(width)
                            textbutton ("Remover dos salvos" if aa_social_is_saved(item) else "Salvar publicação") style "aa_social_button" text_style "aa_social_text" text_size aa_phone_size(15) xfill True padding (14, 12) action Function(aa_social_toggle_save, item)
                            textbutton ("Ver perfil de " + aa_pm.social_author(item)) style "aa_social_button" text_style "aa_social_text" text_size aa_phone_size(15) xfill True padding (14, 12) action Function(aa_social_profile_open, aa_pm.social_author(item))
                    elif panel == "create":
                        use aa_social_context(width)
                        text "Fotos no aparelho" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(16) xpos 14
                        $ photos = aa_pm.app_entries(aa_phone_memory, "photos")
                        if photos:
                            $ tile = (width - 4) // 3
                            for start in range(0, len(photos), 3):
                                hbox:
                                    spacing 2
                                    for item in photos[start:start + 3]:
                                        button:
                                            background None padding (0, 0) xysize (tile, tile + 19)
                                            action Function(aa_phone_select, item, "photos")
                                            alt ("Abrir foto " + item["title"])
                                            add Transform(item["image"], xysize=(tile, tile + 19), fit="cover")
                        else:
                            text "As fotos tiradas durante a história aparecem aqui." style "aa_social_muted" size aa_phone_size(14) xpos 14 xmaximum (width - 28)
                        text "Nenhuma publicação em preparação." style "aa_social_muted" size aa_phone_size(12) xpos 14 xmaximum (width - 28)
        elif tab == "home":
            fixed:
                xpos 5 ypos 48 xysize (width - 10, 48)
                use aa_social_icon_button("plus", Function(aa_social_panel_open, "create"), "Criar", 24)
                text "Momentos" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(22) xalign .5 yalign .5
                fixed:
                    xpos (width - 54)
                    use aa_social_icon_button("heart", Function(aa_social_panel_open, "activity"), "Atividade", 23)
            viewport:
                id "phone_scroll"
                xpos 0 ypos 100 xysize (width, body_bottom - 100)
                mousewheel True draggable True arrowkeys True pagekeys True
                yadjustment scroll
                vbox:
                    xsize width
                    spacing 0
                    use aa_social_context(width)
                    use aa_social_profile_shortcuts(width)
                    if posts:
                        for post in posts:
                            use aa_social_post(post, width, slides.get(post["id"], 0))
                    else:
                        if aa_node != 'e08':
                            null height 48
                            text "Sua rede começa aqui" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(18) xalign .5
                            text "Publicações vistas na história aparecem neste feed." style "aa_social_muted" size aa_phone_size(14) xalign .5 textalign .5 xmaximum (width - 36)
        elif tab == "search":
            fixed:
                xpos 12 ypos 51 xysize (width - 24, 42)
                add aa_phone_round("received", 12) xysize (width - 24, 42)
                add aa_social_icon("search") xysize (19, 19) xpos 11 yalign .5
                input:
                    value ScreenVariableInputValue("social_query")
                    style "aa_social_text"
                    size aa_phone_size(15)
                    xpos 39 yalign .5 xmaximum (width - 76)
                    length 50
                    copypaste True
                    alt "Buscar publicações ou perfis"
            viewport:
                id "phone_scroll"
                xpos 0 ypos 106 xysize (width, body_bottom - 106)
                mousewheel True draggable True arrowkeys True
                yadjustment scroll
                vbox:
                    xsize width
                    spacing 10
                    $ results = aa_social_search(posts, query)
                    if results:
                        use aa_social_grid(results, width)
                    else:
                        text "Nenhuma publicação encontrada" style "aa_social_muted" size aa_phone_size(14) xalign .5 ypos 28
        elif tab == "reels":
            fixed:
                xpos 15 ypos 53 xysize (width - 30, 38)
                text "Reels" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(22)
            viewport:
                id "phone_scroll"
                xpos 0 ypos 102 xysize (width, body_bottom - 102)
                vbox:
                    xsize width
                    spacing 14
                    null height 100
                    add aa_social_icon("reels") xysize (45, 45) xalign .5
                    text "Nenhum reel para ver agora" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17) xalign .5 textalign .5
                    text "As publicações disponíveis estão no feed." style "aa_social_muted" size aa_phone_size(14) xalign .5 textalign .5
                    textbutton "Ver feed" style "aa_social_button" text_style "aa_social_link" text_size aa_phone_size(15) xalign .5 padding (14, 12) action Function(aa_social_tab_open, "home")
        elif tab == "dm":
            fixed:
                xpos 14 ypos 51 xysize (width - 28, 42)
                text "Conversas" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(22)
            viewport:
                id "phone_scroll"
                xpos 0 ypos 101 xysize (width, body_bottom - 101)
                mousewheel True draggable True arrowkeys True
                yadjustment scroll
                vbox:
                    xsize width
                    spacing 2
                    text "Mensagens do celular" style "aa_social_muted" size aa_phone_size(12) xpos 14
                    for thread in aa_phone_threads():
                        button:
                            style "aa_social_button"
                            xsize width yminimum 66 padding (13, 8)
                            action Function(aa_phone_select, thread, "messages")
                            alt ("Abrir conversa com " + thread["title"] + " em Mensagens")
                            hbox:
                                spacing 10
                                use aa_social_avatar(thread["title"], 42)
                                vbox:
                                    yalign .5 spacing 3
                                    text thread["title"] style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(14)
                                    text (thread["messages"][-1][1] if thread["messages"] else "Conversa") style "aa_social_muted" size aa_phone_size(12) xmaximum (width - 84) layout "subtitle"
                        add Solid("#28282c") xysize (width, 1)
        else:
            fixed:
                xpos 5 ypos 48 xysize (width - 10, 47)
                if profile != "Feka":
                    use aa_social_icon_button("back", Function(aa_social_profile_open, "Feka"), "Seu perfil", 22)
                text profile style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(19) xalign .5 yalign .5
            viewport:
                id "phone_scroll"
                xpos 0 ypos 100 xysize (width, body_bottom - 100)
                mousewheel True draggable True arrowkeys True
                yadjustment scroll
                vbox:
                    xsize width
                    spacing 13
                    use aa_social_context(width)
                    hbox:
                        xpos 14 spacing 16 ysize 79
                        use aa_social_avatar(profile, 72)
                        vbox:
                            yalign .5 spacing 3
                            $ profile_posts = aa_pm.social_profile_posts(aa_phone_memory, profile)
                            text str(len(profile_posts)) style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(19)
                            text ("publicação" if len(profile_posts) == 1 else "publicações") style "aa_social_muted" size aa_phone_size(13)
                    text ("Você" if profile == "Feka" else profile) style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(14) xpos 14
                    hbox:
                        xsize width spacing 2
                        textbutton "Publicações":
                            style "aa_social_button" text_style "aa_social_text" text_size aa_phone_size(13)
                            text_xalign .5
                            xsize (width // 2) ysize 42
                            selected profile_section == "posts"
                            action [SetScreenVariable("social_profile_section", "posts"), Function(scroll.change, 0)]
                        if profile == "Feka":
                            textbutton "Salvos":
                                style "aa_social_button" text_style "aa_social_text" text_size aa_phone_size(13)
                                text_xalign .5
                                xsize (width // 2) ysize 42
                                selected profile_section == "saved"
                                action [SetScreenVariable("social_profile_section", "saved"), Function(scroll.change, 0)]
                    fixed:
                        xysize (width, 2)
                        add Solid("#303035") xysize (width, 1)
                        add Solid("#f3f3f5") xpos (0 if profile_section == "posts" else width // 2) xysize (width // 2, 2)
                    $ shown = tuple(post for post in posts if aa_social_is_saved(post)) if profile_section == "saved" and profile == "Feka" else profile_posts
                    if shown:
                        use aa_social_grid(shown, width)
                    else:
                        null height 8
                        text ("Nenhuma publicação salva" if profile_section == "saved" else "Nenhuma publicação disponível") style "aa_social_muted" size aa_phone_size(14) xalign .5
        if not composer:
            use aa_social_navbar(width, height, tab)
        if own_options:
            use aa_social_post_options(width, height, panel)

# The POV insert shares the post component, typography, actions and image
# layout while keeping story progression under the narration's control.
screen aa_social_story_insert(kind, width, height):
    $ entry = next((item for item in aa_phone_memory if item["kind"] == kind), None)
    $ post = entry
    if post:
        fixed:
            xysize (width, height)
            text "Momentos" style "aa_social_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(22) xpos 13 ypos 50
            add aa_social_icon("heart") xysize (23, 23) xpos (width - 34) ypos 54
            viewport:
                xpos 0 ypos 96 xysize (width, height - 166)
                mousewheel True draggable True
                vbox:
                    xsize width
                    use aa_social_post(post, width, 0, False, story_zoom=True)
            add Solid("#101013") xpos 0 ypos (height - 72) xysize (width, 46)
            add Solid("#35353a") xpos 0 ypos (height - 72) xysize (width, 1)
            for index, icon in enumerate(("home-filled", "reels", "dm", "search", "profile")):
                add aa_social_icon(icon) xysize (22, 22) xpos int((index + .5) * width / 5) - 11 ypos (height - 60)
