# Optional phone. Archive events are emitted by the story, never by rendering.
default aa_phone_memory = ()
default aa_phone_preferences = AAPhonePreferences()
default aa_phone_active = False
define aa_initial_balance = 12000

init python:
    import phone_memory as aa_pm

    class AAPhonePreferences(NoRollback):
        # Per-save reading preferences survive rewinding the story.
        # The archive itself remains rollback-aware and filters unseen entries.
        def __init__(self):
            self.favorites = ()
            self.page = "home"
            self.read = ()

    def aa_phone_remember(kind):
        global aa_phone_memory, aa_world
        entry = aa_pm.make_entry(kind, aa_location, aa_state, aa_phone_chats)
        if entry is None:
            return
        old = next((item for item in aa_phone_memory if item["id"] == entry["id"]), None)
        entry["at"] = old.get("at", aa_world["now"]) if old and old["kind"] == kind else aa_world["now"]
        if kind == "conversa": entry["at"] = -1
        previous = next((thread["messages"] for thread in aa_phone_threads() if thread["title"] == entry["title"]), ())
        overlap = 0
        for size in range(1, min(len(previous), len(entry["messages"])) + 1):
            if previous[-size:] == entry["messages"][:size]: overlap = size
        aa_phone_memory = aa_pm.remember(aa_phone_memory, entry)
        incoming = [body for sent, body in entry["messages"][overlap:] if not sent]
        if incoming and kind != "conversa":
            # Notifications reference the archived exchange, never duplicate it.
            from copy import deepcopy
            world = deepcopy(aa_world)
            aa_fm.message(world, "story_" + kind, entry["title"], incoming[-1], entry["at"])
            aa_world = world

    def aa_phone_threads():
        return aa_pm.threads(aa_phone_memory, aa_world["messages"])

    def aa_phone_select(entry):
        global aa_world
        aa_phone_preferences.read = tuple(set(aa_phone_preferences.read) | {entry["id"]})
        if entry["kind"] == "thread":
            aa_phone_preferences.read = tuple(set(aa_phone_preferences.read) | {item["id"] for item in aa_phone_memory if item["section"] == "messages" and item["title"] == entry["title"]})
            for notice in aa_world["messages"]:
                if notice["sender"] == entry["title"]:
                    aa_world = aa_fm.read(aa_world, notice["id"])
        renpy.set_screen_variable("page", entry["section"], "aa_phone_hub")
        renpy.set_screen_variable("selected_entry", entry, "aa_phone_hub")
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_phone_open(contact=None):
        renpy.stop_skipping()
        preferences.afm_enable = False
        renpy.show_screen("aa_phone_hub")
        entry = next((item for item in reversed(aa_phone_memory) if item["kind"] == aa_phone_kind), None)
        if contact or (entry and entry["section"] == "messages"):
            name = contact or entry["title"]
            entry = next((item for item in aa_phone_threads() if item["title"] == name), None)
        if entry:
            aa_phone_select(entry)
        renpy.restart_interaction()

    def aa_phone_context_actions(page):
        choice = renpy.get_screen("choice")
        if not choice: return ()
        captions = {
            ("a00", "photos"): ("Abrir o perfil de Yasmin.",),
            ("a00", "messages"): ("Conferir a conversa antiga com Yasmin.",),
            ("a03", "photos"): ("Conferir pelo celular uma foto minha que Yasmin já curtiu.",),
            ("c02", "photos"): ("Sugerir uma foto.", "Pedir uma foto, mesmo tendo combinado que não pediria."),
            ("k01", "photos"): ("Usar uma foto ou mensagem para fazer a noite parecer boa.",),
        }.get((aa_node, page), ())
        return tuple(item for item in choice.scope.get("items", ()) if item.caption in captions)

    def aa_phone_favorite(ident):
        aa_phone_preferences.favorites = (tuple(key for key in aa_phone_preferences.favorites if key != ident)
                             if ident in aa_phone_preferences.favorites else aa_phone_preferences.favorites + (ident,))
        renpy.restart_interaction()

    def aa_balance_text():
        return aa_pm.brl(aa_world["balance"])

    def aa_phone_time():
        return aa_fm.stamp(aa_world["now"]).split(" · ")[1]

    def aa_phone_new():
        return (any(not message["read"] for message in aa_world["messages"])
                or any(item["section"] != "bank" and item["id"] not in aa_phone_preferences.read for item in aa_phone_memory))

transform aa_hub_enter:
    alpha 0.0
    xoffset 18
    ease (0.20 if persistent.aa_motion else 0.0) alpha 1.0 xoffset 0

style aa_hub_text is default:
    size 20
    color "#eeece7"
    line_spacing 3

style aa_hub_muted is aa_hub_text:
    size 16
    color "#b8b8ae"

style aa_hub_button is button:
    background None
    hover_background Solid("#30342f")
    selected_background Solid("#30342f")
    padding (12, 10)
    yminimum 46

style aa_hub_button_text is aa_hub_text:
    size 18
    hover_color "#ece0bb"
    selected_color "#e3d5ad"
    insensitive_color "#92958b"

style aa_hub_row is aa_hub_button:
    xfill True
    padding (0, 15)

style aa_hub_row_text is aa_hub_button_text

style aa_hub_scroll_viewport is viewport
style aa_hub_scroll_vscrollbar is vscrollbar:
    xsize 3
    base_bar Solid("#30342f")
    thumb Solid("#737868")
    unscrollable "hide"
style aa_hub_scroll_side is side:
    spacing 7

style aa_hub_text:
    variant "small"
    size 24
style aa_hub_muted:
    variant "small"
    size 20
style aa_hub_button_text:
    variant "small"
    size 22

screen aa_hub_icon(name, size=24):
    add ("gui/phone/hub-" + name + ".svg") xysize (size, size)

screen aa_hub_empty(icon, title, body):
    vbox:
        spacing 18
        null height 40
        use aa_hub_icon(icon, 36)
        text title style "aa_hub_text" size 25
        text body style "aa_hub_muted" size 19 xmaximum 344

screen aa_phone_access():
    zorder 105
    if aa_phone_active and quick_menu and not main_menu and not renpy.get_screen("aa_phone_hub") and not renpy.get_screen("aa_phone_image"):
        key "p" action Function(aa_phone_open)
        button:
            xpos 1256
            xanchor 1.0
            ypos 20
            padding (16, 0)
            xysize (214, 52)
            background "gui/phone/hub-chip.svg"
            hover_background "gui/phone/hub-chip-hover.svg"
            action Function(aa_phone_open)
            alt "Celular"
            hbox:
                yalign 0.5
                spacing 14
                fixed:
                    xysize (24, 26)
                    use aa_hub_icon("phone", 24)
                    if aa_phone_new():
                        add Solid("#decfa4") xpos 20 ypos 0 xysize (4, 4)
                add Solid("#50564a") xysize (1, 22) yalign 0.5
                text aa_balance_text() style "aa_hub_text" size 20 yalign 0.5

init python:
    config.overlay_screens.append("aa_phone_access")

screen aa_phone_hub():
    modal True
    zorder 140
    default page = aa_phone_preferences.page
    default selected_entry = None
    default favorites_only = False
    default photo_zoom = False
    default scroll = ui.adjustment()
    $ handset_x = 700 if renpy.variant("small") else 834
    $ handset_width = 548 if renpy.variant("small") else 414
    $ viewport_width = handset_width - 64
    # The vertical scrollbar uses 3 px plus the side's 7 px spacing.
    # Its space must not also be assigned to the scrollable content.
    $ content_width = viewport_width - 10
    $ titles = {"home": "Celular", "messages": "Conversas", "bank": "Banco", "photos": "Fotos", "notes": "Anotações"}
    button:
        xfill True
        yfill True
        background Solid("#13151282")
        action Hide("aa_phone_hub")
        alt "Guardar celular e voltar à cena"
    key "p" action Hide("aa_phone_hub")
    key "game_menu" action (SetScreenVariable("photo_zoom", False) if photo_zoom else SetScreenVariable("selected_entry", None) if selected_entry else Hide("aa_phone_hub"))
    # Modal input stops clicks from advancing the underlying dialogue.
    fixed:
        xpos handset_x
        ypos 18
        xysize (handset_width, 664)
        at aa_hub_enter
        add Frame("gui/phone/hub-shell.svg", 38, 38) xysize (handset_width, 664)
        button:
            xpos 12
            ypos 12
            xysize (handset_width - 24, 640)
            background None
            action NullAction()
            alt "Celular de Feka"
        text ("FEKA · " + aa_fm.stamp(aa_world["now"]).split(" · ")[0]) xpos 32 ypos 25 style "aa_hub_muted" size 12 kerning 2
        text aa_phone_time() xpos (handset_width - 32) ypos 24 xanchor 1.0 style "aa_hub_muted" size 14
        hbox:
            xpos 20
            ypos 51
            xsize (handset_width - 40)
            ysize 48
            button:
                style "aa_hub_button"
                xysize (44, 46)
                action [Function(scroll.change, 0), (SetScreenVariable("selected_entry", None) if selected_entry else [SetScreenVariable("page", "home"), SetField(aa_phone_preferences, "page", "home")])]
                alt ("Voltar" if selected_entry else "Início")
                use aa_hub_icon("back" if selected_entry or page != "home" else "phone", 20)
            text (selected_entry["title"] if selected_entry else titles[page]) style "aa_hub_text" size 25 yalign 0.5 xsize (handset_width - 156) layout "subtitle"
            button:
                style "aa_hub_button"
                xysize (48, 46)
                action Hide("aa_phone_hub")
                alt "Guardar celular"
                use aa_hub_icon("close", 20)
        add Solid("#363a33") xpos 32 ypos 110 xysize (content_width, 1)
        viewport:
            id "phone_scroll"
            xpos 32
            ypos 129
            xysize (viewport_width, 446)
            mousewheel True
            draggable True
            arrowkeys True
            pagekeys True
            yadjustment scroll
            scrollbars "vertical"
            style_prefix "aa_hub_scroll"
            vbox:
                xsize content_width
                spacing 14
                if selected_entry:
                    text selected_entry["subtitle"] style "aa_hub_muted"
                    if selected_entry["kind"] != "thread":
                        text (aa_fm.stamp(selected_entry["at"]) if selected_entry.get("at", -1) >= 0 else selected_entry["location"]) style "aa_hub_muted" size 14
                    if selected_entry.get("image"):
                        button:
                            padding (0, 8)
                            action SetScreenVariable("photo_zoom", True)
                            alt "Ampliar fotografia"
                            add Transform(selected_entry["image"], xysize=(content_width, 260), fit="contain")
                    if selected_entry.get("amount") is not None:
                        text aa_pm.brl(selected_entry["amount"]) style "aa_hub_text" size 38
                    for message_index, (sent, body) in enumerate(selected_entry["messages"]):
                        frame:
                            background Frame("gui/phone/hub-sent.svg" if sent else "gui/phone/hub-received.svg", 14, 14)
                            padding (16, 12)
                            xsize (content_width - 24)
                            xalign (1.0 if sent else 0.0)
                            vbox:
                                spacing 7
                                $ message_at = selected_entry.get("message_times", ())[message_index] if selected_entry.get("message_times") else -1
                                text (("Você" if sent else selected_entry["title"]) + (" · " + aa_fm.stamp(message_at) if message_at >= 0 else "")) style "aa_hub_muted" size 13
                                text body style "aa_hub_text" xmaximum (content_width - 56)
                    for paragraph in selected_entry["paragraphs"]:
                        text paragraph style "aa_hub_text" xmaximum content_width
                    null height 8
                    if selected_entry["section"] != "bank" and selected_entry["kind"] != "scheduled":
                        textbutton ("Remover dos favoritos" if selected_entry["id"] in aa_phone_preferences.favorites else "Guardar nos favoritos"):
                            style "aa_hub_button"
                            action Function(aa_phone_favorite, selected_entry["id"])
                    null height 20
                elif page == "home":
                    text (aa_phone_time() or "Por aqui") style "aa_hub_text" size 48 line_spacing 0
                    text aa_location.split(" · ", 1)[-1] style "aa_hub_muted" size 17
                    null height 10
                    vbox:
                        spacing 0
                        for app, icon, caption in (("messages", "chat", "Mensagens"), ("bank", "bank", "Saldo e extrato"), ("photos", "photo", "Fotos e publicações"), ("notes", "note", "Informações compartilhadas")):
                            button:
                                style "aa_hub_row"
                                padding (0, 10)
                                action [Function(scroll.change, 0), [SetScreenVariable("page", app), SetField(aa_phone_preferences, "page", app)]]
                                hbox:
                                    spacing 18
                                    use aa_hub_icon(icon, 25)
                                    vbox:
                                        spacing 4
                                        text titles[app] style "aa_hub_text" size 22
                                        text caption style "aa_hub_muted" size 15
                            add Solid("#363a33") xysize (content_width, 1)
                elif page == "bank":
                    vbox:
                        spacing 10
                        text "Saldo" style "aa_hub_muted"
                        text aa_balance_text() style "aa_hub_text" size 42
                        add Solid("#363a33") xysize (content_width, 1)
                        for who, d in aa_world["debts"].items():
                            if d["paid_at"] is None:
                                text ("Joãozão" if who == "joaozao" else "Vanessa") style "aa_hub_text" size 22
                                text aa_pm.brl(d["amount"]) style "aa_hub_text"
                                text (("Vencido · " if aa_world["now"] > d["due"] else "Até ") + aa_fm.stamp(d["due"])) style "aa_hub_muted" size 16
                                textbutton "Devolver":
                                    style "aa_hub_button"
                                    sensitive aa_world["dinner_paid"] and aa_world["balance"] >= d["amount"]
                                    action Show("aa_transfer_confirm", who=who)
                                if not aa_world["dinner_paid"]:
                                    text "Pagamento do jantar pendente" style "aa_hub_muted" size 16
                                elif aa_world["balance"] < d["amount"]:
                                    text "Saldo insuficiente" style "aa_hub_muted" size 16
                                add Solid("#363a33") xysize (content_width, 1)
                        if aa_world["dinner_paid"] or aa_node in ("k00", "jl00", "k01"):
                            textbutton "Conta do jantar" style "aa_hub_button" action Show("aa_dinner_receipt")
                        text "Extrato" style "aa_hub_text" size 22
                        if not aa_world["transactions"]:
                            text "Sem movimentações" style "aa_hub_muted"
                        for item in reversed(aa_world["transactions"]):
                            vbox:
                                spacing 5
                                null height 4
                                text item["title"] style "aa_hub_text" size 20
                                text (item["party"] + " · " + aa_fm.stamp(item["at"])) style "aa_hub_muted" size 15
                                text aa_pm.brl(item["amount"]) style "aa_hub_text" size 22 color ("#cad7b9" if item["amount"] > 0 else "#eeece7")
                                text ("Saldo " + aa_pm.brl(item["balance"])) style "aa_hub_muted" size 14
                                null height 6
                else:
                    for choice_item in aa_phone_context_actions(page):
                        textbutton choice_item.caption:
                            style "aa_hub_button"
                            xmaximum content_width
                            text_xmaximum (content_width - 24)
                            action [Hide("aa_phone_hub"), choice_item.action]
                    hbox:
                        spacing 8
                        textbutton "Tudo" style "aa_hub_button" selected not favorites_only action [Function(scroll.change, 0), SetScreenVariable("favorites_only", False)]
                        textbutton "Favoritos" style "aa_hub_button" selected favorites_only action [Function(scroll.change, 0), SetScreenVariable("favorites_only", True)]
                    $ items = tuple(item for item in aa_phone_threads() if not favorites_only or item["id"] in aa_phone_preferences.favorites) if page == "messages" else aa_pm.entries(aa_phone_memory, page, aa_phone_preferences.favorites, favorites_only)
                    if not items:
                        if favorites_only:
                            use aa_hub_empty("star", "Sem favoritos", "")
                        elif page == "messages":
                            use aa_hub_empty("chat", "Sem mensagens", "")
                        elif page == "photos":
                            use aa_hub_empty("photo", "Sem fotos", "")
                        else:
                            use aa_hub_empty("note", "Sem anotações", "")
                    for item in items:
                        button:
                            style "aa_hub_row"
                            action [Function(scroll.change, 0), Function(aa_phone_select, item)]
                            vbox:
                                spacing 8
                                if page == "photos" and item.get("image"):
                                    add Transform(item["image"], xysize=(content_width, 180), fit="cover")
                                text (item["title"] + (" · Nova" if item.get("unread") else "")) style "aa_hub_text" size 23
                                text item["subtitle"] style "aa_hub_muted"
                                if item["messages"]:
                                    text item["messages"][-1][1] style "aa_hub_muted" size 17 line_spacing 0 layout "subtitle" xmaximum content_width
                                if item["id"] in aa_phone_preferences.favorites:
                                    text "Favorito" style "aa_hub_muted" size 13 color "#e3d5ad"
                        add Solid("#363a33") xysize (content_width, 1)
                    null height 15
        add Solid("#363a33") xpos 32 ypos 590 xysize (content_width, 1)
        hbox:
            xpos 24
            ypos 599
            for app, icon, title in (("home", "home", "Início"), ("messages", "chat", "Conversas"), ("bank", "bank", "Banco"), ("photos", "photo", "Fotos")):
                button:
                    style "aa_hub_button"
                    xsize ((handset_width - 48) // 4)
                    padding (2, 6)
                    selected page == app and selected_entry is None
                    action [Function(scroll.change, 0), [SetScreenVariable("page", app), SetField(aa_phone_preferences, "page", app), SetScreenVariable("selected_entry", None), SetScreenVariable("favorites_only", False)]]
                    alt title
                    vbox:
                        xalign 0.5
                        spacing 5
                        use aa_hub_icon(icon, 20)
                        text title style "aa_hub_muted" size 12 xalign 0.5 color ("#e3d5ad" if page == app else "#b8b8ae")
    if photo_zoom and selected_entry and selected_entry.get("image"):
        button:
            xfill True
            yfill True
            background Solid("#11130ff5")
            action SetScreenVariable("photo_zoom", False)
            alt "Fechar fotografia ampliada"
        add Transform(selected_entry["image"], xysize=(1180, 570), fit="contain") xalign 0.5 yalign 0.4
        textbutton "Voltar à foto" style "aa_hub_button" action SetScreenVariable("photo_zoom", False) xalign 0.5 ypos 630
