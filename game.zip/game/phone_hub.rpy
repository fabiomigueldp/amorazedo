# Optional phone. Archive events are emitted by the story, never by rendering.
default aa_phone_memory = ()
default aa_phone_preferences = AAPhonePreferences()
default aa_phone_active = False
define aa_initial_balance = 12000

init python:
    import phone_memory as aa_pm

    class AAPhonePreferences(NoRollback):
        # Per-save reading preferences survive rewinding the story.
        # The archive itself remains rollback-aware and filters unseen entries.
        def __init__(self):
            self.favorites = ()
            self.page = "home"
            self.read = ()
            self.glass = 0.55
            self.text_size = 0
            self.wallpaper = "tide"
            self.positions = {}
            self.unread = ()

    def aa_phone_remember(kind):
        global aa_phone_memory, aa_world
        entry = aa_pm.make_entry(kind, aa_location, aa_state, aa_phone_chats)
        if entry is None:
            return
        if kind == "jantar_pago" and "dinner" in aa_world.get("shortfalls", {}):
            entry = dict(entry, title="Jantar com pendência", paragraphs=("Você pagou o saldo disponível e combinou o restante com o restaurante. A pendência pode ser quitada pelo Banco.",))
        old = next((item for item in aa_phone_memory if item["id"] == entry["id"]), None)
        entry["at"] = old.get("at", aa_world["now"]) if old and old["kind"] == kind else aa_world["now"]
        if kind == "conversa": entry["at"] = -1
        previous = next((thread["messages"] for thread in aa_phone_threads() if thread["title"] == entry["title"]), ())
        overlap = 0
        for size in range(1, min(len(previous), len(entry["messages"])) + 1):
            if previous[-size:] == entry["messages"][:size]: overlap = size
        aa_phone_memory = aa_pm.remember(aa_phone_memory, entry)
        incoming = [body for sent, body in entry["messages"][overlap:] if not sent]
        if incoming and kind != "conversa":
            # Notifications reference the archived exchange, never duplicate it.
            from copy import deepcopy
            world = deepcopy(aa_world)
            aa_fm.message(world, "story_" + kind, entry["title"], incoming[-1], entry["at"])
            aa_world = world

    def aa_phone_threads():
        unread = aa_phone_pref("unread", ())
        return tuple(dict(t, unread=t["unread"] or t["id"] in unread)
                     for t in aa_pm.threads(aa_phone_memory, aa_world["messages"]))

    def aa_phone_select(entry, page=None):
        global aa_world
        aa_phone_preferences.read = tuple(set(aa_phone_preferences.read) | {entry["id"]})
        if entry["kind"] == "thread":
            aa_phone_preferences.unread = tuple(key for key in aa_phone_pref("unread", ()) if key != entry["id"])
            aa_phone_preferences.read = tuple(set(aa_phone_preferences.read) | {item["id"] for item in aa_phone_memory if item["section"] == "messages" and item["title"] == entry["title"]})
            for notice in aa_world["messages"]:
                if notice["sender"] == entry["title"]:
                    aa_world = aa_fm.read(aa_world, notice["id"])
        aa_phone_store_scroll()
        screen = renpy.get_screen("aa_phone_hub")
        renpy.set_screen_variable("message_return_search", bool(screen and screen.scope.get("search_active")), "aa_phone_hub")
        renpy.set_screen_variable("message_panel", None, "aa_phone_hub")
        destination = page or aa_pm.app_for(entry)
        if destination == "bank":
            aa_bank_set(detail=None, trail=(), tab="account", search=False, query="", scroll=ui.adjustment())
        renpy.set_screen_variable("page", destination, "aa_phone_hub")
        aa_phone_preferences.page = destination
        renpy.set_screen_variable("selected_entry", entry, "aa_phone_hub")
        renpy.set_screen_variable("search_active", False, "aa_phone_hub")
        position = aa_phone_pref("positions", {}).get(aa_phone_scroll_key(entry), "bottom" if entry["kind"] == "thread" else 0)
        aa_phone_reset_scroll("bottom" if entry.get("unread") else position)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_phone_open(contact=None):
        renpy.stop_skipping()
        preferences.afm_enable = False
        # Add UI preferences lazily to legacy saves without changing their story.
        for name, value in (("glass", .55), ("text_size", 0), ("wallpaper", "tide"), ("positions", {}), ("unread", ())):
            if not hasattr(aa_phone_preferences, name):
                setattr(aa_phone_preferences, name, value)
        renpy.show_screen("aa_phone_hub")
        entry = next((item for item in reversed(aa_phone_memory) if item["kind"] == aa_phone_kind), None)
        if contact or (entry and entry["section"] == "messages"):
            name = contact or entry["title"]
            entry = next((item for item in aa_phone_threads() if item["title"] == name), None)
        if entry:
            aa_phone_select(entry)
        renpy.restart_interaction()

    def aa_phone_context_actions(page):
        choice = renpy.get_screen("choice")
        if not choice: return ()
        captions = {
            ("a00", "social"): ("Abrir o perfil de Yasmin.",),
            ("a00", "messages"): ("Conferir a conversa antiga com Yasmin.",),
            ("a03", "social"): ("Conferir pelo celular uma foto minha que Yasmin já curtiu.",),
            ("c02", "photos"): ("Sugerir uma foto.", "Pedir uma foto, mesmo tendo combinado que não pediria."),
            ("k01", "social"): ("Usar uma foto ou mensagem para fazer a noite parecer boa.",),
        }.get((aa_node, page), ())
        return tuple(item for item in choice.scope.get("items", ()) if item.caption in captions)

    def aa_phone_favorite_ids(ident):
        # Older saves favorited individual exchanges before contact grouping.
        title = ident[len("contact_"):] if ident.startswith("contact_") else None
        return {ident} | {item["id"] for item in aa_phone_memory if title and item["section"] == "messages" and item["title"] == title}

    def aa_phone_is_favorite(ident):
        return bool(aa_phone_favorite_ids(ident).intersection(aa_phone_preferences.favorites))

    def aa_phone_favorite(ident):
        ids = aa_phone_favorite_ids(ident)
        aa_phone_preferences.favorites = (tuple(key for key in aa_phone_preferences.favorites if key not in ids)
                             if aa_phone_is_favorite(ident) else aa_phone_preferences.favorites + (ident,))
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_balance_text():
        return aa_pm.brl(aa_world["balance"])

    def aa_phone_time():
        return aa_fm.stamp(aa_world["now"]).split(" · ")[1]

    def aa_phone_new():
        return (any(thread["unread"] for thread in aa_phone_threads())
                or any(item["section"] not in ("bank", "messages") and item["id"] not in aa_phone_preferences.read for item in aa_phone_memory))

