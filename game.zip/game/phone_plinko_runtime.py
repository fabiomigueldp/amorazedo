"""A separate, unsaved clock; loading never inherits a previous round's time."""
from phone_crash_clock import CrashClock

clock = CrashClock()
