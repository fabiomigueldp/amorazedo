"""Phone archive. Pure, copy-on-write data; observing never advances the story.

Only explicit story reveals enter the archive. A save from before this feature
starts with an empty archive, rather than reconstructing unseen conversations.
"""

PHOTO_CONTENT = {
    "publicacao": ("Yasmin", "Publicação de hoje", "post3_jaleco", "Publicação vista no celular."),
    "restaurante": ("Casa do Pátio", "Publicação de Yasmin", "post3_restaurante", "Localização compartilhada por Yasmin."),
    "comparacao": ("Uma foto antiga", "Sua publicação", "post6_roupa", "Curtido por Yasmin."),
    "foto": ("O jantar", "Fotografia no aparelho", "images/arte-v2/cg2_foto.png", "Salva no aparelho. Não publicada."),
    "foto_hesita": ("O jantar", "Fotografia no aparelho", "post6_foto_hesita", "Salva no aparelho. Não publicada."),
    "enquadramento": ("Dois copos", "Fotografia no aparelho", "post6_copos", "Salva no aparelho. Não publicada."),
    "publicado": ("Uma noite ótima.", "Sua publicação", "post6_copos", "Publicada."),
    "publicado_depois": ("Uma noite ótima.", "Sua publicação", "post6_copos", "Publicada."),
}


def make_entry(kind, location, state, chats):
    entry = dict(id=kind, kind=kind, section="notes", title="", subtitle="",
                 location=location, messages=(), paragraphs=(), image=None)
    if kind in chats:
        title, subtitle, messages = chats[kind]
        entry.update(section="messages", title=title, subtitle=subtitle,
                     messages=tuple(tuple(message) for message in messages))
        if kind in ("visita_post", "marcacao"):
            entry["image"] = "post6_copos"
        if kind == "marcacao":
            entry["paragraphs"] = ("Marcação removida.",)
        elif kind == "terminou":
            entry["paragraphs"] = ("Sem resposta.",)
    elif kind == "conversa":
        entry.update(section="messages", title="Yasmin", subtitle="Conversa antiga",
                     messages=((False, "Feka, não me espera na saída de novo. Eu não combinei nada com você."),
                               (True, "Eu tava só passando.")))
    elif kind in PHOTO_CONTENT:
        title, subtitle, asset, caption = PHOTO_CONTENT[kind]
        entry.update(id="publicacao_feka" if kind in ("enquadramento", "publicado", "publicado_depois") else kind,
                     section="photos", title=title, subtitle=subtitle, image=asset,
                     paragraphs=(caption,))
        if kind in ("publicado", "publicado_depois") and (kind == "publicado" or state.get("bond") == "mantido"):
            entry["paragraphs"] += ("@Vanessa",)
    elif kind in ("endereco", "almoco_mudanca", "limite_mudanca"):
        notes = {
            "endereco": ("Apartamento de Vanessa", "Ela mostrou o endereço e o ônibus que sai da faculdade. A parada fica a uma quadra do prédio."),
            "almoco_mudanca": ("Almoço na mudança", "Vanessa avisou à mãe que vocês vão comer no apartamento."),
            "limite_mudanca": ("Vanessa", "Ela pediu que você não fosse à mudança."),
        }
        title, body = notes[kind]
        entry.update(title=title, subtitle="Compartilhado com você", paragraphs=(body,))
    elif kind == "orcamento":
        entry.update(title="A mudança de Vanessa", subtitle="Ela mostrou no celular",
                     paragraphs=("Caução · R$ 1.200", "Frete · R$ 180", "Reservado · R$ 1.380",
                                 "Jantar · até R$ 90", "A parte dela, incluindo bebida e serviço. O dinheiro da mudança fica separado."))
    elif kind == "carro":
        entry.update(id="viagem_vanessa", title="A volta de Vanessa", subtitle="Viagem compartilhada com você",
                     paragraphs=("Motorista a caminho", "Chega em 4 min", "Embarque na entrada.",
                                 "Informação mostrada na saída do restaurante."))
    elif kind == "emprestimo_pix":
        entry.update(section="bank", title="Pix recebido", subtitle="Joãozão",
                     amount=6000, paragraphs=("Transferência concluída",), debt="joaozao")
    elif kind == "ajuda_v":
        entry.update(section="bank", title="Ajuda na conta", subtitle="Vanessa",
                     paragraphs=("Vanessa completou no cartão do restaurante.",), debt="vanessa")
    elif kind == "jantar_pago":
        captions = {"dividida": "Cada um acertou a própria parte.", "admitida": "Vocês combinaram dividir a conta.",
                    "emprestimo": "Você pagou depois de receber o Pix de Joãozão.",
                    "vanessa": "Vanessa completou o pagamento.", "cena": "A conta foi acertada no restaurante."}
        entry.update(section="bank", title="Jantar acertado", subtitle="Casa do Pátio",
                     paragraphs=(captions.get(state.get("bill"), "Pagamento no restaurante."),))
    elif kind in ("rascunho", "rascunho_apagado"):
        entry.update(id="rascunho_v", title="Para Vanessa", subtitle="Rascunho" if kind == "rascunho" else "Rascunho apagado",
                     paragraphs=("Sinto muito.", "Não enviado.") if kind == "rascunho" else ("Você apagou o rascunho.",))
    elif kind in ("audio", "audio_resposta"):
        entry.update(id="audio_grupo", section="messages", title="Grupo", subtitle="Hoje · 22:12",
                     messages=((True, "Áudio · Tinham me desrespeitado."),) + (((False, "Complicado."),) if kind == "audio_resposta" else ()))
    else:
        return None
    return entry


def remember(memory, entry):
    if entry is None:
        return tuple(memory)
    old = next((item for item in memory if item["id"] == entry["id"]), None)
    if old and all(old.get(key) == value for key, value in entry.items() if key != "location"):
        return tuple(memory)
    result = tuple(item for item in memory if item["id"] != entry["id"])
    # A removed tag must not remain visible when rereading the earlier post.
    if entry["kind"] == "marcacao":
        result = tuple(dict(item, paragraphs=tuple(p for p in item["paragraphs"] if p != "@Vanessa"))
                       if item["id"] == "publicacao_feka" else item for item in result)
    result += (entry,)
    if entry["kind"] in ("devolucao", "devolucao_v"):
        receipt_id = entry["kind"] + "_receipt"
        receipt = dict(entry, id=receipt_id, kind=receipt_id, section="bank",
                       title="Devolução enviada", subtitle=entry["title"], messages=(),
                       paragraphs=("Recebimento confirmado na conversa.",), image=None)
        if entry["kind"] == "devolucao":
            receipt["amount"] = -6000
        result = tuple(item for item in result if item["id"] != receipt_id) + (receipt,)
    return result


def entries(memory, section, favorites=(), only_favorites=False):
    return tuple(item for item in reversed(memory) if item["section"] == section
                 and (not only_favorites or item["id"] in favorites))


SOCIAL_KINDS = frozenset(("publicacao", "restaurante", "comparacao", "publicado", "publicado_depois"))
SAVED_PHOTO_KINDS = frozenset(("foto", "foto_hesita", "enquadramento", "publicado", "publicado_depois"))


def app_for(entry):
    """Presentation routing also works for older saves without rewriting them."""
    return "social" if entry["kind"] in SOCIAL_KINDS else entry["section"]


def app_entries(memory, app, favorites=(), only_favorites=False, query=""):
    import unicodedata
    def fold(text):
        return ''.join(c for c in unicodedata.normalize('NFD', text.casefold())
                       if unicodedata.category(c) != 'Mn')
    needle = fold(query.strip())
    result = []
    for item in reversed(memory):
        matches_app = (item["kind"] in SOCIAL_KINDS if app == "social" else
                       item["kind"] in SAVED_PHOTO_KINDS if app == "photos" else
                       item["section"] == app)
        if not matches_app or (only_favorites and item["id"] not in favorites):
            continue
        text = ' '.join((item["title"], item["subtitle"]) + tuple(item["paragraphs"]))
        if not needle or needle in fold(text):
            result.append(item)
    return tuple(result)


def fold(text):
    import unicodedata
    return ''.join(c for c in unicodedata.normalize('NFD', text.casefold())
                   if unicodedata.category(c) != 'Mn')


def message_rows(thread):
    """Group contiguous messages without fabricating delivery or read receipts."""
    messages = thread.get("messages", ())
    times = thread.get("message_times", ())
    assets = thread.get("message_assets", ())
    def at(index):
        return times[index] if index < len(times) else -1
    def boundary(index):
        return (index == 0 or (at(index) < 0) != (at(index - 1) < 0)
                or at(index) // 1440 != at(index - 1) // 1440
                or at(index) - at(index - 1) >= 30)
    return tuple(dict(body=body, sent=sent, at=at(index), separator=boundary(index),
                      tail=index == len(messages) - 1 or messages[index + 1][0] != sent or boundary(index + 1),
                      asset=assets[index] if index < len(assets) else None)
                 for index, (sent, body) in enumerate(messages))


def threads(memory, notifications):
    """One conversation per contact; merge overlapping authored chat inserts.

    Story notifications point at their archive entry, not a second message.
    Legacy saves retain their original order and unknown dates stay unknown.
    """
    notice_order = {notice["id"]: i for i, notice in enumerate(notifications)}
    events = [(item.get("at", -1), notice_order.get(item.get("after_message"), -1) + .5, i, item) for i, item in enumerate(memory)
              if item["section"] == "messages"]
    for i, notice in enumerate(notifications):
        if notice["id"].startswith("story_"):
            continue
        events.append((notice["at"], i, len(memory) + i,
                       dict(title=notice["sender"], messages=((False, notice["body"]),),
                            subtitle="", paragraphs=(), id=notice["id"])))
    grouped = {}
    for at, _, _, item in sorted(events, key=lambda row: row[:3]):
        contact = item["title"]
        thread = grouped.setdefault(contact, dict(id="contact_" + contact, kind="thread",
            section="messages", title=contact, subtitle="", location="", messages=(),
            message_times=(), message_assets=(), paragraphs=(), image=None, at=at, unread=False))
        old, new = thread["messages"], tuple(item["messages"])
        overlap = 0
        # Authored inserts may repeat an exchange. Independent delivered events
        # with the same words are still distinct messages, including short replies.
        if item.get("kind") not in (None, "chapter_message"):
            for size in range(1, min(len(old), len(new)) + 1):
                if old[-size:] == new[:size]: overlap = size
        thread["messages"] += new[overlap:]
        thread["message_times"] += (at,) * (len(new) - overlap)
        thread["message_assets"] += tuple(item.get("image") if i == 0 else None for i in range(len(new) - overlap))
        thread.update(at=at, subtitle=item.get("subtitle", ""))
        if item.get("image"): thread["image"] = item["image"]
        thread["paragraphs"] = item.get("paragraphs", ())
    for thread in grouped.values():
        thread["unread"] = any(n["sender"] == thread["title"] and not n["read"] for n in notifications)
    return tuple(sorted(grouped.values(), key=lambda t: t["at"], reverse=True))


def agreements(memory):
    kinds = {item["kind"] for item in memory}
    result = []
    if "emprestimo_pix" in kinds:
        result.append(("Joãozão", "R$ 60,00", "Devolvido" if "devolucao" in kinds else "Devolver amanhã até 12h", "devolucao" in kinds))
    if "ajuda_v" in kinds:
        result.append(("Vanessa", "Ajuda no jantar", "Devolvido" if "devolucao_v" in kinds else "Devolver na sexta-feira", "devolucao_v" in kinds))
    return tuple(result)


def brl(cents):
    return "R$ {:,.2f}".format(cents / 100.0).replace(",", "_").replace(".", ",").replace("_", ".")
