testsuite aa_phone_calculator_test:
    setup:
        $ _test.timeout = 10.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = .02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/calculator-ios27" + ("-small" if renpy.variant("small") else "")
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        keysym "p"
        click "Calculadora"
    teardown:
        exit

    testcase basic_history_keyboard:
        pause .4
        screenshot "basic.png"
        click "6"
        click "0"
        click "÷"
        click "8"
        click "="
        assert eval aa_phone_preferences.calculator[0] == "7.5"
        screenshot "result.png"
        click "="
        assert eval aa_phone_preferences.calculator[0] == "0.9375"
        click "Histórico de cálculos"
        screenshot "history.png"
        click "Recuperar 60÷8"
        assert eval aa_phone_preferences.calculator[0] == "7.5"
        keysym "K_DELETE"
        keysym "2"
        keysym "+"
        keysym "3"
        keysym "*"
        keysym "4"
        keysym "K_RETURN"
        assert eval aa_phone_preferences.calculator[0] == "14"
        click "Início"
        click "Calculadora"
        assert eval aa_phone_preferences.calculator[0] == "14"
        run QuickSave()
        keysym "K_DELETE"
        run QuickLoad(confirm=False)
        assert eval aa_phone_preferences.calculator[0] == "14"
        assert eval len(aa_phone_preferences.calculator_history) == 3
        keysym "p"
        assert screen "aa_phone_hub"
        keysym "K_ESCAPE"
        assert eval renpy.get_screen("aa_phone_hub").scope["page"] == "home"

    testcase modes_and_conversions:
        click "Modo da calculadora"
        pause .3
        screenshot "modes.png"
        click "Científica"
        click "9"
        click "√"
        click "="
        assert eval aa_phone_preferences.calculator[0] == "3"
        screenshot "scientific.png"
        click "Modo da calculadora"
        click "Converter"
        keysym "K_DELETE"
        keysym "1"
        keysym "0"
        keysym "0"
        keysym "0"
        screenshot "convert.png"
        click "Comprimento"
        click "Temperatura"
        assert eval renpy.get_screen("aa_phone_hub").scope["calc_source"] == "°C"
        keysym "K_DELETE"
        click "3"
        click "2"
        click "Modo da calculadora"
        click "Notas Matemáticas"
        type "(2+3)*4"
        click "Calcular e guardar"
        assert eval aa_phone_preferences.calculator_notes[-1][1] == "20"
        pause .2
        screenshot "notes.png"
        keysym "K_ESCAPE"
        assert eval renpy.get_screen("aa_phone_hub").scope["calc_panel"] is None

    testcase long_display_error_and_clear:
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        keysym "9"
        screenshot "long-number.png"
        keysym "K_DELETE"
        click "1"
        click "÷"
        click "0"
        click "="
        assert eval aa_phone_preferences.calculator[0] == "Erro"
        screenshot "error.png"
        click "2"
        click "+"
        click "3"
        click "="
        assert eval aa_phone_preferences.calculator[0] == "5"
        click "Histórico de cálculos"
        click "Editar"
        click "Limpar"
        click "Limpar histórico"
        assert eval not aa_phone_preferences.calculator_history
