# Verificação focal da passagem mesa conjunta -> intervalo -> sobremesa.
label qa_shared_table_setup:
    $ aa_state = aa_new_state()
    $ aa_state.update(route="juntas", trust=2, table_history="admitiu")
    jump i00

testsuite aa_shared_table:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.1
        $ _test.screenshot_directory = 'C:/Users/fabio/Projects/amor_azedo/output/qa/mesa-conjunta'
    teardown:
        exit
    testcase intervalo:
        run Start("qa_shared_table_setup")
        advance until "O garçom recolheu os quatro pratos."
        assert eval aa_last_art == "cg14_intervalo_saida"
        advance until screen "choice"
        assert eval aa_last_art == "cg14_intervalo_papel"
        screenshot "01_intervalo.png"
        click "Ficar com Vanessa."
        advance until screen "choice"
        assert eval aa_last_art == "cg14_intervalo_guardado"
        click "Confirmar a ajuda e combinar depois da aula."
        advance until "O garçom trouxe o pudim"
        assert eval aa_last_art == "cg14_pudim_dois"
        screenshot "02_pudim_dois.png"
        advance until "Yasmin voltou da passagem"
        assert eval aa_last_art == "cg14_pudim_quatro"
        assert eval aa_table_party == 4
        screenshot "03_pudim_quatro.png"
        advance until screen "choice"
        assert not screen "aa_phone_view"
