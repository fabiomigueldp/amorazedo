testsuite aa_history_copy:
    setup:
        $ _test.timeout = 12.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/history"
    teardown:
        exit
    testcase copiar:
        run Start()
        advance until screen "choice"
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == "a03"
        assert eval aa_history_export().count('Feka · pensamento: Vanessa deixou a bolsa na minha cama e abriu o zíper.') == 1
        assert eval "Escolha: Deixar o celular e separar a roupa." in aa_history_export()
        assert eval "[a00" in aa_history_export() and "[a03" in aa_history_export()
        run ShowMenu("history")
        assert screen "history"
        pause 0.3
        screenshot "botao.png"
        click "Copiar histórico"
        python:
            copied = __import__('pygame.scrap', fromlist=['get']).get(__import__('pygame').SCRAP_TEXT).decode("utf-8").rstrip("\x00")
        assert eval copied.replace("\r\n", "\n") == aa_history_export()

    testcase fala_atual_save_e_repeticao:
        run Start()
        pause .5
        advance until eval _history_list and _history_list[-1].what.startswith('Ela entrou no banheiro.')
        assert eval aa_history_export().count('Feka · pensamento: Ela entrou no banheiro. A torneira fez barulho antes de sair água.') == 1 timeout 3.0
        run QuickSave()
        advance until screen 'choice'
        run QuickLoad(confirm=False)
        assert eval aa_history_export().count('Feka · pensamento: Ela entrou no banheiro. A torneira fez barulho antes de sair água.') == 1 timeout 3.0
        advance until screen 'choice'
        assert eval aa_history_export().count('Feka · pensamento: Ela entrou no banheiro. A torneira fez barulho antes de sair água.') == 1
        python:
            old_a = ('a00', 'Quarto', 'Feka', 'Uma fala.')
            old_b = ('a00', 'Quarto', 'Vanessa', 'Outra fala.')
            legacy_result = aa_trace_legacy([old_a, old_a, old_b, old_b])
            new_a = old_a + (2,)
            repeated_result = aa_trace_legacy([new_a, new_a])
        assert eval legacy_result == [old_a, old_b]
        assert eval repeated_result == [new_a, new_a]
