# Gerado por tools/build_meal_tests.py.
label qa_meal_separadas_0_0:
    $ aa_state = aa_new_state()
    $ aa_state.update(route='separadas', seat_swapped=False, photo_asked=False)
    jump i00

label qa_meal_separadas_1_0:
    $ aa_state = aa_new_state()
    $ aa_state.update(route='separadas', seat_swapped=True, photo_asked=False)
    jump i00

label qa_meal_varanda_0_0:
    $ aa_state = aa_new_state()
    $ aa_state.update(route='varanda', seat_swapped=False, photo_asked=False)
    jump i00

label qa_meal_juntas_0_0:
    $ aa_state = aa_new_state()
    $ aa_state.update(route='juntas', seat_swapped=False, photo_asked=False)
    jump i00

label qa_meal_juntas_0_1:
    $ aa_state = aa_new_state()
    $ aa_state.update(route='juntas', seat_swapped=False, photo_asked=True)
    jump i00

label qa_meal_service:
    $ aa_state = aa_new_state()
    $ aa_state.update(route="juntas", stopped_joke=True)
    jump c02

testsuite aa_meal:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = 'C:/Users/fabio/Projects/amor_azedo/output/qa/refeicao'
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu" timeout 10.0
    teardown:
        exit

    testcase separadas_0_0:
        run Start("qa_meal_separadas_0_0")
        assert screen "say" timeout 10.0
        assert eval aa_last_art == "cg7_mesa_escuta_antes"
        advance until "Nossos pratos chegaram."
        assert eval aa_last_art == "cg8_servir_antes"
        assert eval aa_audio_last_event == "QMEAL_SERVICE"
        screenshot "separadas_0_0_servico.png"
        advance until "O garçom se afastou."
        assert eval aa_last_art == "cg7_mesa_pratos_antes"
        assert eval aa_table_party == 2
        assert not screen "aa_phone_view"
        screenshot "separadas_0_0_comendo.png"
        advance until "Quando paramos de comer,"
        assert eval aa_last_art == 'cg7_mesa_pratos_antes'
        advance
        assert "Ele recolheu" timeout 5.0
        assert eval aa_audio_last_event == 'QMEAL_CLEAR_TWO'
        assert eval aa_last_art == 'cg2_papel'
        screenshot "separadas_0_0_intervalo.png"
        advance until screen "choice"

    testcase separadas_1_0:
        run Start("qa_meal_separadas_1_0")
        assert screen "say" timeout 10.0
        assert eval aa_last_art == "cg7_mesa_escuta_troca"
        advance until "Nossos pratos chegaram."
        assert eval aa_last_art == "cg8_servir_troca"
        assert eval aa_audio_last_event == "QMEAL_SERVICE"
        screenshot "separadas_1_0_servico.png"
        advance until "O garçom se afastou."
        assert eval aa_last_art == "cg7_mesa_pratos_troca"
        assert eval aa_table_party == 2
        assert not screen "aa_phone_view"
        screenshot "separadas_1_0_comendo.png"
        advance until "Quando paramos de comer,"
        assert eval aa_last_art == 'cg7_mesa_pratos_troca'
        advance
        assert "Ele recolheu" timeout 5.0
        assert eval aa_audio_last_event == 'QMEAL_CLEAR_TWO'
        assert eval aa_last_art == 'cg2_papel'
        screenshot "separadas_1_0_intervalo.png"
        advance until screen "choice"

    testcase varanda_0_0:
        run Start("qa_meal_varanda_0_0")
        assert screen "say" timeout 10.0
        assert eval aa_last_art == "cg7_mesa_escuta_troca"
        advance until "Nossos pratos chegaram."
        assert eval aa_last_art == "cg8_servir_troca"
        assert eval aa_audio_last_event == "QMEAL_SERVICE"
        screenshot "varanda_0_0_servico.png"
        advance until "O garçom se afastou."
        assert eval aa_last_art == "cg7_mesa_pratos_troca"
        assert eval aa_table_party == 2
        assert not screen "aa_phone_view"
        screenshot "varanda_0_0_comendo.png"
        advance until "Quando paramos de comer,"
        assert eval aa_last_art == 'cg7_mesa_pratos_troca'
        advance
        assert "Ele recolheu" timeout 5.0
        assert eval aa_audio_last_event == 'QMEAL_CLEAR_TWO'
        assert eval aa_last_art == 'cg2_papel'
        screenshot "varanda_0_0_intervalo.png"
        advance until screen "choice"

    testcase juntas_0_0:
        run Start("qa_meal_juntas_0_0")
        assert screen "say" timeout 10.0
        assert eval aa_last_art == "cg2_pratos"
        advance until "Os quatro voltamos a comer."
        assert eval aa_last_art == "cg8_comer_quatro"
        assert eval aa_table_party == 4
        assert not screen "aa_phone_view"
        screenshot "juntas_0_0_comendo.png"
        advance until "Quando paramos de comer,"
        assert eval aa_last_art == 'cg8_comer_quatro'
        advance
        assert "Ele recolheu" timeout 5.0
        assert eval aa_audio_last_event == 'Q041'
        assert eval aa_last_art == 'cg4_intervalo'
        screenshot "juntas_0_0_intervalo.png"
        advance until screen "choice"

    testcase juntas_0_1:
        run Start("qa_meal_juntas_0_1")
        assert screen "say" timeout 10.0
        assert eval aa_last_art == "cg2_pratos"
        advance until "Os quatro voltamos a comer."
        assert eval aa_last_art == "cg8_comer_quatro"
        assert eval aa_table_party == 4
        assert not screen "aa_phone_view"
        screenshot "juntas_0_1_comendo.png"
        advance until "Quando paramos de comer,"
        assert eval aa_last_art == 'cg8_comer_quatro'
        advance
        assert "Ele recolheu" timeout 5.0
        assert eval aa_audio_last_event == 'Q041'
        assert eval aa_last_art == 'cg4_intervalo'
        screenshot "juntas_0_1_intervalo.png"
        advance until screen "choice"

    testcase servico_quatro:
        run Start("qa_meal_service")
        assert screen "say" timeout 10.0
        assert eval aa_last_art == "cg2_quatro"
        advance until "O garçom pediu licença."
        assert eval aa_last_art == "cg8_servir_quatro"
        assert eval aa_audio_last_event == "Q030"
        screenshot "quatro_servico.png"
        advance until "O garçom desejou bom apetite"
        assert eval aa_last_art == "cg2_pratos"
        advance until screen "choice"
        assert eval aa_last_art == "cg2_pratos"
