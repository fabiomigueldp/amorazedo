# Encenação: movimento breve de câmera, nunca balanço automático dos corpos.
default persistent.aa_motion = True
default aa_stage_action = ""
default aa_dialogue_side = False
default aa_table_party = 0

transform aa_camera(z=1.0, fx=0.5, fy=0.5):
    anchor (fx, fy)
    pos (fx, fy)
    subpixel True
    zoom max(1.0, z - 0.025)
    ease (1.4 if persistent.aa_motion else 0.0) zoom z

transform aa_phone_enter:
    alpha 0.0
    yoffset 12
    ease (0.25 if persistent.aa_motion else 0.0) alpha 1.0 yoffset 0

screen aa_phone_note(kind):
    # Compatibilidade com apresentações antigas; conteúdo mantido em um só lugar.
    use aa_phone_view(kind)

screen aa_motion_control():
    key "m" action ToggleField(persistent, "aa_motion")

init python:
    config.overlay_screens.append("aa_motion_control")
