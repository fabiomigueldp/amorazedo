# Encenação: movimento breve de câmera, nunca balanço automático dos corpos.
default persistent.aa_motion = True
default aa_stage_action = ""
default aa_dialogue_side = False

transform aa_camera(z=1.0, fx=0.5, fy=0.5):
    anchor (fx, fy)
    pos (fx, fy)
    subpixel True
    zoom max(1.0, z - 0.025)
    ease (1.4 if persistent.aa_motion else 0.0) zoom z

transform aa_phone_enter:
    alpha 0.0
    yoffset 12
    ease (0.25 if persistent.aa_motion else 0.0) alpha 1.0 yoffset 0

init python:
    aa_phone_text = {
        "conversa": ("Yasmin · conversa antiga", "Feka, não me espera na saída de novo. Eu não combinei nada com você.", "Eu tava só passando."),
        "restaurante": ("Yasmin · publicação recente", "O mesmo restaurante da reserva.", "Ele ainda pode cancelar."),
        "rascunho": ("Vanessa · rascunho", "Sinto muito.", "Mensagem não enviada."),
        "materia": ("Vanessa · no dia seguinte", "A matéria da aula está aqui.", "Obrigada."),
        "devolucao": ("Joãozão · no dia seguinte", "Devolvi o dinheiro.", "Sem outra conversa."),
        "audio": ("Grupo · mensagem de voz", "Tinham me desrespeitado.", "Ele ouve a própria gravação."),
        "enquadramento": ("Publicação · rascunho", "Uma noite ótima.", "A cadeira vazia fica fora da foto."),
        "marcacao": ("Vanessa · mensagem", "Não me marca, por favor.", "A publicação continua no ar."),
        "comparacao": ("Uma foto antiga de Feka", "Yasmin havia curtido aquela foto.", "Ele amplia para conferir a roupa."),
    }

screen aa_phone_view(kind):
    zorder 8
    frame:
        at aa_phone_enter
        xpos 480
        ypos 64
        xsize 330
        padding (22, 22)
        background Solid("#171b24f5")
        vbox:
            spacing 18
            if kind == "publicacao":
                text "Yasmin · publicação" size 20 color "#e9e7e2"
                add "cg2_post_jaleco" xysize (286, 161)
                text "Medicina. Os dois, juntos." size 19 color "#c6c7cc"
            else:
                $ heading, incoming, outgoing = aa_phone_text[kind]
                text heading size 19 color "#cbc6cd"
                frame:
                    background Solid("#303640")
                    padding (12, 12)
                    text incoming size 23 color "#f2eee8"
                text outgoing size 20 color "#d0d9a9"

screen aa_motion_control():
    key "m" action ToggleField(persistent, "aa_motion")

init python:
    config.overlay_screens.append("aa_motion_control")
