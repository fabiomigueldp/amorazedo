"""Percurso sem interface: mesmo estado, relógio e pagamentos do roteiro.

Usado pelo estúdio e pelas verificações. Ações opcionais do celular devem ser
fornecidas separadamente; este módulo não inventa uma devolução pelo jogador.
"""
import story_model as story
import finance_model as finance


def event(state, world, name):
    if name == 'settle_dinner':
        bill = state.get('bill')
        if bill == 'cena' and state.get('debt') and not state.get('v_gone'):
            return world
        name = 'dinner_full' if bill == 'emprestimo' else 'dinner_vanessa' if bill == 'vanessa' else 'dinner_split'
    if name == 'return_home':
        if world['balance'] < 1800:
            return world
        name = 'ride_return'
    return finance.transact(world, name)


def line_effects(state, world, line):
    if not story.matches(state, line.get('when', {})):
        return state, world
    for at in [line.get('at')] + list(line.get('phase_at', {}).values()):
        if at is not None:
            world = finance.advance(world, at)
    if line.get('finance'):
        world = event(state, world, line['finance'])
    if line.get('set'):
        state = dict(state, **line['set'])
    return story.financial_state(state, world), world


def begin(state, world, node):
    state = story.enter(state, node)
    if node.get('at') is not None:
        world = finance.advance(world, node['at'])
    if node.get('finance'):
        world = event(state, world, node['finance'])
    state = story.financial_state(state, world)
    for line in node['lines']:
        state, world = line_effects(state, world, line)
    return state, world


def act(state, world, node, index):
    state = story.choose(story.financial_state(state, world), node, index)
    choice = node['choices'][index]
    if choice.get('repay'):
        world = finance.repay(world, choice['repay'], in_person=choice['repay'] in node.get('present', ()))
    state = story.financial_state(state, world)
    for line in choice.get('response', []):
        state, world = line_effects(state, world, line)
    return state, world
