"""Local media catalogue and transport helpers, independent of Ren'Py."""
import math
import re
import time


def safe_path(value):
    return (isinstance(value, str) and value.startswith(("audio/", "gui/"))
            and "\\" not in value and not any(p in ("", ".", "..") for p in value.split("/")))


def catalogue(data):
    if data.get("version") != 1:
        raise ValueError("Unsupported phone media catalogue version")
    result = {}
    for raw in data["items"]:
        item = dict(raw)
        ident = item["id"]
        if not re.fullmatch(r"[a-z0-9_]+", ident) or ident in result:
            raise ValueError("Invalid or duplicate media id: " + ident)
        if item["kind"] not in ("podcast", "music") or not item["title"].strip():
            raise ValueError("Invalid media metadata: " + ident)
        duration = float(item["duration"])
        gain = float(item.get("gain", 1.0))
        if not math.isfinite(duration) or duration <= 0 or not 0 < gain <= 1:
            raise ValueError("Invalid duration or gain: " + ident)
        sources = {float(rate): path for rate, path in item["sources"].items()}
        if 1.0 not in sources or any(not 0.5 <= rate <= 3.0 or not safe_path(path)
                                      for rate, path in sources.items()):
            raise ValueError("Invalid media sources: " + ident)
        if not safe_path(item["art"]):
            raise ValueError("Invalid media artwork: " + ident)
        item.update(duration=duration, gain=gain, sources=sources)
        result[ident] = item
    return result


def visible(item, unlocked):
    return not item.get("unlock") or item["unlock"] in unlocked


def clamp_position(value, duration):
    value = float(value)
    return min(duration, max(0.0, value)) if math.isfinite(value) else 0.0


def timestamp(seconds):
    value = max(0, int(round(seconds)))
    minutes, seconds = divmod(value, 60)
    hours, minutes = divmod(minutes, 60)
    return "%d:%02d:%02d" % (hours, minutes, seconds) if hours else "%d:%02d" % (minutes, seconds)


def playback_source(item, rate, position):
    rate = rate if rate in item["sources"] else 1.0
    return "<from %.3f>%s" % (clamp_position(position, item["duration"]) / rate, item["sources"][rate])


class Transport:
    """Decoder observations are transient and never serialized or rolled back."""
    def __init__(self):
        self.reset()

    def reset(self):
        self.owner = None
        self.source = None
        self.started = False
        self.issued = 0.0
        self.suspended = False


transport = Transport()
