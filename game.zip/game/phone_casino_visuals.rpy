# Animation presents an already resolved result. No random calls or transactions
# happen in render(), including when prediction or a screenshot renders a frame.
init python:
    import math as aa_casino_math
    import time as aa_casino_time

    class AACasinoVisual(renpy.Displayable):
        def __init__(self, game, data, width, height, started=None, duration=0.0, **properties):
            super(AACasinoVisual, self).__init__(**properties)
            self.game, self.data = game, data
            self.width, self.height = width, height
            self.started, self.duration = started, duration
            names = ("wheel",) if game == "roulette" else tuple(aa_cm.SLOT_PAY) if game == "slots" else tuple("die-" + str(n) for n in range(1, 7))
            self.art = {name: Image(aa_casino_art(name)) for name in names}

        def render(self, width, height, st, at):
            elapsed = max(0.0, aa_casino_time.monotonic() - self.started) if self.started is not None else self.duration
            progress = min(1.0, elapsed / self.duration) if self.duration else 1.0
            if progress < 1.0:
                renpy.redraw(self, 1.0 / 60)
            result = renpy.Render(self.width, self.height)
            if self.game == "roulette":
                size = min(self.width, self.height)
                number = self.data.get("number", 0)
                target = (-aa_cm.WHEEL.index(number) * 360.0 / 37) % 360
                ease = 1 - (1 - progress) ** 3
                angle = (720 + target) * ease if self.duration else target
                rotor = renpy.render(Transform(self.art["wheel"], xysize=(size, size), rotate=angle), size, size, st, at)
                result.blit(rotor, ((self.width - rotor.width) // 2, (self.height - rotor.height) // 2))
                theta = aa_casino_math.radians(-90 - 1080 * (1 - ease))
                radius = size * (.346 + .106 * (1 - ease))
                x = int(self.width / 2 + radius * aa_casino_math.cos(theta))
                y = int(self.height / 2 + radius * aa_casino_math.sin(theta))
                canvas = result.canvas()
                canvas.circle("#19121c80", (x + 1, y + 2), max(3, size // 38))
                canvas.circle("#fff1d9", (x, y), max(3, size // 42))
            elif self.game == "slots":
                names = tuple(aa_cm.SLOT_PAY)
                cell = (self.width - 12) // 3
                symbols = self.data.get("symbols", ("cherry", "lemon", "seven"))
                for column, name in enumerate(symbols):
                    stop = .72 + column * .14
                    t = min(1.0, progress / stop)
                    travel = (30 + names.index(name)) * (1 - (1 - t) ** 3) if self.duration else names.index(name)
                    reel = renpy.Render(cell, self.height)
                    reel.blit(renpy.render(aa_phone_round("casino-card", 12), cell, self.height, st, at), (0, 0))
                    for step in (-1, 0, 1):
                        symbol = names[(int(travel) + step) % len(names)]
                        art_size = min(cell - 12, self.height - 12)
                        art = renpy.render(Transform(self.art[symbol], xysize=(art_size, art_size)), cell, self.height, st, at)
                        offset = (step - (travel % 1)) * self.height
                        reel.blit(art, ((cell - art_size) // 2, int((self.height - art_size) / 2 + offset)))
                    result.blit(reel.subsurface((0, 0, cell, self.height)), (column * (cell + 6), 0))
            else:
                size = min(68, (self.width - 20) // 2, self.height - 14)
                values = self.data.get("values", (3, 4))
                for index, final in enumerate(values):
                    face = (int(progress * 18) + index * 3) % 6 + 1 if progress < .84 else final
                    angle = (1 - progress) ** 2 * 230 * (-1 if index else 1)
                    art = renpy.render(Transform(self.art["die-" + str(face)], xysize=(size, size), rotate=angle), size, size, st, at)
                    cx = self.width / 2 + (size / 2 + 10) * (1 if index else -1)
                    cy = self.height / 2 - 9 * abs(aa_casino_math.sin(progress * 4 * aa_casino_math.pi)) * (1 - progress)
                    result.blit(art, (int(cx - art.width / 2), int(cy - art.height / 2)))
            return result.subsurface((0, 0, self.width, self.height))

        def visit(self):
            return list(self.art.values())
