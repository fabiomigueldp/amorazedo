# Registro da partida em variáveis de store: acompanha save, load e rollback.
default aa_trace = None

init python:
    def aa_trace_plain(text):
        return renpy.filter_text_tags(str(text or ""), allow=set())

    def aa_trace_seed():
        global aa_trace
        if aa_trace is None:
            aa_trace = [("", "Histórico anterior disponível", aa_trace_plain(h.who) or "Feka · pensamento", aa_trace_plain(h.what), 2) for h in _history_list if h.kind != 'current']

    def aa_trace_legacy(rows):
        # Only repair a legacy prefix that exhibits the systematic double capture.
        # New rows carry a version; genuinely repeated new dialogue is preserved.
        legacy = []
        for row in rows:
            if len(row) != 4: break
            legacy.append(row)
        groups = []
        for row in legacy:
            if groups and groups[-1][0] == row:
                groups[-1].append(row)
            else:
                groups.append([row])
        dialogue = [g for g in groups if g[0][2] != 'Escolha']
        if len(dialogue) >= 2 and all(len(g) == 2 for g in dialogue[:-1]) and len(dialogue[-1]) in (1, 2):
            return [g[0] for g in groups] + list(rows[len(legacy):])
        return list(rows)

    def aa_trace_capture(h):
        global aa_trace
        if h.kind == 'current':
            return
        aa_trace_seed()
        aa_trace = aa_trace + [(aa_node, aa_location, aa_trace_plain(h.who) or "Feka · pensamento", aa_trace_plain(h.what), 2)]

    config.history_callbacks.append(aa_trace_capture)

    def aa_history_export():
        rows = aa_trace_legacy(aa_trace) if aa_trace is not None else [("", "Histórico anterior disponível", aa_trace_plain(h.who) or "Feka · pensamento", aa_trace_plain(h.what), 2) for h in _history_list if h.kind != 'current']
        if _history_list and _history_list[-1].kind == 'current':
            h = _history_list[-1]
            current = (aa_node, aa_location, aa_trace_plain(h.who) or "Feka · pensamento", aa_trace_plain(h.what), 2)
            if not rows or len(rows[-1]) != 4 or rows[-1] != current[:4]:
                rows.append(current)
        lines = ["Amor Azedo 2 — Histórico da partida", "Versão: " + str(config.version),
                 "Ponto atual: " + aa_node + " · " + aa_location,
                 "Registro acompanha as escolhas atuais, inclusive após voltar ou carregar.",
                 "Em saves anteriores ao recurso, o trecho antigo se limita ao histórico disponível.", ""]
        previous = None
        for row in rows:
            node, place, who, what = row[:4]
            section = (node, place)
            if section != previous:
                lines += ["", "[" + (node + " · " if node else "") + place + "]"]
                previous = section
            lines.append(who + ": " + what)
        lines += ["", "Estado atual (diagnóstico):", json.dumps(aa_state, ensure_ascii=False, sort_keys=True, indent=2)]
        return "\n".join(lines)

    def aa_copy_history():
        try:
            CopyToClipboard(aa_history_export())()
        except Exception:
            renpy.notify("Não foi possível acessar a área de transferência neste dispositivo.")
        else:
            renpy.notify("Histórico e escolhas copiados.")

define aa_history_choice = Character("Escolha")
