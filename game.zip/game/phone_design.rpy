# Shared visual language for the interactive handset and narrative inserts.
# Glass uses a diffused wallpaper sample + translucent rim, with an opaque fallback.
# All placement stays in the game's 1280x720 logical canvas. The handset silhouette
# follows the measured proportions of the project’s supplied 3D master model.
init -5 python:
    import functools
    import json
    AA_PHONE_ASSETS = "gui/phone/modern/"
    with renpy.open_file(AA_PHONE_ASSETS + "device.json") as phone_contract:
        AA_PHONE_DEVICE = json.load(phone_contract)
    AA_PHONE_BODY_ASPECT = float(AA_PHONE_DEVICE["canvas"][1]) / AA_PHONE_DEVICE["canvas"][0]
    AA_PHONE_BODY_HEIGHT = 684
    AA_PHONE_BODY_WIDTH = int(round(AA_PHONE_BODY_HEIGHT / AA_PHONE_BODY_ASPECT))
    # POV plates contain only the hands/environment. Both the story insert and
    # the interactive hub composite the exact same device into this opening.
    AA_PHONE_POV_HEIGHT = 714
    AA_PHONE_POV_POSITION = (674, 0)
    AA_PHONE_APPS = {
        "home": ("Início", "home"), "messages": ("Mensagens", "chat"),
        "bank": ("Banco", "bank"), "photos": ("Fotos", "photo"),
        "social": ("Momentos", "social"), "notes": ("Notas", "note"),
        "settings": ("Ajustes", "settings"),
        "facetime": ("FaceTime", "phone"), "calendar": ("Calendário", "note"),
        "camera": ("Câmera", "camera"), "mail": ("Mail", "note"),
        "reminders": ("Lembretes", "check"), "clock": ("Relógio", "phone"),
        "tv": ("TV", "photo"), "podcasts": ("Podcasts", "phone"),
        "appstore": ("App Store", "home"), "books": ("Livros", "note"),
        "maps": ("Mapas", "social"), "health": ("Saúde", "heart"),
        "wallet": ("Carteira", "bank"), "files": ("Arquivos", "note"),
        "contacts": ("Contatos", "phone"), "calculator": ("Calculadora", "bank"),
        "recorder": ("Gravador", "phone"), "house": ("Casa", "home"),
        "shortcuts": ("Atalhos", "arrow"), "phone": ("Telefone", "phone"),
        "safari": ("Safari", "social"), "music": ("Música", "phone"),
        "search": ("Buscar", "search"),
        "casino": ("Mesa", "star"),
    }
    AA_PHONE_GRID = (
        ("facetime", "calendar", "photos", "camera"),
        ("mail", "notes", "reminders", "clock"),
        ("tv", "podcasts", "appstore", "books"),
        ("maps", "health", "wallet", "settings"),
        ("files", "contacts", "calculator", "recorder"),
        ("bank", "social", "house", "shortcuts"),
    )
    AA_PHONE_DOCK = ("phone", "safari", "messages", "music")

    def aa_phone_app_art(app, size=54):
        if app in ("bank", "social", "casino"):
            return Transform(aa_phone_asset("app-" + app), xysize=(size, size))
        suffix = ".png" if app in ("settings", "appstore") else ".jpg"
        return AlphaMask(Transform("gui/phone/stock/" + app + suffix, xysize=(size, size)),
                         Transform(aa_phone_asset("mask"), xysize=(size, size)))

    def aa_phone_asset(name):
        if name.startswith("wallpaper-"):
            suffix = ".jpg"
        elif name == "shell":
            suffix = ".png"
        else:
            suffix = ".svg"
        return AA_PHONE_ASSETS + name + suffix

    @functools.lru_cache(maxsize=64)
    def aa_phone_round(name="surface", radius=24):
        return AAPhoneRound(name, radius)

    def aa_phone_pref(name, fallback):
        return getattr(store.aa_phone_preferences, name, fallback)

    def aa_phone_size(size):
        return size + (3 if renpy.variant("small") else 0) + aa_phone_pref("text_size", 0)

    def aa_phone_geometry():
        # Text and controls scale for the small variant; the hardware never widens.
        return 1256 - AA_PHONE_BODY_WIDTH, AA_PHONE_BODY_WIDTH

    def aa_phone_body_size(height=652):
        return int(round(float(height) / AA_PHONE_BODY_ASPECT)), height

    def aa_phone_screen_geometry(width, height):
        x, y, w, h = AA_PHONE_DEVICE["screen"]
        return int(round(x * width)), int(round(y * height)), int(round(w * width)), int(round(h * height))

    def aa_phone_screen_mask(width, height):
        return Transform(aa_phone_asset("screen-mask"), xysize=(width, height))

    def aa_phone_shell(width, height):
        # RGBA generated from the actual geometry, including buttons and camera.
        # Draw over the display; never nine-slice or apply a guessed silhouette.
        return Transform(aa_phone_asset("shell"), xysize=(width, height))

    def aa_phone_date():
        from datetime import timedelta
        dt = aa_fm.EPOCH + timedelta(minutes=aa_world["now"])
        days = ("Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo")
        months = ("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")
        return "%s, %s de %s" % (days[dt.weekday()], dt.day, months[dt.month - 1])

    def aa_phone_contact(name):
        key = {"Vanessa": "v", "Yasmin": "y", "Joãozão": "j", "Pai": "p"}.get(name, "g")
        return aa_phone_asset("avatar-" + key)

    @functools.lru_cache(maxsize=64)
    def aa_phone_image_dimensions(asset):
        return renpy.image_size(renpy.get_registered_image(asset) or Image(asset))

    def aa_phone_cover(asset, width, height):
        # Crop before resizing so supplied photos and wallpapers retain their proportions.
        image = renpy.get_registered_image(asset) or Image(asset)
        source_w, source_h = aa_phone_image_dimensions(asset)
        ratio = float(width) / height
        crop_w, crop_h = min(source_w, source_h * ratio), min(source_h, source_w / ratio)
        return Transform(image, crop=(int((source_w-crop_w)/2), int((source_h-crop_h)/2), int(crop_w), int(crop_h)), xysize=(width, height))

    def aa_phone_wallpaper(width=390, height=684):
        return aa_phone_cover(aa_phone_asset("wallpaper-" + aa_phone_pref("wallpaper", "tide")), width, height)

    def aa_phone_thumbnail(asset, width, height):
        return AlphaMask(aa_phone_cover(asset, width, height), aa_phone_round("mask"))

transform aa_hub_enter:
    alpha 0.0
    yoffset (16 if persistent.aa_motion else 0)
    easeout (0.22 if persistent.aa_motion else 0.0) alpha 1.0 yoffset 0

transform aa_phone_page_enter:
    alpha 0.0
    yoffset (5 if persistent.aa_motion else 0)
    easeout (0.16 if persistent.aa_motion else 0.0) alpha 1.0 yoffset 0

transform aa_phone_press:
    on hover:
        easeout (0.12 if persistent.aa_motion else 0.0) alpha 0.82
    on idle:
        easeout (0.12 if persistent.aa_motion else 0.0) alpha 1.0

style aa_hub_text is default:
    font "fonts/Inter-Regular.ttf"
    size 20
    color "#edf1f7"
    line_spacing 3
    outlines []
style aa_hub_muted is aa_hub_text:
    size 16
    color "#aeb9c8"
style aa_insert_text is aa_hub_text
style aa_insert_frame is frame
style aa_insert_button is button
style aa_insert_vbox is vbox
style aa_insert_hbox is hbox
style aa_insert_fixed is fixed
style aa_insert_viewport is viewport
style aa_phone_title is aa_hub_text:
    font "fonts/Inter-SemiBold.ttf"
    size 31
    kerning -0.8
style aa_hub_button is button:
    background aa_phone_round("glass")
    hover_background aa_phone_round("glass-hover")
    selected_background aa_phone_round("hover")
    insensitive_background aa_phone_round("plain")
    padding (16, 12)
    yminimum 46
style aa_hub_button_text is aa_hub_text:
    size 18
    hover_color "#f5f7fa"
    selected_color "#a5dbf4"
    insensitive_color "#8290a3"
style aa_phone_primary is aa_hub_button:
    background aa_phone_round("primary")
    hover_background aa_phone_round("primary-hover")
    insensitive_background aa_phone_round("surface")
style aa_phone_primary_text is aa_hub_button_text:
    font "fonts/Inter-SemiBold.ttf"
    color "#142f2d"
    hover_color "#142f2d"
    insensitive_color "#87929f"
style aa_hub_row is button:
    background None
    hover_background aa_phone_round("hover")
    padding (8, 15)
    xfill True
    yminimum 60
style aa_hub_row_text is aa_hub_text
style aa_hub_scroll_viewport is viewport
style aa_hub_scroll_vscrollbar is vscrollbar:
    xsize 3
    base_bar Solid("#1a202900")
    thumb Solid("#73819488")
    unscrollable "hide"
style aa_hub_scroll_side is side:
    spacing 7

screen aa_hub_icon(name, size=24):
    add aa_phone_asset("icon-" + name) xysize (size, size)

screen aa_phone_avatar(name, size=42):
    fixed:
        xysize (size, size)
        add aa_phone_contact(name) xysize (size, size)
        text name[0].upper() style "aa_hub_text" font "fonts/Inter-Medium.ttf" size int(size * .43) align (0.5, 0.5)

screen aa_phone_glass(width, height, wallpaper_region=None):
    fixed:
        xysize (width, height)
        if wallpaper_region and aa_phone_pref("glass", 0.55) < 0.95:
            $ px, py, pw, ph = wallpaper_region
            add AlphaMask(Transform(aa_phone_wallpaper(pw, ph), crop=(px, py, width, height), blur=12), aa_phone_round("mask")) xysize (width, height)
        add aa_phone_round("glass") xysize (width, height)
        add aa_phone_round("glass-solid") xysize (width, height) alpha aa_phone_pref("glass", 0.55)

screen aa_phone_control(icon, action, label, chosen=False):
    button:
        style "aa_hub_button"
        background Transform(aa_phone_asset("glass-solid-circle" if aa_phone_pref("glass", 0.55) >= 0.95 else "glass-circle"), xysize=(46, 46))
        hover_background Transform(aa_phone_asset("glass-hover-circle"), xysize=(46, 46))
        selected_background Transform(aa_phone_asset("glass-hover-circle"), xysize=(46, 46))
        xysize (46, 46)
        padding (11, 11)
        selected chosen
        action action
        alt label
        use aa_hub_icon(icon, 24)

screen aa_hub_empty(icon, title, body):
    vbox:
        spacing 13
        xfill True
        null height 45
        use aa_hub_icon(icon, 35)
        text title style "aa_phone_title" size aa_phone_size(24)
        text body style "aa_hub_muted" size aa_phone_size(17)

screen aa_phone_message(body, sent=False, width=310, caption=None, compact=False):
    use aa_messages_bubble(body, sent, width, True, compact)

screen aa_phone_rule(width):
    add Solid("#313946") xysize (width, 1)

screen aa_phone_sheet(title):
    $ sheet_x, sheet_width = aa_phone_geometry()
    $ sheet_screen_x, sheet_screen_y, sheet_inner_width, sheet_inner_height = aa_phone_screen_geometry(sheet_width, AA_PHONE_BODY_HEIGHT)
    $ sheet_height = 18 + sheet_screen_y + sheet_inner_height - 184
    add Solid("#080e1899")
    frame:
        xpos (sheet_x + sheet_screen_x)
        ypos 184
        xysize (sheet_inner_width, sheet_height)
        padding (18, 20)
        background aa_phone_round("surface", 24)
        at aa_hub_enter
        vbox:
            spacing 16
            add aa_phone_round("mask") xysize (40, 4) xalign 0.5 alpha .45
            text title style "aa_phone_title" size 25
            viewport:
                xsize (sheet_inner_width - 36)
                ysize (sheet_height - 106)
                mousewheel True
                draggable True
                arrowkeys True
                scrollbars "vertical"
                style_prefix "aa_hub_scroll"
                vbox:
                    xsize (sheet_inner_width - 46)
                    spacing 16
                    transclude
