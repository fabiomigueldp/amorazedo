"""Three-seat no-limit Hold'em. Integer cents; immutable, saved hand transitions.

The wallet owns the buy-in. This module only moves chips between stacks/pots.
Bots receive their own cards and public information, never the real deck or
another player's cards. Their private random stream is saved with the hand.
"""
from collections import Counter
from copy import deepcopy
from itertools import combinations
from random import Random

NAMES = ("Você", "Lia", "Rui")
STREETS = ("Pré-flop", "Flop", "Turn", "River")
HANDS = ("Carta alta", "Um par", "Dois pares", "Trinca", "Sequência",
         "Flush", "Full house", "Quadra", "Straight flush")
DECK = tuple((rank, suit) for rank in range(1, 14) for suit in range(4))


class PokerError(ValueError):
    pass


def _straight(ranks):
    ranks = set(ranks)
    if 14 in ranks:
        ranks.add(1)
    return next((high for high in range(14, 4, -1)
                 if all(high - step in ranks for step in range(5))), 0)


def evaluate(cards):
    """Lexicographic high-poker score, including every relevant kicker."""
    ranks = [14 if r == 1 else r for r, s in cards]
    counts = Counter(ranks)
    ordered = sorted(counts, reverse=True)
    flush = next((sorted((14 if r == 1 else r for r, s in cards if s == suit), reverse=True)
                  for suit in range(4) if sum(s == suit for r, s in cards) >= 5), None)
    if flush and _straight(flush):
        return (8, _straight(flush))
    quads = [r for r in ordered if counts[r] == 4]
    if quads:
        return (7, quads[0], max(r for r in ranks if r != quads[0]))
    trips = [r for r in ordered if counts[r] >= 3]
    pairs = [r for r in ordered if counts[r] >= 2]
    if trips and any(r != trips[0] for r in pairs):
        return (6, trips[0], next(r for r in pairs if r != trips[0]))
    if flush:
        return (5,) + tuple(flush[:5])
    straight = _straight(ranks)
    if straight:
        return (4, straight)
    if trips:
        return (3, trips[0]) + tuple(r for r in ordered if r != trips[0])[:2]
    if len(pairs) >= 2:
        return (2, pairs[0], pairs[1], next(r for r in ordered if r not in pairs[:2]))
    if pairs:
        return (1, pairs[0]) + tuple(r for r in ordered if r != pairs[0])[:3]
    return (0,) + tuple(ordered[:5])


def hand_name(cards):
    score = evaluate(cards)
    return "Royal flush" if score == (8, 14) else HANDS[score[0]]


def best_five(cards):
    return list(max(combinations(cards, 5), key=evaluate))


def blinds(buyin):
    big = max(2, buyin // 100 * 2)
    return big // 2, big


def order_after(seat):
    return [(seat + step) % 3 for step in (1, 2, 3)]


def pot(d):
    return sum(p["total"] for p in d["players"])


def live(d):
    return [i for i, p in enumerate(d["players"]) if not p["folded"]]


def actionable(d):
    return [i for i in live(d) if d["players"][i]["stack"] > 0]


def _log(d, seat, action, amount=0):
    d["log"].append(dict(street=d["street"], seat=seat, action=action, amount=amount))
    if seat is not None:
        d["players"][seat]["last"] = action


def _pay(d, seat, amount):
    p = d["players"][seat]
    amount = min(amount, p["stack"])
    p["stack"] -= amount
    p["bet"] += amount
    p["total"] += amount
    return amount


def new_hand(buyin, button, rng):
    deck = list(DECK)
    rng.shuffle(deck)
    small, big = blinds(buyin)
    stacks = (buyin, max(big, buyin * 3 // 4), buyin * 5 // 4)
    players = [dict(name=name, hole=[], initial=stack, stack=stack, bet=0,
                    total=0, folded=False, acted_to=None, last="")
               for name, stack in zip(NAMES, stacks)]
    d = dict(players=players, deck=deck, board=[], burned=[], button=button,
             small=small, big=big, street=0, current=big, min_raise=big,
             phase="betting", pending=order_after((button + 2) % 3), turn=button,
             runout=False, showdown=False, pots=[], awards=[0, 0, 0],
             refunds=[0, 0, 0], log=[], ai_state=Random(rng.randrange(1 << 30)).getstate())
    for _ in range(2):
        for seat in order_after(button):
            players[seat]["hole"].append(deck.pop())
    for seat, amount, label in (((button + 1) % 3, small, "small"), ((button + 2) % 3, big, "big")):
        _log(d, seat, label, _pay(d, seat, amount))
    return d


def legal(d, seat):
    p = d["players"][seat]
    to_call = max(0, d["current"] - p["bet"])
    maximum = p["bet"] + p["stack"]
    reopened = p["acted_to"] is None or d["current"] - p["acted_to"] >= d["min_raise"]
    can_raise = reopened and maximum > d["current"] and any(i != seat for i in actionable(d))
    return dict(to_call=to_call, call=min(to_call, p["stack"]),
                minimum=d["current"] + d["min_raise"], maximum=maximum,
                can_raise=can_raise, reopened=reopened)


def _refund(d):
    # Unmatched chips are returned even if the owner declared all-in.
    totals = sorted(((p["total"], i) for i, p in enumerate(d["players"])), reverse=True)
    excess = totals[0][0] - totals[1][0]
    if excess:
        seat = totals[0][1]
        p = d["players"][seat]
        p["stack"] += excess
        p["total"] -= excess
        p["bet"] = max(0, p["bet"] - excess)
        d["refunds"][seat] += excess
        _log(d, seat, "refund", excess)


def _settle(d):
    _refund(d)
    survivors = live(d)
    d["showdown"] = len(survivors) > 1
    scores = {i: evaluate(d["players"][i]["hole"] + d["board"]) for i in survivors} if d["showdown"] else {}
    previous = 0
    for level in sorted(set(p["total"] for p in d["players"] if p["total"])):
        contributors = [i for i, p in enumerate(d["players"]) if p["total"] >= level]
        eligible = [i for i in survivors if i in contributors]
        if not eligible:
            raise PokerError("Pote sem participante elegível.")
        amount = (level - previous) * len(contributors)
        # Folded contributions can create several tiers with the same eligible
        # hands. Merge them before division so odd cents are awarded only once.
        if d["pots"] and d["pots"][-1]["eligible"] == eligible:
            d["pots"][-1]["amount"] += amount
        else:
            d["pots"].append(dict(amount=amount, eligible=eligible))
        previous = level
    for side in d["pots"]:
        eligible, amount = side["eligible"], side["amount"]
        best = max(scores[i] for i in eligible) if scores else None
        winners = [i for i in order_after(d["button"]) if i in eligible and (not scores or scores[i] == best)]
        shares = {i: amount // len(winners) + (index < amount % len(winners)) for index, i in enumerate(winners)}
        side.update(winners=winners, shares=shares)
        for i, share in shares.items():
            d["awards"][i] += share
            d["players"][i]["stack"] += share
    d.update(phase="done", turn=None, pending=[])


def _advance(d):
    if len(live(d)) == 1:
        _settle(d)
        return
    eligible = actionable(d)
    d["pending"] = [i for i in d["pending"] if i in eligible]
    if len(eligible) <= 1:
        # A lone funded player can only respond to an outstanding wager.
        d["pending"] = [i for i in d["pending"] if d["players"][i]["bet"] < d["current"]]
    if d["pending"]:
        d["turn"] = d["pending"][0]
        return
    _refund(d)
    d["runout"] = len(actionable(d)) <= 1
    if d["street"] == 3:
        _settle(d)
    else:
        d.update(phase="deal", turn=None)


def _deal(d):
    d["street"] += 1
    d["burned"].append(d["deck"].pop())
    for _ in range(3 if d["street"] == 1 else 1):
        d["board"].append(d["deck"].pop())
    for p in d["players"]:
        p.update(bet=0, acted_to=None, last="")
    d.update(current=0, min_raise=d["big"], phase="betting",
             pending=[i for i in order_after(d["button"]) if i in actionable(d)])
    _log(d, None, "deal")
    _advance(d)


def _play(d, seat, action, target=None):
    if d["phase"] != "betting" or d["turn"] != seat:
        raise PokerError("Aguarde a sua vez de jogar.")
    p = d["players"][seat]
    limits = legal(d, seat)
    if action == "fold":
        p["folded"] = True
        _log(d, seat, "fold")
    elif action in ("check", "call"):
        if action == "check" and limits["to_call"]:
            raise PokerError("É preciso pagar a aposta ou desistir.")
        amount = _pay(d, seat, limits["call"])
        _log(d, seat, "allin" if p["stack"] == 0 else "call" if amount else "check", amount)
    elif action == "raise":
        if not limits["can_raise"]:
            raise PokerError("A ação não permite aumentar agora.")
        if type(target) is not int or not d["current"] < target <= limits["maximum"]:
            raise PokerError("Escolha um total dentro das fichas disponíveis.")
        if target < limits["minimum"] and target != limits["maximum"]:
            raise PokerError("O aumento é menor que o mínimo da rodada.")
        increment = target - d["current"]
        opening = d["current"] == 0
        _pay(d, seat, target - p["bet"])
        if increment >= d["min_raise"]:
            d["min_raise"] = increment
        d["current"] = target
        d["pending"] = [i for i in order_after(seat) if i != seat and i in actionable(d)]
        _log(d, seat, "allin_to" if p["stack"] == 0 else "bet" if opening else "raise", target)
    else:
        raise PokerError("Escolha passar, pagar, aumentar ou desistir.")
    p["acted_to"] = d["current"]
    d["pending"] = [i for i in d["pending"] if i != seat]
    _advance(d)


def observation(d, seat):
    """A deliberately narrow boundary: no deck, burns or other hole cards."""
    return dict(hole=list(d["players"][seat]["hole"]), board=list(d["board"]),
                opponents=len(live(d)) - 1, pot=pot(d), big=d["big"],
                bet=d["players"][seat]["bet"], seat=seat, limits=legal(d, seat))


def bot_choice(view, rng):
    known = set(tuple(c) for c in view["hole"] + view["board"])
    unseen = [c for c in DECK if c not in known]
    equity = 0.0
    missing = 5 - len(view["board"])
    # Small equity estimate against unknown hands, not the real opponents.
    for _ in range(36):
        sample = rng.sample(unseen, missing + 2 * view["opponents"])
        board = view["board"] + sample[:missing]
        mine = evaluate(view["hole"] + board)
        others = [evaluate(sample[missing + 2*i:missing + 2*i + 2] + board) for i in range(view["opponents"])]
        if mine >= max(others):
            equity += 1.0 / (1 + others.count(mine))
    equity /= 36
    limits = view["limits"]
    price = limits["call"] / max(1, view["pot"] + limits["call"])
    roll = rng.random()
    aggressive = .64 if view["seat"] == 1 else .43
    if limits["to_call"] and equity + .045 < price and roll > .1:
        return "fold", None
    strong = equity > 1 / (view["opponents"] + 1) + .16
    if limits["can_raise"] and ((strong and roll < aggressive) or roll < .055):
        size = max(view["big"], int((view["pot"] + limits["call"]) * (.75 if strong else .5)))
        target = max(limits["minimum"], view["bet"] + limits["call"] + size)
        return "raise", min(target, limits["maximum"])
    return ("call" if limits["to_call"] else "check"), None


def can_finish(d):
    return d["phase"] != "done" and (d["players"][0]["folded"] or d["players"][0]["stack"] == 0 or d["runout"])


def step(data, action, target=None):
    if data["phase"] == "done":
        raise PokerError("Esta mão já terminou.")
    d = deepcopy(data)
    if action == "finish":
        if not can_finish(d):
            raise PokerError("Ainda há decisões suas nesta mão.")
        while d["phase"] != "done":
            d = step(d, "auto")
        return d
    if action == "auto":
        if d["phase"] == "deal":
            _deal(d)
        elif d["turn"] != 0:
            rng = Random()
            rng.setstate(d["ai_state"])
            choice, amount = bot_choice(observation(d, d["turn"]), rng)
            d["ai_state"] = rng.getstate()
            _play(d, d["turn"], choice, amount)
        else:
            raise PokerError("A decisão é sua.")
    else:
        _play(d, 0, action, target)
    return d


def visible(d, seat):
    return seat == 0 or (not d["players"][seat]["folded"] and (d["showdown"] or d["runout"]))


def result_label(d):
    player = d["players"][0]
    if player["folded"]:
        return "Você desistiu"
    if d["awards"][0]:
        shared = any(0 in p["winners"] and len(p["winners"]) > 1 for p in d["pots"])
        return "Pote dividido" if shared else "Você venceu" if player["stack"] > player["initial"] else "Você recebeu parte do pote"
    winners = sorted({i for p in d["pots"] for i in p["winners"]})
    return " e ".join(NAMES[i] for i in winners) + (" venceram" if len(winners) > 1 else " venceu")


def history(data):
    d = {key: deepcopy(value) for key, value in data.items() if key not in ("deck", "burned", "ai_state")}
    for i, p in enumerate(d["players"]):
        if not visible(data, i):
            p["hole"] = None
    return d
