"""Deterministic, bounded presentation timing, independent of narrative minutes."""
from hashlib import sha256
from time import monotonic


def plan(body, seed, ident):
    values = sha256((str(seed) + ":typing:" + ident).encode("utf-8")).digest()
    # All phases, including hesitation, fit inside 4.8s (+ <=100ms UI tick).
    total = min(4800, max(1000, 950 + len(body) * 18 + int(values[0] / 255 * 360) - 180))
    start = 180 + values[1] * 220 // 255
    pause_start = pause_end = 0
    if total >= 1900 and values[2] < 89:  # 35%, at most one short hesitation
        pause_start = start + (total - start) * (38 + values[3] % 18) // 100
        pause_end = min(total - 450, pause_start + 250 + values[4] * 300 // 255)
    return dict(total_ms=total, start_ms=start, pause_start_ms=pause_start, pause_end_ms=pause_end)


def phase(pending):
    elapsed, timing = pending["elapsed_ms"], pending["timing"]
    if elapsed >= timing["total_ms"]:
        return "done"
    if elapsed < timing["start_ms"]:
        return "waiting"
    if timing["pause_start_ms"] <= elapsed < timing["pause_end_ms"]:
        return "paused"
    return "typing"


class ReplyClock:
    """Unsaved monotonic anchors. Only elapsed_ms is saved by the campaign.

    Equivalent snapshots from read flags / other apps keep their anchor. Loading,
    context changes, or a backwards elapsed value reset it to saved progress.
    """
    def __init__(self, now=monotonic):
        self.now = now
        self.reset()

    def reset(self):
        self.bindings = {}

    def sync(self, seed, pending):
        keys = {(seed, p["id"]) for p in pending}
        self.bindings = {k: v for k, v in self.bindings.items() if k in keys}
        for p in pending:
            key = (seed, p["id"])
            bound = self.bindings.get(key)
            if bound is None or p["elapsed_ms"] != bound[2]:
                self.bindings[key] = [self.now(), p["elapsed_ms"], p["elapsed_ms"]]

    def elapsed(self, seed, pending):
        anchor, base, _ = self.bindings[(seed, pending["id"])]
        return min(pending["timing"]["total_ms"], max(pending["elapsed_ms"],
                   base + int((self.now() - anchor) * 1000)))

    def follow(self, seed, pending):
        for p in pending:
            bound = self.bindings.get((seed, p["id"]))
            if bound is not None:
                bound[2] = p["elapsed_ms"]


clock = ReplyClock()
