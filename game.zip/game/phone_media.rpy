# One transport shared by Music, Podcasts and the system mini-player.
# Listening preferences belong to a save; story unlocks remain rollback-aware.
default aa_media_state = AAMediaState()
default aa_media_unlocked = ()

init -4 python:
    import json
    import phone_media as aa_media_model
    renpy.music.register_channel("aa_phone_media", mixer="phone_media", loop=False, stop_on_mute=False)
    with renpy.open_file("phone_media_catalog.json") as media_source:
        AA_MEDIA = aa_media_model.catalogue(json.load(media_source))

init python:
    class AAMediaState(NoRollback):
        def __init__(self):
            self.current = None
            self.positions = {}
            self.completed = ()
            self.queue = ()
            self.playing = False
            self.rate = 1.0
            self.background = True
            self.repeat = False
            self.error = ""

    def aa_media_item(ident=None):
        return AA_MEDIA.get(ident or aa_media_state.current)

    def aa_media_available(item):
        return bool(item and aa_media_model.visible(item, aa_media_unlocked))

    def aa_media_items(page, query=""):
        import unicodedata
        def fold(value):
            return "".join(c for c in unicodedata.normalize("NFD", value.casefold()) if unicodedata.category(c) != "Mn")
        kind = "podcast" if page == "podcasts" else "music"
        return tuple(item for item in AA_MEDIA.values() if item["kind"] == kind and aa_media_available(item)
                     and fold(query.strip()) in fold(item["title"] + " " + item["collection"]))

    def aa_media_discover(family):
        global aa_media_unlocked
        if family and family not in ("SEM", "M09", "M10") and family not in aa_media_unlocked and not main_menu:
            aa_media_unlocked += (family,)

    def aa_media_position(item=None):
        item = item or aa_media_item()
        return aa_media_model.clamp_position(aa_media_state.positions.get(item["id"], 0), item["duration"]) if item else 0.0

    def aa_media_rate(item=None):
        item = item or aa_media_item()
        return aa_media_state.rate if item and aa_media_state.rate in item["sources"] else 1.0

    def aa_media_caption(item, width):
        # Full title is exposed by the button's accessible label and full player.
        limit = max(12, int(width / 7))
        title = item["title"]
        return title if len(title) <= limit else title[:limit - 1].rstrip() + "…"

    def aa_media_snapshot():
        runtime = aa_media_model.transport
        item = aa_media_item()
        if not item or runtime.owner is not aa_media_state or not runtime.started:
            return
        position = renpy.music.get_pos(channel="aa_phone_media")
        if position is not None:
            positions = dict(aa_media_state.positions)
            positions[item["id"]] = aa_media_model.clamp_position(position * aa_media_rate(item), item["duration"])
            aa_media_state.positions = positions

    def aa_media_interruption():
        if main_menu or renpy.context_nesting_level() != 0 or aa_audio_gallery_active:
            return "Pausado no menu"
        if renpy.is_skipping():
            return "Pausado ao pular cenas"
        if not aa_phone_active:
            return "Pausado durante a cena"
        if renpy.music.is_playing(channel="voice"):
            return "Pausado durante a fala"
        if not aa_media_state.background and not renpy.get_screen("aa_phone_hub"):
            return "Pausado com o celular guardado"
        return ""

    def aa_media_has_focus():
        return bool(aa_media_state.playing and aa_media_available(aa_media_item()) and not aa_media_interruption())

    def aa_media_status(item=None):
        item = item or aa_media_item()
        if not item:
            return "Nada em reprodução"
        if item["id"] == aa_media_state.current:
            if aa_media_state.error:
                return aa_media_state.error
            if aa_media_state.playing:
                return aa_media_interruption() or "Reproduzindo"
        if item["id"] in aa_media_state.completed:
            return "Concluído"
        position = aa_media_position(item)
        return ("Retomar em " + aa_media_model.timestamp(position)) if position > 1 else "No aparelho"

    def aa_media_changed():
        aa_audio_apply_mix()
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_media_start_decoder():
        item = aa_media_item()
        if not aa_media_available(item):
            aa_media_state.playing = False
            return
        source = aa_media_model.playback_source(item, aa_media_rate(item), aa_media_position(item))
        path = item["sources"][aa_media_rate(item)]
        if not renpy.loadable(path):
            aa_media_state.error = "Áudio indisponível no aparelho"
            aa_media_state.playing = False
            renpy.music.stop(channel="aa_phone_media")
            return
        runtime = aa_media_model.transport
        runtime.owner = aa_media_state
        runtime.source = source
        runtime.started = False
        runtime.issued = aa_media_model.time.monotonic()
        try:
            renpy.music.play(source, channel="aa_phone_media", loop=False, fadeout=0, fadein=.08,
                             relative_volume=item["gain"])
            runtime.suspended = bool(aa_media_interruption())
            renpy.music.set_pause(not aa_media_state.playing or runtime.suspended, channel="aa_phone_media")
        except Exception:
            aa_media_state.error = "Não foi possível reproduzir este áudio"
            aa_media_state.playing = False
            renpy.music.stop(channel="aa_phone_media")

    def aa_media_play(ident=None):
        item = aa_media_item(ident)
        if not aa_media_available(item):
            return
        aa_media_snapshot()
        aa_media_state.current = item["id"]
        aa_media_state.error = ""
        if aa_media_position(item) >= item["duration"] - .25 or item["id"] in aa_media_state.completed:
            aa_media_state.positions = dict(aa_media_state.positions, **{item["id"]: 0.0})
            aa_media_state.completed = tuple(i for i in aa_media_state.completed if i != item["id"])
        aa_media_state.queue = tuple(i for i in aa_media_state.queue if i != item["id"])
        aa_media_state.playing = True
        aa_media_start_decoder()
        aa_media_changed()

    def aa_media_toggle():
        if aa_media_state.playing:
            aa_media_snapshot()
            aa_media_state.playing = False
            renpy.music.set_pause(True, channel="aa_phone_media")
            aa_media_changed()
        else:
            aa_media_play()

    def aa_media_stop():
        # End this listening session, while keeping the episode's bookmark.
        if not aa_media_state.current:
            return
        aa_media_snapshot()
        renpy.music.stop(channel="aa_phone_media", fadeout=0)
        aa_media_model.transport.reset()
        aa_media_state.current = None
        aa_media_state.playing = False
        aa_media_state.queue = ()
        aa_media_state.error = ""
        aa_media_changed()

    def aa_media_seek(position):
        item = aa_media_item()
        if not item:
            return
        aa_media_state.positions = dict(aa_media_state.positions, **{item["id"]: aa_media_model.clamp_position(position, item["duration"])})
        aa_media_state.completed = tuple(i for i in aa_media_state.completed if i != item["id"])
        if aa_media_position(item) >= item["duration"]:
            aa_media_state.playing = False
            aa_media_state.completed += (item["id"],)
            renpy.music.stop(channel="aa_phone_media")
            aa_media_model.transport.reset()
        else:
            aa_media_start_decoder()
        aa_media_changed()

    def aa_media_skip(seconds):
        aa_media_snapshot()
        aa_media_seek(aa_media_position() + seconds)

    def aa_media_cycle_rate():
        item = aa_media_item()
        if not item:
            return
        aa_media_snapshot()
        rates = sorted(item["sources"])
        aa_media_state.rate = rates[(rates.index(aa_media_rate(item)) + 1) % len(rates)]
        aa_media_start_decoder()
        aa_media_changed()

    def aa_media_queue(ident):
        if aa_media_available(aa_media_item(ident)) and ident != aa_media_state.current:
            aa_media_state.queue = (tuple(i for i in aa_media_state.queue if i != ident) if ident in aa_media_state.queue
                                    else aa_media_state.queue + (ident,))
            aa_media_changed()

    def aa_media_play_all(page):
        items = aa_media_items(page)
        if items:
            aa_media_state.queue = tuple(item["id"] for item in items[1:])
            aa_media_play(items[0]["id"])

    def aa_media_next():
        available = tuple(i for i in aa_media_state.queue if aa_media_available(aa_media_item(i)))
        if available:
            aa_media_state.queue = available[1:]
            aa_media_play(available[0])
        else:
            aa_media_snapshot()
            aa_media_state.playing = False
            renpy.music.set_pause(True, channel="aa_phone_media")
            aa_media_changed()

    def aa_media_finish():
        item = aa_media_item()
        if not item:
            return
        aa_media_state.positions = dict(aa_media_state.positions, **{item["id"]: item["duration"]})
        aa_media_state.completed = tuple(set(aa_media_state.completed) | {item["id"]})
        if aa_media_state.repeat and item["kind"] == "music":
            aa_media_play(item["id"])
        else:
            aa_media_next()

    def aa_media_guard():
        runtime = aa_media_model.transport
        item = aa_media_item()
        if main_menu or (item and not aa_media_available(item)):
            aa_media_snapshot()
            aa_media_state.playing = False
            renpy.music.stop(channel="aa_phone_media")
            runtime.reset()
        elif item and runtime.owner is aa_media_state:
            suspended = bool(aa_media_interruption())
            if suspended != runtime.suspended:
                aa_media_snapshot()
                runtime.suspended = suspended
            renpy.music.set_pause(not aa_media_state.playing or suspended, channel="aa_phone_media")
        aa_audio_apply_mix()

    def aa_media_tick():
        runtime = aa_media_model.transport
        aa_media_guard()
        if not aa_media_has_focus():
            return
        if runtime.owner is not aa_media_state:
            aa_media_start_decoder()
            return
        position = renpy.music.get_pos(channel="aa_phone_media")
        if position is not None:
            runtime.started = True
            aa_media_snapshot()
        elif runtime.started and not renpy.music.is_playing(channel="aa_phone_media"):
            runtime.started = False
            # Ren'Py stops non-looping channels on rollback/context restoration.
            # A decoder stop in the middle of an episode is not a natural EOF.
            remaining = aa_media_item()["duration"] - aa_media_position()
            if remaining > max(1.0, aa_media_rate() * .75):
                aa_media_start_decoder()
            else:
                aa_media_finish()
        elif not runtime.started and aa_media_model.time.monotonic() - runtime.issued > 5 and not renpy.music.is_playing(channel="aa_phone_media"):
            aa_media_state.playing = False
            aa_media_state.error = "Não foi possível reproduzir este áudio"
            aa_media_changed()
        renpy.retain_after_load()

    def aa_media_after_load():
        # Loading never produces an unexpected spoken episode. Resume is explicit.
        aa_media_state.playing = False
        aa_media_model.transport.reset()
        renpy.music.stop(channel="aa_phone_media")
        aa_media_discover(aa_audio_family)
        aa_audio_apply_mix()

    def aa_media_open(ident=None):
        item = aa_media_item(ident)
        if not aa_media_available(item):
            return
        if not renpy.get_screen("aa_phone_hub"):
            aa_phone_open()
        aa_phone_go("podcasts" if item["kind"] == "podcast" else "music")
        renpy.set_screen_variable("media_detail", item["id"], "aa_phone_hub")
        renpy.restart_interaction()

    def aa_media_panel(panel):
        renpy.set_screen_variable("media_panel", panel, "aa_phone_hub")
        renpy.restart_interaction()

    class AAMediaSeek(BarValue):
        def __init__(self):
            self.adjustment = None

        def get_adjustment(self):
            item = aa_media_item()
            self.adjustment = ui.adjustment(range=item["duration"] if item else 1,
                                           value=aa_media_position(), changed=aa_media_seek, adjustable=True, step=5)
            return self.adjustment

        def periodic(self, st):
            if self.adjustment:
                # Setting the value directly avoids seeking on a clock refresh.
                self.adjustment.value = aa_media_position()
            return .25

        def get_style(self):
            return "slider", "vslider"

init 5 python:
    config.interact_callbacks.append(aa_media_guard)
    config.after_load_callbacks.append(aa_media_after_load)
    config.start_callbacks.append(aa_media_model.transport.reset)
    config.overlay_screens.append("aa_media_clock")

screen aa_media_clock():
    if not main_menu and renpy.context_nesting_level() == 0 and aa_media_state.playing:
        timer .25 repeat True action Function(aa_media_tick)
