testsuite aa_group_source:
    setup:
        $ _test.timeout = 12.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
    before testcase:
        if not screen 'main_menu':
            run MainMenu(confirm=False)
        assert screen 'main_menu'
    teardown:
        exit

    testcase indicacao_sem_publicacao:
        run Start()
        advance until screen 'choice'
        run Jump('a06')
        advance until screen 'choice'
        click 'Dizer que uma amiga da escola compartilhou o restaurante num grupo.'
        advance until screen 'choice'
        assert eval aa_node == 'b00' and aa_state['group_source'] and not aa_state['ambush']
        assert eval not aa_state['initial_lie'] and not aa_state['v_knows']
        click 'Apresentar Vanessa como minha namorada.'
        advance until screen 'choice'
        assert eval 'É a amiga que mandou no grupo?' in aa_history_export()
        click 'Dizer que vamos deixar os dois jantarem.'
        advance until screen 'choice'
        assert eval 'É a amiga do grupo. E você escolheu sentar de frente pra mesa dela.' in aa_history_export()
        assert eval 'Então foi ela que indicou.' not in aa_history_export()

    testcase indicacao_com_publicacao_mesa_quatro:
        run Start()
        advance until screen 'choice'
        $ aa_state = dict(aa_state, knew=True)
        run Jump('a06')
        advance until screen 'choice'
        click 'Dizer que uma amiga da escola compartilhou o restaurante num grupo.'
        advance until screen 'choice'
        assert eval aa_state['ambush'] and not aa_state['presence_told'] and not aa_state['initial_lie']
        click 'Apresentar Vanessa como minha namorada.'
        advance until screen 'choice'
        click 'Sugerir que juntemos as mesas.'
        advance until screen 'choice'
        click 'Admitir que a crítica de Vanessa é justa.'
        advance until screen 'choice'
        click 'Dizer que não era uma coincidência e assumir a insistência.'
        advance until screen 'choice'
        assert eval aa_state['past_told'] and aa_state['v_knows']
        assert eval 'Você falou de uma amiga. Por que não me contou essa parte antes?' in aa_history_export()

    testcase indicacao_varanda:
        run Start()
        advance until screen 'choice'
        $ aa_state = dict(aa_state, group_source=True, route='varanda')
        run Jump('t02')
        advance until screen 'choice'
        click 'Pedir desculpa pelo tempo e contar o que fui fazer.'
        advance until screen 'choice'
        assert eval aa_node == 'i00' and aa_state['v_knows'] and aa_state['source_truth']
        assert eval 'Eu fui falar com a Yasmin porque ainda penso nela.' in aa_history_export()
