"""Migration of completed publication facts from saves predating the branch."""
def migrate(state, memory, now, node):
    if state.get('post_arc_version'):
        return state
    from story_model import new_state
    result = dict(new_state(), **state)
    result['post_arc_version'] = 1
    post = next((p for p in memory if p['id'] == 'publicacao_feka'), None)
    kinds = {p['kind'] for p in memory}
    if post:
        result['post_status'] = ('withdrawn' if post.get('subtitle') == 'Publicação retirada'
                                 else 'published' if post['kind'] in ('publicado','publicado_depois') else 'draft')
        result['post_tagged'] = '@Vanessa' in post.get('paragraphs', ())
    if 'marcacao' in kinds:
        result.update(tag_response='removed', post_tagged=False)
    # Old E08 told the colleague at the campus before reaching its continuation.
    # At the E08 label, only the actual day transition proves it has occurred.
    after_e08 = state.get('chapter_origin') == 'e08' and (node != 'e08' or now >= 1440)
    if after_e08:
        result['colleague_account'] = 'blamed'
        # Pre-archive saves still have the completed, fixed E08 outcome.
        if not post:
            result['post_status'] = 'withdrawn' if state.get('public_corrected') else 'published'
            result['post_tagged'] = state.get('bond') == 'mantido' and not state.get('public_corrected')
            if state.get('bond') != 'mantido':
                result['tag_response'] = 'removed'
    return result
