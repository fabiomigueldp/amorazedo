# Rounded surfaces are drawn at their final dimensions, never sliced from a
# smaller rounded image. In particular, a 4 px home indicator needs a 2 px radius.
init -6 python:
    renpy.register_shader("aa.phone_round", variables="""
        uniform vec2 u_phone_round_size;
        uniform float u_phone_round_radius;
        uniform vec4 u_phone_round_top;
        uniform vec4 u_phone_round_bottom;
        uniform vec4 u_phone_round_edge;
        attribute vec4 a_position;
        varying vec2 v_phone_round_coord;
    """, vertex_300="""
        v_phone_round_coord = a_position.xy / u_phone_round_size;
    """, fragment_300="""
        vec2 half_size = u_phone_round_size * 0.5;
        float radius = min(u_phone_round_radius, min(half_size.x, half_size.y));
        vec2 q = abs(v_phone_round_coord * u_phone_round_size - half_size) - (half_size - vec2(radius));
        float distance = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - radius;
        float coverage = 1.0 - smoothstep(-0.65, 0.0, distance);
        vec4 fill = mix(u_phone_round_top, u_phone_round_bottom, v_phone_round_coord.y);
        float edge = smoothstep(-1.3, -0.45, distance) * u_phone_round_edge.a;
        fill.rgb = mix(fill.rgb, u_phone_round_edge.rgb, edge);
        fill.a *= coverage;
        gl_FragColor = vec4(fill.rgb * fill.a, fill.a);
    """)

    class AAPhoneRound(renpy.Displayable):
        def __init__(self, name, radius=24, **properties):
            super(AAPhoneRound, self).__init__(**properties)
            self.name = name
            self.radius = radius
            self.tail = name[len("message-bubble-"):] if name.startswith("message-bubble-") else None
            name = self.tail or name
            materials = {
                "social-blue": ("#1877ed", "#1877ed", "#ffffff10"),
                "media-glass": ("#45414ae8", "#29252eee", "#ddd1e152"),
                "media-glass-solid": ("#45414a", "#29252e", "#ddd1e152"),
                "media-purple": ("#d5b3f5", "#d5b3f5", "#00000000"),
                "media-red": ("#ffadb9", "#ffadb9", "#00000000"),
                "media-hover": ("#554b5d", "#554b5d", "#ddd1e142"),
                "island": ("#08090c", "#08090c", "#75677f48"),
                "island-control": ("#29262d", "#29262d", "#f4eef52a"),
                "island-control-hover": ("#45404a", "#45404a", "#f4eef545"),
                "calc-number": ("#2c2c2c", "#383838", "#ffffff20"),
                "calc-number-hover": ("#626262", "#686868", "#ffffff30"),
                "calc-function": ("#5c5c5c", "#5c5c5c", "#ffffff30"),
                "calc-function-hover": ("#8a8a8a", "#8a8a8a", "#ffffff40"),
                "calc-orange": ("#ff9f00", "#ff9500", "#00000000"),
                "calc-orange-hover": ("#ffbf61", "#ffb957", "#00000000"),
                "calc-selected": ("#fff5e7", "#fff5e7", "#00000000"),
                "calc-toolbar": ("#252525", "#1d1d1d", "#ffffff25"),
                "calc-sheet": ("#252525", "#252525", "#ffffff25"),
                "surface": ("#1d222b", "#1d222b", "#343b47"),
                "plain": ("#151a22", "#151a22", "#00000000"),
                "hover": ("#343f50", "#343f50", "#7294b450"),
                "sent": ("#006fe6", "#006fe6", "#00000000"),
                "received": ("#262629", "#262629", "#00000000"),
                "primary": ("#98d9c1", "#98d9c1", "#00000000"),
                "primary-hover": ("#b4ead4", "#b4ead4", "#00000000"),
                "badge": ("#dd565d", "#dd565d", "#00000000"),
                "mask": ("#f8f9fa", "#f8f9fa", "#00000000"),
                "shade": ("#101620", "#101620", "#00000000"),
                "glass": ("#73848e8a", "#142834b0", "#dce9ec60"),
                "glass-hover": ("#73848ecc", "#142834f2", "#dce9ec80"),
                "glass-solid": ("#73848e", "#142834", "#dce9ec65"),
                "message-field": ("#1c1c1e", "#1c1c1e", "#49494d"),
                "message-sheet": ("#1c1c1e", "#1c1c1e", "#48484b"),
                "message-hover": ("#343438", "#343438", "#00000000"),
                "message-glass": ("#404045e0", "#242426e0", "#b4b4bc55"),
                "message-glass-solid": ("#404045", "#242426", "#b4b4bc55"),
                "casino-surface": ("#242129", "#242129", "#423c4a"),
                "casino-dock": ("#1e1a22", "#1e1a22", "#62536b66"),
                "casino-table": ("#312738", "#312738", "#62506e"),
                "casino-accent": ("#d8c4ed", "#d8c4ed", "#00000000"),
                "casino-hover": ("#483c54", "#483c54", "#796589"),
                "casino-card": ("#f2ede7", "#f2ede7", "#ffffff"),
                "casino-red": ("#743a49", "#743a49", "#b86073"),
                "casino-green": ("#305548", "#305548", "#6f9f87"),
                "bank-surface": ("#202523", "#202523", "#00000000"),
                "bank-hover": ("#353d38", "#353d38", "#00000000"),
                "bank-selected": ("#3a453e", "#3a453e", "#ffffff0c"),
                "bank-success": ("#253c30", "#253c30", "#00000000"),
                "bank-glass": ("#404b43ed", "#232b26f2", "#dcece35c"),
                "bank-glass-solid": ("#404b43", "#232b26", "#dcece35c"),
                "bank-sheet": ("#252b27", "#252b27", "#a9b9ad42"),
            }
            def rgba(value):
                value = value.lstrip("#")
                value += "ff" if len(value) == 6 else ""
                return tuple(int(value[i:i+2], 16) / 255.0 for i in (0, 2, 4, 6))
            self.colors = tuple(rgba(value) for value in materials[name])
            self.surface = Solid("#ffffff")
            self.tail_image = (Transform("gui/phone/modern/message-tail-" + self.tail + ".svg",
                                         xysize=(13, 15), xzoom=(-1 if self.tail == "received" else 1)) if self.tail else None)

        def render(self, width, height, st, at):
            width, height = max(1, int(width)), max(1, int(height))
            result = renpy.Render(width, height)
            result.blit(renpy.render(self.surface, width, height, st, at), (0, 0))
            result.mesh = True
            result.add_shader("aa.phone_round")
            result.add_uniform("u_phone_round_size", (float(width), float(height)))
            result.add_uniform("u_phone_round_radius", float(self.radius))
            for key, color in zip(("top", "bottom", "edge"), self.colors):
                result.add_uniform("u_phone_round_" + key, color)
            if self.tail_image:
                combined = renpy.Render(width, height)
                combined.blit(result, (0, 0))
                combined.blit(renpy.render(self.tail_image, 13, 15, st, at),
                              (0 if self.tail == "received" else width - 13, height - 15))
                return combined
            return result

        def visit(self):
            return [self.surface] + ([self.tail_image] if self.tail_image else [])
