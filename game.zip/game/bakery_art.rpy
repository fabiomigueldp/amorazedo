# Fundos da padaria P1.0. Gerado por tools/build_bakery.py.
# Disponíveis para novos capítulos; sem alterações nas rotas existentes.
image bg_padaria_fachada_manha = Transform("images/padaria-v1/bg_padaria_fachada_manha.png", xysize=(1280, 720), fit="cover")
image bg_padaria_salao_manha = Transform("images/padaria-v1/bg_padaria_salao_manha.png", xysize=(1280, 720), fit="cover")
image bg_padaria_balcao = Transform("images/padaria-v1/bg_padaria_balcao.png", xysize=(1280, 720), fit="cover")
image bg_padaria_mesa_a_banco = Transform("images/padaria-v1/bg_padaria_mesa_a_banco.png", xysize=(1280, 720), fit="cover")
image bg_padaria_mesa_a_cadeira = Transform("images/padaria-v1/bg_padaria_mesa_a_cadeira.png", xysize=(1280, 720), fit="cover")
image bg_padaria_mesa_c = Transform("images/padaria-v1/bg_padaria_mesa_c.png", xysize=(1280, 720), fit="cover")
image bg_padaria_vestibulo = Transform("images/padaria-v1/bg_padaria_vestibulo.png", xysize=(1280, 720), fit="cover")
image bg_padaria_banheiro = Transform("images/padaria-v1/bg_padaria_banheiro.png", xysize=(1280, 720), fit="cover")
image bg_padaria_preparo = Transform("images/padaria-v1/bg_padaria_preparo.png", xysize=(1280, 720), fit="cover")
image bg_padaria_salao_tarde = Transform("images/padaria-v1/bg_padaria_salao_tarde.png", xysize=(1280, 720), fit="cover")
