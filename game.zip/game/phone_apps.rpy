# Conteúdo visível ao protagonista. Cada chave é um estado de leitura, nunca
# um temporizador: salvar, carregar e rollback recuperam a mesma composição.
init python:
    aa_phone_chats = {
        "mudanca_cancelada": ("Vanessa", "Dia seguinte", [(False, "Você tem certeza?"), (True, "Tenho."), (False, "Não vai à mudança, por favor.")]),
        "cheguei": ("Vanessa", "À noite", [(False, "Cheguei."), (True, "Que bom.")]),
        "depois_agressao": ("Vanessa", "Madrugada", [(False, "Cheguei com minha mãe. Hoje não me procura. Amanhã eu vejo como falar com você.")]),
        "grupo_materia": ("Turma · Direito", "Dia seguinte", [(True, "Matéria da aula"), (True, "Anotações da aula · documento")]),
        "materia": ("Vanessa", "Dia seguinte", [(True, "A matéria da aula está aqui."), (False, "Peguei a chave. Podemos conversar na quinta, depois da aula?")]),
        "quinta": ("Vanessa", "Dia seguinte", [(False, "Podemos conversar na quinta, depois da aula?"), (True, "Sim.")]),
        "visita": ("Vanessa", "Dia seguinte · de manhã", [(True, "Bom dia. Vou depois da aula. Pode ser?"), (False, "Pode. Vou te esperar.")]),
        "so_materia": ("Vanessa", "Segunda-feira", [(False, "Quero só a matéria, pelo grupo.")]),
        "espaco": ("Vanessa", "Segunda-feira · à noite", [(False, "Ainda não sei terminar. Mas não quero te ver fora da aula por enquanto."), (True, "Entendi.")]),
        "promessa": ("Vanessa", "Dia seguinte", [(True, "Não vou à mudança. Não posso pedir que você me espere."), (False, "Você falou que ia.")]),
        "indefinido": ("Vanessa", "Dia seguinte", [(True, "Não vou à mudança. Desculpa por ter prometido."), (False, "Você ainda quer o namoro?"), (True, "Não sei. Entendo se você não quiser esperar.")]),
        "devolucao": ("Joãozão", "Dia seguinte · 11h18", [(True, "Devolvi os R$ 60."), (False, "Recebi.")]),
        "devolucao_v": ("Vanessa", "Sexta-feira", [(True, "Devolvi o dinheiro."), (False, "Recebi. O valor está certo.")]),
        "chegou": ("Vanessa", "Mais tarde", [(False, "Você chegou?"), (False, "Preciso ficar sem conversar hoje.")]),
        "terminou": ("Vanessa", "Ontem / hoje", [(False, "Cheguei."), (True, "Que bom."), (False, "A gente terminou?")]),
        "visita_post": ("Vanessa", "Resposta à publicação", [(False, "A visita à mudança ainda tá combinada?"), (True, "Sim.")]),
        "marcacao": ("Vanessa", "Agora · resposta à publicação", [(False, "Não me marca, por favor.")]),
    }

screen aa_phone_header(title, subtitle):
    vbox:
        spacing 8
        text title style "aa_phone_title" size 25
        text subtitle style "aa_hub_muted" size 15
        null height 3
        use aa_phone_rule(292)

screen aa_phone_bubble(body, sent=False):
    use aa_phone_message(body, sent, 268, "Feka · enviado" if sent else "Recebido", True)

screen aa_phone_picture(asset, height=340, crop=False):
    button:
        padding (0, 0)
        xsize 292
        ysize height
        action Show("aa_phone_image", asset=asset)
        alt "Ampliar fotografia"
        viewport:
            xysize (292, height)
            add Transform(asset, xysize=(292, height), fit=("cover" if crop else "contain")) xalign 0.5 yalign 0.5
    text "Toque na foto para ampliar" size 14 color "#bcb9b7" xalign 0.5

screen aa_phone_image(asset):
    modal True
    zorder 150
    add Solid("#090e17f5")
    add Transform(asset, xysize=(1080, 590), fit="contain") xalign 0.5 yalign 0.43
    textbutton "Voltar à conversa" style "aa_hub_button" action Hide("aa_phone_image") xalign 0.5 ypos 644 text_size 20
    key "game_menu" action Hide("aa_phone_image")
    key "dismiss" action Hide("aa_phone_image")

screen aa_phone_app(kind):
    style_prefix "aa_insert"
    vbox:
        xsize 292
        spacing 12
        if kind in aa_phone_chats:
            $ title, subtitle, messages = aa_phone_chats[kind]
            use aa_phone_header(title, subtitle)
            if kind in ("visita_post", "marcacao"):
                add Transform("post6_copos", xysize=(292, 110), fit="cover")
            for sent, body in messages:
                use aa_phone_bubble(body, sent)
            if kind == "marcacao":
                text "Marcação removida" size 17 color "#c2c8b4"
            if kind == "terminou":
                text "Sem resposta" size 16 color "#bcb9b7"
        elif kind == "emprestimo_pix":
            use aa_phone_header("Pix recebido", "Agora · conta de Feka")
            null height 20
            text "R$ 60,00" size 36 color "#f2eeea"
            text "De Joãozão" size 22 color "#c2c8b4"
            text "Transferência concluída" size 18 color "#bcb9b7"
            null height 25
            add Solid("#55545a") xysize (292, 1)
            text "Combinado entre vocês" size 17 color "#e9cf9f"
            text "Devolver amanhã\naté 12h." size 22 color "#f2eeea"
        elif kind == "comparacao":
            use aa_phone_header("Feka", "Publicação antiga")
            use aa_phone_picture("post6_roupa", 380, True)
            text "Curtido por Yasmin" size 18 color "#e9cf9f"
        elif kind in ("foto", "foto_hesita"):
            use aa_phone_header("Fotografias", "Agora · no restaurante")
            null height 30
            use aa_phone_picture("post6_foto_hesita" if kind == "foto_hesita" else "images/arte-v2/cg2_foto.png", 235)
            text "Salva no aparelho" size 18 color "#c2c8b4"
            text "Não publicada" size 16 color "#bcb9b7"
        elif kind in ("enquadramento", "publicado", "publicado_depois"):
            use aa_phone_header("Câmera" if kind == "enquadramento" else "Feka", "FOTO · 1×" if kind == "enquadramento" else "Publicação · agora")
            viewport:
                xysize (292, 350)
                fixed:
                    xysize (292, 350)
                    add Transform("post6_copos", xysize=(292, 350), fit="cover")
                    if kind == "enquadramento":
                        for x in (97, 194):
                            add Solid("#ffffff44") xpos x xysize (1, 350)
                        for y in (117, 234):
                            add Solid("#ffffff44") ypos y xysize (292, 1)
            if kind == "enquadramento":
                text "FOTO" size 16 color "#e9cf9f" xalign 0.5
                text "○" size 48 color "#f2eeea" xalign 0.5
            else:
                text "Uma noite ótima." size 23 color "#f2eeea"
                if kind == "publicado" or aa_state.get("bond") == "mantido":
                    text "@Vanessa" size 17 color "#e9cf9f"
                text "Ver visualizações" size 15 color "#bcb9b7"
        elif kind in ("rascunho", "rascunho_apagado"):
            use aa_phone_header("Vanessa", "Rascunho")
            null height 100
            frame:
                padding (13, 12)
                xsize 292
                background aa_phone_round("received")
                text ("Sinto muito." if kind == "rascunho" else "Mensagem") size 23 color ("#f2eeea" if kind == "rascunho" else "#929095")
            text ("Não enviado" if kind == "rascunho" else "Rascunho apagado") size 16 color "#bcb9b7"
        elif kind in ("audio", "audio_resposta"):
            use aa_phone_header("Grupo", "Hoje · 22:12")
            frame:
                xalign 1.0
                xsize 270
                padding (14, 14)
                background aa_phone_round("sent")
                vbox:
                    spacing 12
                    text "Você · mensagem de voz" size 16 color "#c2c8b4"
                    hbox:
                        spacing 3
                        for height in (8, 16, 28, 12, 21, 35, 16, 26, 11, 31, 22, 13, 29, 19, 8, 23, 14, 30, 11, 18, 8, 13, 26, 12):
                            add Solid("#c2c8b4") xysize (6, height) yalign 0.5
                    text "Tinham me desrespeitado." size 20 color "#f2eeea"
                    text "Transcrição · enviado" size 14 color "#c2c8b4"
            if kind == "audio_resposta":
                use aa_phone_bubble("Complicado.")
            else:
                text "Segunda gravação · não enviada" size 15 color "#bcb9b7"
        elif kind == "orcamento":
            use aa_phone_header("Minhas notas", "Meu apartamento · amanhã")
            text "Dinheiro separado" size 25 color "#f2eeea"
            text "Guardar para a mudança" size 17 color "#bcb9b7"
            for item, value in (("Caução", "R$ 1.200"), ("Frete", "R$ 180")):
                hbox:
                    xsize 292
                    text item size 21 color "#f2eeea" xsize 145
                    text value size 21 color "#f2eeea" xsize 147 textalign 1.0
            add Solid("#55545a") xysize (292, 1)
            text "Reservado: R$ 1.380" size 21 color "#e9cf9f"
            text "Não usar no restaurante." size 17 color "#bcb9b7"
            null height 10
            text "Jantar de hoje" size 25 color "#f2eeea"
            text "Até R$ 90" size 36 color "#e9cf9f"
            text "Só a minha parte, incluindo bebida e serviço." size 20 color "#f2eeea"
            text "Escolher dentro desse limite." size 17 color "#bcb9b7"
        elif kind == "carro":
            use aa_phone_header("Sua viagem", "Motorista a caminho")
            fixed:
                xysize (292, 220)
                add Solid("#30383a")
                for y in (30, 92, 154, 206):
                    add Solid("#555b5a") ypos y xysize (292, 5)
                for x in (48, 148, 244):
                    add Solid("#555b5a") xpos x xysize (5, 220)
                add Solid("#d2c49e") xpos 49 ypos 34 xysize (103, 5)
                add Solid("#d2c49e") xpos 148 ypos 34 xysize (5, 123)
                add Solid("#d2c49e") xpos 148 ypos 154 xysize (72, 5)
                text "●" xpos 42 ypos 21 size 22 color "#f2eeea"
                text "●" xpos 208 ypos 140 size 22 color "#e9cf9f"
            text "Chega em 4 min" size 27 color "#f2eeea"
            text "Embarque na entrada" size 19 color "#bcb9b7"
        elif kind == "relogio":
            null height 90
            text aa_phone_time() size 66 color "#f2eeea" xalign 0.5
            text "Nenhuma notificação" size 18 color "#bcb9b7" xalign 0.5
