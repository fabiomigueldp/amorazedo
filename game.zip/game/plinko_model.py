"""Eight unbiased deflections; the recorded path drives both money and motion."""
from math import comb

ROWS = 8
DURATION_MS = 3000
FIRST_HIT_MS = 380
HOP_MS = 300
RISKS = {"low": "Baixo", "medium": "Médio", "high": "Alto"}
# Previous rounds retain their original contract when loading an older save.
LEGACY_PAYS = {
    "low": (650, 200, 120, 90, 50, 90, 120, 200, 650),
    "medium": (1500, 400, 150, 50, 20, 50, 150, 400, 1500),
    "high": (5000, 400, 100, 25, 0, 25, 100, 400, 5000),
}
# Hundredths, including stake. Frequent small wins replace part of rare prizes.
PAYS = {
    "low": (300, 150, 115, 105, 60, 105, 115, 150, 300),
    "medium": (500, 200, 150, 102, 20, 102, 150, 200, 500),
    "high": (3000, 650, 110, 25, 0, 25, 110, 650, 3000),
}
WAYS = tuple(comb(ROWS, i) for i in range(ROWS + 1))


def text(multiplier):
    return ("%d,%02d" % divmod(multiplier, 100)).rstrip("0").rstrip(",") + "×"


def payouts(data=None, risk="medium"):
    return tuple(data.get("pays", LEGACY_PAYS[data["risk"]])) if data else PAYS[risk]


def rtp(risk):
    return sum(n * m for n, m in zip(WAYS, PAYS[risk])) / 25600


def new_round(risk, rng):
    path = tuple(rng.randrange(2) for _ in range(ROWS))
    slot = sum(path)
    return dict(risk=risk, path=path, slot=slot, multiplier=PAYS[risk][slot], pays=PAYS[risk], elapsed_ms=0)


def contacts(elapsed_ms):
    return min(ROWS, max(0, (elapsed_ms - FIRST_HIT_MS) // HOP_MS + 1))


def point(path, elapsed_ms):
    """Position in peg spacings, continuous at every recorded contact.

    x=0 is the centre; y=0 is immediately above the first peg. Ballistic
    arcs between contacts have a short upward response and accelerate down.
    There is no sampled physics or frame-dependent integration in the view.
    """
    t = max(0, elapsed_ms)
    if t < FIRST_HIT_MS:
        return 0.0, -1.2 * (1 - (t / FIRST_HIT_MS) ** 2)
    travel = min(ROWS, (t - FIRST_HIT_MS) / HOP_MS)
    row = min(ROWS - 1, int(travel))
    u = travel - row
    x = sum(path[:row]) - row / 2 + (path[row] - .5) * u
    y = row + 1.24 * u * u - .24 * u
    return x, y


def trace(path, elapsed_ms, samples=100):
    end = min(DURATION_MS, max(0, elapsed_ms))
    return tuple(point(path, end * i / samples) for i in range(samples + 1))
