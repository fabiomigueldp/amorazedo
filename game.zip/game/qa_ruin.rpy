label qa_ruin_setup:
    $ aa_world_start()
    $ aa_state = aa_new_state()
    $ aa_state.update(route="juntas", bill="dividida", promised=True)
    $ aa_phone_memory = ()
    jump d00

testsuite aa_ruin:
    setup:
        $ _test.timeout = 20.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = 'C:/Users/fabio/Projects/amor_azedo/output/qa/escalada'
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        exit
    testcase ate_delegacia:
        run Start("qa_ruin_setup")
        advance until screen "choice"
        click "Passar na frente de Yasmin e exigir que ela me escute."
        advance until screen "choice"
        click "Tentar abraçá-la mesmo depois da recusa."
        advance until screen "choice"
        assert eval not aa_state["punched"]
        screenshot "01_recusa.png"
        click "Continuar segurando e mandar Joãozão ficar fora disso."
        advance until "Yasmin tentou puxar o braço outra vez."
        assert eval aa_audio_last_event == "QRUIN_HIT"
        assert eval aa_last_art == "cg15_queda"
        assert eval not aa_phone_active
        screenshot "02_golpe.png"
        advance until screen "choice"
        click "Dizer que eu só queria abraçar Yasmin."
        advance until "Entrei no banco de trás"
        assert eval aa_last_art == "cg15_viatura"
        assert eval aa_present == ()
        advance until screen "choice"
        assert eval aa_last_art == "cg15_depoimento"
        screenshot "03_relato.png"
        click "Omitir que ela pediu para eu soltar e dizer que Joãozão me atacou sem motivo."
        advance until "Fiquei segurando o celular."
        assert eval aa_node == "e12" and aa_state["punched"]
        assert eval aa_state["station_account"] == "omitiu"
        assert eval aa_audio_family is None
        assert eval any(e["kind"] == "depois_agressao" for e in aa_phone_memory)
        screenshot "04_espera.png"
    testcase soltar_antes:
        run Start("qa_ruin_setup")
        advance until screen "choice"
        click "Passar na frente de Yasmin e exigir que ela me escute."
        advance until screen "choice"
        click "Tentar abraçá-la mesmo depois da recusa."
        advance until screen "choice"
        click "Soltar o braço e me afastar."
        advance until "O funcionário me acompanhou até a calçada."
        assert eval not aa_state["punched"]
        assert eval aa_last_art == "cg15_recuo"
