# Messages presentation. The archive and existing choice actions remain authoritative.
init python:
    @functools.lru_cache(maxsize=512)
    def aa_messages_elide(body, width, size, lines=2):
        # Ren'Py has no max-lines property. Measure with the same font instead of
        # guessing a character count (accents and accessibility sizes included).
        def height(value):
            return renpy.render(Text(value, font="fonts/Inter-Regular.ttf", size=size,
                                     line_spacing=1, outlines=[]), width, 4096, 0, 0).height
        limit = height("Ag") * lines + lines - 1
        if height(body) <= limit:
            return body
        low, high = 0, len(body)
        while low < high:
            mid = (low + high + 1) // 2
            if height(body[:mid].rstrip() + "…") <= limit:
                low = mid
            else:
                high = mid - 1
        return body[:low].rstrip() + "…"

    def aa_messages_date(at, full=False):
        if at < 0:
            return "Conversa antiga" if full else "Anterior"
        days = aa_world["now"] // 1440 - at // 1440
        clock = aa_fm.stamp(at).split(" · ")[1]
        date = "Hoje" if days == 0 else "Ontem" if days == 1 else aa_fm.stamp(at).split(" · ")[0]
        return date + " · " + clock if full else clock if days == 0 else date

    def aa_messages_preview(entry, query=""):
        rows = entry["messages"]
        if query.strip():
            matches = [body for _, body in rows if aa_pm.fold(query.strip()) in aa_pm.fold(body)]
            if matches:
                return matches[-1]
        if rows:
            return ("Você: " if rows[-1][0] else "") + rows[-1][1]
        return "Fotografia" if entry.get("image") else ""

    def aa_messages_filter(value):
        renpy.set_screen_variable("message_filter", value, "aa_phone_hub")
        renpy.set_screen_variable("message_panel", None, "aa_phone_hub")
        aa_phone_reset_scroll()
        renpy.restart_interaction()

    def aa_messages_search(active):
        renpy.set_screen_variable("search_active", active, "aa_phone_hub")
        if not active:
            renpy.set_screen_variable("query", "", "aa_phone_hub")
        aa_phone_reset_scroll()
        renpy.restart_interaction()

    def aa_messages_mark_unread(entry):
        aa_phone_preferences.unread = tuple(set(aa_phone_pref("unread", ())) | {entry["id"]})
        renpy.set_screen_variable("message_panel", None, "aa_phone_hub")
        aa_phone_back()
        renpy.retain_after_load()

    def aa_messages_read_all():
        global aa_world
        for notice in aa_world["messages"]:
            aa_world = aa_fm.read(aa_world, notice["id"])
        aa_phone_preferences.unread = ()
        aa_phone_preferences.read = tuple(set(aa_phone_preferences.read) | {e["id"] for e in aa_phone_memory if e["section"] == "messages"})
        renpy.set_screen_variable("message_panel", None, "aa_phone_hub")
        renpy.retain_after_load()
        renpy.restart_interaction()

    # Only these authored *text* choices are available in the composer. Calls and
    # in-person speech are not turned into texts. The original menu still works.
    AA_MESSAGE_REPLIES = {
        "b_wait_reply": ("Vanessa", {
            "Responder que entendi e esperar.": "Entendi. Vou esperar.",
            "Dizer que ela precisa decidir agora.": "Preciso que você decida agora.",
        }),
        "w_night": ("Vanessa", {
            "Responder que hoje preciso estudar e combinar falar amanhã.": "Preciso terminar uma leitura hoje. Podemos falar amanhã depois da aula?",
        }),
    }

    def aa_messages_replies(contact):
        choice = renpy.get_screen("choice")
        target, captions = AA_MESSAGE_REPLIES.get(aa_node, (None, {}))
        if not choice or contact != target:
            return ()
        return tuple((item, captions[item.caption]) for item in choice.scope.get("items", ())
                     if item.caption in captions and item.action is not None)

    def aa_messages_send_reply(contact, caption):
        # Recheck at activation so a stale sheet cannot trigger another scene.
        reply = next(((item, body) for item, body in aa_messages_replies(contact) if item.caption == caption), None)
        if reply is None:
            return
        item, body = reply
        aa_phone_close()
        return renpy.run(item.action)

    def aa_messages_archive_choice(node_id, index):
        # Canonical choice hook: the ordinary story menu and the phone produce
        # exactly the same archive entry, state transitions and rollback history.
        contact, captions = AA_MESSAGE_REPLIES.get(node_id, (None, {}))
        body = captions.get(aa_nodes[node_id]["choices"][index]["text"])
        if body is not None:
            aa_chapter_message(dict(id="phone_reply_" + node_id, sender=contact, body=body, outgoing=True))

style aa_messages_text is aa_hub_text:
    size 17
    color "#f5f5f7"
    line_spacing 1
style aa_messages_secondary is aa_messages_text:
    color "#a4a4ac"
style aa_messages_row is button:
    background None
    hover_background aa_phone_round("message-hover")
    padding (0, 0)
style aa_messages_action is aa_messages_row:
    padding (14, 13)
    yminimum 44
style aa_messages_action_text is aa_messages_text:
    color "#70b5ff"
    insensitive_color "#6e6e76"

screen aa_messages_control(icon, action, label, size=44):
    button:
        style "aa_messages_row"
        xysize (size, size)
        background Transform(aa_phone_asset("message-glass-solid-circle" if aa_phone_pref("glass", .55) >= .95 else "message-glass-circle"), xysize=(size, size))
        hover_background aa_phone_round("message-hover", size // 2)
        action action
        alt label
        add aa_phone_asset("icon-" + icon) xysize (21, 21) align (.5, .5)

screen aa_messages_bubble(body, sent, width, tail=True, compact=False):
    frame:
        background aa_phone_round(("message-bubble-" if tail else "") + ("sent" if sent else "received"), 24)
        padding (12, 8)
        xmaximum width
        xalign (1.0 if sent else 0.0)
        text body:
            style "aa_messages_text"
            size (19 if compact else aa_phone_size(17))
            color "#ffffff"
            xmaximum (width - 24)
            alt (("Você: " if sent else "Mensagem recebida: ") + body)

screen aa_messages_thread(entry, width):
    for row in aa_pm.message_rows(entry):
        if row["separator"]:
            null height 12
            text aa_messages_date(row["at"], True) style "aa_messages_secondary" size aa_phone_size(11) xalign .5
            null height 12
        if row["asset"]:
            button:
                style "aa_messages_row"
                xalign (1.0 if row["sent"] else 0.0)
                padding (5, 0)
                action Show("aa_phone_image", asset=row["asset"])
                alt "Ampliar fotografia da conversa"
                add aa_phone_thumbnail(row["asset"], width - 48, 156) xysize (width - 48, 156)
            null height 4
        use aa_messages_bubble(row["body"], row["sent"], width - 28, row["tail"])
        null height (9 if row["tail"] else 3)
    for paragraph in entry["paragraphs"]:
        text paragraph style "aa_messages_secondary" size aa_phone_size(12) xalign .5 textalign .5 xmaximum (width - 24)
    null height 12

screen aa_messages_list_row(item, width, query=""):
    $ row_height = 86 + 3 * (aa_phone_size(14) - 14)
    button:
        style "aa_messages_row"
        xysize (width, row_height)
        action Function(aa_phone_select, item)
        alt (item["title"] + (" · Não lida" if item["unread"] else ""))
        fixed:
            xysize (width, row_height)
            if item["unread"]:
                add aa_phone_asset("message-dot") xpos 0 ypos 37 xysize (7, 7)
            fixed:
                xpos 13
                ypos 20
                use aa_phone_avatar(item["title"], 43)
            text aa_messages_elide(item["title"], width - 132, aa_phone_size(16), 1):
                style "aa_messages_text"
                font "fonts/Inter-SemiBold.ttf"
                size aa_phone_size(16)
                xpos 65
                ypos 14
                xmaximum (width - 130)
                ysize aa_phone_size(26)
                layout "nobreak"
            text aa_messages_date(item["at"]) style "aa_messages_secondary" size 11 xpos (width - 19) xanchor 1.0 ypos 18
            add aa_phone_asset("icon-forward") xpos (width - 13) ypos 18 xysize (10, 10) alpha .45
            text aa_messages_elide(aa_messages_preview(item, query), width - 69, aa_phone_size(14)):
                style "aa_messages_secondary"
                size aa_phone_size(14)
                xpos 65
                ypos (39 + aa_phone_size(14) - 14)
                xsize (width - 69)
                line_spacing 1
                line_leading 0
            add Solid("#2b2b2e") xpos 65 ypos (row_height - 1) xysize (width - 65, 1)

screen aa_messages_empty(title, body, width):
    vbox:
        xsize width
        spacing 10
        null height 78
        add aa_phone_asset("icon-chat") xysize (36, 36) xalign .5 alpha .45
        text title style "aa_phone_title" size aa_phone_size(22) textalign .5 xalign .5 xmaximum (width - 24)
        text body style "aa_messages_secondary" size aa_phone_size(15) textalign .5 xalign .5 xmaximum (width - 30)

screen aa_messages_app(width, height, entry, query, search_active, message_filter, message_panel, scroll, read_only=False):
    $ listing = aa_phone_search(aa_phone_threads(), query)
    $ listing = tuple(t for t in listing if message_filter != "unread" or t["unread"])
    $ listing = tuple(t for t in listing if message_filter != "pinned" or aa_phone_is_favorite(t["id"]))
    $ pinned = tuple(t for t in listing if aa_phone_is_favorite(t["id"])) if not search_active and message_filter == "all" else ()
    $ regular = tuple(t for t in listing if t not in pinned)
    if entry:
        if not read_only:
            fixed:
                xpos 12
                ypos 50
                use aa_messages_control("back", Function(aa_phone_back), "Voltar às conversas")
        button:
            style "aa_messages_row"
            xalign .5
            ypos 45
            xysize (width - 128, 76)
            action (Function(aa_phone_open, entry["title"]) if read_only else SetScreenVariable("message_panel", "contact"))
            alt (("Abrir conversa com " if read_only else "Informações de ") + entry["title"])
            vbox:
                xalign .5
                spacing 5
                fixed:
                    xalign .5
                    xysize (42, 42)
                    use aa_phone_avatar(entry["title"], 42)
                hbox:
                    xalign .5
                    spacing 3
                    text entry["title"] style "aa_messages_text" font "fonts/Inter-Medium.ttf" size 13 xmaximum (width - 144)
                    add aa_phone_asset("icon-forward") xysize (10, 10) yalign .5 alpha .65
        viewport:
            id "phone_scroll"
            xpos 9
            ypos 128
            xysize (width - 18, height - 228)
            mousewheel True
            draggable True
            arrowkeys True
            pagekeys True
            yadjustment scroll
            vbox:
                xsize (width - 18)
                use aa_messages_thread(entry, width - 18)
        $ replies = () if read_only else aa_messages_replies(entry["title"])
        text ("Escolha como responder" if replies else "Respostas disponíveis durante a história"):
            style "aa_messages_secondary"
            size 11
            xalign .5
            ypos (height - 94)
        button:
            style "aa_messages_row"
            background aa_phone_round("message-field", 24)
            xpos 13
            ypos (height - 73)
            xysize (width - 26, 44)
            sensitive bool(replies)
            action SetScreenVariable("message_panel", "reply")
            alt ("Escolher resposta" if replies else "Nenhuma resposta disponível nesta cena")
            text ("Responder…" if replies else "Mensagem") style "aa_messages_secondary" size 15 xpos 15 yalign .5
            add aa_phone_asset("icon-send") xysize (21, 21) xpos (width - 61) yalign .5 alpha (1.0 if replies else .25)
    else:
        text ("Buscar" if search_active else "Não lidas" if message_filter == "unread" else "Fixadas" if message_filter == "pinned" else "Mensagens"):
            style "aa_phone_title"
            color "#ffffff"
            size 30
            xpos 17
            ypos 64
            xmaximum (width - 77)
        fixed:
            xpos (width - 57)
            ypos 57
            use aa_messages_control("filter", SetScreenVariable("message_panel", "filters"), "Filtrar conversas")
        viewport:
            id "phone_scroll"
            xpos 11
            ypos 117
            xysize (width - 22, height - 208)
            mousewheel True
            draggable True
            arrowkeys True
            pagekeys True
            yadjustment scroll
            vbox:
                xsize (width - 22)
                if pinned:
                    vpgrid:
                        cols 3
                        xsize (width - 22)
                        spacing 0
                        for item in pinned:
                            button:
                                style "aa_messages_row"
                                xysize ((width - 22) // 3, 104)
                                action Function(aa_phone_select, item)
                                alt (item["title"] + " · Fixada")
                                vbox:
                                    xalign .5
                                    spacing 7
                                    fixed:
                                        xysize (60, 60)
                                        use aa_phone_avatar(item["title"], 60)
                                        if item["unread"]:
                                            add aa_phone_asset("message-dot") xpos 49 ypos 48 xysize (11, 11)
                                    text item["title"] style "aa_messages_text" size 13 xalign .5 xmaximum 88 textalign .5
                    null height 10
                for choice_item in aa_phone_context_actions("messages"):
                    textbutton choice_item.caption style "aa_messages_action" text_size aa_phone_size(15) xsize (width - 22) action [Function(aa_phone_close), choice_item.action]
                if not listing:
                    use aa_messages_empty("Nenhum resultado" if query else "Tudo lido" if message_filter == "unread" else "Nenhuma conversa fixada" if message_filter == "pinned" else "Suas mensagens", "Tente outro nome ou uma palavra da conversa." if query else "As próximas mensagens aparecerão aqui." if message_filter == "unread" else "Abra um contato para fixar sua conversa." if message_filter == "pinned" else "As conversas da sua história aparecem aqui.", width - 22)
                for item in regular:
                    use aa_messages_list_row(item, width - 22, query)
                null height 12
        fixed:
            xpos 12
            ypos (height - 78)
            xysize (width - 24, 46)
            add aa_phone_round("message-glass-solid" if aa_phone_pref("glass", .55) >= .95 else "message-glass", 30) xysize (width - 78, 46)
            if search_active:
                add aa_phone_asset("icon-search") xpos 14 ypos 13 xysize (20, 20) alpha .7
                input:
                    id "message_search_input"
                    value ScreenVariableInputValue("query")
                    length 60
                    style "aa_messages_text"
                    size 16
                    xpos 42
                    ypos 13
                    xmaximum (width - 134)
                    default_focus True
                    copypaste True
            else:
                button:
                    style "aa_messages_row"
                    xysize (width - 78, 46)
                    action Function(aa_messages_search, True)
                    alt "Buscar mensagens"
                    fixed:
                        xysize (width - 78, 46)
                        add aa_phone_asset("icon-search") xpos 14 ypos 13 xysize (20, 20) alpha .7
                        text "Buscar" style "aa_messages_secondary" size 16 xpos 42 yalign .5
            fixed:
                xpos (width - 68)
                use aa_messages_control("close" if search_active else "compose", Function(aa_messages_search, False) if search_active else SetScreenVariable("message_panel", "compose"), "Cancelar busca" if search_active else "Nova mensagem", 46)
    if message_panel:
        use aa_messages_panel(width, height, entry, message_panel, message_filter)

screen aa_messages_panel(width, height, entry, panel, message_filter):
    button:
        xysize (width, height - 30)
        background Solid("#000000a0")
        action SetScreenVariable("message_panel", None)
        alt "Fechar painel de mensagens"
    frame:
        xpos 7
        ypos 108
        xysize (width - 14, height - 143)
        background aa_phone_round("message-sheet", 24)
        padding (14, 15)
        fixed:
            xysize (width - 42, height - 173)
            text {"filters": "Mensagens", "contact": "Contato", "compose": "Nova mensagem", "reply": "Responder"}[panel] style "aa_phone_title" size 21 ypos 8 xmaximum (width - 96)
            fixed:
                xpos (width - 85)
                use aa_messages_control("close", SetScreenVariable("message_panel", None), "Fechar painel", 44)
            viewport:
                id "message_panel_scroll"
                ypos 57
                xysize (width - 42, height - 239)
                mousewheel True
                draggable True
                arrowkeys True
                vbox:
                    xsize (width - 42)
                    spacing 9
                    if panel == "filters":
                        for value, title in (("all", "Todas as mensagens"), ("unread", "Não lidas"), ("pinned", "Fixadas")):
                            button:
                                style "aa_messages_action"
                                xfill True
                                selected message_filter == value
                                action Function(aa_messages_filter, value)
                                alt title
                                hbox:
                                    spacing 12
                                    text title style "aa_messages_text" size 16 xsize (width - 116)
                                    if message_filter == value:
                                        add aa_phone_asset("icon-check") xysize (20, 20) yalign .5
                        null height 8
                        add Solid("#38383c") xysize (width - 42, 1)
                        textbutton "Marcar todas como lidas" style "aa_messages_action" text_size 16 xfill True sensitive aa_phone_badge("messages") > 0 action Function(aa_messages_read_all)
                    elif panel == "contact" and entry:
                        fixed:
                            xsize (width - 42)
                            ysize 83
                            fixed:
                                xalign .5
                                xysize (76, 76)
                                use aa_phone_avatar(entry["title"], 76)
                        text entry["title"] style "aa_phone_title" size 24 xalign .5 xmaximum (width - 42) textalign .5
                        textbutton ("Desafixar conversa" if aa_phone_is_favorite(entry["id"]) else "Fixar conversa") style "aa_messages_action" xfill True action Function(aa_phone_favorite, entry["id"])
                        textbutton "Marcar como não lida" style "aa_messages_action" text_size 16 xfill True action Function(aa_messages_mark_unread, entry)
                        $ photos = tuple(dict.fromkeys(a for a in entry.get("message_assets", ()) if a))
                        if photos:
                            text "Fotos" style "aa_phone_title" size 21
                            for asset in photos:
                                button:
                                    style "aa_messages_row"
                                    action Show("aa_phone_image", asset=asset)
                                    alt "Ampliar foto compartilhada"
                                    add aa_phone_thumbnail(asset, width - 48, 146) xysize (width - 48, 146)
                    elif panel == "compose":
                        text "Para:" style "aa_messages_secondary" size 15
                        if not aa_phone_threads():
                            text "Seus contatos aparecem conforme a história avança." style "aa_messages_secondary" size 16
                        for item in aa_phone_threads():
                            button:
                                style "aa_messages_action"
                                xfill True
                                action Function(aa_phone_select, item)
                                alt ("Conversar com " + item["title"])
                                hbox:
                                    spacing 12
                                    use aa_phone_avatar(item["title"], 32)
                                    text item["title"] style "aa_messages_text" size 16 yalign .5 xmaximum (width - 116)
                    elif panel == "reply" and entry:
                        for item, body in aa_messages_replies(entry["title"]):
                            button:
                                style "aa_messages_action"
                                background aa_phone_round("message-hover")
                                xfill True
                                action Function(aa_messages_send_reply, entry["title"], item.caption)
                                alt item.caption
                                text body style "aa_messages_text" size aa_phone_size(16) xmaximum (width - 70)
                        text "A resposta continua a cena." style "aa_messages_secondary" size 12
