# Native handset UI. Rendering is read-only; actions reuse the campaign model.
init python:
    def aa_phone_scroll_key(entry):
        return entry["id"] + ":" + str(len(entry.get("messages", ())))

    def aa_phone_store_scroll():
        screen = renpy.get_screen("aa_phone_hub")
        if screen and screen.scope.get("selected_entry"):
            entry = screen.scope["selected_entry"]
            positions = dict(aa_phone_pref("positions", {}))
            positions[aa_phone_scroll_key(entry)] = screen.scope["scroll"].value
            aa_phone_preferences.positions = positions

    def aa_phone_scroll_ready(adjustment):
        screen = renpy.get_screen("aa_phone_hub")
        if not screen or screen.scope.get("scroll") is not adjustment:
            return
        target = screen.scope.get("pending_scroll")
        if target is not None and adjustment.range > 0:
            screen.scope["pending_scroll"] = None
            adjustment.change(adjustment.range if target == "bottom" else min(target, adjustment.range))

    def aa_phone_reset_scroll(position=0):
        renpy.set_screen_variable("pending_scroll", position, "aa_phone_hub")
        renpy.set_screen_variable("scroll", ui.adjustment(ranged=aa_phone_scroll_ready), "aa_phone_hub")

    def aa_phone_go(page):
        aa_phone_store_scroll()
        if page != "casino":
            aa_casino_silence()
        aa_phone_preferences.page = page
        for name, value in (("page", page), ("selected_entry", None), ("favorites_only", False),
                            ("query", ""), ("search_active", page == "search"), ("photo_zoom", False),
                            ("message_panel", None), ("message_filter", "all"), ("message_return_search", False)):
            renpy.set_screen_variable(name, value, "aa_phone_hub")
        aa_phone_reset_scroll()
        if page == "bank":
            aa_bank_nav("account")
        renpy.restart_interaction()

    def aa_phone_close():
        aa_phone_store_scroll()
        aa_casino_silence()
        renpy.hide_screen("aa_phone_hub")
        renpy.restart_interaction()

    def aa_phone_back():
        screen = renpy.get_screen("aa_phone_hub")
        if not screen:
            return
        scope = screen.scope
        if scope["photo_zoom"]:
            renpy.set_screen_variable("photo_zoom", False, "aa_phone_hub")
        elif scope.get("message_panel"):
            renpy.set_screen_variable("message_panel", None, "aa_phone_hub")
        elif scope["page"] == "casino" and scope.get("casino_panel"):
            aa_casino_panel(None)
        elif scope["page"] == "casino" and scope.get("casino_view", "lobby") != "lobby":
            aa_casino_nav("lobby")
        elif scope["page"] == "bank" and (scope.get("bank_detail") or scope.get("selected_entry")):
            aa_bank_back()
        elif scope["page"] == "bank" and scope.get("bank_search"):
            aa_bank_search(False)
        elif scope["search_active"]:
            renpy.set_screen_variable("search_active", False, "aa_phone_hub")
            renpy.set_screen_variable("query", "", "aa_phone_hub")
        elif scope["selected_entry"]:
            aa_phone_store_scroll()
            renpy.set_screen_variable("selected_entry", None, "aa_phone_hub")
            if scope["page"] == "messages" and scope.get("message_return_search"):
                renpy.set_screen_variable("search_active", True, "aa_phone_hub")
                renpy.set_screen_variable("message_return_search", False, "aa_phone_hub")
            aa_phone_reset_scroll()
        elif scope["page"] != "home":
            aa_phone_go("home")
        else:
            aa_phone_close()
        renpy.restart_interaction()

    def aa_phone_search(items, query):
        import unicodedata
        def fold(s):
            return ''.join(c for c in unicodedata.normalize('NFD', s.casefold()) if unicodedata.category(c) != 'Mn')
        needle = fold(query.strip())
        return tuple(item for item in items if needle in fold(item["title"] + " " + " ".join(body for _, body in item["messages"])))

    def aa_phone_badge(app):
        if app == "messages":
            return sum(1 for thread in aa_phone_threads() if thread["unread"])
        if app in ("social", "photos", "notes"):
            return sum(1 for entry in aa_pm.app_entries(aa_phone_memory, app) if entry["id"] not in aa_phone_preferences.read)
        return 0

    def aa_phone_set_pref(name, value):
        setattr(aa_phone_preferences, name, value)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_phone_after_load():
        # New appearance fields use getattr defaults; old archive IDs stay valid.
        aa_casino_silence()
        for screen in ("aa_phone_hub", "aa_phone_image", "aa_transfer_confirm", "aa_dinner_receipt"):
            renpy.hide_screen(screen)

    config.after_load_callbacks.append(aa_phone_after_load)
    config.overlay_screens.append("aa_phone_access")

screen aa_phone_access():
    zorder 105
    if aa_phone_active and quick_menu and not main_menu and not renpy.get_screen("aa_phone_hub") and not renpy.get_screen("aa_phone_image"):
        key "p" action Function(aa_phone_open)
        button:
            xpos 1256
            xanchor 1.0
            ypos 20
            xysize (184, 50)
            padding (14, 10)
            style "aa_hub_button"
            background aa_phone_round("glass-solid" if aa_phone_pref("glass", .55) >= .95 else "glass")
            action Function(aa_phone_open)
            alt "Celular"
            hbox:
                spacing 12
                use aa_hub_icon("phone", 23)
                text aa_balance_text() style "aa_hub_text" size 18 yalign 0.5
        if aa_phone_new():
            add aa_phone_asset("badge") xpos 1241 ypos 16 xysize (11, 11)

screen aa_phone_app_icon(app, size=54, cell=84, dock=False):
    $ title = AA_PHONE_APPS[app][0]
    $ badge = aa_phone_badge(app)
    button:
        padding (0, 0)
        xysize (cell, size + (8 if dock else 23))
        background None
        action Function(aa_phone_go, app)
        alt title
        at aa_phone_press
        fixed:
            xysize (cell, size + (8 if dock else 23))
            add aa_phone_app_art(app, size) xysize (size, size) xalign 0.5
            if app == "calendar":
                $ icon_today = aa_phone_calendar()[0]
                add Solid("#ffffff") xpos ((cell - size) // 2 + 7) ypos 6 xysize (size - 14, size - 11)
                text ("SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM")[icon_today.weekday()] style "aa_hub_text" font "fonts/Inter-Medium.ttf" size 8 color "#ee3843" xalign 0.5 ypos 6
                text str(icon_today.day) style "aa_hub_text" font "fonts/Inter-Light.ttf" size 30 color "#161619" xalign 0.5 ypos 16
            if not dock:
                text title style "aa_hub_text" size 12 xalign 0.5 ypos (size + 5) outlines [(1, "#172d3c88", 0, 1)]
            if badge:
                frame:
                    background aa_phone_round("badge")
                    padding (5, 1)
                    xpos (cell // 2 + size // 2 - 8)
                    ypos -5
                    text str(badge) style "aa_hub_text" size 12

screen aa_phone_home(width, height):
    $ cell = (width - 12) // 4
    $ icon_size = min(50, cell - 21)
    $ dock_y = height - 98
    $ search_y = dock_y - 40
    $ row_step = (search_y - 12 - icon_size - 23 - 12) // 5
    fixed:
        xysize (width, height)
        for row, apps in enumerate(AA_PHONE_GRID if aa_phone_pref("home_page", 0) == 0 else (("casino",),)):
            hbox:
                xpos ((width - cell * 4) // 2)
                ypos (12 + row * row_step)
                for app in apps:
                    use aa_phone_app_icon(app, icon_size, cell)
        textbutton "Buscar":
            style "aa_hub_button"
            background aa_phone_round("glass", 15)
            hover_background aa_phone_round("glass-hover", 15)
            text_size 12
            padding (0, 0)
            xysize (72, 30)
            text_align (0.5, 0.5)
            xalign 0.5
            ypos search_y
            action Function(aa_phone_go, "search")
        for target, px, caption in ((0, 22, "‹"), (1, width - 66, "›")):
            textbutton caption:
                style "aa_hub_button"
                background None
                xysize (44, 44)
                padding (0, 0)
                text_size 28
                text_align (.5, .5)
                xpos px
                ypos (search_y - 7)
                sensitive aa_phone_pref("home_page", 0) != target
                action Function(aa_phone_set_pref, "home_page", target)
                alt ("Primeira página de apps" if target == 0 else "Segunda página de apps")
        fixed:
            xpos 10
            ypos dock_y
            xysize (width - 20, 82)
            use aa_phone_glass(width - 20, 82, (10, dock_y + 44, width, height + 44))
            hbox:
                xalign 0.5
                ypos 14
                for app in AA_PHONE_DOCK:
                    use aa_phone_app_icon(app, icon_size + 2, (width - 28) // 4, True)

screen aa_phone_filters(width, favorites_only, scroll):
    hbox:
        spacing 8
        textbutton "Tudo" style "aa_hub_button" text_size 15 selected not favorites_only action [Function(scroll.change, 0), SetScreenVariable("favorites_only", False)]
        textbutton "Favoritos" style "aa_hub_button" text_size 15 selected favorites_only action [Function(scroll.change, 0), SetScreenVariable("favorites_only", True)]

screen aa_phone_context_choices(page, width):
    for choice_item in aa_phone_context_actions(page):
        textbutton choice_item.caption:
            style "aa_hub_button"
            text_size aa_phone_size(17)
            xsize width
            text_xmaximum (width - 32)
            action [Function(aa_phone_close), choice_item.action]

screen aa_phone_detail(entry, width):
    if entry["kind"] == "thread":
        use aa_messages_thread(entry, width)
    else:
        text entry["subtitle"] style "aa_hub_muted" size aa_phone_size(16)
        if entry.get("at", -1) >= 0:
            text aa_fm.stamp(entry["at"]) style "aa_hub_muted" size 13
        if entry.get("image"):
            button:
                padding (0, 8)
                action SetScreenVariable("photo_zoom", True)
                alt "Ampliar fotografia"
                add Transform(entry["image"], xysize=(width, 280), fit="contain")
        if entry.get("amount") is not None:
            text aa_pm.brl(entry["amount"]) style "aa_phone_title" size 38
        for paragraph in entry["paragraphs"]:
            text paragraph style "aa_hub_text" size aa_phone_size(20) xmaximum width
        null height 16

screen aa_phone_library(page, width, query, favorites_only):
    $ items = aa_pm.app_entries(aa_phone_memory, page, aa_phone_preferences.favorites, favorites_only, query)
    if not items:
        use aa_hub_empty(AA_PHONE_APPS[page][1], "Nada por aqui" if query or favorites_only else {"photos": "Suas fotos", "social": "Seus momentos", "notes": "Suas anotações"}[page], "Tente outra busca ou veja todos os itens." if query or favorites_only else {"photos": "As fotografias que você tirar ficam aqui.", "social": "Publicações vistas e compartilhadas durante a sua história.", "notes": "Informações que compartilharam com você, reunidas em um lugar."}[page])
    if page == "photos" and items:
        $ tile = (width - 10) // 2
        vpgrid:
            cols 2
            spacing 10
            xsize width
            for item in items:
                button:
                    background None
                    hover_background aa_phone_round("hover")
                    padding (0, 0)
                    action Function(aa_phone_select, item, page)
                    alt item["title"]
                    vbox:
                        spacing 7
                        add aa_phone_thumbnail(item["image"], tile, tile + 18) xysize (tile, tile + 18)
                        text item["title"] style "aa_hub_text" size aa_phone_size(15) xmaximum tile
                        text ("Publicada" if item["kind"] in aa_pm.SOCIAL_KINDS else "No aparelho") style "aa_hub_muted" size 12
    else:
        for item in items:
            if page == "social":
                $ author = "Yasmin" if item["kind"] in ("publicacao", "restaurante") else "Feka"
                null height 4
                hbox:
                    spacing 10
                    use aa_phone_avatar(author, 34)
                    vbox:
                        text author style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size 17
                        text item["subtitle"] style "aa_hub_muted" size 13
                button:
                    padding (0, 0)
                    xsize width
                    action Function(aa_phone_select, item, page)
                    alt ("Abrir publicação de " + author)
                    add Transform(item["image"], xysize=(width, 300), fit="contain") xalign 0.5
                if item["title"] != author:
                    text item["title"] style "aa_hub_text" size aa_phone_size(18)
                if item["kind"] != "publicacao":
                    for paragraph in item["paragraphs"]:
                        text paragraph style "aa_hub_muted" size aa_phone_size(15)
                null height 8
            else:
                button:
                    style "aa_hub_row"
                    action Function(aa_phone_select, item, page)
                    vbox:
                        spacing 7
                        text item["title"] style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(20)
                        text item["subtitle"] style "aa_hub_muted" size aa_phone_size(15)
                        if item["paragraphs"]:
                            text item["paragraphs"][0] style "aa_hub_muted" size aa_phone_size(16)
            use aa_phone_rule(width)

screen aa_phone_settings(width):
    $ preview_width = (width - 12) // 2 - 12
    text "Do seu jeito" style "aa_phone_title" size aa_phone_size(24)
    text "Papel de parede" style "aa_hub_muted" size aa_phone_size(16)
    hbox:
        spacing 12
        for name, title in (("tide", "Maré"), ("dusk", "Entardecer")):
            button:
                padding (6, 6)
                background aa_phone_round("hover" if aa_phone_pref("wallpaper", "tide") == name else "plain")
                action Function(aa_phone_set_pref, "wallpaper", name)
                alt ("Papel de parede " + title)
                vbox:
                    spacing 7
                    add AlphaMask(aa_phone_cover(aa_phone_asset("wallpaper-" + name), preview_width, 140), aa_phone_round("mask")) xysize (preview_width, 140)
                    text title style "aa_hub_text" size 14 xalign 0.5
    null height 8
    text "Transparência" style "aa_phone_title" size aa_phone_size(23)
    text "Mais cor deixa os controles mais opacos." style "aa_hub_muted" size aa_phone_size(16)
    bar:
        value FieldValue(aa_phone_preferences, "glass", range=1.0)
        xsize width
        ysize 28
        left_bar aa_phone_round("primary")
        right_bar aa_phone_round("received")
        thumb Transform(aa_phone_round("mask", 13), xysize=(26, 26))
        thumb_offset 0
        thumb_shadow None
        alt "Opacidade do vidro"
    hbox:
        xsize width
        text "Translúcido" style "aa_hub_muted" size 14 xsize (width // 2)
        text "Opaco" style "aa_hub_muted" size 14 xsize (width // 2) textalign 1.0
    null height 12
    text "Tamanho do texto" style "aa_phone_title" size aa_phone_size(23)
    hbox:
        spacing 8
        for amount, caption in ((0, "Padrão"), (3, "Maior")):
            textbutton caption style "aa_hub_button" text_size 16 selected aa_phone_pref("text_size", 0) == amount action Function(aa_phone_set_pref, "text_size", amount)
    textbutton ("Movimento: ligado" if persistent.aa_motion else "Movimento: reduzido"):
        style "aa_hub_button"
        text_size 16
        action ToggleField(persistent, "aa_motion")
    null height 10
    text "P guarda o celular. Esc volta uma tela. A barra inferior leva ao início." style "aa_hub_muted" size aa_phone_size(15)

screen aa_phone_hub():
    modal True
    zorder 140
    default page = aa_phone_preferences.page if aa_phone_preferences.page in AA_PHONE_APPS else "home"
    default selected_entry = None
    default favorites_only = False
    default photo_zoom = False
    default search_active = False
    default query = ""
    default message_panel = None
    default message_filter = "all"
    default message_return_search = False
    default casino_view = "lobby"
    default casino_panel = None
    default casino_amount = aa_phone_pref("casino_amount", "5,00")
    default casino_roulette = aa_phone_pref("casino_roulette", "red")
    default casino_dice = aa_phone_pref("casino_dice", "under")
    default casino_mines = aa_phone_pref("casino_mines", 3)
    default casino_busy = None
    default casino_started = None
    default casino_duration = 0.0
    default casino_record = None
    default casino_history_filter = "all"
    default casino_error = ""
    default casino_scroll = ui.adjustment()
    default bank_tab = "account"
    default bank_detail = None
    default bank_trail = ()
    default bank_filter = "all"
    default bank_query = ""
    default bank_search = False
    default bank_payments = "pending"
    default bank_limit = 40
    default bank_scroll = ui.adjustment()
    default pending_scroll = None
    default scroll = ui.adjustment(ranged=aa_phone_scroll_ready)
    $ handset_height = AA_PHONE_POV_HEIGHT if aa_phone_pov else AA_PHONE_BODY_HEIGHT
    $ handset_x, handset_width = ((AA_PHONE_POV_POSITION[0], aa_phone_body_size(handset_height)[0]) if aa_phone_pov else aa_phone_geometry())
    $ screen_x, screen_y, inner_width, inner_height = aa_phone_screen_geometry(handset_width, handset_height)
    $ content_width = inner_width - 44
    $ titles = AA_PHONE_APPS
    button:
        xfill True
        yfill True
        background Solid("#080e185c")
        action Function(aa_phone_close)
        alt "Guardar celular e voltar à cena"
    if not search_active and not (page == "bank" and bank_search and not bank_detail and not selected_entry):
        key "p" action Function(aa_phone_close)
    fixed:
        xpos handset_x
        ypos (AA_PHONE_POV_POSITION[1] if aa_phone_pov else 18)
        xysize (handset_width, handset_height)
        at aa_hub_enter
        fixed:
            id "phone_display"
            xpos screen_x
            ypos screen_y
            xysize (inner_width, inner_height)
            if page == "home":
                add AlphaMask(aa_phone_wallpaper(inner_width, inner_height), aa_phone_screen_mask(inner_width, inner_height))
            else:
                add AlphaMask(Solid("#000000" if page == "messages" else "#161318" if page == "casino" else "#111613" if page == "bank" else "#151a22"), aa_phone_screen_mask(inner_width, inner_height)) xysize (inner_width, inner_height)
            button:
                xysize (inner_width, inner_height)
                background None
                action NullAction()
                alt "Celular de Feka"
            text aa_phone_time() style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size 14 xpos 20 ypos 13
            add aa_phone_asset("status") xpos (inner_width - 74) ypos 15 xysize (58, 15)
            if page == "home":
                fixed:
                    ypos 44
                    use aa_phone_home(inner_width, inner_height - 44)
            elif page == "messages":
                use aa_messages_app(inner_width, inner_height, selected_entry, query, search_active, message_filter, message_panel, scroll)
            elif page == "casino":
                use aa_casino_app(inner_width, inner_height, casino_view, casino_panel, casino_amount, casino_roulette, casino_dice, casino_mines, casino_busy, casino_error, casino_scroll, casino_record, casino_history_filter)
            elif page == "bank":
                use aa_bank_app(inner_width, inner_height, bank_tab, bank_detail, bank_filter, bank_query, bank_search, bank_payments, bank_limit, bank_scroll, selected_entry)
            else:
                $ has_header_action = (selected_entry and selected_entry["section"] != "bank") or (not selected_entry and page in ("messages", "photos", "social", "notes"))
                fixed:
                    xpos 14
                    ypos 53
                    xysize (inner_width - 28, 60)
                    use aa_phone_control("back", Function(aa_phone_back), "Voltar")
                    text (selected_entry["title"] if selected_entry else titles[page][0]):
                        style "aa_phone_title"
                        size (21 if selected_entry or has_header_action else 26)
                        xpos 55
                        yalign 0.38
                        xmaximum (inner_width - 83 - (54 if has_header_action else 0))
                        layout "subtitle"
                    if has_header_action:
                        fixed:
                            xpos (inner_width - 74)
                            if selected_entry:
                                use aa_phone_control("star", Function(aa_phone_favorite, selected_entry["id"]), "Remover dos favoritos" if aa_phone_is_favorite(selected_entry["id"]) else "Guardar nos favoritos", aa_phone_is_favorite(selected_entry["id"]))
                            else:
                                use aa_phone_control("search", SetScreenVariable("search_active", not search_active), "Buscar")
                viewport:
                    id "phone_scroll"
                    xpos 17
                    ypos 122
                    xysize (inner_width - 34, inner_height - 192)
                    mousewheel True
                    draggable True
                    arrowkeys True
                    pagekeys True
                    yadjustment scroll
                    scrollbars "vertical"
                    style_prefix "aa_hub_scroll"
                    vbox:
                        xsize content_width
                        spacing 12
                        if search_active and not selected_entry:
                            frame:
                                background aa_phone_round("received")
                                padding (14, 12)
                                xsize content_width
                                input:
                                    value ScreenVariableInputValue("query")
                                    length 60
                                    style "aa_hub_text"
                                    size aa_phone_size(18)
                                    xmaximum (content_width - 28)
                                    default_focus True
                                    copypaste True
                            text ("Busque um aplicativo" if page == "search" else "Busque por nome ou conteúdo") style "aa_hub_muted" size 13
                        if selected_entry:
                            use aa_phone_detail(selected_entry, content_width)
                        elif page == "settings":
                            use aa_phone_settings(content_width)
                        elif page not in ("messages", "photos", "social", "notes"):
                            use aa_phone_system_app(page, content_width, query)
                        else:
                            use aa_phone_context_choices(page, content_width)
                            use aa_phone_filters(content_width, favorites_only, scroll)
                            use aa_phone_library(page, content_width, query, favorites_only)
                        null height 18
                textbutton "Guardar":
                    style "aa_hub_button"
                    text_size 14
                    xpos (inner_width - 118)
                    ypos (inner_height - 64)
                    ysize 40
                    padding (16, 8)
                    action Function(aa_phone_close)
            button:
                xalign 0.5
                ypos (inner_height - 28)
                xysize (124, 28)
                background None
                action Function(aa_phone_go, "home")
                alt "Início"
                add aa_phone_round("mask") xysize (96, 4) align (0.5, 0.50)
        # Hardware is a single undistorted render; its actual island occludes the UI.
        add aa_phone_shell(handset_width, handset_height)
    if photo_zoom and selected_entry and selected_entry.get("image"):
        button:
            xfill True
            yfill True
            background Solid("#090e17f5")
            action SetScreenVariable("photo_zoom", False)
            alt "Fechar fotografia ampliada"
        add Transform(selected_entry["image"], xysize=(1176, 572), fit="contain") xalign 0.5 ypos 26
        textbutton "Voltar à foto" style "aa_hub_button" action SetScreenVariable("photo_zoom", False) xalign 0.5 ypos 633
    # Handle navigation before an active input consumes queued keyboard events.
    key "game_menu" action Function(aa_phone_back)
