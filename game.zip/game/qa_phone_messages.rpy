# Native UI + real narrative action coverage for Messages. Test-only fixtures.
init python:
    def aa_qa_message_seed():
        global aa_world
        from copy import deepcopy
        aa_world = deepcopy(aa_world)
        aa_phone_remember("visita")
        aa_phone_remember("visita_post")
        aa_fm.message(aa_world, "qa_joao", "Joãozão", "Já cheguei. Estou na entrada do restaurante.")
        aa_fm.message(aa_world, "qa_pai", "Pai", "Me avisa quando chegar em casa, filho.")

label qa_messages_reply:
    $ aa_world_start()
    $ aa_state = dict(aa_new_state(), route="juntas", trust=3, bond="mantido")
    $ aa_phone_memory = ()
    $ aa_phone_preferences = AAPhonePreferences()
    jump b_wait_reply

testsuite aa_phone_messages_test:
    setup:
        $ _test.timeout = 12.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = .02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/phone-messages" + ("-small" if renpy.variant("small") else "")
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        exit

    testcase list_filters_and_notification:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        run Function(aa_qa_message_seed)
        assert eval aa_phone_badge("messages") == 3
        run Function(aa_notification_open, "qa_joao")
        assert eval renpy.get_screen("aa_phone_hub").scope["selected_entry"]["title"] == "Joãozão"
        assert eval aa_phone_badge("messages") == 2
        click "Voltar às conversas"
        pause .3
        screenshot "conversations.png"
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").xadjustment.range == 0
        click "Filtrar conversas"
        click "Não lidas"
        assert "Vanessa"
        assert not "Yasmin"
        assert not "Joãozão"
        click "Filtrar conversas"
        click "Marcar todas como lidas"
        assert eval aa_phone_badge("messages") == 0
        assert "Tudo lido"

    testcase search_restores_results_without_leaking_story:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        run Function(aa_qa_message_seed)
        keysym "p"
        click "Mensagens"
        click "Buscar mensagens"
        type "joao"
        assert "Joãozão"
        assert not "Yasmin"
        click "Joãozão"
        click "Voltar às conversas"
        assert eval renpy.get_screen("aa_phone_hub").scope["search_active"]
        assert eval renpy.get_screen("aa_phone_hub").scope["query"] == "joao"
        click "Cancelar busca"
        click "Buscar mensagens"
        type "entrada"
        assert "Joãozão"
        pause .3
        screenshot "search.png"
        click "Cancelar busca"
        click "Buscar mensagens"
        type "inexistente"
        assert "Nenhum resultado"
        assert eval not any(e["kind"] == "terminou" for e in aa_phone_memory)
        keysym "K_ESCAPE"
        assert eval not renpy.get_screen("aa_phone_hub").scope["search_active"]
        assert not "Nenhum resultado"

    testcase pins_read_state_attachments_and_save:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        run Function(aa_qa_message_seed)
        keysym "p"
        click "Mensagens"
        click "Vanessa"
        pause .3
        screenshot "conversation.png"
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").xadjustment.range == 0
        click "Informações de Vanessa"
        click "Fixar conversa"
        pause .3
        screenshot "contact.png"
        run Function(renpy.get_widget("aa_phone_hub", "message_panel_scroll").yadjustment.change, 100)
        click "Ampliar foto compartilhada"
        assert screen "aa_phone_image"
        keysym "K_ESCAPE"
        assert screen "aa_phone_hub"
        click "Marcar como não lida"
        assert eval aa_phone_badge("messages") == 3
        assert eval renpy.get_screen("aa_phone_hub").scope["selected_entry"] is None
        pause .3
        screenshot "pinned.png"
        run QuickSave()
        click "Vanessa"
        assert eval aa_phone_badge("messages") == 2
        run QuickLoad(confirm=False)
        assert eval aa_phone_badge("messages") == 3
        assert eval aa_phone_is_favorite("contact_Vanessa")

    testcase new_message_uses_only_known_contacts:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        keysym "p"
        click "Mensagens"
        click "Nova mensagem"
        assert "Conversar com Yasmin"
        assert not "Conversar com Vanessa"
        click "Conversar com Yasmin"
        assert eval not aa_messages_replies("Yasmin")
        assert eval renpy.get_screen("aa_phone_hub").scope["message_panel"] is None

    testcase real_story_reply_and_rollback:
        run Start("qa_messages_reply")
        advance until screen "choice"
        $ before_history = len(aa_phone_memory)
        run Function(aa_phone_open, "Vanessa")
        assert eval len(aa_messages_replies("Vanessa")) == 2
        assert eval not aa_messages_replies("Yasmin")
        click "Escolher resposta"
        pause .3
        screenshot "reply.png"
        keysym "K_ESCAPE"
        assert eval len(aa_phone_memory) == before_history
        click "Escolher resposta"
        click "Responder que entendi e esperar."
        assert not screen "aa_phone_hub"
        advance until "Escrevi que esperaria."
        assert eval any(e["id"] == "phone_reply_b_wait_reply" for e in aa_phone_memory)
        assert eval aa_phone_threads()[0]["messages"][-1] == (True, "Entendi. Vou esperar.")
        run QuickSave()
        advance until eval aa_node != "b_wait_reply"
        run QuickLoad(confirm=False)
        assert eval len([e for e in aa_phone_memory if e["id"] == "phone_reply_b_wait_reply"]) == 1
        run Rollback() until eval not any(e["id"] == "phone_reply_b_wait_reply" for e in aa_phone_memory) timeout 10.0
        assert eval not any(e["id"] == "phone_reply_b_wait_reply" for e in aa_phone_memory)

    testcase large_text_opaque_glass_long_thread:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        run Function(aa_qa_message_seed)
        run Function(aa_phone_set_pref, "text_size", 3)
        run Function(aa_phone_set_pref, "glass", 1.0)
        keysym "p"
        click "Mensagens"
        pause .3
        screenshot "large-list.png"
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").xadjustment.range == 0
        click "Vanessa"
        pause .3
        screenshot "large-thread.png"
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").xadjustment.range == 0
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.range > 0
        click "Informações de Vanessa"
        assert eval renpy.get_widget("aa_phone_hub", "message_panel_scroll").xadjustment.range == 0
        keysym "K_ESCAPE"
        keysym "p"
        assert not screen "aa_phone_hub"

    testcase ordinary_menu_archives_the_same_reply:
        run Start("qa_messages_reply")
        advance until screen "choice"
        click "Responder que entendi e esperar."
        advance until "Escrevi que esperaria."
        assert eval any(e["id"] == "phone_reply_b_wait_reply" for e in aa_phone_memory)
        assert eval next(t for t in aa_phone_threads() if t["title"] == "Vanessa")["messages"][-1] == (True, "Entendi. Vou esperar.")
