# Gerado por tools/build_story.py. Edite a fonte editorial, não este arquivo.
label start:
    $ aa_state = aa_new_state()
    $ aa_last_art = ""
    jump a00

label a00:
    $ aa_node = 'a00'
    $ aa_location = '18h42 · Quarto de Feka'
    $ aa_stage_action = 'Vanessa larga a bolsa; Feka sentado, ainda sem celular.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_bolsa'
    show screen aa_location_display
    "Vanessa deixou a bolsa na minha cama e abriu o zíper."
    $ aa_stage_action = 'Vanessa entrou no banheiro; Feka responde da cama.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_banheiro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_banheiro'
    show screen aa_location_display
    "Ela entrou no banheiro. A torneira fez barulho antes de sair água."
    v "Onde você deixa a toalha de rosto?"
    f "Atrás da porta."
    $ aa_stage_action = 'Ela seca as mãos na toalha de banho; o gancho fica vazio.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.08, 0.83, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "Era a de banho. A de rosto estava no cesto havia três dias. Ela não reclamou."
    "Meu quarto tinha banheiro. A cozinha e a sala eram divididas com gente que sempre sabia quando eu tinha visita."
    $ aa_stage_action = 'Atenção nos cadernos e na escrivaninha, ainda no mesmo espaço.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.2, 0.54, 0.44)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "Na escrivaninha, dois cadernos de Direito. Vanessa tinha corrigido minhas anotações em caneta azul. Eu tinha feito um desenho na margem do dela."
    $ aa_stage_action = 'A escolha ocorre antes de Feka pegar o celular.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "O celular estava no carregador. Yasmin não tinha me mandado mensagem. Não era preciso uma mensagem para eu pegar o celular."
    menu:
        "Abrir o perfil de Yasmin.":
            $ aa_state = aa_choose(aa_state, 'a00', 0)
            jump a01
        "Conferir a conversa antiga com Yasmin.":
            $ aa_state = aa_choose(aa_state, 'a00', 1)
            jump a02
        "Deixar o celular e separar a roupa.":
            $ aa_state = aa_choose(aa_state, 'a00', 2)
            $ aa_stage_action = 'Ele deixa o telefone e presta atenção no quarto.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_brincos'
            "Afastei o celular com a jaqueta. Não apaguei nada. Só deixei para depois."
            jump a03

label a01:
    $ aa_node = 'a01'
    $ aa_location = '18h46 · Quarto de Feka'
    $ aa_stage_action = 'Feka pega o celular; Vanessa continua no banheiro.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    window hide
    hide screen aa_location_display
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    if aa_last_art != 'cg2_celular':
        show screen aa_cg_continue
        pause
        hide screen aa_cg_continue
    window auto
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    $ aa_stage_action = 'A foto do casal de jaleco ocupa a tela.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('publicacao')
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    "Primeiro apareceu uma foto de jaleco. Yasmin e Joãozão estudavam Medicina juntos. Ele estava ao lado dela de um jeito que eu sempre procurava corrigir quando cortava uma foto na cabeça."
    $ aa_stage_action = 'A publicação seguinte revela o restaurante.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    "A publicação seguinte era recente. Um copo, um cardápio e a mão dele sobre a mesa. O nome do restaurante estava no alto."
    "Era o lugar da minha reserva. Eu podia cancelar. Ainda nem tínhamos saído."
    "A ideia de cancelar me deu uma raiva pequena e imediata. Eu tinha passado a semana dizendo que aquele jantar era para Vanessa."
    $ aa_stage_action = 'A pergunta de Vanessa interrompe a tela; foco no banheiro.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.16, 0.83, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    v "Você viu meu brinco? O pequeno."
    "Eu respondi que não sem levantar os olhos."
    menu:
        "Fechar a publicação. Agora eu sei que ela está lá.":
            $ aa_state = aa_choose(aa_state, 'a01', 0)
            jump a03
        "Ficar olhando mais um pouco.":
            $ aa_state = aa_choose(aa_state, 'a01', 1)
            jump a02

label a02:
    $ aa_node = 'a02'
    $ aa_location = '18h51 · Quarto de Feka'
    $ aa_stage_action = 'A conversa é uma leitura na tela, não Yasmin presente.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    "A conversa era antiga. Não o suficiente para eu ter esquecido o que ela dizia."
    y "Feka, não me espera na saída de novo. Eu não combinei nada com você."
    "Embaixo, eu tinha escrito que estava só passando. Eu lembrava de ter chegado cedo."
    "Conheci Yasmin no ensino médio. Durante anos, qualquer coisa serviu: uma resposta curta, uma foto nova, o lugar onde ela dizia que ia estar."
    "Eu chamava aquilo de gostar de alguém. A palavra não dizia quanto trabalho eu dava a ela."
    $ aa_stage_action = 'A voz de Vanessa devolve o quarto ao primeiro plano.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    v "Feka?"
    menu:
        "Guardar o celular e responder.":
            $ aa_state = aa_choose(aa_state, 'a02', 0)
            jump a03
        "Reler minha resposta, procurando alguma defesa.":
            $ aa_state = aa_choose(aa_state, 'a02', 1)
            jump a03

label a03:
    $ aa_node = 'a03'
    $ aa_location = '19h02 · Quarto e banheiro'
    $ aa_stage_action = 'Celular abaixado; toalha devolvida; Vanessa termina o brinco.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    "Vanessa pendurou a toalha úmida no banheiro. Ainda mexia no fecho do brinco, perto da porta. O casaco e a bolsa estavam na cama."
    v "Achei o brinco. Tava na minha bolsa."
    if aa_matches(aa_state, {'knew': True}):
        v "Você podia ter falado que não estava ouvindo."
    if aa_matches(aa_state, {'late': True}):
        v "Eu te chamei duas vezes. Achei que você tivesse saído."
    $ aa_stage_action = 'Último ajuste do brinco antes de atravessar o quarto.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.13, 0.83, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    "Ela terminou de colocar o brinco, atravessou o quarto e pegou o casaco."
    if aa_matches(aa_state, {'knew': True}):
        "Eu sabia onde Yasmin estava. Vanessa só sabia onde íamos jantar."
    $ aa_stage_action = 'Feka levanta, veste a jaqueta e acerta a gola; cadeira livre.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    "Levantei e vesti a jaqueta escura. Vanessa me olhou enquanto eu acertava a gola."
    $ aa_stage_action = 'O olhar de Vanessa acompanha a escolha da roupa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.1, 0.27, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    v "Essa? Você não vai sentir calor?"
    menu:
        "Perguntar se ela prefere a camiseta.":
            $ aa_state = aa_choose(aa_state, 'a03', 0)
            $ aa_stage_action = 'Vanessa responde à pergunta sobre a roupa.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.1, 0.27, 0.32)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_jaqueta'
            v "Eu gosto da camiseta. Mas veste o que você quiser. Não precisa fazer votação."
            jump a04
        "Dizer que já está bom e elogiar o cabelo dela.":
            $ aa_state = aa_choose(aa_state, 'a03', 1)
            $ aa_stage_action = 'Elogio sem aproximação física inventada.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_jaqueta'
            f "Seu cabelo ficou bonito."
            v "Obrigada. Ainda vou terminar."
            jump a04
        "Conferir pelo celular uma foto minha que Yasmin já curtiu.":
            $ aa_state = aa_choose(aa_state, 'a03', 2)
            $ aa_stage_action = 'O telefone volta como comparação, não como informação nova.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            show screen aa_phone_view('comparacao')
            $ aa_last_art = 'cg2_quarto_jaqueta'
            "Ampliei a foto para ver a roupa. Vanessa passou atrás de mim para buscar a bolsa. Bloqueei a tela antes de ela chegar perto."
            jump a04

label a04:
    $ aa_node = 'a04'
    $ aa_location = '19h13 · Cozinha compartilhada'
    $ aa_stage_action = 'Feka junto à panela; Vanessa diante da geladeira.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    "Na cozinha, alguém tinha deixado uma panela dentro da pia. Passei duas vezes por ela como se não fosse minha."
    $ aa_stage_action = 'Vanessa começa a falar; a panela fica no campo periférico.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.06, 0.78, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    v "Amanhã eu pego a chave."
    f "Do apartamento?"
    v "Não. Da prefeitura."
    "Eu ri atrasado. Ela abriu a geladeira, viu uma garrafa com o nome de outro morador e fechou."
    $ aa_stage_action = 'A geladeira é fechada; conversa continua entre os dois.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    v "Vou poder comprar uma coisa e encontrar a mesma coisa quando voltar."
    "Estudávamos Direito na mesma turma. Eu sabia as matérias em que Vanessa ia bem. Não sabia quem tinha ido ver o apartamento com ela."
    menu:
        "Perguntar como foi a visita e deixar ela contar.":
            $ aa_state = aa_choose(aa_state, 'a04', 0)
            jump a05
        "Brincar que agora vou ter onde dormir.":
            $ aa_state = aa_choose(aa_state, 'a04', 1)
            jump a05
        "Avisar que precisamos sair, olhando o celular.":
            $ aa_state = aa_choose(aa_state, 'a04', 2)
            v "Eu já estou pronta. Você também? Então vamos."
            jump a05

label a05:
    $ aa_node = 'a05'
    $ aa_location = '19h22 · Cozinha compartilhada'
    $ aa_stage_action = 'Geladeira fechada; Vanessa mostra o orçamento no celular.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    if aa_matches(aa_state, {'heard': True}):
        v "Fui com a minha mãe. É pequeno. Não tem onde pôr uma mesa grande. Mas a porta fecha."
    if aa_matches(aa_state, {'claimed_space': True}):
        v "Você continua tendo onde dormir. Aqui."
    $ aa_stage_action = 'Orçamento na mão dela, não na tela de Feka.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.1, 0.74, 0.48)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    "Ela me mostrou no celular quanto queria gastar naquela noite. Não era um pedido de ajuda."
    v "Cada um paga o seu, tá? Tô com caução, mudança e um monte de coisa."
    "Yasmin tinha recomendado o restaurante no grupo três semanas antes. Guardei o nome. Para Vanessa, disse que tinha pensado nela."
    "Meu saldo aguentava meu prato. Não aguentava a pessoa que eu queria parecer."
    menu:
        "Combinar que cada um paga o seu.":
            $ aa_state = aa_choose(aa_state, 'a05', 0)
            f "Combinado. Cada um o seu."
            v "Obrigada. Prefiro saber antes."
            jump a06
        "Insistir que hoje eu pago tudo.":
            $ aa_state = aa_choose(aa_state, 'a05', 1)
            f "Hoje deixa comigo."
            v "Tem certeza?"
            f "Tenho."
            "Consegui dizer sem conferir o saldo outra vez."
            jump a06
        "Admitir que estou apertado e pedir um jantar mais simples lá.":
            $ aa_state = aa_choose(aa_state, 'a05', 2)
            v "Tudo bem. Eu falei de jantar, não de te quebrar."
            jump a06

label a06:
    $ aa_node = 'a06'
    $ aa_location = '19h30 · Hall do apartamento'
    $ aa_stage_action = 'Casaco vestido, caderno entrando na bolsa, chave com Feka.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall'
    show screen aa_location_display
    "Vanessa vestiu o casaco, guardou o caderno na bolsa e conferiu a chave, o celular e a carteira. Fiquei esperando que terminasse sem me perguntar mais nada."
    $ aa_stage_action = 'A bolsa se fecha; Vanessa levanta os olhos para perguntar.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    v "Foi você mesmo que descobriu esse lugar?"
    "A pergunta podia acabar ali. Isso era o que eu queria: que uma pergunta acabasse antes de chegar onde doía."
    menu:
        "Contar que Yasmin indicou o lugar e que eu vi que ela está lá." if aa_matches(aa_state, {'knew': True}):
            $ aa_state = aa_choose(aa_state, 'a06', 0)
            jump a07
        "Contar que quem indicou foi uma menina de quem eu gostei." if aa_matches(aa_state, {'knew': False}):
            $ aa_state = aa_choose(aa_state, 'a06', 1)
            jump a07
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': True}):
            $ aa_state = aa_choose(aa_state, 'a06', 2)
            jump a08
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': False}):
            $ aa_state = aa_choose(aa_state, 'a06', 3)
            jump a08

label a07:
    $ aa_node = 'a07'
    $ aa_location = '19h34 · Hall do apartamento'
    $ aa_stage_action = 'Vanessa interrompe a saída e olha para Feka.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.08, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    v "De quem você gostou?"
    $ aa_stage_action = 'Contracampo de Feka antes de dizer o nome.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.14, 0.74, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    f "Yasmin. A gente estudou junto no ensino médio."
    if aa_matches(aa_state, {'knew': True}):
        v "E você ia me levar sabendo que ela está lá?"
    if aa_matches(aa_state, {'knew': False}):
        v "Você podia ter falado. Eu não ia proibir um restaurante."
    $ aa_stage_action = 'A distância entre ambos reaparece no plano aberto.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    "Eu quase disse que não havia motivo para ciúme. Ela ainda não tinha falado de ciúme."
    menu:
        "Admitir que ainda penso nela e deixar Vanessa decidir.":
            $ aa_state = aa_choose(aa_state, 'a07', 0)
            jump a09
        "Dizer que é passado e manter a reserva.":
            $ aa_state = aa_choose(aa_state, 'a07', 1)
            jump a08

label a09:
    $ aa_node = 'a09'
    $ aa_location = '19h38 · Hall do apartamento'
    $ aa_stage_action = 'A porta continua fechada enquanto Vanessa decide.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.13, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    v "Ainda pensa como?"
    "Não respondi. O silêncio fez o serviço que eu estava adiando."
    $ aa_stage_action = 'Vanessa determina o limite mantendo a porta fechada.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.16, 0.28, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    v "Eu vou jantar. Eu me arrumei, guardei dinheiro e passei a semana esperando. Mas não vai ter foto de casal para te ajudar a parecer bem."
    v "Se você quiser cancelar, cancela por você. Não diz depois que fui eu que estraguei."
    menu:
        "Ir, aceitando esse limite.":
            $ aa_state = aa_choose(aa_state, 'a09', 0)
            jump a08
        "Cancelar e encerrar o encontro sem pedir que ela me console.":
            $ aa_state = aa_choose(aa_state, 'a09', 1)
            jump e00

label a08:
    $ aa_node = 'a08'
    $ aa_location = '19h48 · A caminho do restaurante'
    $ aa_stage_action = 'Ambos caminham; Vanessa puxa a manga do casaco.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    "Na rua, Vanessa puxou a própria manga sobre a mão. Perguntei se estava com frio. Ela disse que não era nada."
    if aa_matches(aa_state, {'ambush': True}):
        "A tela do meu celular continuava escura. Eu sabia tudo que precisava saber para fingir uma surpresa."
    if aa_matches(aa_state, {'knew': False}):
        "Eu não sabia que Yasmin estaria lá. Isso me daria, mais tarde, uma frase verdadeira para colocar na frente de várias mentiras."
    $ aa_stage_action = 'A promessa sobre a aula acontece enquanto caminham.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.06, 0.65, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    v "Amanhã, se eu faltar na primeira aula, você pega a matéria?"
    f "Pego."
    "Essa promessa eu conseguia cumprir. Fiquei feliz de receber uma fácil."
    jump b00

label b00:
    $ aa_node = 'b00'
    $ aa_location = '20h10 · Entrada do restaurante'
    $ aa_stage_action = 'Reconhecimento: olhar de Feka, casal sentado, Vanessa ao lado.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    "A primeira coisa que vi foi Joãozão. Depois a mão de Yasmin no braço dele. Achei essa ordem injusta."
    $ aa_stage_action = 'Feka volta a ouvir Vanessa e a recepção.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.08, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    "Vanessa tirou o casaco e parou ao meu lado, com ele no braço. A recepcionista perguntou o nome da reserva. Eu disse meu nome baixo demais e precisei repetir."
    if aa_matches(aa_state, {'v_knows': True}):
        v "É ela?"
    if aa_matches(aa_state, {'v_knows': False}):
        v "Você conhece alguém?"
    menu:
        "Apresentar Vanessa como minha namorada.":
            $ aa_state = aa_choose(aa_state, 'b00', 0)
            f "Essa é a Vanessa, minha namorada."
            "Ela se adiantou meio passo. Não parecia precisar que eu completasse a apresentação."
            jump b01
        "Dizer que são pessoas da época da escola.":
            $ aa_state = aa_choose(aa_state, 'b00', 1)
            f "É gente da escola. Conhecidos."
            "Falei baixo. Vanessa ainda não tinha perguntado por que eu estava falando baixo."
            jump b01
        "Puxar Vanessa para perto antes que Yasmin olhe.":
            $ aa_state = aa_choose(aa_state, 'b00', 2)
            "Passei o braço pela cintura de Vanessa. Ela se ajeitou, surpresa. Eu estava olhando para Yasmin."
            jump b01

label b01:
    $ aa_node = 'b01'
    $ aa_location = '20h14 · Salão'
    $ aa_stage_action = 'Joãozão continua sentado; Feka e Vanessa estão de pé.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.08, 0.73, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    y "Feka. Você veio mesmo."
    "Vanessa virou o rosto para mim. Eu senti um alívio absurdo: Yasmin tinha lembrado meu nome."
    y "O restaurante. Eu mandei no grupo. Faz um tempo."
    j "Boa noite."
    $ aa_stage_action = 'Joãozão não oferece a mão; mostrar o gesto interrompido.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cumprimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cumprimento'
    show screen aa_location_display
    "Joãozão não levantou. Fui apertar uma mão que ele não tinha oferecido. Consertei o movimento mexendo na cadeira."
    $ aa_stage_action = 'Vanessa faz a própria apresentação.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.14, 0.38, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    v "Vanessa."
    y "Yasmin. Vocês se conhecem de onde?"
    v "Da faculdade. Direito."
    "Ela respondeu antes de eu descobrir uma forma de dizer aquilo que parecesse importante."
    menu:
        "Dizer que vamos deixar os dois jantarem.":
            $ aa_state = aa_choose(aa_state, 'b01', 0)
            jump p00
        "Sugerir que juntemos as mesas.":
            $ aa_state = aa_choose(aa_state, 'b01', 1)
            jump c00
        "Pedir um minuto com Yasmin antes de sentar.":
            $ aa_state = aa_choose(aa_state, 'b01', 2)
            jump t00

label p00:
    $ aa_node = 'p00'
    $ aa_location = '20h25 · Mesa junto ao vidro'
    $ aa_stage_action = 'Dois sentados. Feka vê o salão por trás de Vanessa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_menu_antes at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    "Pedi uma mesa de onde dava para ver o salão. Vanessa sentou de costas para Yasmin. Eu podia ter escolhido o outro lado."
    if aa_matches(aa_state, {'source_truth': False}):
        v "Então foi ela que indicou."
    if aa_matches(aa_state, {'source_truth': True}):
        v "Você disse que foi indicação dela. Não disse que ia querer sentar olhando pra mesa dela."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio aberto entre os dois. · lugares trocados'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Cardápio aberto entre os dois.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    "Ela abriu o cardápio sem olhar os pratos. Eu conhecia o gesto: na aula, fazia isso quando queria que alguém terminasse logo."
    menu:
        "Pedir para trocar de cadeira e contar a origem da reserva.":
            $ aa_state = aa_choose(aa_state, 'p00', 0)
            $ aa_stage_action = 'Troca efetiva dos lugares; manter até o fim desse diálogo.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_menu at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_menu'
            "Trocamos de cadeira. O vidro ficou atrás de mim."
            f "Foi indicação dela. Eu peguei o nome no grupo e fiz a reserva."
            jump p01
        "Dizer que muita gente indica restaurante.":
            $ aa_state = aa_choose(aa_state, 'p00', 1)
            v "Eu não perguntei quanta gente indica restaurante. Perguntei quem indicou esse."
            jump p01
        "Fazer um elogio alto o suficiente para a outra mesa ouvir.":
            $ aa_state = aa_choose(aa_state, 'p00', 2)
            f "Você tá linda hoje."
            v "Por que você tá falando alto?"
            jump p01

label p01:
    $ aa_node = 'p01'
    $ aa_location = '20h34 · Mesa junto ao vidro'
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Vanessa fala do apartamento; o lugar escolhido permanece. · lugares trocados'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Vanessa fala do apartamento; o lugar escolhido permanece.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'claimed_space': True}):
        v "Você perguntou se podia dormir no apartamento. Eu sei que era brincadeira."
    v "Quando eu disse que ia morar sozinha, você não perguntou se eu estava com medo."
    f "Você tá?"
    v "Tô. Mas quero ir mesmo assim."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'O pensamento de Feka interrompe a conversa. · lugares trocados'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.08, 0.5, 0.3)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'O pensamento de Feka interrompe a conversa.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.08, 0.5, 0.3)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    "Eu tinha medo de um homem sentado a poucos metros. Ela tinha medo de uma mudança inteira. Fiquei irritado por perceber a diferença."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Devolver o plano aos dois quando Vanessa diz o que queria. · lugares trocados'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Devolver o plano aos dois quando Vanessa diz o que queria.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    v "Eu queria falar disso hoje."
    menu:
        "Pedir que conte o que mais a preocupa.":
            $ aa_state = aa_choose(aa_state, 'p01', 0)
            v "Ter que resolver tudo. E gostar tanto de resolver sozinha que depois eu não saiba pedir ajuda."
            jump p02
        "Prometer que ela nunca vai ficar sozinha.":
            $ aa_state = aa_choose(aa_state, 'p01', 1)
            v "Mas eu quero morar sozinha. Você tá ouvindo a parte que eu tô falando?"
            jump p02
        "Olhar o movimento no vidro enquanto ela fala.":
            $ aa_state = aa_choose(aa_state, 'p01', 2)
            "Ela parou no meio de uma frase. Eu só percebi quando o silêncio durou."
            jump p02

label p02:
    $ aa_node = 'p02'
    $ aa_location = '20h45 · Mesa junto ao vidro'
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'O olhar desviado deixa de passar despercebido. · lugares trocados'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.1, 0.5, 0.32)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'O olhar desviado deixa de passar despercebido.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.1, 0.5, 0.32)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    v "Você fica diferente quando olha pra lá."
    f "Diferente como?"
    v "Como se estivesse esperando uma nota."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Sustentar a pausa; sem trocar sorriso por animação cômica. · lugares trocados'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.14, 0.5, 0.3)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Sustentar a pausa; sem trocar sorriso por animação cômica.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.14, 0.5, 0.3)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    "Quis rir para tornar a frase pequena. Ela não estava brincando."
    menu:
        "Contar que insisti por anos, mesmo depois de ela dizer não.":
            $ aa_state = aa_choose(aa_state, 'p02', 0)
            f "Eu insisti. Não foi uma semana. Foram anos. Ela pediu que eu parasse."
            v "E parou?"
            jump i00
        "Chamar de uma paixão boba de escola.":
            $ aa_state = aa_choose(aa_state, 'p02', 1)
            v "Se era tão boba, por que eu estou tendo que perguntar?"
            jump i00
        "Dizer que Vanessa está procurando problema.":
            $ aa_state = aa_choose(aa_state, 'p02', 2)
            jump i00

label c00:
    $ aa_node = 'c00'
    $ aa_location = '20h25 · Mesas aproximadas'
    $ aa_stage_action = 'Quatro sentados; mesas aproximadas, ainda sem pratos servidos.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    "Joãozão disse que os pratos deles já estavam chegando. Eu respondi que tudo bem, como se a objeção fosse logística."
    y "Se a Vanessa quiser."
    v "Pode ser. Só não quero passar a noite falando de faculdade."
    "Ela concordou. Eu me agarrei a isso antes que tivesse alguma coisa para justificar."
    y "Vocês dois em Direito. Deve ser bom discutir e já vir com referência."
    $ aa_stage_action = 'Feka tenta parecer um bom namorado.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.1, 0.18, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    f "Com ela eu nem discuto."
    v "Você só some no meio da conversa."
    $ aa_stage_action = 'A risada não é compartilhada por Vanessa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    "Yasmin riu. Eu ri também. Vanessa parou primeiro."
    menu:
        "Admitir que a crítica de Vanessa é justa.":
            $ aa_state = aa_choose(aa_state, 'c00', 0)
            f "Eu faço isso mesmo. Desculpa."
            v "Faz."
            jump c01
        "Explicar que ela está brincando.":
            $ aa_state = aa_choose(aa_state, 'c00', 1)
            f "Ela fala assim, mas é brincadeira."
            v "Eu sei dizer quando tô brincando."
            jump c01
        "Puxar uma lembrança minha com Yasmin.":
            $ aa_state = aa_choose(aa_state, 'c00', 2)
            f "Lembra daquela festa depois da prova?"
            y "Você lembra mais dessas coisas do que eu."
            jump c01

label c01:
    $ aa_node = 'c01'
    $ aa_location = '20h38 · Mesa dos quatro'
    $ aa_stage_action = 'Yasmin dirige a lembrança a Vanessa, não à câmera.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.08, 0.48, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    y "Ele era assim na escola. Você chegava num lugar e ele já tava lá."
    "Ela falou para Vanessa. Tinha um sorriso. Eu não consegui saber se era maldade ou só facilidade. O efeito era o mesmo."
    $ aa_stage_action = 'Vanessa recebe a informação em público.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.1, 0.77, 0.37)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    v "Como assim?"
    $ aa_stage_action = 'Joãozão oferece uma saída para o assunto.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.1, 0.7, 0.23)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    j "Melhor mudar de assunto."
    "Joãozão me ofereceu uma saída. Tive vontade de odiá-lo ainda mais."
    menu:
        "Dizer que não era uma coincidência e assumir a insistência.":
            $ aa_state = aa_choose(aa_state, 'c01', 0)
            f "Eu ia porque ela ia. Não era por acaso."
            v "Você está me contando isso agora porque ela falou?"
            jump c02
        "Pedir a Yasmin que pare de fazer disso uma piada.":
            $ aa_state = aa_choose(aa_state, 'c01', 1)
            f "Não faz piada disso com ela."
            "Eu também queria que Yasmin parasse de falar. As duas vontades cabiam na mesma frase."
            jump c02
        "Dizer que Yasmin gostava da atenção.":
            $ aa_state = aa_choose(aa_state, 'c01', 2)
            $ aa_stage_action = 'Ele acusa; o enquadramento fecha sobre a reação de Vanessa.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quatro at aa_camera(1.15, 0.77, 0.35)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quatro'
            f "Você também gostava. Nunca foi só comigo."
            "Minha voz saiu mais alta no fim. Vanessa tirou a mão da mesa."
            y "Eu gostava de poder sair da aula sem explicar para onde ia."
            jump c02

label c02:
    $ aa_node = 'c02'
    $ aa_location = '20h49 · Mesa dos quatro'
    $ aa_stage_action = 'A piada termina antes da chegada da comida.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'stopped_joke': True}):
        y "Tá. Não foi uma boa piada."
    $ aa_stage_action = 'Pratos servidos ocupam o espaço dos cotovelos.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pratos'
    show screen aa_location_display
    "O garçom colocou os pratos. Ninguém tinha espaço para os cotovelos. Eu disse que a mesa estava ótima."
    v "Não precisa fazer parecer uma festa."
    $ aa_stage_action = 'O celular fica junto ao prato; ainda não há fotografia.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_pratos at aa_camera(1.06, 0.35, 0.55)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pratos'
    show screen aa_location_display
    "Meu celular estava ao lado do prato. Uma foto poderia registrar quatro pessoas jantando. Não registraria o que cada uma estava aguentando."
    menu:
        "Pedir uma foto, se todos quiserem.":
            $ aa_state = aa_choose(aa_state, 'c02', 0)
            jump c03
        "Guardar o celular e voltar a comer.":
            $ aa_state = aa_choose(aa_state, 'c02', 1)
            "Deixei o celular no bolso. A comida tinha esfriado enquanto eu tentava parecer à vontade."
            jump i00
        "Oferecer pagar a mesa inteira para mudar o clima.":
            $ aa_state = aa_choose(aa_state, 'c02', 2)
            j "Não precisa. A nossa conta a gente paga."
            "Ficou só a promessa que eu tinha feito para Vanessa. Ainda era mais do que eu podia."
            jump i00

label c03:
    $ aa_node = 'c03'
    $ aa_location = '20h52 · Mesa dos quatro'
    $ aa_stage_action = 'Celular ainda guardado; a fotografia depende da resposta.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pratos'
    show screen aa_location_display
    if aa_matches(aa_state, {'no_photo': True}):
        v "Eu já disse que não."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        v "Agora não. Come antes que esfrie."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'gte': 2}}):
        $ aa_stage_action = 'Só exibir a fotografia no ramo em que Vanessa aceita.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_foto at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_foto'
        show screen aa_location_display
        "Vanessa aceitou. Joãozão fez a foto. Yasmin olhou para a lente durante menos de um segundo. Eu quis que aquilo provasse alguma coisa."
    menu:
        "Aceitar a resposta sem insistir.":
            $ aa_state = aa_choose(aa_state, 'c03', 0)
            $ aa_stage_action = 'Telefone guardado, independentemente de terem feito a foto.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_pratos'
            "Guardei o celular. Deixei a resposta como estava."
            jump i00
        "Cobrar de todos um esforço para melhorar a noite.":
            $ aa_state = aa_choose(aa_state, 'c03', 1)
            v "Esforço pra quê, Feka? A gente tá comendo."
            jump i00

label t00:
    $ aa_node = 't00'
    $ aa_location = '20h24 · Porta da varanda'
    $ aa_stage_action = 'Yasmin segura a bolsa dentro da porta; distância física explícita.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    y "Eu só vim pegar minha bolsa. Fala daqui."
    "Yasmin ficou do lado de dentro. Vanessa tinha sentado à mesa, com o casaco no colo."
    f "Você tá bem?"
    y "Tava jantando."
    "Eu esperei que ela perguntasse de mim. Ela segurou a bolsa com as duas mãos."
    $ aa_stage_action = 'A recusa pertence a Yasmin.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.13, 0.28, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    y "Feka, eu não quero ficar com você. Isso não mudou. E você tá aqui com uma pessoa."
    menu:
        "Dizer que entendi e voltar para Vanessa.":
            $ aa_state = aa_choose(aa_state, 't00', 0)
            jump t01
        "Perguntar se ela falaria isso se Joãozão não estivesse ali.":
            $ aa_state = aa_choose(aa_state, 't00', 1)
            jump t01
        "Dizer que ela não precisava me humilhar.":
            $ aa_state = aa_choose(aa_state, 't00', 2)
            jump t01

label t01:
    $ aa_node = 't01'
    $ aa_location = '20h28 · Porta da varanda'
    $ aa_stage_action = 'Yasmin conclui a resposta antes de Joãozão entrar.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    if aa_matches(aa_state, {'insisted': True}):
        y "Eu falei antes de namorar ele. Você lembra."
    if aa_matches(aa_state, {'stopped_joke': True}):
        y "Eu posso ter sido escrota. Isso não muda a resposta."
    $ aa_stage_action = 'Joãozão entra só agora; Yasmin continua no próprio lugar.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite_joao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite_joao'
    show screen aa_location_display
    j "Tá acontecendo alguma coisa?"
    "O corpo de Joãozão ocupou o espaço que eu estava usando para imaginar uma conversa diferente."
    $ aa_stage_action = 'Yasmin interrompe a tentativa de falar por ela.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite_joao at aa_camera(1.1, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite_joao'
    show screen aa_location_display
    y "Já respondi. Eu mesma."
    menu:
        "Sair do caminho e voltar à mesa.":
            $ aa_state = aa_choose(aa_state, 't01', 0)
            jump t02
        "Dizer a Joãozão que ele não manda em mim.":
            $ aa_state = aa_choose(aa_state, 't01', 1)
            j "Eu perguntei se estava acontecendo alguma coisa."
            "Ele não tinha precisado levantar a voz para eu perceber a minha."
            jump t02
        "Pedir que ele deixe Yasmin terminar de falar.":
            $ aa_state = aa_choose(aa_state, 't01', 2)
            y "Eu já terminei. Agora quero voltar."
            jump t02

label t02:
    $ aa_node = 't02'
    $ aa_location = '20h33 · Mesa de Vanessa'
    $ aa_stage_action = 'Vanessa sentada; meio copo e casaco na cadeira de Feka.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    "O copo de Vanessa estava pela metade. Ela tinha dobrado o casaco sobre a cadeira que eu devia estar usando."
    $ aa_stage_action = 'Reprovação sentada; não substituir por retrato de pé.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.1, 0.62, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    v "Já pode começar nosso jantar?"
    "Eu procurei uma resposta engraçada. Todas pioravam a pergunta."
    menu:
        "Pedir desculpa pelo tempo e contar o que fui fazer.":
            $ aa_state = aa_choose(aa_state, 't02', 0)
            jump i00
        "Dizer que foi só uma conversa de escola.":
            $ aa_state = aa_choose(aa_state, 't02', 1)
            jump i00
        "Reclamar que Joãozão é agressivo.":
            $ aa_state = aa_choose(aa_state, 't02', 2)
            jump i00

label i00:
    $ aa_node = 'i00'
    $ aa_location = '21h02 · Entre os pratos'
    $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_papel'
    show screen aa_location_display
    "Quando recolheram os pratos, apareceu um intervalo pequeno. Vanessa procurou alguma coisa na bolsa. Yasmin foi até a porta da varanda. Joãozão ficou perto do balcão."
    $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_papel at aa_camera(1.07, 0.5, 0.43)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_papel'
    show screen aa_location_display
    "Eu podia escolher para onde ir. Não podia estar nos três lugares. Pela primeira vez naquela noite, isso pareceu um problema meu."
    menu:
        "Ficar com Vanessa.":
            $ aa_state = aa_choose(aa_state, 'i00', 0)
            jump iv
        "Conversar com Joãozão, sem plateia.":
            $ aa_state = aa_choose(aa_state, 'i00', 1)
            jump ij
        "Procurar Yasmin no corredor.":
            $ aa_state = aa_choose(aa_state, 'i00', 2)
            jump iy

label iv:
    $ aa_node = 'iv'
    $ aa_location = '21h06 · Mesa'
    $ aa_stage_action = 'Papel com medidas nas mãos de Vanessa, não uma acusação.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_papel'
    show screen aa_location_display
    "Era um papel dobrado com medidas de móveis. Eu estava esperando que fosse alguma prova contra mim. Vanessa estava tentando ver se a cama cabia."
    v "A gente passou a aula de ontem discutindo se uma pessoa pode concordar sem saber tudo."
    f "Eu lembro."
    v "Você falou bastante."
    $ aa_stage_action = 'Ela dobra e guarda o papel antes da escolha.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_papel_guardado at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_papel_guardado'
    show screen aa_location_display
    "Ela guardou o papel. Não fez a comparação por mim."
    menu:
        "Perguntar o que ela queria desta noite e ouvir.":
            $ aa_state = aa_choose(aa_state, 'iv', 0)
            v "Comer com você. Contar do apartamento. Voltar sem ter que adivinhar se você preferia estar com outra pessoa."
            jump r00
        "Dizer que eu também estou tendo uma noite difícil.":
            $ aa_state = aa_choose(aa_state, 'iv', 1)
            v "Eu percebi. Só que parece que eu vim trabalhar nela."
            jump r00
        "Prometer levar as coisas dela na mudança.":
            $ aa_state = aa_choose(aa_state, 'iv', 2)
            v "Eu já combinei a mudança. Não precisa prometer uma coisa nova agora."
            jump r00

label ij:
    $ aa_node = 'ij'
    $ aa_location = '21h06 · Balcão'
    $ aa_stage_action = 'Dois homens de pé, mãos abertas; sem plateia.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    j "Eu não quero ficar vigiando vocês. É um negócio ridículo."
    f "Então não fica."
    $ aa_stage_action = 'Joãozão responde à provocação sem avançar.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.12, 0.74, 0.31)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    j "Ela já pediu pra você parar. E você vem falar comigo. Quer que eu faça o quê?"
    "Eu tinha preparado uma fala sobre ciúme. Ela não servia para responder àquilo."
    $ aa_stage_action = 'A referência a Vanessa faz o plano voltar aos dois.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    j "E a Vanessa tá sentada lá, cara."
    menu:
        "Admitir minha insistência e pedir que não faça uma cena.":
            $ aa_state = aa_choose(aa_state, 'ij', 0)
            j "Então escuta quando ela pede. Não precisa vir explicar pra mim."
            jump r00
        "Dizer que Yasmin sabe responder por ela.":
            $ aa_state = aa_choose(aa_state, 'ij', 1)
            j "Sabe. E já respondeu. Você sabe disso melhor do que eu."
            jump r00
        "Chamar Joãozão de inseguro alto o suficiente para ela ouvir.":
            $ aa_state = aa_choose(aa_state, 'ij', 2)
            "Yasmin olhou. Era o que eu queria. Dei um passo para trás antes de Joãozão se mexer."
            jump r00

label iy:
    $ aa_node = 'iy'
    $ aa_location = '21h06 · Corredor'
    $ aa_stage_action = 'Feka procura a mesma pessoa no mesmo corredor outra vez.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.07, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    y "Você deixou sua namorada na mesa."
    "Não consegui dizer que era só um minuto. Yasmin já conhecia a duração dos meus minutos."
    f "Você me acha uma pessoa tão ruim assim?"
    $ aa_stage_action = 'A segunda recusa tem menos espaço para negociação.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.17, 0.28, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    y "Eu não quero ter que te avaliar para poder jantar."
    "Essa resposta eu não podia transformar em quase. Ela nem estava falando de amor."
    menu:
        "Parar de pedir uma resposta diferente.":
            $ aa_state = aa_choose(aa_state, 'iy', 0)
            f "Tá. Eu vou voltar."
            y "Volta."
            jump r00
        "Pedir só que ela admita que já me deu esperança.":
            $ aa_state = aa_choose(aa_state, 'iy', 1)
            y "Eu preciso pedir desculpa por você ter entendido o que quis?"
            jump r00
        "Dizer que estou com Vanessa e não preciso dela.":
            $ aa_state = aa_choose(aa_state, 'iy', 2)
            y "Então por que você tá aqui falando comigo?"
            "Eu não tinha uma resposta que não incluísse a cadeira vazia de Vanessa."
            jump r00

label r00:
    $ aa_node = 'r00'
    $ aa_location = '21h18 · A mesa de Vanessa'
    $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa'
    show screen aa_location_display
    "Eu tinha pedido um pudim com duas colheres. Vanessa não tinha dito que queria sobremesa. Eu queria conseguir chegar à sobremesa."
    $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    "Vanessa afastou o prato. Não levantou a voz. Eu precisei me inclinar para ouvir."
    if aa_matches(aa_state, {'presence_told': False}):
        v "Você sabia que ela estaria aqui?"
    if aa_matches(aa_state, {'presence_told': True}):
        v "Você me disse que ela estaria aqui. Eu quero entender por que quis vir mesmo assim."
    if aa_matches(aa_state, {'knew': True}):
        "Eu sabia. Vi no quarto, enquanto ela procurava o brinco."
    if aa_matches(aa_state, {'knew': False}):
        "Não sabia. Percebi o quanto queria usar essa resposta para encerrar todo o resto."
    menu:
        "Admitir que vi a publicação e quis encontrá-la." if aa_matches(aa_state, {'knew': True}):
            $ aa_state = aa_choose(aa_state, 'r00', 0)
            jump r01
        "Dizer que não sabia, mas escolhi o lugar por causa dela." if aa_matches(aa_state, {'knew': False}):
            $ aa_state = aa_choose(aa_state, 'r00', 1)
            jump r01
        "Falar só da indicação e esconder o que vi no celular." if aa_matches(aa_state, {'knew': True, 'presence_told': False}):
            $ aa_state = aa_choose(aa_state, 'r00', 2)
            jump r02
        "Repetir que foi coincidência e que Vanessa está exagerando.":
            $ aa_state = aa_choose(aa_state, 'r00', 3)
            jump r02

label r01:
    $ aa_node = 'r01'
    $ aa_location = '21h22 · Mesa'
    $ aa_stage_action = 'Vanessa olha para as mãos; Feka procura uma reação.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.08, 0.63, 0.38)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    if aa_matches(aa_state, {'knew': True}):
        v "Você me viu passando maquiagem e sabia?"
    if aa_matches(aa_state, {'knew': False}):
        v "E eu agradecendo por você ter pensado em mim."
    $ aa_stage_action = 'Mãos recolhidas; evitar lágrimas que o texto não confirma.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.12, 0.63, 0.45)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    "Ela olhou para as mãos. Eu achei que fosse chorar e senti uma vontade horrível de que chorasse. Uma pessoa chorando ainda pode aceitar um abraço."
    v "O que você tá fazendo comigo?"
    menu:
        "Admitir que fiquei com ela para não me sentir sozinho.":
            $ aa_state = aa_choose(aa_state, 'r01', 0)
            jump r03
        "Dizer que gosto dela, mas estou confuso.":
            $ aa_state = aa_choose(aa_state, 'r01', 1)
            jump r02
        "Pedir que ela veja quanto Yasmin me machucou.":
            $ aa_state = aa_choose(aa_state, 'r01', 2)
            jump r04

label r02:
    $ aa_node = 'r02'
    $ aa_location = '21h25 · Mesa'
    $ aa_stage_action = 'Ela continua sentada; isso não significa consentimento.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.04, 0.62, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    v "Eu não consigo conferir o que passa na sua cabeça. Consigo ver que você continua procurando ela."
    v "Se você vai mentir, eu não vou ficar aqui encontrando a frase certa para fazer você parar."
    $ aa_stage_action = 'A permanência é espera pela conta, sem aproximação.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    "Ela ainda estava sentada. Eu quis chamar isso de outra chance. Talvez fosse só a conta que não tinha chegado."
    menu:
        "Parar de reduzir o problema e contar tudo.":
            $ aa_state = aa_choose(aa_state, 'r02', 0)
            jump r03
        "Pedir para terminar o jantar sem falar nisso.":
            $ aa_state = aa_choose(aa_state, 'r02', 1)
            v "Eu posso esperar a conta. Não chama isso de terminar o jantar."
            jump k00
        "Dizer que ela aceitou vir e também fez suas escolhas.":
            $ aa_state = aa_choose(aa_state, 'r02', 2)
            jump r05

label r04:
    $ aa_node = 'r04'
    $ aa_location = '21h26 · Mesa'
    $ aa_stage_action = 'Vanessa cansada; sobremesa intocada.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.07, 0.65, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    f "Você não entende o que foram esses anos."
    if aa_matches(aa_state, {'past_told': False}):
        v "Não. Você não contou."
    if aa_matches(aa_state, {'past_told': True}):
        v "Você contou. Eu não disse que ia resolver."
    f "Eu sofri muito."
    v "E resolveu dividir comigo sem me perguntar."
    $ aa_stage_action = 'O cansaço substitui a reação que Feka procura.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.1, 0.63, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    "Eu queria que ela fosse injusta. Queria uma frase cruel que me deixasse ir embora ofendido. Ela só estava cansada."
    menu:
        "Admitir o que fiz sem pedir pena.":
            $ aa_state = aa_choose(aa_state, 'r04', 0)
            jump r03
        "Dizer que estou sozinho até quando estou com ela.":
            $ aa_state = aa_choose(aa_state, 'r04', 1)
            jump r05
        "Ficar calado até a conta chegar.":
            $ aa_state = aa_choose(aa_state, 'r04', 2)
            "Ela virou o rosto para a janela. Não insisti. Esperei que o silêncio fizesse por mim o que minhas frases não conseguiam."
            jump k00

label r03:
    $ aa_node = 'r03'
    $ aa_location = '21h29 · Mesa'
    $ aa_stage_action = 'A confissão acontece diante dela, sem cortar para Yasmin.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    f "Eu não queria ficar sozinho. Você gostava de estar comigo e eu deixei você achar que era igual."
    if aa_matches(aa_state, {'knew': True}):
        f "Eu vi que ela estava aqui antes de a gente sair."
    if aa_matches(aa_state, {'knew': False}):
        f "Eu não sabia que ia encontrar ela. Mas o lugar tinha a ver com ela desde o começo."
    $ aa_stage_action = 'Ela pergunta o que ele quer; plano mais fechado.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.14, 0.63, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    v "E agora você quer o quê?"
    "Era a pergunta certa. Eu tinha conseguido falar de mim outra vez. Ela continuava tendo de decidir o que fazer com aquilo."
    menu:
        "Pedir uma chance e prometer esquecer Yasmin.":
            $ aa_state = aa_choose(aa_state, 'r03', 0)
            jump r06
        "Ouvir o que Vanessa quer fazer, sem negociar a resposta.":
            $ aa_state = aa_choose(aa_state, 'r03', 1)
            jump r06
        "Dizer que contei a verdade e mereço algum crédito.":
            $ aa_state = aa_choose(aa_state, 'r03', 2)
            jump r05

label r06:
    $ aa_node = 'r06'
    $ aa_location = '21h33 · Mesa'
    $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    if aa_matches(aa_state, {'bargain': True}):
        v "Você promete esquecer uma pessoa como promete pegar matéria. Depois sou eu que tenho que cobrar."
    v "Eu gostei de você. Isso é a parte que eu vou ter que aguentar amanhã."
    $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_mao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_mao'
    show screen aa_location_display
    v "Não encosta em mim agora."
    $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    "Minha mão já estava indo. Recolhi antes de chegar à dela. Ninguém na outra mesa teria percebido a diferença."
    menu:
        "Respeitar e chamar a conta.":
            $ aa_state = aa_choose(aa_state, 'r06', 0)
            jump k00
        "Dizer que ela não pode me deixar assim depois de eu me abrir.":
            $ aa_state = aa_choose(aa_state, 'r06', 1)
            jump r05
        "Pedir desculpa diante dos outros para mostrar que é sério.":
            $ aa_state = aa_choose(aa_state, 'r06', 2)
            jump r07

label r07:
    $ aa_node = 'r07'
    $ aa_location = '21h37 · Salão'
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_publico at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_publico'
    else:
        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    "Levantei a voz antes de levantar da cadeira. Contei que estava errado. Eu disse o nome de Vanessa duas vezes."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_publico at aa_camera(1.12, 0.74, 0.35)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_publico'
    else:
        $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_publico_dois at aa_camera(1.12, 0.74, 0.35)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    v "Não faz isso comigo."
    "Yasmin parou de mexer no copo. Joãozão olhou para a recepção. Todo mundo estava prestando atenção em mim. Era uma sensação boa demais para ser uma desculpa limpa."
    menu:
        "Parar quando Vanessa pede e voltar a sentar.":
            $ aa_state = aa_choose(aa_state, 'r07', 0)
            jump k00
        "Continuar até todos entenderem meu lado.":
            $ aa_state = aa_choose(aa_state, 'r07', 1)
            jump r05

label r05:
    $ aa_node = 'r05'
    $ aa_location = '21h40 · Salão'
    $ aa_stage_action = 'Vanessa põe fim à conversa antes de pagar e levantar.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    v "Chega. Eu não vou continuar te ajudando a explicar."
    $ aa_stage_action = 'Vanessa paga a própria parte ainda sentada.'
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pagamento'
    show screen aa_location_display
    "Ela chamou o garçom e acertou o que tinha pedido. Eu quis pagar. Ela disse que não."
    v "Na aula eu sento em outro lugar. A matéria de amanhã eu peço para outra pessoa."
    $ aa_stage_action = 'Ela levanta e recolhe casaco e bolsa; cadeira se afasta.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_levantar'
    show screen aa_location_display
    "Ela pegou o casaco. Não pediu licença a Yasmin. Também não olhou para Joãozão. Eu não era o centro da saída dela. Só era o motivo."
    menu:
        "Deixar ela sair.":
            $ aa_state = aa_choose(aa_state, 'r05', 0)
            $ aa_stage_action = 'Vanessa saiu. Nunca repor seu retrato nesta mesa.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sozinho'
            jump k00
        "Chamar por ela alto, obrigando o salão a olhar.":
            $ aa_state = aa_choose(aa_state, 'r05', 1)
            $ aa_stage_action = 'Chamado não desfaz a saída.'
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sozinho'
            jump k00

label k00:
    $ aa_node = 'k00'
    $ aa_location = '21h48 · Mesa'
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg_conta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg_conta'
    else:
        $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_conta_presente'
    show screen aa_location_display
    "A conta chegou dobrada. Eu abri devagar, como se pudesse negociar os números antes que alguém visse."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        "O valor era maior do que eu tinha. A promessa de pagar tudo continuava existindo, embora o dinheiro não."
    if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
        "Sem a parte de Vanessa, eu conseguia pagar. Ela tinha resolvido até a promessa que eu não podia cumprir."
    if aa_matches(aa_state, {'debt': False}):
        "Cabia no que tínhamos combinado. Pela primeira vez, uma parte da noite tinha o tamanho certo."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg_conta at aa_camera(1.1, 0.51, 0.45)
        with Dissolve(0.25)
        $ aa_last_art = 'cg_conta'
        show screen aa_location_display
        "A parte de Vanessa já estava paga. A assinatura dela no comprovante parecia normal."
    menu:
        "Pagar minha parte como combinado." if aa_matches(aa_state, {'debt': False}):
            $ aa_state = aa_choose(aa_state, 'k00', 0)
            jump k01
        "Admitir que prometi mais do que podia e pedir divisão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_state = aa_choose(aa_state, 'k00', 1)
            jump k01
        "Pagar minha parte agora que Vanessa acertou a dela." if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
            $ aa_state = aa_choose(aa_state, 'k00', 2)
            jump k01
        "Pedir dinheiro emprestado a Joãozão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_state = aa_choose(aa_state, 'k00', 3)
            jump k01
        "Reclamar alto do preço para desviar a atenção.":
            $ aa_state = aa_choose(aa_state, 'k00', 4)
            jump k01

label k01:
    $ aa_node = 'k01'
    $ aa_location = '21h55 · Salão'
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_stage_action = 'Feka sozinho após Vanessa sair.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    else:
        $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa'
    show screen aa_location_display
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        "A recepção já estava olhando para nossa mesa. O garçom perguntou, pela segunda vez, se precisávamos de alguma coisa."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_stage_action = 'O empréstimo exige olhar para Joãozão.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_balcao'
        show screen aa_location_display
        j "Eu transfiro. Você me devolve amanhã."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        "Joãozão disse isso sem sorrir. Eu teria suportado melhor uma piada."
    if aa_matches(aa_state, {'bill': 'cena'}):
        "O garçom apontou os itens. Eu sabia que estavam certos. Continuei olhando até ele perceber que eu não tinha uma dúvida."
    if aa_matches(aa_state, {'bill': 'cena', 'debt': True, 'v_gone': False}):
        "Vanessa pediu que separassem o que ela tinha consumido. Com a parte dela paga, meu saldo foi suficiente. Eu ainda resmunguei enquanto aproximava o cartão."
    if aa_matches(aa_state, {'bill': 'admitida', 'v_gone': False}):
        $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_conta_presente'
        show screen aa_location_display
        v "Eu pago o que comi. Só não diz que estava me dando um presente."
    "O salão começava a esvaziar. Restava pouco tempo para transformar aquela noite em uma história que eu conseguiria contar."
    menu:
        "Perguntar a Vanessa como ela quer ir embora." if aa_matches(aa_state, {'v_gone': False}):
            $ aa_state = aa_choose(aa_state, 'k01', 0)
            jump s00
        "Aceitar que ela foi embora e sair sozinho." if aa_matches(aa_state, {'v_gone': True}):
            $ aa_state = aa_choose(aa_state, 'k01', 1)
            jump e04
        "Tentar uma última conversa com Yasmin.":
            $ aa_state = aa_choose(aa_state, 'k01', 2)
            jump s01
        "Acertar o limite com Joãozão, sem levantar a voz." if aa_matches(aa_state, {'j_limit': True, 'truth': True}):
            $ aa_state = aa_choose(aa_state, 'k01', 3)
            jump s02
        "Provocar Joãozão na frente de Yasmin.":
            $ aa_state = aa_choose(aa_state, 'k01', 4)
            jump s03
        "Usar uma foto ou mensagem para fazer a noite parecer boa." if aa_matches(aa_state, {'public': True}):
            $ aa_state = aa_choose(aa_state, 'k01', 5)
            jump e08

label s00:
    $ aa_node = 's00'
    $ aa_location = '22h02 · Entrada'
    $ aa_stage_action = 'Casaco vestido; Vanessa confere o carro sem procurar Feka.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    v "Eu vou de carro por aplicativo. Você não precisa esperar."
    $ aa_stage_action = 'Foco no telefone dela, no carro que ela escolheu.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.1, 0.73, 0.42)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    "Eu queria que ela pedisse alguma coisa. Um casaco, companhia, uma promessa. Ela estava conferindo a placa na tela."
    menu:
        "Aceitar o término sem pedir uma promessa de volta.":
            $ aa_state = aa_choose(aa_state, 's00', 0)
            v "Eu não quero continuar assim."
            f "Eu entendi."
            jump e01
        "Perguntar se ela aceita conversar outro dia, sem exigir namoro." if aa_matches(aa_state, {'truth': True, 'listened': True, 'respect': True, 'heard': True, 'used': False, 'ambush': False, 'trust': {'gte': 2}}):
            $ aa_state = aa_choose(aa_state, 's00', 1)
            jump e02
        "Pedir para continuar como se fosse só uma noite ruim." if aa_matches(aa_state, {'truth': False, 'used': False, 'trust': {'gte': 2}}):
            $ aa_state = aa_choose(aa_state, 's00', 2)
            jump e03
        "Pedir a Yasmin que reconheça a humilhação que causou." if aa_matches(aa_state, {'stopped_joke': True, 'truth': True, 'respect': True, 'route': 'juntas'}):
            $ aa_state = aa_choose(aa_state, 's00', 3)
            jump e09
        "Ficar calado, esperando Vanessa resolver por mim.":
            $ aa_state = aa_choose(aa_state, 's00', 4)
            jump e10

label s01:
    $ aa_node = 's01'
    $ aa_location = '22h02 · Perto do balcão'
    $ aa_stage_action = 'Yasmin fecha a bolsa e recusa outra conversa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    f "Yasmin, espera."
    "Ela fechou a bolsa. Não precisou olhar para Joãozão."
    $ aa_stage_action = 'Recusa sem sorriso.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.1, 0.73, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    y "Não."
    "Eu ainda nem tinha feito a pergunta. Percebi que era sempre a mesma."
    menu:
        "Parar ali.":
            $ aa_state = aa_choose(aa_state, 's01', 0)
            jump e05
        "Insistir, falando por cima dela.":
            $ aa_state = aa_choose(aa_state, 's01', 1)
            jump s03

label s02:
    $ aa_node = 's02'
    $ aa_location = '22h03 · Balcão'
    $ aa_stage_action = 'Feka admite o limite; Joãozão não oferece amizade.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    f "Eu não vou procurar ela. Não quero que você fale por mim nem por ela."
    j "Você não vai procurar porque eu mandei?"
    $ aa_stage_action = 'O medo não desaparece depois da frase correta.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.13, 0.24, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    "Ele estava perto. Eu continuava com medo. Não precisava fingir que tinha parado de ter para responder."
    menu:
        "Dizer que a resposta dela já basta.":
            $ aa_state = aa_choose(aa_state, 's02', 0)
            jump e06
        "Dizer que Yasmin não merece tudo isso.":
            $ aa_state = aa_choose(aa_state, 's02', 1)
            jump e05

label s03:
    $ aa_node = 's03'
    $ aa_location = '22h04 · Salão'
    $ aa_stage_action = 'Yasmin detém o passo de Joãozão; funcionário se aproxima.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    j "Para de chamar ela. Ela acabou de falar."
    $ aa_stage_action = 'Mostrar a mão de Yasmin no braço, não uma briga.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.08, 0.67, 0.4)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    "Algumas pessoas olharam. Joãozão deu um passo. Yasmin tocou o braço dele e disse para ele não fazer aquilo."
    if aa_matches(aa_state, {'heat': {'gte': 3}}):
        j "Você passou a noite inteira fazendo isso."
    $ aa_stage_action = 'Abrir o plano para incluir o funcionário.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    "Um funcionário veio até nós. Não perguntou quem tinha razão. Perguntou se havia algum problema."
    menu:
        "Baixar a voz e sair.":
            $ aa_state = aa_choose(aa_state, 's03', 0)
            jump e05
        "Continuar provocando, mesmo depois do aviso.":
            $ aa_state = aa_choose(aa_state, 's03', 1)
            jump e07

label e00:
    $ aa_node = 'e00'
    $ aa_location = '19h45 · Hall do apartamento'
    $ aa_stage_action = 'Cancelamento antes de sair; Vanessa não fica para consolar.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    "Cancelei a reserva. Vanessa chamou um carro e não aceitou ficar para pedir comida."
    v "Eu ia gostar de ter sabido antes de me arrumar."
    $ aa_location = '19h50 · Cozinha compartilhada'
    $ aa_stage_action = 'Vanessa já foi; a panela permanece. Vazio agora tem causa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha'
    show screen aa_location_display
    "Depois que ela saiu, tirei a jaqueta. Na cozinha, a panela continuava na pia."
    "Peguei o celular. A vontade de ver Yasmin não tinha acabado porque eu tinha feito uma coisa certa."
    $ aa_location = '19h55 · Cozinha compartilhada'
    $ aa_stage_action = 'Feka lava a própria panela; encerramento concreto.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_lavar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_lavar'
    show screen aa_location_display
    "Deixei em cima da mesa e lavei a panela. Na manhã seguinte, Vanessa respondeu à pergunta sobre a chave. Não respondeu ao resto."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E00 · A noite que não aconteceu"
    return

label e01:
    $ aa_node = 'e01'
    $ aa_location = '22h10 · Calçada'
    $ aa_stage_action = 'Duas pessoas diante da mesma porta escolhem rumos diferentes.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    f "Tá. Eu vou por outro caminho."
    v "Tá."
    "Esperei uma frase maior. Ela não tinha obrigação de encerrar aquilo de um jeito que me ajudasse."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Sozinho, Feka apaga a cobrança disfarçada de desculpa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('rascunho')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "No caminho de volta, escrevi que sentia muito. Apaguei quando percebi que estava esperando uma resposta antes de enviar."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Dia seguinte: distância entre os colegas.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, Vanessa sentou longe de mim. Mandei a matéria pelo grupo da turma, onde ela podia pegar sem precisar agradecer."
    "Eu soube que ela tinha recebido as chaves por outra pessoa."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E01 · Duas contas"
    return

label e02:
    $ aa_node = 'e02'
    $ aa_location = '22h10 · Calçada'
    $ aa_stage_action = 'Vanessa aceita apenas a possibilidade de outra conversa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    f "Você aceita conversar outro dia? Se não quiser, eu não vou ficar perguntando."
    v "Talvez na faculdade. Outro dia. Agora eu não quero."
    "Quase chamei aquilo de uma chance. Era uma conversa que ainda não tinha sido aceita."
    v "E não aparece na mudança. Se eu precisar, eu peço."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A matéria é enviada sem usar a mensagem como reconciliação.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, mandei só a matéria que tinha prometido. Ela respondeu ‘obrigada’. Passei tempo demais olhando a palavra."
    "Não mandei outra. Não porque estivesse curado. Porque ela tinha sido clara."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E02 · Sem promessa"
    return

label e03:
    $ aa_node = 'e03'
    $ aa_location = '22h10 · Calçada'
    $ aa_stage_action = 'A relação continua por inércia, antes de entrarem no carro.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    f "A gente não precisa terminar por causa de uma noite."
    v "Eu não vou decidir isso agora."
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'Entram no mesmo carro e olham para lados opostos.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_carro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_carro'
    show screen aa_location_display
    "Entrei no carro com ela quando abriu espaço. Fomos olhando para lados diferentes."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A convivência continua sem intimidade restaurada.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, respondeu às mensagens com frases curtas. Não me convidou para conhecer o apartamento."
    "Quando me perguntaram se estava tudo bem, eu disse que sim. Era verdade que não estava solteiro. Era o que eu tinha conseguido preservar."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E03 · Continuar"
    return

label e04:
    $ aa_node = 'e04'
    $ aa_location = '22h10 · Mesa'
    $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    "A cadeira ainda estava um pouco afastada. Tive vontade de pôr no lugar, como se isso diminuísse o que tinha acontecido."
    "O garçom perguntou se podia tirar o segundo copo. Respondi que podia. Foi a única decisão que alguém ainda precisava de mim."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Um caderno na mesa; o de Vanessa foi embora com ela.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Em casa, só o meu caderno estava na escrivaninha. Vanessa tinha levado o dela. Meu desenho foi junto."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Cumprimento distante no dia seguinte.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Na segunda-feira, cumprimentei de longe. Ela respondeu. Ser tratado com educação foi menos confortável do que ser xingado."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E04 · Cadeira vazia"
    return

label e05:
    $ aa_node = 'e05'
    $ aa_location = '22h10 · Entrada'
    $ aa_stage_action = 'Yasmin e Joãozão saem juntos.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    show aa_y firm at aa_left
    show aa_j neutral at aa_right
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    "Yasmin foi embora com Joãozão. Não houve uma última olhada. Esperei até a porta fechar mesmo assim."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_stage_action = 'Exibir Vanessa somente se ainda não tiver saído.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        "Quando voltei, Vanessa já tinha chamado o carro. Disse que não precisava mais esperar por mim."
    $ aa_stage_action = 'Feka permanece sem conseguir reter ninguém.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "Eu tinha perdido o jantar de Vanessa e ainda queria que alguém reconhecesse meu sofrimento como a parte principal."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A toalha úmida retoma o início da noite.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "No quarto, a toalha continuava úmida. Eu lembrava de Vanessa perguntando onde estava. Não lembrava do que respondi."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A mesma mensagem antiga, agora sem desculpa.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Abri a conversa de Yasmin. A mensagem antiga continuava lá, dizendo para eu não esperar na saída. Era uma resposta que eu tinha passado anos fingindo não saber ler."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E05 · A mesma resposta"
    return

label e06:
    $ aa_node = 'e06'
    $ aa_location = '22h10 · Balcão e calçada'
    $ aa_stage_action = 'A conversa termina sem aperto de mão.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    f "Não. Porque ela não quer."
    j "Então faz isso."
    "Ele não me deu a mão. Eu não ofereci a minha. Não havia amizade escondida esperando a frase certa."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_stage_action = 'Vanessa tem seu transporte; acordo com Joãozão não a retém.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        "Vanessa já tinha seu próprio carro chamado. Eu não usei a conversa com Joãozão como motivo para pedir que ficasse."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_stage_action = 'O ramo em que ela já saiu permanece vazio.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'bg_calcada'
        show screen aa_location_display
        "Vanessa já tinha ido. Acertar uma coisa não trouxe de volta a outra."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Empréstimo devolvido no dia seguinte.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "No dia seguinte, devolvi o dinheiro de Joãozão com uma mensagem curta."
    "Eu ia continuar estudando com Vanessa. Yasmin, com ele. Pela primeira vez pensei nisso como a vida deles, não como uma provocação."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E06 · Sem plateia"
    return

label e07:
    $ aa_node = 'e07'
    $ aa_location = '22h12 · Entrada de serviço'
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    "O funcionário pediu que eu saísse. Eu tentei contar a história. Ele repetiu o pedido, agora mais devagar."
    y "João, para. Não precisa ir atrás."
    "Joãozão parou. Nem a briga que eu estava tentando fabricar aconteceu do jeito que eu precisava."
    if aa_matches(aa_state, {'v_gone': False}):
        "Vanessa saiu pela outra porta. Não veio perguntar se eu estava bem."
    $ aa_stage_action = 'Feka grava o áudio na calçada, já fora do restaurante.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.14, 0.74, 0.33)
    with Dissolve(0.25)
    show screen aa_phone_view('audio')
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    "Na calçada, o frio veio depois da vergonha. Enviei um áudio dizendo que tinham me desrespeitado. Ouvi antes de enviar o segundo. Minha voz parecia satisfeita por finalmente ter um culpado."
    "No grupo, alguém respondeu ‘complicado’. Eu guardei aquela palavra como apoio."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E07 · Fora do salão"
    return

label e08:
    $ aa_node = 'e08'
    $ aa_location = '22h16 · Celular'
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    else:
        $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_levantar'
        show screen aa_location_display
        "Vanessa disse que ia embora. Respondi sem tirar o olho da tela. Ela não repetiu."
    $ aa_stage_action = 'Só então a cadeira fica vazia.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('enquadramento')
    $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    "Fotografei as duas taças que ainda estavam na mesa. Não era preciso falsificar uma foto. Bastava escolher o que ficava fora."
    "Escrevi que a noite tinha sido boa. Fiquei olhando as visualizações."
    $ aa_stage_action = 'A mensagem desmonta a publicação feliz.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('marcacao')
    $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    "Vanessa mandou uma mensagem pedindo que eu não a marcasse. Não tinha palavrão. Apaguei a marcação e deixei a publicação."
    "Yasmin não respondeu. Eu disse a mim mesmo que ela devia ter visto."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Outro público para a versão menor da história.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Na manhã seguinte, contei a um colega que Vanessa estava estranha. Ele não conhecia o começo da história. Era por isso que eu tinha escolhido contar a ele."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E08 · Uma noite ótima"
    return

label e09:
    $ aa_node = 'e09'
    $ aa_location = '22h10 · Entrada'
    $ aa_stage_action = 'Yasmin se dirige a Vanessa; Joãozão aguarda.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    "Chamei Yasmin quando ela e Joãozão chegaram à porta."
    f "Você podia pelo menos pedir desculpa pelo que falou."
    "Yasmin olhou para Vanessa. Eu fiquei esperando que olhasse para mim."
    $ aa_stage_action = 'Yasmin olha para Vanessa, Feka fora do centro.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.12, 0.52, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    y "Eu fiz uma piada e te coloquei no meio. Foi escroto. Desculpa."
    v "Foi. Mas o que ele fez comigo não foi culpa sua."
    $ aa_stage_action = 'Cada uma segue seu caminho; ninguém posa para Feka.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    "As duas não viraram amigas. Vanessa foi para o carro. Yasmin voltou para buscar a bolsa. Eu tinha produzido uma conversa em que não havia lugar para mim."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A interpretação continua difícil no dia seguinte.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, tentei lembrar a noite sem dividir as pessoas entre quem me humilhou e quem devia ter me salvado. Não consegui o tempo todo."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E09 · Não foi por mim"
    return

label e10:
    $ aa_node = 'e10'
    $ aa_location = '22h14 · Mesa'
    $ aa_stage_action = 'Vanessa anuncia o carro antes de sair.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    v "Meu carro chegou."
    "Eu disse ‘tá’ e esperei que ela perguntasse se eu ia junto. Ela foi embora."
    $ aa_stage_action = 'Feka volta à sobremesa com duas colheres e uma cadeira vazia.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    "Voltei à mesa. A sobremesa que eu tinha pedido veio com duas colheres. Não avisei o garçom. Fiquei com vergonha de explicar uma coisa tão simples."
    "Não fiz uma cena. Não disse uma última mentira. Também não disse o que devia. Consegui passar pela noite deixando o trabalho para os outros."
    $ aa_location = 'Mais tarde · Cozinha compartilhada'
    $ aa_stage_action = 'Panela limpa por outra pessoa: repetir o espaço, mudar o objeto.'
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha_noite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha_noite'
    show screen aa_location_display
    "Em casa, a cozinha estava limpa. Um dos moradores tinha lavado minha panela. Senti alívio antes de sentir vergonha."
    hide screen aa_location_display
    hide screen aa_phone_view
    centered "E10 · Sobremesa fria"
    return
