# Gerado por tools/build_story.py. Edite a fonte editorial, não este arquivo.
label start:
    $ aa_world_start()
    $ aa_trace = []
    $ aa_state = aa_new_state()
    $ aa_last_art = ""
    $ aa_phone_memory = ()
    $ aa_phone_active = True
    $ aa_audio_reset()
    jump a00

label a00:
    $ aa_node = 'a00'
    $ aa_location = '18h42 · Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1122)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a00')
    $ aa_stage_action = 'Vanessa larga a bolsa; Feka sentado, ainda sem celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_bolsa'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 0, phase=0)
    "Vanessa deixou a bolsa na minha cama e abriu o zíper."
    $ aa_audio_event('a00', 'line', 1, phase=0)
    $ aa_stage_action = 'Vanessa entrou no banheiro; Feka responde da cama.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_banheiro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_banheiro'
    show screen aa_location_display
    "Ela entrou no banheiro. A torneira fez barulho antes de sair água."
    $ aa_audio_event('a00', 'line', 2, phase=0)
    v "Onde você deixa a toalha de rosto?"
    $ aa_audio_event('a00', 'line', 3, phase=0)
    f "Atrás da porta."
    $ aa_audio_event('a00', 'line', 4, phase=0)
    $ aa_stage_action = 'Ela seca as mãos na toalha de banho; o gancho fica vazio.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.08, 0.83, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "Era a de banho. A de rosto estava no cesto havia três dias. Ela não reclamou."
    $ aa_audio_event('a00', 'line', 5, phase=0)
    "Meu quarto tinha banheiro. A cozinha e a sala eram divididas com gente que sempre sabia quando eu tinha visita."
    $ aa_audio_event('a00', 'line', 6, phase=0)
    $ aa_stage_action = 'Atenção nos cadernos e na escrivaninha, ainda no mesmo espaço.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.2, 0.54, 0.44)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "Na escrivaninha, dois cadernos de Direito. Vanessa tinha corrigido minhas anotações. Antes da última prova, eu tinha esperado com ela no corredor até a mão parar de tremer. Ela ainda falava daquele dia."
    $ aa_audio_event('a00', 'line', 7, phase=0)
    $ aa_stage_action = 'A escolha ocorre antes de Feka pegar o celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "O celular estava no carregador. Yasmin não tinha me mandado mensagem. Não era preciso uma mensagem para eu pegar o celular."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Abrir o perfil de Yasmin.":
            $ aa_audio_event('a00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a00', 0)
            jump a01
        "Conferir a conversa antiga com Yasmin.":
            $ aa_audio_event('a00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a00', 1)
            jump a02
        "Deixar o celular e separar a roupa.":
            $ aa_audio_event('a00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a00', 2)
            $ aa_stage_action = 'Ele deixa o telefone e presta atenção no quarto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_brincos'
            $ aa_audio_event('a00', 'response', 0, 2)
            "Afastei o celular com a jaqueta. Não apaguei nada. Só deixei para depois."
            jump a03

label a01:
    $ aa_node = 'a01'
    $ aa_location = '18h46 · Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1126)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a01')
    $ aa_stage_action = 'Feka pega o celular; Vanessa continua no banheiro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    window hide
    hide screen aa_location_display
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    if aa_last_art != 'cg2_celular':
        show screen aa_cg_continue
        pause
        hide screen aa_cg_continue
    window auto
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    $ aa_audio_event('a01', 'line', 0, phase=0)
    $ aa_stage_action = 'Foto vertical do casal na tela, vista das mãos de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'publicacao'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('publicacao')
    show screen aa_phone_view('publicacao')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    "Os dois de jaleco. Eu já sabia que estudavam juntos. Abri a foto mesmo assim."
    $ aa_audio_event('a01', 'line', 1, phase=0)
    $ aa_stage_action = 'Passa à foto do copo, cardápio e mão de Joãozão; localização legível.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'restaurante'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('restaurante')
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    "A publicação seguinte era de poucos minutos antes."
    $ aa_audio_event('a01', 'line', 2, phase=0)
    "Casa do Pátio. Era o lugar da minha reserva. Eu podia cancelar. Ainda nem tínhamos saído."
    $ aa_audio_event('a01', 'line', 3, phase=0)
    "A ideia de cancelar me deu uma raiva pequena e imediata. Eu tinha passado a semana dizendo que aquele jantar era para Vanessa."
    $ aa_audio_event('a01', 'line', 4, phase=0)
    $ aa_stage_action = 'Vanessa chama fora do quadro; ele ainda olha a publicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'restaurante'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('restaurante')
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    v "Você viu meu brinco? O pequeno."
    $ aa_audio_event('a01', 'line', 5, phase=0)
    $ aa_stage_action = 'Retorno ao quarto após a interrupção; telefone ainda nas mãos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    "Eu respondi que não sem levantar os olhos."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Fechar a publicação. Agora eu sei que ela está lá.":
            $ aa_audio_event('a01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a01', 0)
            jump a03
        "Ficar olhando mais um pouco.":
            $ aa_audio_event('a01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a01', 1)
            jump a02

label a02:
    $ aa_node = 'a02'
    $ aa_location = '18h51 · Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1131)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a02')
    $ aa_stage_action = 'Conversa antiga na tela física; nenhum pensamento atribuído a Yasmin.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'conversa'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('conversa')
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    $ aa_audio_event('a02', 'line', 0, phase=0)
    "A conversa era antiga. Não o suficiente para eu ter esquecido o que ela dizia."
    $ aa_audio_event('a02', 'line', 1, phase=0)
    y "Feka, não me espera na saída de novo. Eu não combinei nada com você."
    $ aa_audio_event('a02', 'line', 2, phase=0)
    "Embaixo, eu tinha escrito que estava só passando. Eu lembrava de ter chegado cedo."
    $ aa_audio_event('a02', 'line', 3, phase=0)
    "Conheci Yasmin no ensino médio. Durante anos, qualquer coisa serviu: uma resposta curta, uma foto nova, o lugar onde ela dizia que ia estar."
    $ aa_audio_event('a02', 'line', 4, phase=0)
    "Eu chamava aquilo de gostar de alguém. A palavra não dizia quanto trabalho eu dava a ela."
    $ aa_audio_event('a02', 'line', 5, phase=0)
    $ aa_stage_action = 'A voz de Vanessa devolve o quarto ao primeiro plano.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    v "Feka?"
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Guardar o celular e responder.":
            $ aa_audio_event('a02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a02', 0)
            jump a03
        "Reler minha resposta, procurando alguma defesa.":
            $ aa_audio_event('a02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a02', 1)
            jump a03

label a03:
    $ aa_node = 'a03'
    $ aa_location = '19h02 · Quarto e banheiro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a03'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1142)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a03')
    $ aa_stage_action = 'Celular abaixado; toalha devolvida; Vanessa termina o brinco.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    $ aa_audio_event('a03', 'line', 0, phase=0)
    "Vanessa pendurou a toalha úmida no banheiro. Ainda mexia no fecho do brinco, perto da porta. O casaco e a bolsa estavam na cama."
    $ aa_audio_event('a03', 'line', 1, phase=0)
    v "Achei o brinco. Tava na minha bolsa."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a03', 'line', 2, phase=0)
        v "Você nem olhou quando eu perguntei. Ficou no celular."
    if aa_matches(aa_state, {'late': True}):
        $ aa_audio_event('a03', 'line', 3, phase=0)
        v "Você ficou quieto. Achei que tinha desistido de sair."
    $ aa_audio_event('a03', 'line', 4, phase=0)
    $ aa_stage_action = 'Último ajuste do brinco antes de atravessar o quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.13, 0.83, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    "Ela terminou de colocar o brinco, atravessou o quarto e pegou o casaco."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a03', 'line', 5, phase=0)
        "Eu sabia onde Yasmin estava. Vanessa só sabia onde íamos jantar."
    $ aa_audio_event('a03', 'line', 6, phase=0)
    $ aa_stage_action = 'Feka levanta, veste a jaqueta e acerta a gola; cadeira livre.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    "Levantei e vesti a jaqueta escura. Vanessa me olhou enquanto eu acertava a gola."
    $ aa_audio_event('a03', 'line', 7, phase=0)
    $ aa_stage_action = 'O olhar de Vanessa acompanha a escolha da roupa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.1, 0.27, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    v "Essa? Você não vai sentir calor?"
    $ aa_audio_event('a03', 'line', 8, phase=0)
    v "Eu demorei muito?"
    $ aa_audio_event('a03', 'line', 9, phase=0)
    f "Não."
    $ aa_audio_event('a03', 'line', 10, phase=0)
    "Ela olhou para o meu rosto para conferir. Eu estava terminando de arrumar a gola."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Perguntar se ela prefere a camiseta.":
            $ aa_audio_event('a03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a03', 0)
            $ aa_stage_action = 'Ela espera que a escolha da roupa encerre a distração.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_quarto_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_quarto_espera'
            $ aa_audio_event('a03', 'response', 0, 0)
            v "Eu gosto da camiseta. Mas essa também fica boa."
            $ aa_audio_event('a03', 'response', 1, 0)
            "Ela esperou eu escolher. Eu tinha perguntado por costume."
            jump a04
        "Dizer que já está bom e elogiar o cabelo dela.":
            $ aa_audio_event('a03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a03', 1)
            $ aa_stage_action = 'Feka finalmente olha para ela; sorriso breve, casaco no braço.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_quarto_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_quarto_espera'
            $ aa_audio_event('a03', 'response', 0, 1)
            f "Seu cabelo ficou bonito."
            $ aa_audio_event('a03', 'response', 1, 1)
            v "É? Eu achei que você nem tinha visto."
            $ aa_audio_event('a03', 'response', 2, 1)
            "Ela sorriu. Eu devia ter olhado antes de falar."
            jump a04
        "Conferir pelo celular uma foto minha que Yasmin já curtiu.":
            $ aa_audio_event('a03', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a03', 2)
            $ aa_stage_action = 'Foto antiga ampliável; ele bloqueia antes de Vanessa se aproximar.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = 'comparacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_phone_remember('comparacao')
            show screen aa_phone_view('comparacao')
            $ aa_last_art = 'cg2_quarto_jaqueta'
            $ aa_audio_event('a03', 'response', 0, 2)
            "Ampliei a foto para ver a roupa."
            $ aa_audio_event('a03', 'response', 1, 2)
            $ aa_stage_action = 'Tela bloqueada; Vanessa volta a ocupar a cena.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_jaqueta'
            "Vanessa passou atrás de mim para buscar a bolsa. Bloqueei a tela antes de ela chegar perto."
            jump a04

label a04:
    $ aa_node = 'a04'
    $ aa_location = '19h13 · Cozinha compartilhada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a04'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1153)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a04')
    $ aa_stage_action = 'Feka junto à panela; Vanessa diante da geladeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    $ aa_audio_event('a04', 'line', 0, phase=0)
    "Na cozinha, alguém tinha deixado uma panela dentro da pia. Passei duas vezes por ela como se não fosse minha."
    $ aa_audio_event('a04', 'line', 1, phase=0)
    $ aa_stage_action = 'Vanessa começa a falar; a panela fica no campo periférico.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.06, 0.78, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    v "Amanhã eu pego a chave."
    $ aa_audio_event('a04', 'line', 2, phase=0)
    f "Do apartamento?"
    $ aa_audio_event('a04', 'line', 3, phase=0)
    v "Não. Da prefeitura."
    $ aa_audio_event('a04', 'line', 4, phase=0)
    "Eu ri atrasado. Ela abriu a geladeira, viu uma garrafa com o nome de outro morador e fechou."
    $ aa_audio_event('a04', 'line', 5, phase=0)
    $ aa_stage_action = 'A geladeira é fechada; conversa continua entre os dois.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    v "Vou poder comprar uma coisa e encontrar a mesma coisa quando voltar."
    $ aa_audio_event('a04', 'line', 6, phase=0)
    "Estudávamos Direito na mesma turma. Eu sabia as matérias em que Vanessa ia bem. Não sabia quem tinha ido ver o apartamento com ela."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Perguntar como foi a visita e deixar ela contar.":
            $ aa_audio_event('a04', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a04', 0)
            jump a05
        "Brincar que agora vou ter onde dormir.":
            $ aa_audio_event('a04', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a04', 1)
            jump a05
        "Avisar que precisamos sair, olhando o celular.":
            $ aa_audio_event('a04', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a04', 2)
            $ aa_stage_action = 'Uma olhada no relógio encerra a escuta.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = 'relogio'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_phone_remember('relogio')
            show screen aa_phone_view('relogio')
            $ aa_last_art = 'cg2_cozinha_fechada'
            $ aa_audio_event('a04', 'response', 0, 2)
            v "Eu já estou pronta. Você também? Então vamos."
            jump a05

label a05:
    $ aa_node = 'a05'
    $ aa_location = '19h22 · Cozinha compartilhada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a05'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1162)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a05')
    $ aa_stage_action = 'Geladeira fechada; Vanessa mostra o orçamento no celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    if aa_matches(aa_state, {'heard': True}):
        $ aa_audio_event('a05', 'line', 0, phase=0)
        v "Fui com a minha mãe. É pequeno. Não tem onde pôr uma mesa grande. Mas a porta fecha."
    if aa_matches(aa_state, {'claimed_space': True}):
        $ aa_audio_event('a05', 'line', 1, phase=0)
        v "Vai querer ir mesmo ou tá só falando?"
    $ aa_audio_event('a05', 'line', 2, phase=0)
    $ aa_stage_action = 'Orçamento na mão dela, não na tela de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'orcamento'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.1, 0.74, 0.48)
    with Dissolve(0.25)
    $ aa_phone_remember('orcamento')
    show screen aa_phone_view('orcamento')
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    "Ela virou o celular para mim. Tinha separado o dinheiro da caução e do frete. Para o jantar, sobravam noventa reais."
    $ aa_audio_event('a05', 'line', 3, phase=0)
    $ aa_stage_action = 'Voltar a Vanessa: ela explica o limite do orçamento.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    v "Cada um paga o seu, tá? Posso gastar até noventa hoje. O dinheiro da mudança eu não quero mexer."
    $ aa_audio_event('a05', 'line', 4, phase=0)
    "Yasmin tinha recomendado o restaurante no grupo três semanas antes. Guardei o nome. Para Vanessa, disse que tinha pensado nela."
    $ aa_audio_event('a05', 'line', 5, phase=0)
    f "Meu pai vai mandar cem reais amanhã de manhã."
    $ aa_audio_event('a05', 'line', 6, phase=0)
    v "Minha mãe vai ajudar com a mudança de manhã. Você podia ir depois da aula."
    $ aa_audio_event('a05', 'line', 7, phase=0)
    "Ela disse isso enquanto guardava o celular, sem olhar para mim."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Combinar que cada um paga o seu.":
            $ aa_audio_event('a05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a05', 0)
            $ aa_audio_event('a05', 'response', 0, 0)
            f "Combinado. Cada um o seu."
            $ aa_audio_event('a05', 'response', 1, 0)
            v "Obrigada. Prefiro saber antes."
            jump a06
        "Insistir que hoje eu pago tudo.":
            $ aa_audio_event('a05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a05', 1)
            $ aa_audio_event('a05', 'response', 0, 1)
            f "Hoje deixa comigo."
            $ aa_audio_event('a05', 'response', 1, 1)
            v "Tem certeza?"
            $ aa_audio_event('a05', 'response', 2, 1)
            f "Tenho."
            $ aa_audio_event('a05', 'response', 3, 1)
            "Consegui dizer sem conferir o saldo outra vez."
            jump a06
        "Dizer que estou apertado e combinar de dividir a conta.":
            $ aa_audio_event('a05', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a05', 2)
            $ aa_audio_event('a05', 'response', 0, 2)
            v "Tudo bem. Eu falei de jantar, não de te quebrar."
            jump a06

label a06:
    $ aa_node = 'a06'
    $ aa_location = '19h30 · Hall do apartamento'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a06'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1170)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a06')
    $ aa_stage_action = 'Casaco vestido, caderno entrando na bolsa, chave com Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall'
    show screen aa_location_display
    $ aa_audio_event('a06', 'line', 0, phase=0)
    "Vanessa vestiu o casaco, guardou o caderno na bolsa e conferiu a chave, o celular e a carteira. Fiquei esperando que terminasse sem me perguntar mais nada."
    $ aa_audio_event('a06', 'line', 1, phase=0)
    $ aa_stage_action = 'A bolsa se fecha; Vanessa levanta os olhos para perguntar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    v "Foi você mesmo que descobriu esse lugar?"
    $ aa_audio_event('a06', 'line', 2, phase=0)
    "A pergunta podia acabar ali. Isso era o que eu queria: que uma pergunta acabasse antes de chegar onde doía."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Contar que Yasmin indicou o lugar e que eu vi que ela está lá." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a06', 0)
            jump a07
        "Contar que quem indicou foi uma menina de quem eu gostei." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a06', 1)
            jump a07
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a06', 2)
            $ aa_audio_event('a06', 'response', 0, 2)
            f "Achei por acaso. Vi o lugar e pensei na gente."
            jump a08
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'a06', 3)
            $ aa_audio_event('a06', 'response', 0, 3)
            f "Achei por acaso. Vi o lugar e pensei na gente."
            jump a08
        "Dizer que uma amiga da escola compartilhou o restaurante num grupo." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'a06', 4)
            $ aa_audio_event('a06', 'response', 0, 4)
            f "Uma amiga da escola mandou no grupo. Achei o lugar legal."
            $ aa_audio_event('a06', 'response', 1, 4)
            v "Ah. Pensei que você já tivesse ido."
            $ aa_audio_event('a06', 'response', 2, 4)
            f "Não. Vai ser a primeira vez."
            jump a08
        "Dizer que uma amiga da escola compartilhou o restaurante num grupo." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'a06', 5)
            $ aa_audio_event('a06', 'response', 0, 5)
            f "Uma amiga da escola mandou no grupo. Achei o lugar legal."
            $ aa_audio_event('a06', 'response', 1, 5)
            v "Ah. Pensei que você já tivesse ido."
            $ aa_audio_event('a06', 'response', 2, 5)
            f "Não. Vai ser a primeira vez."
            jump a08

label a07:
    $ aa_node = 'a07'
    $ aa_location = '19h34 · Hall do apartamento'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a07'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1174)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a07')
    $ aa_stage_action = 'Vanessa interrompe a saída e olha para Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.08, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    $ aa_audio_event('a07', 'line', 0, phase=0)
    v "De quem você gostou?"
    $ aa_audio_event('a07', 'line', 1, phase=0)
    $ aa_stage_action = 'Contracampo de Feka antes de dizer o nome.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.14, 0.74, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    f "Yasmin. A gente estudou junto no ensino médio."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a07', 'line', 2, phase=0)
        v "E você ia me levar sabendo que ela está lá?"
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('a07', 'line', 3, phase=0)
        $ aa_stage_action = 'A pergunta pede uma resposta suportável.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_hall_duvida'
        show screen aa_location_display
        v "Mas você não gosta mais dela, né?"
    $ aa_audio_event('a07', 'line', 4, phase=0)
    $ aa_stage_action = 'A distância entre ambos reaparece no plano aberto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    "Eu quase disse que não havia motivo para ciúme. Ela ainda não tinha falado de ciúme."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir que ainda penso nela e deixar Vanessa decidir.":
            $ aa_audio_event('a07', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a07', 0)
            jump a09
        "Dizer que é passado e manter a reserva.":
            $ aa_audio_event('a07', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a07', 1)
            jump a08

label a09:
    $ aa_node = 'a09'
    $ aa_location = '19h38 · Hall do apartamento'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a09'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1178)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a09')
    $ aa_stage_action = 'Vanessa busca uma garantia antes de sair; bolsa nas mãos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('a09', 'line', 0, phase=0)
    v "Ainda pensa como?"
    $ aa_audio_event('a09', 'line', 1, phase=0)
    "Não respondi. O silêncio fez o serviço que eu estava adiando."
    $ aa_audio_event('a09', 'line', 2, phase=0)
    $ aa_stage_action = 'Ela ainda deseja ir ao jantar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.08, 0.3, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    v "Eu quero ir com você. Só não quero chegar lá e ficar sobrando."
    $ aa_audio_event('a09', 'line', 3, phase=0)
    v "E não pede foto se a gente estiver brigado. Eu vou acabar aceitando e depois vou odiar a foto."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Ir, aceitando esse limite.":
            $ aa_audio_event('a09', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a09', 0)
            $ aa_audio_event('a09', 'response', 0, 0)
            f "Tá. Sem foto."
            $ aa_audio_event('a09', 'response', 1, 0)
            v "Mas você ainda quer ir comigo?"
            $ aa_audio_event('a09', 'response', 2, 0)
            f "Quero."
            $ aa_audio_event('a09', 'response', 3, 0)
            "Era verdade que eu queria ir. Deixei a resposta inteira por conta dela."
            jump a08
        "Cancelar o jantar e terminar o namoro, sem pedir que ela me console.":
            $ aa_audio_event('a09', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a09', 1)
            jump e00

label a08:
    $ aa_node = 'a08'
    $ aa_location = '19h48 · A caminho do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['a08'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1188)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('a08')
    $ aa_stage_action = 'Ambos caminham; Vanessa puxa a manga do casaco.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    $ aa_audio_event('a08', 'line', 0, phase=0)
    "Na rua, Vanessa puxou a própria manga sobre a mão. Perguntei se estava com frio. Ela disse que não era nada."
    if aa_matches(aa_state, {'ambush': True}):
        $ aa_audio_event('a08', 'line', 1, phase=0)
        "A tela do meu celular continuava escura. Eu sabia tudo que precisava saber para fingir uma surpresa."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('a08', 'line', 2, phase=0)
        "Fiquei procurando alguma coisa para dizer. Vanessa andava ao meu lado, e eu já estava deixando que ela fizesse o esforço de puxar conversa."
    $ aa_audio_event('a08', 'line', 3, phase=0)
    $ aa_stage_action = 'A promessa sobre a aula acontece enquanto caminham.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.06, 0.65, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    v "Amanhã, se eu faltar na primeira aula, você pega a matéria?"
    $ aa_audio_event('a08', 'line', 4, phase=0)
    f "Pego."
    $ aa_audio_event('a08', 'line', 5, phase=0)
    "Ela perguntou se eu mandaria a matéria mesmo se não desse para ir à mudança. Falei que sim. Ela disse obrigada duas vezes."
    jump b00

label b00:
    $ aa_node = 'b00'
    $ aa_location = '20h10 · Entrada do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1210)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b00')
    $ aa_stage_action = 'Feka reconhece Joãozão e depois Yasmin enquanto Vanessa espera uma explicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg11_recepcao_reconhecimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg11_recepcao_reconhecimento'
    show screen aa_location_display
    $ aa_audio_event('b00', 'line', 0, phase=0)
    "A primeira coisa que vi foi Joãozão. Depois a mão de Yasmin no braço dele. Achei essa ordem injusta."
    $ aa_audio_event('b00', 'line', 1, phase=0)
    $ aa_stage_action = 'Feka reconhece Joãozão e depois Yasmin enquanto Vanessa espera uma explicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg11_recepcao_reconhecimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg11_recepcao_reconhecimento'
    show screen aa_location_display
    "Vanessa tirou o casaco e parou ao meu lado, com ele no braço. A recepcionista perguntou o nome da reserva. Eu disse meu nome baixo demais e precisei repetir."
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('b00', 'line', 2, phase=0)
        v "É ela?"
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('b00', 'line', 3, phase=0)
        v "Você conhece alguém?"
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Responder Vanessa e perguntar se ela quer cumprimentar os dois.":
            $ aa_audio_event('b00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b00', 0)
            if aa_matches(aa_state, {'v_knows': True}):
                $ aa_audio_event('b00', 'response', 0, 0)
                $ aa_stage_action = 'Feka se volta para Vanessa antes de se aproximarem da mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg11_entrada_conversa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg11_entrada_conversa'
                f "É ela. Se você não quiser falar com eles, a gente vai direto pra nossa mesa."
            if aa_matches(aa_state, {'v_knows': False, 'group_source': True}):
                $ aa_audio_event('b00', 'response', 1, 0)
                $ aa_stage_action = 'Feka se volta para Vanessa antes de se aproximarem da mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg11_entrada_conversa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg11_entrada_conversa'
                f "É a amiga do grupo. O namorado dela é o Joãozão. Se você quiser, a gente vai direto pra nossa mesa."
            if aa_matches(aa_state, {'v_knows': False, 'group_source': False}):
                $ aa_audio_event('b00', 'response', 2, 0)
                $ aa_stage_action = 'Feka se volta para Vanessa antes de se aproximarem da mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg11_entrada_conversa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg11_entrada_conversa'
                f "É a Yasmin. A gente estudou junto. Se você não quiser falar com eles, a gente vai direto pra nossa mesa."
            $ aa_audio_event('b00', 'response', 3, 0)
            v "Eles já viram a gente. Vamos só dar boa noite. Depois a gente senta."
            $ aa_audio_event('b00', 'response', 4, 0)
            "Vanessa ajeitou o casaco no braço e esperou que eu andasse ao lado dela."
            jump b01
        "Ir até a mesa e apresentar Vanessa como minha namorada.":
            $ aa_audio_event('b00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b00', 1)
            $ aa_audio_event('b00', 'response', 0, 1)
            "Fui até a mesa sem responder à pergunta de Vanessa. Esperei Yasmin olhar para nós."
            jump b01
        "Puxar Vanessa para perto antes que Yasmin olhe.":
            $ aa_audio_event('b00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b00', 2)
            $ aa_audio_event('b00', 'response', 0, 2)
            "Passei o braço pela cintura de Vanessa. O corpo dela endureceu por um instante. Ela ajeitou o casaco e ficou perto de mim."
            jump b01

label b01:
    $ aa_node = 'b01'
    $ aa_location = '20h14 · Salão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1214)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b01')
    $ aa_stage_action = 'Joãozão continua sentado; Feka e Vanessa estão de pé.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.08, 0.73, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    $ aa_audio_event('b01', 'line', 0, phase=0)
    y "Feka? Oi."
    $ aa_audio_event('b01', 'line', 1, phase=0)
    "Vanessa virou o rosto para mim. Eu senti um alívio absurdo: Yasmin tinha lembrado meu nome."
    if aa_matches(aa_state, {'group_source': True}):
        $ aa_audio_event('b01', 'line', 2, phase=0)
        y "Você veio conhecer o restaurante? Eu mandei no grupo da escola faz um tempo."
    if aa_matches(aa_state, {'group_source': False}):
        $ aa_audio_event('b01', 'line', 3, phase=0)
        y "Faz tempo."
    $ aa_audio_event('b01', 'line', 4, phase=0)
    j "Boa noite."
    $ aa_audio_event('b01', 'line', 5, phase=0)
    $ aa_stage_action = 'Joãozão não oferece a mão; Feka transforma o gesto em ajuste da cadeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cumprimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cumprimento'
    show screen aa_location_display
    "Joãozão não levantou. Fui apertar uma mão que ele não tinha oferecido. Consertei o movimento mexendo na cadeira."
    if aa_matches(aa_state, {'introduced': True}):
        $ aa_audio_event('b01', 'line', 6, phase=0)
        $ aa_stage_action = 'Joãozão continua sentado; Feka e Vanessa estão de pé.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg_chegada at aa_camera(1.08, 0.73, 0.35)
        with Dissolve(0.25)
        $ aa_last_art = 'cg_chegada'
        show screen aa_location_display
        f "Essa é a Vanessa, minha namorada."
    if aa_matches(aa_state, {'introduced': True}):
        $ aa_audio_event('b01', 'line', 7, phase=0)
        "Ela se aproximou um pouco. Eu vi o sorriso chegar antes de ela cumprimentar Yasmin."
    if aa_matches(aa_state, {'introduced': False}):
        $ aa_audio_event('b01', 'line', 8, phase=0)
        v "Vanessa."
    $ aa_audio_event('b01', 'line', 9, phase=0)
    y "Yasmin. Vocês se conhecem de onde?"
    $ aa_audio_event('b01', 'line', 10, phase=0)
    v "Da faculdade. Direito."
    $ aa_audio_event('b01', 'line', 11, phase=0)
    "Ela respondeu antes de eu descobrir uma forma de dizer aquilo que parecesse importante."
    if aa_matches(aa_state, {'group_source': True}):
        $ aa_audio_event('b01', 'line', 12, phase=0)
        v "É a amiga que mandou no grupo?"
    if aa_matches(aa_state, {'group_source': True}):
        $ aa_audio_event('b01', 'line', 13, phase=0)
        f "É."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que vamos deixar os dois jantarem.":
            $ aa_audio_event('b01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b01', 0)
            $ aa_audio_event('b01', 'response', 0, 0)
            f "A gente vai sentar. Bom jantar."
            $ aa_audio_event('b01', 'response', 1, 0)
            y "Pra vocês também."
            $ aa_audio_event('b01', 'response', 2, 0)
            $ aa_stage_action = 'O garçom conduz Feka e Vanessa para a mesa junto ao vidro.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg11_ir_mesa_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg11_ir_mesa_dois'
            "Um garçom nos conduziu até a mesa junto ao vidro. Vanessa foi ao meu lado. Olhei para trás uma vez."
            jump p00
        "Sugerir que juntemos as mesas.":
            $ aa_audio_event('b01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b01', 1)
            $ aa_audio_event('b01', 'response', 0, 1)
            f "Se não atrapalhar, a gente pode juntar as mesas."
            $ aa_audio_event('b01', 'response', 1, 1)
            j "A gente já fez o pedido."
            $ aa_audio_event('b01', 'response', 2, 1)
            f "Tudo bem."
            $ aa_audio_event('b01', 'response', 3, 1)
            $ aa_stage_action = 'O garçom começa a unir as mesas antes de Vanessa responder.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg11_juntar_mesas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg11_juntar_mesas'
            "Chamei o garçom. Ele começou a arrastar uma mesa vazia antes de Vanessa responder."
            jump c00
        "Pedir um minuto com Yasmin antes de sentar.":
            $ aa_audio_event('b01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b01', 2)
            $ aa_audio_event('b01', 'response', 0, 2)
            f "Yasmin, posso falar com você um minuto?"
            $ aa_audio_event('b01', 'response', 1, 2)
            y "Aqui?"
            $ aa_audio_event('b01', 'response', 2, 2)
            f "Num lugar mais quieto."
            $ aa_audio_event('b01', 'response', 3, 2)
            $ aa_stage_action = 'Vanessa é conduzida sozinha à mesa enquanto Feka segue Yasmin.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg11_deixar_vanessa at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg11_deixar_vanessa'
            "Yasmin pegou a bolsa e caminhou até a porta da varanda. Eu fui atrás. A recepcionista mostrou nossa mesa para Vanessa."
            $ aa_audio_event('b01', 'response', 4, 2)
            v "Feka, a mesa..."
            $ aa_audio_event('b01', 'response', 5, 2)
            f "Eu já volto."
            $ aa_audio_event('b01', 'response', 6, 2)
            "Vanessa sentou sem tirar o casaco do braço. Depois dobrou o tecido sobre a cadeira vazia."
            jump t00

label p00:
    $ aa_node = 'p00'
    $ aa_location = '20h25 · Mesa junto ao vidro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['p00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1225)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('p00')
    $ aa_stage_action = 'Dois sentados. Feka vê o salão por trás de Vanessa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_menu_antes at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    $ aa_audio_event('p00', 'line', 0, phase=0)
    "Pedi uma mesa de onde dava para ver o salão. Vanessa sentou de costas para Yasmin. Eu podia ter escolhido o outro lado."
    if aa_matches(aa_state, {'source_truth': False, 'group_source': False}):
        $ aa_audio_event('p00', 'line', 1, phase=0)
        v "Então foi ela que indicou."
    if aa_matches(aa_state, {'source_truth': True}):
        $ aa_audio_event('p00', 'line', 2, phase=0)
        v "Você prefere sentar do outro lado? Eu troco."
    $ aa_audio_event('p00', 'line', 3, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio aberto entre os dois. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Cardápio aberto entre os dois.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    "Ela abriu o cardápio sem olhar os pratos. Eu conhecia o gesto: na aula, fazia isso quando queria que alguém terminasse logo."
    if aa_matches(aa_state, {'group_source': True, 'source_truth': False}):
        $ aa_audio_event('p00', 'line', 4, phase=0)
        v "É a amiga do grupo. E você escolheu sentar de frente pra mesa dela."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pedir para trocar de cadeira e contar a origem da reserva.":
            $ aa_audio_event('p00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p00', 0)
            $ aa_stage_action = 'Troca efetiva dos lugares; manter até o fim desse diálogo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_menu at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_menu'
            $ aa_audio_event('p00', 'response', 0, 0)
            "Trocamos de cadeira. A mesa de Yasmin ficou atrás de mim; o vidro, à minha direita."
            $ aa_audio_event('p00', 'response', 1, 0)
            f "Foi indicação dela. Eu peguei o nome no grupo e fiz a reserva."
            jump p01
        "Dizer que muita gente indica restaurante.":
            $ aa_audio_event('p00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p00', 1)
            $ aa_audio_event('p00', 'response', 0, 1)
            f "Muita gente indica restaurante. Não tem nada demais."
            $ aa_audio_event('p00', 'response', 1, 1)
            v "Eu tô falando de você. Por que escolheu justo esse?"
            jump p01
        "Fazer um elogio alto o suficiente para a outra mesa ouvir.":
            $ aa_audio_event('p00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p00', 2)
            $ aa_audio_event('p00', 'response', 0, 2)
            f "Você tá linda hoje."
            $ aa_audio_event('p00', 'response', 1, 2)
            v "Por que você tá falando alto?"
            jump p01

label p01:
    $ aa_node = 'p01'
    $ aa_location = '20h34 · Mesa junto ao vidro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['p01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1234)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('p01')
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    $ aa_audio_event('p01', 'line', 0, phase=0)
    "Fizemos o pedido quando o garçom voltou. Vanessa escolheu primeiro. Eu pedi o mesmo e esperei ele se afastar."
    $ aa_audio_event('p01', 'line', 1, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    "Vanessa fechou o cardápio e deixou as mãos em cima dele. Esperou que eu olhasse para ela."
    if aa_matches(aa_state, {'claimed_space': True}):
        $ aa_audio_event('p01', 'line', 2, phase=0)
        v "Você falou de dormir lá. Eu fiquei pensando se era sério."
    $ aa_audio_event('p01', 'line', 3, phase=0)
    v "Eu queria falar do apartamento. Eu quero morar lá. Só não queria que você parasse de ir me ver."
    $ aa_audio_event('p01', 'line', 4, phase=0)
    f "Você tá com medo de ficar sozinha lá?"
    $ aa_audio_event('p01', 'line', 5, phase=0)
    v "Tô. De chegar, fechar a porta e não ter ninguém pra contar como foi o dia."
    $ aa_audio_event('p01', 'line', 6, phase=0)
    "Eu podia perguntar da mudança. Fiquei esperando que ela me dissesse quanto espaço pretendia me dar."
    $ aa_audio_event('p01', 'line', 7, phase=0)
    v "Eu queria falar disso hoje."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pedir que conte o que mais a preocupa.":
            $ aa_audio_event('p01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p01', 0)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p01', 'response', 0, 0)
            f "O que mais te preocupa nessa mudança?"
            $ aa_audio_event('p01', 'response', 1, 0)
            v "Eu sei resolver as coisas. Tenho medo é de não fazer falta."
            $ aa_audio_event('p01', 'response', 2, 0)
            "Ela riu depois da frase. Eu não ri junto."
            jump p02
        "Prometer ir amanhã e combinar outras visitas.":
            $ aa_audio_event('p01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p01', 1)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p01', 'response', 0, 1)
            f "Você não vai ficar sozinha. Amanhã eu vou lá. Depois a gente combina os outros dias."
            $ aa_audio_event('p01', 'response', 1, 1)
            v "Você fala sério?"
            $ aa_audio_event('p01', 'response', 2, 1)
            "Assenti. Ela começou a falar dos horários em que eu poderia ir. Eu ainda não tinha pensado em nenhum."
            jump p02
        "Procurar a mesa de Yasmin enquanto Vanessa fala.":
            $ aa_audio_event('p01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p01', 2)
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '20h45 · Mesa junto ao vidro'
                $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_procura_troca'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '20h45 · Mesa junto ao vidro'
                    $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_procura_troca'
                else:
                    $ aa_location = '20h45 · Mesa junto ao vidro'
                    $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg12_procura_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_procura_antes'
            $ aa_audio_event('p01', 'response', 0, 2)
            "Ela parou no meio de uma frase. Eu só percebi quando o silêncio durou."
            jump p02

label p02:
    $ aa_node = 'p02'
    $ aa_location = '20h45 · Mesa junto ao vidro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['p02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1245)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('p02')
    if aa_matches(aa_state, {'route': 'varanda'}):
        $ aa_location = '20h45 · Mesa junto ao vidro'
        $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg12_procura_troca'
    else:
        if aa_matches(aa_state, {'seat_swapped': True}):
            $ aa_location = '20h45 · Mesa junto ao vidro'
            $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_procura_troca'
        else:
            $ aa_location = '20h45 · Mesa junto ao vidro'
            $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_procura_antes at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_procura_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'seat_swapped': False, 'table_focus': 'yasmin'}):
        $ aa_audio_event('p02', 'line', 0, phase=0)
        "Outro movimento atrás de Vanessa puxou meu olhar. Eu já tinha escolhido procurar Yasmin uma vez; fiz de novo."
    if aa_matches(aa_state, {'seat_swapped': False, 'table_focus': {'ne': 'yasmin'}}):
        $ aa_audio_event('p02', 'line', 1, phase=0)
        "Um movimento atrás de Vanessa puxou meu olhar para a mesa de Yasmin antes que eu decidisse se queria olhar."
    if aa_matches(aa_state, {'seat_swapped': True, 'table_focus': 'yasmin'}):
        $ aa_audio_event('p02', 'line', 2, phase=0)
        "Ouvi uma cadeira arrastar atrás de mim. Virei de novo para procurar Yasmin, mesmo depois de trocar de lugar."
    if aa_matches(aa_state, {'seat_swapped': True, 'table_focus': {'ne': 'yasmin'}}):
        $ aa_audio_event('p02', 'line', 3, phase=0)
        "Ouvi uma cadeira arrastar atrás de mim. Virei antes de perceber que tinha virado."
    $ aa_audio_event('p02', 'line', 4, phase=0)
    v "Você fica diferente quando olha pra lá."
    $ aa_audio_event('p02', 'line', 5, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    f "Diferente como?"
    $ aa_audio_event('p02', 'line', 6, phase=0)
    v "Você fica esperando ela olhar. Eu tô bem aqui."
    $ aa_audio_event('p02', 'line', 7, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    "Quis rir para tornar a frase pequena. Ela não estava brincando."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Contar que insisti por anos, mesmo depois de ela dizer não.":
            $ aa_audio_event('p02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p02', 0)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 0)
            f "Eu insisti. Não foi uma semana. Foram anos. Ela pediu que eu parasse."
            $ aa_audio_event('p02', 'response', 1, 0)
            v "E parou?"
            $ aa_audio_event('p02', 'response', 2, 0)
            "Fiquei olhando o copo. Ela esperou. Eu não respondi."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('p02', 'response', 3, 0)
                v "Quando você falou de uma amiga, eu não entendi que tinha acontecido tudo isso."
            jump i00
        "Chamar de uma paixão boba de escola.":
            $ aa_audio_event('p02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p02', 1)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 1)
            f "Foi uma paixão boba de escola. Já passou."
            $ aa_audio_event('p02', 'response', 1, 1)
            v "Então me fala olhando pra mim."
            $ aa_audio_event('p02', 'response', 2, 1)
            "Olhei. Ela esperou. Eu não repeti."
            jump i00
        "Dizer que Vanessa está procurando problema.":
            $ aa_audio_event('p02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p02', 2)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 2)
            v "Eu não quero brigar. Eu só queria que você olhasse pra mim."
            $ aa_audio_event('p02', 'response', 1, 2)
            "Ela abaixou a voz e parou de perguntar. Quando o garçom voltou, falou comigo como se qualquer frase pudesse começar outra briga."
            jump i00
        "Reconhecer que fiquei olhando para Yasmin e prestar atenção em Vanessa." if aa_matches(aa_state, {'source_truth': True, 'table_focus': 'vanessa', 'used': False, 'trust': {'gte': 2}}):
            $ aa_audio_event('p02', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'p02', 3)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 3)
            f "Você tem razão. Eu fiquei olhando pra lá. Desculpa."
            $ aa_audio_event('p02', 'response', 1, 3)
            f "Eu quero estar aqui com você."
            $ aa_audio_event('p02', 'response', 2, 3)
            v "Então fica aqui. Comigo."
            $ aa_audio_event('p02', 'response', 3, 3)
            f "Eu fico."
            $ aa_audio_event('p02', 'response', 4, 3)
            "Voltei a olhar para Vanessa e tirei a mão do celular. Ela ainda esperou um pouco antes de continuar."
            jump i00

label c00:
    $ aa_node = 'c00'
    $ aa_location = '20h25 · Mesas aproximadas'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1225)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c00')
    $ aa_stage_action = 'Mesa C é aproximada pelo sul de B; Feka e Vanessa aguardam no corredor leste.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_juntar_mesas at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_juntar_mesas'
    show screen aa_location_display
    $ aa_audio_event('c00', 'line', 0, phase=0)
    $ aa_stage_action = 'Mesa C é aproximada pelo sul de B; Feka e Vanessa aguardam no corredor leste.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_juntar_mesas at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_juntar_mesas'
    show screen aa_location_display
    "O garçom trouxe a mesa vazia do lado do corredor e encostou na ponta da mesa deles. Joãozão repetiu que eles já tinham feito o pedido."
    $ aa_audio_event('c00', 'line', 1, phase=0)
    y "Se a Vanessa quiser."
    $ aa_audio_event('c00', 'line', 2, phase=0)
    v "Por mim tudo bem. Se vocês quiserem."
    $ aa_audio_event('c00', 'line', 3, phase=0)
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    "Vanessa concordou. Sentamos um de frente para o outro na mesa acrescentada, sem fazer Yasmin e Joãozão mudarem de lugar. O garçom anotou nosso pedido. Pedi que trouxesse tudo junto antes de olhar para Vanessa."
    $ aa_audio_event('c00', 'line', 4, phase=0)
    y "Vocês fazem os trabalhos juntos também?"
    $ aa_audio_event('c00', 'line', 5, phase=0)
    f "Faço dupla com ela sempre que dá."
    $ aa_audio_event('c00', 'line', 6, phase=0)
    v "Quando responde minhas mensagens, né?"
    $ aa_audio_event('c00', 'line', 7, phase=0)
    "Yasmin riu. Vanessa sorriu para mim, esperando que eu respondesse."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir que a crítica de Vanessa é justa.":
            $ aa_audio_event('c00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c00', 0)
            $ aa_audio_event('c00', 'response', 0, 0)
            f "É. Eu demoro mesmo. Desculpa."
            $ aa_audio_event('c00', 'response', 1, 0)
            v "Às vezes eu preciso saber no mesmo dia, Feka."
            jump c01
        "Explicar que ela está brincando.":
            $ aa_audio_event('c00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c00', 1)
            $ aa_audio_event('c00', 'response', 0, 1)
            f "Ela tá brincando."
            $ aa_audio_event('c00', 'response', 1, 1)
            v "Não, eu fico esperando você responder."
            $ aa_audio_event('c00', 'response', 2, 1)
            "Ela mexeu no guardanapo."
            jump c01
        "Puxar uma lembrança minha com Yasmin.":
            $ aa_audio_event('c00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c00', 2)
            $ aa_audio_event('c00', 'response', 0, 2)
            f "Lembra daquela festa depois da prova, Yasmin?"
            $ aa_audio_event('c00', 'response', 1, 2)
            y "Você ficou até o fim, né?"
            $ aa_audio_event('c00', 'response', 2, 2)
            f "Fiquei."
            jump c01

label c01:
    $ aa_node = 'c01'
    $ aa_location = '20h38 · Mesa dos quatro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1238)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c01')
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'table_topic': {'ne': 'festa'}}):
        $ aa_audio_event('c01', 'line', 0, phase=0)
        y "Comigo era o contrário. Eu nem precisava chamar, ele já aparecia."
    if aa_matches(aa_state, {'table_topic': 'festa'}):
        $ aa_audio_event('c01', 'line', 1, phase=0)
        y "Você tava em todas. Bastava eu falar que ia."
    $ aa_audio_event('c01', 'line', 2, phase=0)
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    "Yasmin falou olhando para Vanessa."
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('c01', 'line', 3, phase=0)
        v "Vocês saíam juntos?"
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('c01', 'line', 4, phase=0)
        v "Isso foi na época que você me contou?"
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('c01', 'line', 5, phase=0)
        y "Não. Ele perguntava onde eu ia e aparecia lá."
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('c01', 'line', 6, phase=0)
        y "Na escola. Ele perguntava onde eu ia e aparecia lá."
    $ aa_audio_event('c01', 'line', 7, phase=0)
    j "Yasmin, deixa."
    $ aa_audio_event('c01', 'line', 8, phase=0)
    "Joãozão olhou para ela. Eu fiquei olhando para o cardápio fechado."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que não era uma coincidência e assumir a insistência.":
            $ aa_audio_event('c01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c01', 0)
            $ aa_audio_event('c01', 'response', 0, 0)
            f "Eu ia porque ela ia. Não era por acaso."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('c01', 'response', 1, 0)
                v "Você falou de uma amiga. Por que não me contou essa parte antes?"
            if aa_matches(aa_state, {'group_source': False, 'source_truth': False}):
                $ aa_audio_event('c01', 'response', 2, 0)
                v "Você não me contou isso."
            if aa_matches(aa_state, {'source_truth': True, 'group_source': False}):
                $ aa_audio_event('c01', 'response', 3, 0)
                v "Você disse que gostava dela. Não falou que ficava indo atrás."
            $ aa_audio_event('c01', 'response', 4, 0)
            f "Fiquei com vergonha."
            $ aa_audio_event('c01', 'response', 5, 0)
            v "Eu preferia saber por você."
            $ aa_audio_event('c01', 'response', 6, 0)
            "Eu disse que sabia. Vanessa baixou os olhos e soltou o guardanapo."
            jump c02
        "Pedir a Yasmin que pare de fazer disso uma piada.":
            $ aa_audio_event('c01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c01', 1)
            $ aa_audio_event('c01', 'response', 0, 1)
            f "Você precisa contar isso desse jeito?"
            $ aa_audio_event('c01', 'response', 1, 1)
            y "Tá. Desculpa."
            $ aa_audio_event('c01', 'response', 2, 1)
            v "Mas aconteceu?"
            $ aa_audio_event('c01', 'response', 3, 1)
            f "Aconteceu."
            $ aa_audio_event('c01', 'response', 4, 1)
            "Vanessa esperou. Não acrescentei nada."
            jump c02
        "Dizer que Yasmin gostava da atenção.":
            $ aa_audio_event('c01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c01', 2)
            $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conversa_quatro'
            $ aa_audio_event('c01', 'response', 0, 2)
            f "Você também gostava. Nunca foi só comigo."
            $ aa_audio_event('c01', 'response', 1, 2)
            y "Eu te pedi pra parar, Feka."
            $ aa_audio_event('c01', 'response', 2, 2)
            "Joãozão se virou para mim. Baixei a voz."
            $ aa_audio_event('c01', 'response', 3, 2)
            f "Tá. Deixa."
            jump c02

label c02:
    $ aa_node = 'c02'
    $ aa_location = '20h49 · Mesa dos quatro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1249)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c02')
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'table_history': 'culpou'}):
        $ aa_audio_event('c02', 'line', 0, phase=0)
        "Vanessa continuou olhando para mim até o garçom chegar."
    $ aa_audio_event('c02', 'line', 1, phase=0)
    $ aa_stage_action = 'Garçom atende pela lateral leste; Vanessa recolhe as mãos para o prato.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_servir_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_servir_quatro'
    show screen aa_location_display
    "O garçom pediu licença. Vanessa afastou o copo para ele apoiar os pratos."
    $ aa_audio_event('c02', 'line', 2, phase=0)
    "O garçom colocou meu prato na minha frente. Recolhi os braços para ele passar e puxei o prato um pouco para perto."
    $ aa_audio_event('c02', 'line', 3, phase=0)
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    "O garçom desejou bom apetite e saiu. Joãozão experimentou a carne. Yasmin mostrou o prato para ele."
    $ aa_audio_event('c02', 'line', 4, phase=0)
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    y "Quer provar o meu?"
    $ aa_audio_event('c02', 'line', 5, phase=0)
    j "Daqui a pouco."
    $ aa_audio_event('c02', 'line', 6, phase=0)
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    "Yasmin voltou ao prato. Peguei o celular que estava ao lado do meu."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Sugerir uma foto." if aa_matches(aa_state, {'no_photo': False}):
            $ aa_audio_event('c02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c02', 0)
            $ aa_audio_event('c02', 'response', 0, 0)
            f "Vamos tirar uma foto?"
            jump c03
        "Guardar o celular.":
            $ aa_audio_event('c02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c02', 1)
            $ aa_audio_event('c02', 'response', 0, 1)
            "Deixei o celular no bolso."
            jump i00
        "Oferecer pagar a mesa inteira para mudar o clima.":
            $ aa_audio_event('c02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c02', 2)
            $ aa_audio_event('c02', 'response', 0, 2)
            f "Hoje eu pago. De vocês também."
            $ aa_audio_event('c02', 'response', 1, 2)
            j "Não precisa. A nossa conta a gente paga."
            $ aa_audio_event('c02', 'response', 2, 2)
            f "A sua eu pago, Vanessa."
            $ aa_audio_event('c02', 'response', 3, 2)
            v "Tem certeza?"
            $ aa_audio_event('c02', 'response', 4, 2)
            f "Tenho."
            $ aa_audio_event('c02', 'response', 5, 2)
            "Guardei o celular sem abrir o aplicativo do banco."
            jump i00
        "Pedir uma foto, mesmo tendo combinado que não pediria." if aa_matches(aa_state, {'no_photo': True}):
            $ aa_audio_event('c02', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'c02', 3)
            $ aa_audio_event('c02', 'response', 0, 3)
            f "Vamos tirar uma foto?"
            jump c03

label c03:
    $ aa_node = 'c03'
    $ aa_location = '20h52 · Mesa dos quatro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c03'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1252)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c03')
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'no_photo': True}):
        $ aa_audio_event('c03', 'line', 0, phase=0)
        v "Feka, a gente combinou que não."
    if aa_matches(aa_state, {'no_photo': True}):
        $ aa_audio_event('c03', 'line', 1, phase=0)
        "Baixei o celular. Vanessa olhou para Yasmin e depois para o prato."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        $ aa_audio_event('c03', 'line', 2, phase=0)
        v "Uma só. Me mostra antes de postar."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'gte': 2}}):
        $ aa_audio_event('c03', 'line', 3, phase=0)
        v "Tá. Peraí."
    if aa_matches(aa_state, {'no_photo': False}):
        $ aa_audio_event('c03', 'line', 4, phase=0)
        j "Eu tiro."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'gte': 2}}):
        $ aa_audio_event('c03', 'line', 5, phase=0)
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'foto'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('foto')
        show screen aa_phone_view('foto')
        $ aa_last_art = 'cg14_refeicao_quatro'
        show screen aa_location_display
        $ aa_phone_remember('foto')
        "Joãozão pegou meu celular e se levantou. Contornei a ponta livre da mesa para ficar ao lado de Vanessa. Yasmin se inclinou para entrar no quadro, e ele tirou a foto."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        $ aa_audio_event('c03', 'line', 6, phase=0)
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'foto_hesita'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('foto_hesita')
        show screen aa_phone_view('foto_hesita')
        $ aa_last_art = 'cg14_refeicao_quatro'
        show screen aa_location_display
        $ aa_phone_remember('foto_hesita')
        "Entreguei o celular a Joãozão, que se levantou. Contornei a ponta da mesa e fiquei ao lado de Vanessa. Yasmin se inclinou para caber no quadro. Vanessa sorriu até ele baixar o aparelho."
    $ aa_audio_event('c03', 'line', 7, phase=0)
    window hide None
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    window auto
    show screen aa_location_display
    "Guardei o celular e me acomodei de novo na cadeira, de frente para Vanessa."
    jump i00

label t00:
    $ aa_node = 't00'
    $ aa_location = '20h24 · Porta da varanda'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['t00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1224)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('t00')
    $ aa_stage_action = 'Yasmin mantém distância junto à porta; Vanessa ficou na mesa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    $ aa_audio_event('t00', 'line', 0, phase=0)
    y "Você pediu um minuto. Fala daqui."
    $ aa_audio_event('t00', 'line', 1, phase=0)
    "Yasmin ficou do lado de dentro. Vanessa tinha sentado à mesa, com o casaco no colo."
    $ aa_audio_event('t00', 'line', 2, phase=0)
    f "Você tá bem?"
    $ aa_audio_event('t00', 'line', 3, phase=0)
    y "Tava jantando."
    $ aa_audio_event('t00', 'line', 4, phase=0)
    "Eu esperei que ela perguntasse de mim. Ela segurou a bolsa com as duas mãos."
    $ aa_audio_event('t00', 'line', 5, phase=0)
    $ aa_stage_action = 'A recusa pertence a Yasmin.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.13, 0.28, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    y "Feka, eu não quero ficar com você. Isso não mudou. E você tá aqui com uma pessoa."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que entendi e voltar para Vanessa.":
            $ aa_audio_event('t00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't00', 0)
            jump t01
        "Perguntar se ela falaria isso se Joãozão não estivesse ali.":
            $ aa_audio_event('t00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't00', 1)
            jump t01
        "Dizer que ela não precisava me humilhar.":
            $ aa_audio_event('t00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't00', 2)
            jump t01

label t01:
    $ aa_node = 't01'
    $ aa_location = '20h28 · Porta da varanda'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['t01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1228)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('t01')
    $ aa_stage_action = 'Yasmin conclui a resposta antes de Joãozão entrar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    if aa_matches(aa_state, {'insisted': True}):
        $ aa_audio_event('t01', 'line', 0, phase=0)
        y "Eu falei antes de namorar ele. Você lembra."
    if aa_matches(aa_state, {'stopped_joke': True}):
        $ aa_audio_event('t01', 'line', 1, phase=0)
        y "Eu não te humilhei, Feka. Só falei o que você já sabia."
    $ aa_audio_event('t01', 'line', 2, phase=0)
    $ aa_stage_action = 'Joãozão entra só agora; Yasmin continua no próprio lugar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_joao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_joao_r1'
    show screen aa_location_display
    j "Tá acontecendo alguma coisa?"
    $ aa_audio_event('t01', 'line', 3, phase=0)
    "O corpo de Joãozão ocupou o espaço que eu estava usando para imaginar uma conversa diferente."
    $ aa_audio_event('t01', 'line', 4, phase=0)
    $ aa_stage_action = 'Yasmin interrompe a tentativa de falar por ela.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_joao_r1 at aa_camera(1.1, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_joao_r1'
    show screen aa_location_display
    y "Já respondi. Eu mesma."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Sair do caminho e voltar à mesa.":
            $ aa_audio_event('t01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't01', 0)
            jump t02
        "Dizer a Joãozão que ele não manda em mim.":
            $ aa_audio_event('t01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't01', 1)
            $ aa_audio_event('t01', 'response', 0, 1)
            j "Eu perguntei se estava acontecendo alguma coisa."
            $ aa_audio_event('t01', 'response', 1, 1)
            "Ele não tinha precisado levantar a voz para eu perceber a minha."
            jump t02
        "Pedir que ele deixe Yasmin terminar de falar.":
            $ aa_audio_event('t01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't01', 2)
            $ aa_audio_event('t01', 'response', 0, 2)
            y "Eu já terminei. Agora quero voltar."
            jump t02

label t02:
    $ aa_node = 't02'
    $ aa_location = '20h33 · Mesa de Vanessa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['t02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1233)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('t02')
    $ aa_stage_action = 'Vanessa sentada; meio copo e casaco na cadeira de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    $ aa_audio_event('t02', 'line', 0, phase=0)
    "O copo de Vanessa estava pela metade. Ela tinha dobrado o casaco sobre a cadeira que eu devia estar usando."
    $ aa_audio_event('t02', 'line', 1, phase=0)
    $ aa_stage_action = 'Reprovação sentada; não substituir por retrato de pé.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.1, 0.62, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    v "Achei que você não ia voltar. Vamos pedir? Eu esperei você."
    $ aa_audio_event('t02', 'line', 2, phase=0)
    "Eu procurei uma resposta engraçada. Todas pioravam a pergunta."
    $ aa_audio_event('t02', 'line', 3, phase=0)
    $ aa_stage_action = 'Feka senta; casaco devolvido à cadeira dela, cardápio fechado.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_mesa_escuta_troca'
    show screen aa_location_display
    "Devolvi o casaco à cadeira dela e sentei. Vanessa sorriu, depois perguntou o que tinha demorado tanto."
    $ aa_audio_event('t02', 'line', 4, phase=0)
    "Quando o garçom passou, fizemos o pedido. Vanessa precisou perguntar o meu duas vezes. Eu ainda estava pensando no que tinha acontecido na varanda."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pedir desculpa pelo tempo e contar o que fui fazer.":
            $ aa_audio_event('t02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't02', 0)
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('t02', 'response', 0, 0)
                f "Desculpa ter te deixado esperando. Eu fui falar com a Yasmin porque ainda penso nela."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('t02', 'response', 1, 0)
                v "A amiga do grupo."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('t02', 'response', 2, 0)
                f "É. Eu devia ter explicado antes de sair da mesa."
            jump i00
        "Dizer que foi só uma conversa de escola.":
            $ aa_audio_event('t02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't02', 1)
            jump i00
        "Reclamar que Joãozão é agressivo.":
            $ aa_audio_event('t02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't02', 2)
            jump i00

label i00:
    $ aa_node = 'i00'
    $ aa_location = '21h02 · Entre os pratos'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['i00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1262)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('i00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '20h53 · Mesa B+C'
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_refeicao_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_location = '20h53 · Mesa dos quatro'
            $ aa_stage_action = 'Retomam a refeição depois da escolha; celular guardado.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_pratos'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '20h49 · Mesa'
                $ aa_stage_action = 'Aguardam a comida; ainda não há pratos servidos.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '20h49 · Mesa'
                    $ aa_stage_action = 'Aguardam a comida; ainda não há pratos servidos.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_escuta_troca'
                else:
                    $ aa_location = '20h49 · Mesa'
                    $ aa_stage_action = 'Aguardam a comida; ainda não há pratos servidos.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'route': 'separadas'}):
        $ aa_audio_event('i00', 'line', 0, phase=0)
        "O garçom passou com uma bandeja para outra mesa. Vanessa acompanhou com os olhos, depois voltou a olhar para mim."
    if aa_matches(aa_state, {'route': 'varanda'}):
        $ aa_audio_event('i00', 'line', 1, phase=0)
        "Esperamos a comida. Vanessa mexia no guardanapo. Eu pensava numa forma de retomar o jantar sem voltar ao assunto da varanda."
    if aa_matches(aa_state, {'route': 'juntas', 'photo_asked': True}):
        $ aa_audio_event('i00', 'line', 2, phase=0)
        "Cortei um pedaço do frango. Ainda estava quente."
    if aa_matches(aa_state, {'route': 'juntas', 'photo_asked': False}):
        $ aa_audio_event('i00', 'line', 3, phase=0)
        "Yasmin puxou o copo para perto. Comecei a comer."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 4, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h50 · Mesa'
            $ aa_stage_action = 'Chegada dos pratos à mesa de dois.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg8_servir_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg8_servir_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h50 · Mesa'
                $ aa_stage_action = 'Chegada dos pratos à mesa de dois.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg8_servir_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg8_servir_troca'
            else:
                $ aa_location = '20h50 · Mesa'
                $ aa_stage_action = 'Chegada dos pratos à mesa de dois.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg8_servir_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg8_servir_antes'
        show screen aa_location_display
        "Nossos pratos chegaram. Recolhi as mãos; Vanessa afastou o copo para o garçom terminar de servir."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 5, phase=0)
        v "Obrigada."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 6, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'O serviço terminou; os dois começam a comer.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg7_mesa_pratos_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'O serviço terminou; os dois começam a comer.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'O serviço terminou; os dois começam a comer.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_antes'
        show screen aa_location_display
        "O garçom se afastou. Peguei o garfo e comecei a comer. Vanessa cortou o frango em pedaços pequenos."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 7, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_refeicao_quatro'
        else:
            $ aa_location = '20h54 · Mesa dos quatro'
            $ aa_stage_action = 'A refeição avança com os quatro presentes.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg8_comer_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg8_comer_quatro'
        show screen aa_location_display
        "Joãozão pediu o sal. Passei por cima dos pratos, com cuidado para não esbarrar nos copos."
    $ aa_audio_event('i00', 'line', 8, phase=0)
    "Vanessa separava os pedaços com o garfo antes de comer."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 9, phase=0)
        "Yasmin provou um pedaço da carne de Joãozão. Eu acompanhei a mão dela e demorei a voltar para o meu prato."
    if aa_matches(aa_state, {'route': 'varanda'}):
        $ aa_audio_event('i00', 'line', 10, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_refeicao_procura_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_antes'
        show screen aa_location_display
        "Yasmin estava atrás de mim. Esperei Vanessa baixar os olhos e virei para procurar a outra mesa."
    if aa_matches(aa_state, {'route': 'separadas', 'table_focus': 'vanessa'}):
        $ aa_audio_event('i00', 'line', 11, phase=0)
        "Eu ainda sabia exatamente onde Yasmin estava. Quando ouvi a mesa dela, mantive os olhos no prato."
    if aa_matches(aa_state, {'route': 'separadas', 'table_focus': 'promise'}):
        $ aa_audio_event('i00', 'line', 12, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_refeicao_procura_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_antes'
        show screen aa_location_display
        "Quando ouvi uma cadeira na mesa de Yasmin, olhei de relance e voltei ao prato antes que Vanessa levantasse os olhos."
    if aa_matches(aa_state, {'route': 'separadas', 'table_focus': 'yasmin'}):
        $ aa_audio_event('i00', 'line', 13, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_refeicao_procura_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_antes'
        show screen aa_location_display
        "Esperei Vanessa baixar os olhos para procurar Yasmin de novo."
    $ aa_audio_event('i00', 'line', 14, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_refeicao_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_location = '20h58 · Mesa dos quatro'
            $ aa_stage_action = 'Os quatro continuam comendo, sem nova fotografia.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg8_comer_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg8_comer_quatro'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '20h58 · Mesa'
                $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_troca'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '20h58 · Mesa'
                    $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_pratos_troca'
                else:
                    $ aa_location = '20h58 · Mesa'
                    $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_pratos_antes'
    show screen aa_location_display
    f "Tá bom o seu?"
    if aa_matches(aa_state, {'trust': {'lte': 1}}):
        $ aa_audio_event('i00', 'line', 15, phase=0)
        v "Tá."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': True}):
        $ aa_audio_event('i00', 'line', 16, phase=0)
        v "Tá."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': 'culpou'}):
        $ aa_audio_event('i00', 'line', 17, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_refeicao_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '20h58 · Mesa dos quatro'
                $ aa_stage_action = 'Os quatro continuam comendo, sem nova fotografia.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg8_comer_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg8_comer_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_location = '20h58 · Mesa'
                    $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_pratos_troca'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_location = '20h58 · Mesa'
                        $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                        $ aa_table_party = 2
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg7_mesa_pratos_troca'
                    else:
                        $ aa_location = '20h58 · Mesa'
                        $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                        $ aa_table_party = 2
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg7_mesa_pratos_antes'
        show screen aa_location_display
        v "Tá."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 18, phase=0)
        v "Tá. Quer provar?"
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 19, phase=0)
        f "Quero."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 20, phase=0)
        "Ela cortou um pedaço e deixou na beirada do meu prato. Dei um pouco do meu para ela."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 21, phase=0)
        v "Tá. E o seu?"
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 22, phase=0)
        f "Tá bom também."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 23, phase=0)
        "Vanessa assentiu e cortou outro pedaço."
    $ aa_audio_event('i00', 'line', 24, phase=0)
    "Quando paramos de comer, o garçom perguntou se podia retirar os pratos. Vanessa ainda tinha um pouco de comida. Disse que podia."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 25, phase=0)
        $ aa_location = '21h02 · Mesa B+C · Entre os pratos'
        $ aa_stage_action = 'Pratos recolhidos; Yasmin segue para noroeste, Joãozão para o balcão a leste.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_saida'
        show screen aa_location_display
        "O garçom recolheu os quatro pratos. Yasmin disse que ia tomar um ar e saiu pelo corredor em direção à passagem da varanda. Joãozão avisou que ia pedir água no balcão. Vanessa e eu ficamos nos nossos lugares."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 26, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_location = '21h02 · Entre os pratos'
            $ aa_stage_action = 'Pratos recolhidos; dois lugares vazios mostram a ausência temporária do casal.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_intervalo at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_intervalo'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '21h02 · Entre os pratos'
                $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_papel'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '21h02 · Entre os pratos'
                    $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_papel'
                else:
                    $ aa_location = '21h02 · Entre os pratos'
                    $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_papel_antes'
        show screen aa_location_display
        "Ele recolheu nossos pratos e talheres. Na outra mesa, Yasmin se levantou e foi até a porta da varanda; Joãozão seguiu para o balcão."
    $ aa_audio_event('i00', 'line', 27, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h03 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_intervalo at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_intervalo'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_papel at aa_camera(1.07, 0.5, 0.43)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_papel'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_papel at aa_camera(1.07, 0.5, 0.43)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_papel'
                else:
                    $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_papel_antes at aa_camera(1.07, 0.5, 0.43)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    "Vanessa tirou da bolsa um papel dobrado e abriu sobre a mesa. Tinha medidas anotadas e um desenho de um quarto."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Ficar com Vanessa.":
            $ aa_audio_event('i00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'i00', 0)
            $ aa_audio_event('i00', 'response', 0, 0)
            f "Deixa eu ver essas medidas."
            $ aa_audio_event('i00', 'response', 1, 0)
            "Vanessa virou o papel para que eu pudesse ler. Continuei sentado."
            jump iv
        "Conversar com Joãozão, sem plateia.":
            $ aa_audio_event('i00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'i00', 1)
            $ aa_audio_event('i00', 'response', 0, 1)
            f "Vou falar um minuto com o Joãozão."
            $ aa_audio_event('i00', 'response', 1, 1)
            v "Tá. Eu espero aqui."
            $ aa_audio_event('i00', 'response', 2, 1)
            $ aa_stage_action = 'Dois homens de pé, mãos abertas; sem plateia.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_balcao_r1'
            "Afastei a cadeira, contornei a ponta livre da mesa e segui pelo corredor até o balcão. Joãozão acabava de pedir água."
            jump ij
        "Procurar Yasmin no corredor.":
            $ aa_audio_event('i00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'i00', 2)
            $ aa_audio_event('i00', 'response', 0, 2)
            "Afastei a cadeira. Vanessa parou com a mão em cima do papel."
            $ aa_audio_event('i00', 'response', 1, 2)
            v "Você vai falar com ela?"
            $ aa_audio_event('i00', 'response', 2, 2)
            f "Só um minuto."
            $ aa_audio_event('i00', 'response', 3, 2)
            $ aa_stage_action = 'Feka chega à passagem da varanda; Yasmin fica à esquerda, junto ao acesso oeste.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_varanda_r1 at aa_camera(1.07, 0.3, 0.32)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_varanda_r1'
            "Ela dobrou o papel sem responder. Contornei a mesa e segui pelo corredor até a passagem da varanda. Yasmin ainda estava do lado de dentro."
            jump iy

label iv:
    $ aa_node = 'iv'
    $ aa_location = '21h06 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['iv'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1266)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('iv')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_papel_espera'
            else:
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    $ aa_audio_event('iv', 'line', 0, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_papel_espera'
            else:
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    "O desenho mostrava a cama encostada na parede. Vanessa apontou a medida do espaço que sobrava."
    $ aa_audio_event('iv', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Ela busca a confirmação da visita.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.07, 0.52, 0.38)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Ela busca a confirmação da visita.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_papel_espera at aa_camera(1.07, 0.52, 0.38)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_papel_espera'
            else:
                $ aa_stage_action = 'Ela busca a confirmação da visita.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_papel_antes at aa_camera(1.07, 0.52, 0.38)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    v "E amanhã? Você consegue ir depois da aula?"
    $ aa_audio_event('iv', 'line', 2, phase=0)
    f "Sua mãe fica até que horas?"
    $ aa_audio_event('iv', 'line', 3, phase=0)
    v "Só de manhã. Ela tem que ir embora antes do almoço."
    $ aa_audio_event('iv', 'line', 4, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_guardado'
    else:
        $ aa_stage_action = 'Ela dobra e guarda o papel antes da escolha.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_papel_guardado at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_papel_guardado'
    show screen aa_location_display
    "Ela dobrou o papel pela mesma marca e guardou na bolsa. Esperou minha resposta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Perguntar o que ela queria desta noite e ouvir.":
            $ aa_audio_event('iv', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'iv', 0)
            $ aa_audio_event('iv', 'response', 0, 0)
            v "Eu queria comer com você. Contar do apartamento. Hoje parece que eu preciso acertar tudo que falo pra você ficar."
            $ aa_audio_event('iv', 'response', 1, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Dizer que eu também estou tendo uma noite difícil.":
            $ aa_audio_event('iv', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'iv', 1)
            $ aa_audio_event('iv', 'response', 0, 1)
            v "Eu sei."
            $ aa_audio_event('iv', 'response', 1, 1)
            "Ela começou a perguntar o que tinha acontecido com Yasmin. Parou."
            $ aa_audio_event('iv', 'response', 2, 1)
            v "Mas eu também tô aqui."
            $ aa_audio_event('iv', 'response', 3, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Confirmar a ajuda e combinar depois da aula.":
            $ aa_audio_event('iv', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'iv', 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_papel_espera'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_papel_antes'
            $ aa_audio_event('iv', 'response', 0, 2)
            v "Então eu te mando o endereço. Posso esperar você depois da aula?"
            $ aa_audio_event('iv', 'response', 1, 2)
            f "Pode."
            $ aa_audio_event('iv', 'response', 2, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_papel'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Ela tirou o papel da bolsa outra vez. Eu tinha dado uma hora à promessa e evitado o resto da conversa."
            $ aa_audio_event('iv', 'response', 3, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Vanessa guardou o papel outra vez. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00

label ij:
    $ aa_node = 'ij'
    $ aa_location = '21h06 · Balcão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['ij'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1266)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('ij')
    $ aa_stage_action = 'Dois homens de pé, mãos abertas; sem plateia.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    $ aa_audio_event('ij', 'line', 0, phase=0)
    j "Você veio falar dela comigo? Eu não quero ficar vigiando vocês."
    $ aa_audio_event('ij', 'line', 1, phase=0)
    f "Então não fica."
    $ aa_audio_event('ij', 'line', 2, phase=0)
    $ aa_stage_action = 'Joãozão responde à provocação sem avançar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.12, 0.74, 0.31)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    j "Ela já pediu pra você parar. E você vem falar comigo. Quer que eu faça o quê?"
    $ aa_audio_event('ij', 'line', 3, phase=0)
    "Eu tinha preparado uma fala sobre ciúme. Ela não servia para responder àquilo."
    $ aa_audio_event('ij', 'line', 4, phase=0)
    $ aa_stage_action = 'A referência a Vanessa faz o plano voltar aos dois.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    j "E a Vanessa tá sentada lá, cara."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir minha insistência e pedir que não faça uma cena.":
            $ aa_audio_event('ij', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'ij', 0)
            $ aa_audio_event('ij', 'response', 0, 0)
            j "Então escuta quando ela pede. Não precisa vir explicar pra mim."
            $ aa_audio_event('ij', 'response', 1, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Dizer que Yasmin sabe responder por ela.":
            $ aa_audio_event('ij', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'ij', 1)
            $ aa_audio_event('ij', 'response', 0, 1)
            j "Sabe. E já respondeu. Você sabe disso melhor do que eu."
            $ aa_audio_event('ij', 'response', 1, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Chamar Joãozão de inseguro, falando alto.":
            $ aa_audio_event('ij', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'ij', 2)
            $ aa_audio_event('ij', 'response', 0, 2)
            f "Você é muito inseguro, cara."
            $ aa_audio_event('ij', 'response', 1, 2)
            "Duas pessoas no balcão olharam. Joãozão largou o copo e me encarou. Dei um passo para trás."
            $ aa_audio_event('ij', 'response', 2, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00

label iy:
    $ aa_node = 'iy'
    $ aa_location = '21h06 · Corredor'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['iy'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1266)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('iy')
    $ aa_stage_action = 'Feka chega à passagem da varanda; Yasmin fica à esquerda, junto ao acesso oeste.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.07, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    $ aa_audio_event('iy', 'line', 0, phase=0)
    y "Você deixou sua namorada na mesa."
    $ aa_audio_event('iy', 'line', 1, phase=0)
    "Não consegui dizer que era só um minuto. Yasmin já conhecia a duração dos meus minutos."
    $ aa_audio_event('iy', 'line', 2, phase=0)
    f "Você me acha uma pessoa tão ruim assim?"
    $ aa_audio_event('iy', 'line', 3, phase=0)
    $ aa_stage_action = 'A segunda recusa tem menos espaço para negociação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.17, 0.28, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    y "Eu não quero ter que te avaliar para poder jantar."
    $ aa_audio_event('iy', 'line', 4, phase=0)
    "Essa resposta eu não podia transformar em quase. Ela nem estava falando de amor."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Parar de pedir uma resposta diferente.":
            $ aa_audio_event('iy', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'iy', 0)
            $ aa_audio_event('iy', 'response', 0, 0)
            f "Tá. Eu vou voltar."
            $ aa_audio_event('iy', 'response', 1, 0)
            y "Volta."
            $ aa_audio_event('iy', 'response', 2, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Pedir só que ela admita que já me deu esperança.":
            $ aa_audio_event('iy', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'iy', 1)
            $ aa_audio_event('iy', 'response', 0, 1)
            y "Eu preciso pedir desculpa por você ter entendido o que quis?"
            $ aa_audio_event('iy', 'response', 1, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Dizer que estou com Vanessa e não preciso dela.":
            $ aa_audio_event('iy', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'iy', 2)
            $ aa_audio_event('iy', 'response', 0, 2)
            y "Então por que você tá aqui falando comigo?"
            $ aa_audio_event('iy', 'response', 1, 2)
            "Eu tinha deixado Vanessa esperando para vir dizer que não precisava de Yasmin. Fiquei sem resposta."
            $ aa_audio_event('iy', 'response', 2, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00

label r00:
    $ aa_node = 'r00'
    $ aa_location = '21h18 · A mesa de Vanessa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1278)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pudim na mesa C; Yasmin e Joãozão ainda ausentes, cadeiras de B vazias.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_dois'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pudim chega perto de Vanessa; as cadeiras centrais ainda estão vazias.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_privado at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_privado'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa'
                else:
                    $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_antes'
    show screen aa_location_display
    $ aa_audio_event('r00', 'line', 0, phase=0)
    "O garçom trouxe o pudim com duas colheres e completou a água. Vanessa não tinha dito que queria sobremesa. Eu queria conseguir chegar à sobremesa."
    $ aa_audio_event('r00', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pudim na mesa C; Yasmin e Joãozão ainda ausentes, cadeiras de B vazias.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_dois'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pudim afastado, dois lugares ainda vazios.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Vanessa afastou o prato. Não levantou a voz. Eu precisei me inclinar para ouvir."
    if aa_matches(aa_state, {'presence_told': False}):
        $ aa_audio_event('r00', 'line', 2, phase=0)
        v "Você sabia que ela estaria aqui?"
    if aa_matches(aa_state, {'presence_told': True}):
        $ aa_audio_event('r00', 'line', 3, phase=0)
        v "Você me disse que ela estaria aqui. Eu quero entender por que quis vir mesmo assim."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r00', 'line', 4, phase=0)
        "Eu sabia. Vi no quarto, enquanto ela procurava o brinco."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r00', 'line', 5, phase=0)
        "Não sabia. Percebi o quanto queria usar essa resposta para encerrar todo o resto."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r00', 'line', 6, phase=0)
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
        show screen aa_location_display
        "Yasmin voltou da passagem da varanda; Joãozão veio do balcão. Os dois puxaram as próprias cadeiras na outra ponta das mesas unidas. Vanessa esperou o barulho parar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r00', 'line', 7, phase=0)
        v "Fala baixo. Eu tô ouvindo."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('r00', 'line', 8, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sobremesa_afastada'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        "Yasmin e Joãozão voltaram para a outra mesa; as cadeiras arrastaram no piso."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}, 'interval': 'vanessa', 'present_choice': False}):
        $ aa_audio_event('r00', 'line', 9, phase=0)
        "Olhei na direção do barulho e voltei para Vanessa antes que ela precisasse me esperar."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}, 'interval': 'joaozao'}):
        $ aa_audio_event('r00', 'line', 10, phase=0)
        "Acompanhei os dois até se sentarem. Depois procurei Vanessa outra vez."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}, 'interval': 'yasmin'}):
        $ aa_audio_event('r00', 'line', 11, phase=0)
        "Acompanhei Yasmin até ela se sentar. Vanessa esperou até eu parar."
    if aa_matches(aa_state, {'route': 'separadas', 'interval': 'vanessa', 'present_choice': True}):
        $ aa_audio_event('r00', 'line', 12, phase=0)
        "Ouvi as cadeiras, mas continuei olhando para Vanessa. Ela esperava minha resposta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir que vi a publicação e quis encontrá-la." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('r00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r00', 0)
            $ aa_audio_event('r00', 'response', 0, 0)
            f "Eu vi a publicação antes de sair de casa. Sabia que ela estava aqui e quis vir mesmo assim."
            jump r01
        "Dizer que não sabia, mas escolhi o lugar por causa dela." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('r00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r00', 1)
            $ aa_audio_event('r00', 'response', 0, 1)
            f "Eu não sabia que ela ia estar aqui. Mas guardei o nome do restaurante por causa dela."
            jump r01
        "Falar só da indicação e esconder o que vi no celular." if aa_matches(aa_state, {'knew': True, 'presence_told': False}):
            $ aa_audio_event('r00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r00', 2)
            jump r02
        "Repetir que foi coincidência e que Vanessa está exagerando.":
            $ aa_audio_event('r00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'r00', 3)
            $ aa_audio_event('r00', 'response', 0, 3)
            f "Foi coincidência encontrar os dois. Você tá exagerando."
            $ aa_audio_event('r00', 'response', 1, 3)
            "Ela deixou de mexer na colher e olhou para mim."
            jump r02
        "Dizer que a indicação veio de Yasmin, mas que escolhi o lugar pensando em Vanessa." if aa_matches(aa_state, {'knew': False, 'route': 'separadas', 'interval': 'vanessa', 'source_truth': True, 'present_choice': True, 'used': False, 'trust': {'gte': 2}}):
            $ aa_audio_event('r00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'r00', 4)
            $ aa_location = '21h22 · Mesa junto ao vidro'
            $ aa_stage_action = 'Feka mantém o olhar em Vanessa enquanto assume a indicação e muda o motivo da reserva.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg13_mesa_escolha at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg13_mesa_escolha'
            jump h00

label r01:
    $ aa_node = 'r01'
    $ aa_location = '21h22 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1282)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r01', 'line', 0, phase=0)
        v "Você viu que ela estava aqui e quis vir mesmo assim?"
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r01', 'line', 1, phase=0)
        v "E eu agradecendo por você ter pensado em mim."
    $ aa_audio_event('r01', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Ela olhou para as mãos. Eu achei que fosse chorar e senti uma vontade horrível de que chorasse. Uma pessoa chorando ainda pode aceitar um abraço."
    $ aa_audio_event('r01', 'line', 3, phase=0)
    v "Mas você queria sair comigo também?"
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir que fiquei com ela para não me sentir sozinho.":
            $ aa_audio_event('r01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r01', 0)
            jump r03
        "Dizer que gosto dela, mas estou confuso.":
            $ aa_audio_event('r01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r01', 1)
            jump r02
        "Pedir que ela veja quanto Yasmin me machucou.":
            $ aa_audio_event('r01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r01', 2)
            jump r04
        "Dizer que é com ela que quero ficar, só para acalmá-la.":
            $ aa_audio_event('r01', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'r01', 3)
            $ aa_audio_event('r01', 'response', 0, 3)
            f "Queria. É com você que eu quero ficar. Eu gosto de você."
            $ aa_audio_event('r01', 'response', 1, 3)
            v "Você tá falando isso porque eu tô quase chorando?"
            $ aa_audio_event('r01', 'response', 2, 3)
            f "Não. Tô falando porque é verdade."
            $ aa_audio_event('r01', 'response', 3, 3)
            "Eu queria que ela parasse de perguntar. Disse aquilo olhando para ela, sem procurar Yasmin."
            $ aa_audio_event('r01', 'response', 4, 3)
            "Vanessa soltou o guardanapo que estava apertando. Ainda esperou um pouco antes de responder."
            $ aa_audio_event('r01', 'response', 5, 3)
            v "Tá. Eu quero acreditar em você."
            $ aa_audio_event('r01', 'response', 6, 3)
            "Ela falou mais baixo. Eu senti alívio e fiquei quieto. Por alguns minutos, fingimos que a resposta tinha resolvido a pergunta."
            jump v00

label r02:
    $ aa_node = 'r02'
    $ aa_location = '21h25 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1285)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r02')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r02', 'line', 0, phase=0)
    v "Eu tento acreditar. Mas não consigo entender o que você quer comigo."
    $ aa_audio_event('r02', 'line', 1, phase=0)
    v "Se eu parar de perguntar, você fica aqui comigo até a gente ir embora?"
    $ aa_audio_event('r02', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Ela continuava sentada. Parecia esperar um sim. Eu ainda estava escolhendo a parte da pergunta que podia responder."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Parar de reduzir o problema e contar tudo.":
            $ aa_audio_event('r02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r02', 0)
            jump r03
        "Pedir para terminar o jantar sem falar nisso.":
            $ aa_audio_event('r02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r02', 1)
            if aa_matches(aa_state, {'interval': 'yasmin'}):
                $ aa_audio_event('r02', 'response', 0, 1)
                v "Tá. Mas você foi atrás dela e me deixou esperando. Se quiser sair da mesa, fala comigo antes."
            if aa_matches(aa_state, {'interval': 'joaozao'}):
                $ aa_audio_event('r02', 'response', 1, 1)
                v "Tá. Você foi falar com Joãozão e eu fiquei esperando. Se precisar levantar, me avisa antes."
            if aa_matches(aa_state, {'interval': 'vanessa', 'route': 'varanda'}):
                $ aa_audio_event('r02', 'response', 2, 1)
                v "Tá. Quando a gente chegou, você me deixou esperando pra falar com ela. Agora eu queria ficar com você."
            if aa_matches(aa_state, {'interval': 'vanessa', 'route': {'ne': 'varanda'}}):
                $ aa_audio_event('r02', 'response', 3, 1)
                v "Tá. Você ficou aqui comigo. Eu sei. Só queria sentir que você também quer estar aqui."
            $ aa_audio_event('r02', 'response', 4, 1)
            "Aproximei o pudim. Ela deixou a colher onde estava."
            jump v00
        "Dizer que ela aceitou vir e também fez suas escolhas.":
            $ aa_audio_event('r02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r02', 2)
            jump r05

label r04:
    $ aa_node = 'r04'
    $ aa_location = '21h26 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r04'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1286)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r04')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r04', 'line', 0, phase=0)
    f "Você não entende o que foram esses anos."
    if aa_matches(aa_state, {'past_told': False}):
        $ aa_audio_event('r04', 'line', 1, phase=0)
        v "Você não me contou o que aconteceu nesses anos. Eu tô tentando entender."
    if aa_matches(aa_state, {'past_told': True}):
        $ aa_audio_event('r04', 'line', 2, phase=0)
        v "Eu lembro do que você contou. Ainda tô tentando entender."
    $ aa_audio_event('r04', 'line', 3, phase=0)
    f "Eu sofri muito."
    $ aa_audio_event('r04', 'line', 4, phase=0)
    v "Eu posso ouvir. Só... você quer ficar comigo ou quer que eu te ajude com ela?"
    $ aa_audio_event('r04', 'line', 5, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Ela tinha baixado a voz para me acalmar. Percebi que eu podia continuar falando dos meus anos ruins e adiar a resposta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir o que fiz sem pedir pena.":
            $ aa_audio_event('r04', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r04', 0)
            jump r03
        "Dizer que estou sozinho até quando estou com ela.":
            $ aa_audio_event('r04', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r04', 1)
            jump r05
        "Ficar calado, esperando que ela pare de perguntar.":
            $ aa_audio_event('r04', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r04', 2)
            $ aa_audio_event('r04', 'response', 0, 2)
            "Ela virou o rosto para a janela. Não insisti. Esperei que o silêncio fizesse por mim o que minhas frases não conseguiam."
            jump v00

label r03:
    $ aa_node = 'r03'
    $ aa_location = '21h29 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r03'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1289)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r03')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r03', 'line', 0, phase=0)
    f "Eu não queria ficar sozinho. Você gostava de estar comigo e eu deixei você achar que era igual."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r03', 'line', 1, phase=0)
        f "Eu vi que ela estava aqui antes de a gente sair."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r03', 'line', 2, phase=0)
        f "Eu não sabia que ia encontrar ela. Mas o lugar tinha a ver com ela desde o começo."
    $ aa_audio_event('r03', 'line', 3, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    v "Mas você gostou de ficar comigo depois?"
    $ aa_audio_event('r03', 'line', 4, phase=0)
    "Olhei para o prato. Ela disse que não precisava ter sido desde o começo. Eu podia dizer que gostava. Ela tinha deixado a resposta pronta para mim."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pedir uma chance e prometer esquecer Yasmin.":
            $ aa_audio_event('r03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r03', 0)
            jump r06
        "Ouvir o que Vanessa quer fazer, sem negociar a resposta.":
            $ aa_audio_event('r03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r03', 1)
            jump r06
        "Dizer que contei a verdade e mereço algum crédito.":
            $ aa_audio_event('r03', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r03', 2)
            jump r05

label r06:
    $ aa_node = 'r06'
    $ aa_location = '21h33 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r06'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1293)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r06')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'bargain': True}):
        $ aa_audio_event('r06', 'line', 0, phase=0)
        v "Se você quer continuar, por que fala como se eu tivesse que te convencer?"
    $ aa_audio_event('r06', 'line', 1, phase=0)
    v "Eu gosto de você. Tô tentando entender o que eu faço com isso agora."
    $ aa_audio_event('r06', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka tenta aproximar a mão; Vanessa recolhe as suas e pede distância.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_limite_mao at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_limite_mao'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_mao_corrigida at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_mao_corrigida'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_mao at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_mao'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg2_mao at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_mao'
                    else:
                        $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_mao_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_mao_antes'
    show screen aa_location_display
    v "Não encosta em mim agora."
    $ aa_audio_event('r06', 'line', 3, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_sobremesa_afastada'
                    else:
                        $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Minha mão já estava indo. Recolhi antes de chegar à dela."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r06', 'line', 4, phase=0)
        "Baixei a voz. Yasmin olhava para o copo; Joãozão, para a recepção. Eles continuavam sentados perto de nós."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('r06', 'line', 5, phase=0)
        "Ninguém na outra mesa teria percebido a diferença."
    $ aa_audio_event('r06', 'line', 6, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    v "Não tô dizendo que nunca mais. Eu só não consigo agora."
    $ aa_audio_event('r06', 'line', 7, phase=0)
    "Ela se apressou em explicar o limite. Eu podia respeitar sem fazê-la pedir desculpa por ele."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Recolher a mão e ouvir como ela quer seguir.":
            $ aa_audio_event('r06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r06', 0)
            jump v00
        "Dizer que ela não pode me deixar assim depois de eu me abrir.":
            $ aa_audio_event('r06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r06', 1)
            jump r05
        "Pedir desculpa diante dos outros para mostrar que é sério.":
            $ aa_audio_event('r06', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r06', 2)
            jump r07

label r07:
    $ aa_node = 'r07'
    $ aa_location = '21h37 · Salão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r07'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1297)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r07')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_desculpa_publica'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_publico'
        else:
            $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    $ aa_audio_event('r07', 'line', 0, phase=0)
    "Levantei a voz antes de levantar da cadeira. Contei que estava errado. Eu disse o nome de Vanessa duas vezes."
    $ aa_audio_event('r07', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_desculpa_publica'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_publico'
        else:
            $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_publico_dois at aa_camera(1.12, 0.74, 0.35)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    v "Não faz isso comigo."
    $ aa_audio_event('r07', 'line', 2, phase=0)
    "Yasmin parou de mexer no copo. Joãozão olhou para a recepção. Todo mundo estava prestando atenção em mim. Era uma sensação boa demais para ser uma desculpa limpa."
    $ aa_audio_event('r07', 'line', 3, phase=0)
    v "Senta, por favor. Fala comigo."
    $ aa_audio_event('r07', 'line', 4, phase=0)
    "Ouvir meu pedido em voz alta parecia ter importado. Ela ainda queria que eu parasse."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Parar quando Vanessa pede e voltar a sentar.":
            $ aa_audio_event('r07', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r07', 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_pudim_quatro'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_desculpa_publica'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 4
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg4_pudim_publico'
                    else:
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_publico_dois'
            $ aa_audio_event('r07', 'response', 0, 0)
            "Sentei e baixei a voz. Vanessa esperou que eu parasse de olhar para os outros."
            jump v00
        "Continuar até todos entenderem meu lado.":
            $ aa_audio_event('r07', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r07', 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_pudim_quatro'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_desculpa_publica'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 4
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg4_pudim_publico'
                    else:
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_publico_dois'
            $ aa_audio_event('r07', 'response', 0, 1)
            "Continuei falando por cima dela. Quando sentei, Vanessa já tinha puxado a bolsa para perto."
            jump r05

label r05:
    $ aa_node = 'r05'
    $ aa_location = '21h40 · Salão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['r05'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1300)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('r05')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r05', 'line', 0, phase=0)
    v "Eu não aguento você falando comigo desse jeito."
    $ aa_audio_event('r05', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_hesita'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_hesita_antes'
    show screen aa_location_display
    "Ela puxou a bolsa para o colo. O casaco continuou na cadeira."
    $ aa_audio_event('r05', 'line', 2, phase=0)
    v "Eu devia ir embora."
    $ aa_audio_event('r05', 'line', 3, phase=0)
    "Esperei que levantasse. Ela ficou olhando para mim."
    $ aa_audio_event('r05', 'line', 4, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Espera a resposta sem se levantar.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Espera a resposta sem se levantar.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_hesita'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Espera a resposta sem se levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    $ aa_stage_action = 'Espera a resposta sem se levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_hesita_antes'
    show screen aa_location_display
    v "Você quer que eu vá?"
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Parar de argumentar e dar espaço para ela decidir.":
            $ aa_audio_event('r05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r05', 0)
            jump v01
        "Prometer que vou ficar com ela e ir à mudança.":
            $ aa_audio_event('r05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r05', 1)
            jump v02
        "Dizer que ela está fazendo uma cena para me prender.":
            $ aa_audio_event('r05', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r05', 2)
            jump v01

label k00:
    $ aa_node = 'k00'
    $ aa_location = '21h48 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['k00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1308)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('k00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_tres'
        else:
            $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_tres'
            else:
                $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
        else:
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg_conta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_conta_presente'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_conta_presente'
                    else:
                        $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_conta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_conta_antes'
    show screen aa_location_display
    $ aa_audio_event('k00', 'line', 0, phase=0)
    "Abri a conta. Cento e oitenta reais pela minha parte e a de Vanessa, com o serviço e a sobremesa."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 1, phase=0)
        "Eu tinha cento e vinte e tinha prometido pagar pelos dois. Faltavam sessenta."
    if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
        $ aa_audio_event('k00', 'line', 2, phase=0)
        "Eu tinha prometido pagar pelos dois. Ela já tinha pago a parte dela."
    if aa_matches(aa_state, {'debt': False}):
        $ aa_audio_event('k00', 'line', 3, phase=0)
        "Cabia no que tínhamos combinado. Pela primeira vez, uma parte da noite tinha o tamanho certo."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('k00', 'line', 4, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_tres'
            else:
                $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg_conta at aa_camera(1.1, 0.51, 0.45)
                with Dissolve(0.25)
                $ aa_last_art = 'cg_conta'
        show screen aa_location_display
        "Dos cento e oitenta, restavam os meus noventa."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 5, phase=0)
        v "Posso completar os sessenta. Depois você me devolve."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 6, phase=0)
        "Eu ainda podia pedir para dividir a conta. Tinha sido ela quem propôs isso antes de sairmos."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pagar minha parte como combinado." if aa_matches(aa_state, {'debt': False}):
            $ aa_audio_event('k00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'k00', 0)
            jump k01
        "Admitir que prometi mais do que podia e pedir divisão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'k00', 1)
            jump k01
        "Pagar minha parte agora que Vanessa acertou a dela." if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
            $ aa_audio_event('k00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'k00', 2)
            jump k01
        "Pedir dinheiro emprestado a Joãozão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'k00', 3)
            jump jl00
        "Reclamar alto do preço para desviar a atenção.":
            $ aa_audio_event('k00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'k00', 4)
            jump k01
        "Aceitar que Vanessa complete o dinheiro e combinar a devolução." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'k00', 5)
            if aa_matches(aa_state, {'route': 'juntas'}):
                if aa_matches(aa_state, {'v_gone': True}):
                    $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                    $ aa_table_party = 3
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_tres'
                else:
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Ela completa a conta antes da saída do casal.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg4_pudim_pagamento at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg4_pudim_pagamento'
                else:
                    $ aa_stage_action = 'Ela completa o pagamento no cartão.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_pagamento'
            $ aa_audio_event('k00', 'response', 0, 5)
            $ aa_finance_event('dinner_vanessa')
            "Paguei cento e vinte. Vanessa completou os sessenta no cartão. Eu disse que devolveria na sexta."
            $ aa_audio_event('k00', 'response', 1, 5)
            v "Tá. Sexta."
            $ aa_audio_event('k00', 'response', 2, 5)
            "Ela repetiu a data. Eu fiz que sim. Já estava arrependido de ter escolhido uma."
            jump k01

label k01:
    $ aa_node = 'k01'
    $ aa_location = '21h55 · Salão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['k01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1315)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_finance_event('settle_dinner')
    $ aa_audio_enter('k01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_tres'
        else:
            $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_tres'
            else:
                $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
        else:
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Feka sozinho após Vanessa sair.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sozinho'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_sobremesa'
                    else:
                        $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('k01', 'line', 0, phase=0)
        "A recepção já estava olhando para nossa mesa. O garçom perguntou, pela segunda vez, se precisávamos de alguma coisa."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_event('k01', 'line', 1, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_conta_presente'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_conta_presente'
                    else:
                        $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_conta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_conta_antes'
        show screen aa_location_display
        "O Pix de Joãozão tinha completado o que faltava. Eu precisava devolver os sessenta até meio-dia de amanhã."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_event('k01', 'line', 2, phase=0)
        "Eu tinha pedido dinheiro a ele. Ainda estava tentando aceitar isso."
    if aa_matches(aa_state, {'bill': 'cena'}):
        $ aa_audio_event('k01', 'line', 3, phase=0)
        "O garçom apontou os itens. Eu sabia que estavam certos. Continuei olhando até ele perceber que eu não tinha uma dúvida."
    if aa_matches(aa_state, {'bill': 'cena', 'debt': True, 'v_gone': False}):
        $ aa_finance_event('dinner_split')
        $ aa_audio_event('k01', 'line', 4, phase=0)
        "Vanessa pediu que separassem o que ela tinha consumido. Com a parte dela paga, meu saldo foi suficiente. Eu ainda resmunguei enquanto aproximava o cartão."
    if aa_matches(aa_state, {'bill': 'admitida', 'v_gone': False}):
        $ aa_audio_event('k01', 'line', 5, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_conta_presente'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_conta_presente'
                    else:
                        $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_conta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_conta_antes'
        show screen aa_location_display
        v "Eu trouxe dinheiro pra minha parte. Por que você insistiu que dava pra pagar tudo?"
    $ aa_audio_event('k01', 'line', 6, phase=0)
    "O salão começava a esvaziar. Do lado de fora, a chuva já tinha diminuído."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('k01', 'line', 7, phase=0)
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Todos saíram da mesa B+C; Feka permanece no mesmo assento oeste.'
            $ aa_table_party = 1
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_sozinho'
        else:
            $ aa_stage_action = 'Pudim na mesa C; Yasmin e Joãozão ainda ausentes, cadeiras de B vazias.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_dois'
        show screen aa_location_display
        "Yasmin recolheu a bolsa. Ela e Joãozão deixaram as cadeiras e foram pagar a conta deles no balcão."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('k01', 'line', 8, phase=0)
        "Na outra mesa, Yasmin recolheu a bolsa. Ela e Joãozão foram ao balcão acertar a conta."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False, 'bond': 'mantido'}):
        $ aa_audio_event('k01', 'line', 9, phase=0)
        v "Sobre amanhã, me avisa antes de sair. Eu te mando o endereço."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False, 'bond': 'mantido'}):
        $ aa_audio_event('k01', 'line', 10, phase=0)
        "Ela guardou o telefone e procurou o casaco."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False, 'bond': 'indefinido'}):
        $ aa_audio_event('k01', 'line', 11, phase=0)
        v "A mudança eu resolvo com a minha mãe. A gente combina outra hora para conversar."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Perguntar a Vanessa como ela quer ir embora." if aa_matches(aa_state, {'v_gone': False}):
            $ aa_audio_event('k01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'k01', 0)
            jump s00
        "Aceitar que ela foi embora e sair sozinho." if aa_matches(aa_state, {'v_gone': True}):
            $ aa_audio_event('k01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'k01', 1)
            jump e04
        "Tentar uma última conversa com Yasmin.":
            $ aa_audio_event('k01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'k01', 2)
            jump s01
        "Acertar o limite com Joãozão, sem levantar a voz." if aa_matches(aa_state, {'j_limit': True, 'truth': True}):
            $ aa_audio_event('k01', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'k01', 3)
            jump s02
        "Provocar Joãozão na frente de Yasmin.":
            $ aa_audio_event('k01', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'k01', 4)
            jump s03
        "Usar uma foto ou mensagem para fazer a noite parecer boa." if aa_matches(aa_state, {'public': True}):
            $ aa_audio_event('k01', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'k01', 5)
            jump e08
        "Perguntar se Vanessa quer voltar comigo para a moradia." if aa_matches(aa_state, {'tender_lie': True, 'chosen_vanessa': True, 'bond': 'mantido', 'contact': 'juntos', 'promised': True, 'bill': 'dividida', 'v_gone': False}):
            $ aa_audio_event('k01', 'choice', 6, 6)
            $ aa_state = aa_choose(aa_state, 'k01', 6)
            jump h02

label s00:
    $ aa_node = 's00'
    $ aa_location = '22h02 · Entrada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['s00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1322)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('s00')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('s00', 'line', 0, phase=0)
    "Vanessa conferiu o destino no aplicativo. Depois baixou o telefone e me olhou."
    if aa_matches(aa_state, {'bond': 'mantido'}):
        $ aa_audio_event('s00', 'line', 1, phase=0)
        v "Você espera comigo?"
    if aa_matches(aa_state, {'bond': {'ne': 'mantido'}}):
        $ aa_audio_event('s00', 'line', 2, phase=0)
        v "Eu vou sozinha. Mas espera o carro chegar?"
    $ aa_audio_event('s00', 'line', 3, phase=0)
    $ aa_stage_action = 'Após pedir companhia, ela volta a conferir a placa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'carro'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('carro')
    show screen aa_phone_view('carro')
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    "Eu disse que esperava. Ela virou a tela para mim: o carro ainda estava a quatro minutos."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('s00', 'line', 4, phase=0)
        $ aa_stage_action = 'Telefone baixo; a resposta é dada a Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_saida_espera'
        show screen aa_location_display
        v "Se você mudar de ideia sobre amanhã, fala. Não some."
    if aa_matches(aa_state, {'promised': False}):
        $ aa_audio_event('s00', 'line', 5, phase=0)
        $ aa_stage_action = 'Telefone baixo; a resposta é dada a Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_saida_espera'
        show screen aa_location_display
        v "Amanhã a gente vai se ver na aula. Eu não sei como vai ser."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que quero encerrar o namoro.":
            $ aa_audio_event('s00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's00', 0)
            $ aa_audio_event('s00', 'response', 0, 0)
            f "Eu quero terminar."
            $ aa_audio_event('s00', 'response', 1, 0)
            v "Você esperou eu chamar o carro pra falar?"
            $ aa_audio_event('s00', 'response', 2, 0)
            "Eu tinha esperado. Não tentei dar outro nome."
            $ aa_audio_event('s00', 'response', 3, 0)
            v "Tá. Então deixa eu ir."
            jump e01
        "Perguntar se ela aceita conversar outro dia, sem exigir namoro." if aa_matches(aa_state, {'truth': True, 'listened': True, 'respect': True, 'heard': True, 'bond': 'indefinido'}):
            $ aa_audio_event('s00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's00', 1)
            jump e02
        "Garantir que não vou sumir e confirmar o combinado de amanhã." if aa_matches(aa_state, {'bond': {'ne': 'terminado'}}):
            $ aa_audio_event('s00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 's00', 2)
            jump cr00
        "Pedir a Yasmin que reconheça a humilhação que causou." if aa_matches(aa_state, {'stopped_joke': True, 'truth': True, 'respect': True, 'route': 'juntas'}):
            $ aa_audio_event('s00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 's00', 3)
            jump e09
        "Ficar calado, esperando Vanessa resolver por mim.":
            $ aa_audio_event('s00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 's00', 4)
            jump e10

label s01:
    $ aa_node = 's01'
    $ aa_location = '22h02 · Perto do balcão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['s01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1322)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('s01')
    $ aa_stage_action = 'Yasmin fecha a bolsa e recusa outra conversa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    $ aa_audio_event('s01', 'line', 0, phase=0)
    f "Yasmin, espera."
    $ aa_audio_event('s01', 'line', 1, phase=0)
    "Ela fechou a bolsa. Não precisou olhar para Joãozão."
    $ aa_audio_event('s01', 'line', 2, phase=0)
    $ aa_stage_action = 'Recusa sem sorriso.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.1, 0.73, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    y "Não."
    $ aa_audio_event('s01', 'line', 3, phase=0)
    "Eu ainda nem tinha feito a pergunta. Percebi que era sempre a mesma."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Parar ali.":
            $ aa_audio_event('s01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's01', 0)
            jump e05
        "Insistir, falando por cima dela.":
            $ aa_audio_event('s01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's01', 1)
            jump s03

label s02:
    $ aa_node = 's02'
    $ aa_location = '22h03 · Balcão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['s02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1323)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('s02')
    $ aa_stage_action = 'Feka admite o limite; Joãozão não oferece amizade.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    $ aa_audio_event('s02', 'line', 0, phase=0)
    f "Eu não vou procurar ela. Não quero que você fale por mim nem por ela."
    $ aa_audio_event('s02', 'line', 1, phase=0)
    j "Você não vai procurar porque eu mandei?"
    $ aa_audio_event('s02', 'line', 2, phase=0)
    $ aa_stage_action = 'O medo não desaparece depois da frase correta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.13, 0.24, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    "Ele estava perto. Eu continuava com medo. Não precisava fingir que tinha parado de ter para responder."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que a resposta dela já basta.":
            $ aa_audio_event('s02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's02', 0)
            jump e06
        "Dizer que Yasmin não merece tudo isso.":
            $ aa_audio_event('s02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's02', 1)
            jump e05

label s03:
    $ aa_node = 's03'
    $ aa_location = '22h04 · Salão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['s03'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1324)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('s03')
    $ aa_stage_action = 'Yasmin detém o passo de Joãozão; funcionário se aproxima.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    $ aa_audio_event('s03', 'line', 0, phase=0)
    j "Para. A gente está indo embora."
    $ aa_audio_event('s03', 'line', 1, phase=0)
    $ aa_stage_action = 'Mostrar a mão de Yasmin no braço, não uma briga.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.08, 0.67, 0.4)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    "Algumas pessoas olharam. Joãozão deu um passo. Yasmin tocou o braço dele e disse para ele não fazer aquilo."
    if aa_matches(aa_state, {'heat': {'gte': 3}}):
        $ aa_audio_event('s03', 'line', 2, phase=0)
        j "Para de insistir. A gente já disse que vai embora."
    $ aa_audio_event('s03', 'line', 3, phase=0)
    $ aa_stage_action = 'Abrir o plano para incluir o funcionário.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    "Um funcionário veio até nós. Não perguntou quem tinha razão. Perguntou se havia algum problema."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Baixar a voz e sair.":
            $ aa_audio_event('s03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's03', 0)
            jump e05
        "Continuar provocando, mesmo depois do aviso.":
            $ aa_audio_event('s03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's03', 1)
            $ aa_audio_event('s03', 'response', 0, 1)
            f "Você só sabe falar por ela?"
            $ aa_audio_event('s03', 'response', 1, 1)
            y "Eu não quero falar com você. Quero ir embora."
            jump d00

label e00:
    $ aa_node = 'e00'
    $ aa_location = '19h45 · Hall do apartamento'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1185)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e00')
    $ aa_stage_action = 'Ela tenta adiar a separação antes de chamar o carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('e00', 'line', 0, phase=0)
    "Cancelei a reserva. Vanessa perguntou se eu estava cancelando só o jantar. Eu disse que não sabia continuar o namoro daquele jeito."
    $ aa_audio_event('e00', 'line', 1, phase=0)
    v "Eu podia ficar um pouco. A gente não precisa sair."
    $ aa_audio_event('e00', 'line', 2, phase=0)
    $ aa_location = '19h50 · Cozinha compartilhada'
    $ aa_stage_action = 'Vanessa já foi; a panela permanece. Vazio agora tem causa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha'
    show screen aa_location_display
    "Eu repeti que precisava encerrar. Ela chamou a mãe antes de pedir o carro."
    $ aa_audio_event('e00', 'line', 2, phase=1)
    "Depois que saiu, tirei a jaqueta. A panela continuava na pia."
    $ aa_audio_event('e00', 'line', 3, phase=0)
    "Peguei o celular. A vontade de ver Yasmin não tinha acabado porque eu tinha feito uma coisa certa."
    $ aa_audio_event('e00', 'line', 4, phase=0)
    $ aa_location = '19h55 · Cozinha compartilhada'
    $ aa_stage_action = 'Feka lava a própria panela; encerramento concreto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_lavar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_lavar'
    show screen aa_location_display
    "Deixei o celular na mesa e lavei a panela."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e00', 'line', 4, phase=1)
    $ aa_phone_remember('mudanca_cancelada')
    "Na manhã seguinte, Vanessa perguntou se eu tinha certeza. Respondi que sim. Ela pediu que eu não fosse à mudança."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E00 · A noite que não aconteceu"
    return

label e01:
    $ aa_node = 'e01'
    $ aa_location = '22h10 · Calçada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e01')
    $ aa_stage_action = 'Duas pessoas diante da mesma porta escolhem rumos diferentes.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('e01', 'line', 0, phase=0)
    f "Tá. Eu vou por outro caminho."
    $ aa_audio_event('e01', 'line', 1, phase=0)
    v "Eu vou querer te mandar mensagem. Não responde como se hoje não tivesse acontecido."
    $ aa_audio_event('e01', 'line', 2, phase=0)
    "Esperei uma frase maior. Ela não tinha obrigação de encerrar aquilo de um jeito que me ajudasse."
    $ aa_audio_event('e01', 'line', 3, phase=0)
    $ aa_location = 'Mais tarde · Caminho de volta'
    $ aa_stage_action = 'Sozinho, Feka apaga a cobrança disfarçada de desculpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'rascunho'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('rascunho')
    show screen aa_phone_view('rascunho')
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "No caminho de volta, escrevi que sentia muito."
    $ aa_audio_event('e01', 'line', 4, phase=0)
    $ aa_location = 'Mais tarde · Caminho de volta'
    $ aa_stage_action = 'Campo vazio; a desculpa não foi enviada.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'rascunho_apagado'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('rascunho_apagado')
    show screen aa_phone_view('rascunho_apagado')
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "Apaguei quando percebi que estava esperando uma resposta antes de enviar."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e01', 'line', 5, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Dia seguinte: distância entre os colegas.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'grupo_materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('grupo_materia')
    show screen aa_phone_view('grupo_materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, Vanessa sentou com uma colega. Olhou para meu lugar quando cheguei, mas não me chamou. Mandei a matéria pelo grupo."
    $ aa_audio_event('e01', 'line', 6, phase=0)
    "Eu soube que ela tinha recebido as chaves por outra pessoa."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E01 · Duas contas"
    return

label e02:
    $ aa_node = 'e02'
    $ aa_location = '22h10 · Calçada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e02')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('e02', 'line', 0, phase=0)
    f "Você aceita conversar outro dia? Se não quiser, eu não vou ficar perguntando."
    $ aa_audio_event('e02', 'line', 1, phase=0)
    v "Eu quero. Mas eu vou acabar perguntando se você volta. Preciso pensar antes."
    $ aa_audio_event('e02', 'line', 2, phase=0)
    "Quase chamei aquilo de uma chance. Era uma conversa que ainda não tinha sido aceita."
    $ aa_audio_event('e02', 'line', 3, phase=0)
    v "Na mudança vai minha mãe. Não aparece sem combinar. Eu posso querer te chamar e ainda assim precisar que você não vá."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e02', 'line', 4, phase=0)
    $ aa_location = 'Campus de Direito'
    $ aa_audio_ambient('AMB15')
    $ aa_stage_action = 'Matéria e conversa para quinta; distância no campus.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, mandei a matéria. Ela respondeu que tinha recebido a chave e perguntou se podíamos conversar na quinta, depois da aula."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e02', 'line', 5, phase=0)
    $ aa_location = 'Campus de Direito'
    $ aa_audio_ambient('AMB15')
    $ aa_stage_action = 'Matéria e conversa para quinta; distância no campus.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Respondi que sim. Não tratei a quinta-feira como a data em que ela seria minha namorada de novo."
    jump b_wait

label e03:
    $ aa_node = 'e03'
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e03'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1920)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e03')
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 0, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 1, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    "O celular estava ao lado da minha perna. Eu tinha prometido mandar mensagem quando acordasse. Passei alguns segundos sentado antes de pegar."
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 2, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Só agora pega o celular e confirma a visita.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'visita'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('visita')
    show screen aa_phone_view('visita')
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    "Mandei bom dia e confirmei que iria depois da aula. Vanessa respondeu que ia me esperar."
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 3, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Conversa fecha; ele precisa se preparar para a aula.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    "Ainda precisava me arrumar e ir para a aula. A visita agora tinha uma hora na minha cabeça. Eu podia passar a manhã inteira procurando uma desculpa."
    $ aa_present = ()
    call aa_advance_clock(2400)
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 4, phase=0)
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chega com uma caixa do corredor; Vanessa abre a porta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_chegada_mudanca'
    show screen aa_location_display
    "Depois da aula, fui ao endereço que ela tinha mandado. Vanessa abriu a porta enquanto eu levantava uma das caixas que o frete tinha deixado no corredor."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 5, phase=0)
    v "Você veio. Minha mãe ficou até agora e acabou de sair. Pode entrar."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 6, phase=0)
    f "Onde ponho essa?"
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 7, phase=0)
    v "Perto da janela. É pesada? Espera, eu tiro a cadeira."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 8, phase=0)
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Caixas abertas; os dois trabalham na cozinha.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_trabalho_mudanca'
    show screen aa_location_display
    "Levei a caixa para dentro. Vanessa afastou a cadeira antes que eu pedisse. A sala era menor do que eu tinha imaginado."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 9, phase=0)
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Ela indica a posição da mesa; diálogo durante o trabalho.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_trabalho_mudanca'
    show screen aa_location_display
    "Abrimos as caixas da cozinha. Eu tirava os copos do papel; ela separava o que ia para o armário. Pela primeira vez desde o jantar, havia uma coisa simples para fazer."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 10, phase=0)
    v "A mesa fica aqui. Você acha que dá pra passar?"
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 11, phase=0)
    f "Se puxar um pouco pra janela, dá."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 12, phase=0)
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Os dois deslocam a mesa; caixas e louça continuam por guardar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_mesa_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_mesa_mudanca'
    show screen aa_location_display
    "Tiramos os copos de cima e empurramos a mesa alguns centímetros. Ela ficou segurando a outra ponta até eu dizer que estava bom."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 13, phase=0)
    v "Você fica pra comer? Minha mãe deixou comida."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 14, phase=0)
    f "Fico."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 15, phase=0)
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Vanessa chega com os dois pratos; antes de sentarem.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_comida_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_comida_mudanca'
    show screen aa_location_display
    "Ela foi buscar os pratos. Antes de servir, perguntou de novo se eu não precisava ir embora."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 16, phase=0)
    f "Eu falei que fico."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 17, phase=0)
    v "Tá. Eu só queria saber."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 18, phase=0)
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Os dois finalmente sentados para comer; caixas ainda abertas.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_refeicao_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_refeicao_mudanca'
    show screen aa_location_display
    "Sentamos. Ela esperou minha primeira garfada antes de começar. As caixas continuavam abertas junto da parede."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 19, phase=0)
    "Eu tinha ajudado na mudança. Vanessa agradeceu por eu ter ido. Olhei as caixas abertas; ainda havia coisas para guardar antes de ir embora."
    jump w_louca

label e04:
    $ aa_node = 'e04'
    $ aa_location = '22h10 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e04'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e04')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
        $ aa_table_party = 1
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_sozinho'
    else:
        $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    $ aa_audio_event('e04', 'line', 0, phase=0)
    "A cadeira ainda estava um pouco afastada. Tive vontade de pôr no lugar, como se isso diminuísse o que tinha acontecido."
    $ aa_audio_event('e04', 'line', 1, phase=0)
    "O garçom perguntou se podia tirar o segundo copo. Respondi que podia. Foi a única decisão que alguém ainda precisava de mim."
    $ aa_audio_event('e04', 'line', 2, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Um caderno na mesa; o de Vanessa foi embora com ela.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Em casa, só o meu caderno estava na escrivaninha. Vanessa tinha guardado o dela na bolsa antes de sairmos."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e04', 'line', 3, phase=0)
    $ aa_location = 'Segunda-feira · Campus de Direito'
    $ aa_stage_action = 'Cumprimento distante no dia seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'so_materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('so_materia')
    show screen aa_phone_view('so_materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Na segunda-feira, Vanessa sentou com uma colega. Me cumprimentou de longe. Depois recebi uma mensagem: queria só a matéria, pelo grupo."
    if aa_matches(aa_state, {'bond': 'indefinido'}):
        $ aa_present = ()
        call aa_advance_clock(2640)
        $ aa_audio_event('e04', 'line', 4, phase=0)
        $ aa_location = 'Segunda-feira à noite · Quarto de Feka'
        $ aa_stage_action = 'Contato posterior não desfaz a saída da noite anterior.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'espaco'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('espaco')
        show screen aa_phone_view('espaco')
        $ aa_last_art = 'cg2_retorno'
        show screen aa_location_display
        "À noite ela escreveu que ainda não sabia terminar, mas não queria me ver fora da aula por enquanto. Respondi que tinha entendido."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        $ aa_audio_event('e04', 'line', 5, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'O término continua explícito.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "A vontade de chamá-la de volta não era um motivo para fingir que o término tinha ficado em dúvida."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        jump z04
    jump b_space

label e05:
    $ aa_node = 'e05'
    $ aa_location = '22h10 · Entrada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e05'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e05')
    $ aa_stage_action = 'Yasmin e Joãozão saem juntos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    show aa_y firm at aa_left
    show aa_j neutral at aa_right
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    $ aa_audio_event('e05', 'line', 0, phase=0)
    "Yasmin foi embora com Joãozão. Não houve uma última olhada. Esperei até a porta fechar mesmo assim."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e05', 'line', 1, phase=0)
        $ aa_stage_action = 'Exibir Vanessa somente se ainda não tiver saído.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        "Quando voltei, Vanessa ainda esperava perto da porta. Perguntou se agora podíamos ir. Eu disse que ela devia ir sem mim. Ela chamou o carro e perguntou outra vez se eu tinha certeza."
    $ aa_audio_event('e05', 'line', 2, phase=0)
    $ aa_stage_action = 'Feka permanece sem conseguir reter ninguém.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "Eu tinha perdido o jantar de Vanessa e ainda queria que alguém reconhecesse meu sofrimento como a parte principal."
    $ aa_audio_event('e05', 'line', 3, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A toalha úmida retoma o início da noite.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "No quarto, a toalha continuava úmida. Eu lembrava de Vanessa perguntando onde estava. Não lembrava do que respondi."
    $ aa_audio_event('e05', 'line', 4, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A mesma mensagem antiga, agora sem desculpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'conversa'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('conversa')
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Abri a conversa de Yasmin. A mensagem antiga continuava lá, dizendo para eu não esperar na saída. Era uma resposta que eu tinha passado anos fingindo não saber ler."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('e05', 'line', 5, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'A promessa quebrada recebe uma resposta no dia seguinte.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "Eu tinha prometido ir à mudança."
        $ aa_present = ()
        call aa_advance_clock(1980)
        $ aa_audio_event('e05', 'line', 5, phase=1)
        $ aa_phone_remember('promessa')
        "No dia seguinte escrevi que não iria e que não podia pedir que ela me esperasse. Ela respondeu horas depois: “Você falou que ia.”"
    jump z05

label e06:
    $ aa_node = 'e06'
    $ aa_location = '22h10 · Balcão e calçada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e06'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('joaozao',)
    $ aa_audio_enter('e06')
    $ aa_stage_action = 'A conversa termina sem aperto de mão.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    $ aa_audio_event('e06', 'line', 0, phase=0)
    f "Não. Porque ela não quer."
    $ aa_audio_event('e06', 'line', 1, phase=0)
    j "Então faz isso."
    $ aa_audio_event('e06', 'line', 2, phase=0)
    "Ele não me deu a mão. Eu não ofereci a minha. Não havia amizade escondida esperando a frase certa."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_present = ('vanessa',)
        $ aa_audio_event('e06', 'line', 3, phase=0)
        $ aa_stage_action = 'Vanessa tem seu transporte; acordo com Joãozão não a retém.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        "Vanessa tinha chamado o carro. Perguntou se a conversa tinha acabado."
        $ aa_audio_event('e06', 'line', 3, phase=1)
        "Eu disse que sim e esperei até a placa aparecer. Ela foi sozinha."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_present = ()
        $ aa_audio_event('e06', 'line', 4, phase=0)
        $ aa_stage_action = 'O ramo em que ela já saiu permanece vazio.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'bg_calcada'
        show screen aa_location_display
        "Vanessa já tinha ido. Acertar uma coisa não trouxe de volta a outra."
    $ aa_present = ()
    $ aa_audio_event('e06', 'line', 6, phase=0)
    "Eu ia continuar estudando com Vanessa. Yasmin, com ele. Pela primeira vez pensei nisso como a vida deles, não como uma provocação."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False}):
        $ aa_present = ()
        call aa_advance_clock(1980)
        $ aa_present = ()
        $ aa_audio_event('e06', 'line', 7, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'A relação continua indefinida; a promessa é cobrada.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'indefinido'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('indefinido')
        show screen aa_phone_view('indefinido')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "Na manhã seguinte, mandei que não iria à mudança e pedi desculpa por ter prometido. Ela perguntou se eu ainda queria o namoro. Respondi que não sabia e que entendia se ela não quisesse esperar."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_present = ()
        call aa_advance_clock(2400)
        $ aa_present = ()
        $ aa_audio_transients()
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Empréstimo devolvido no dia seguinte.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "[aa_financial_line('joao_epilogue')]"
    jump z06

label e07:
    $ aa_node = 'e07'
    $ aa_location = '22h12 · Entrada do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e07'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1332)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e07')
    $ aa_location = 'Entrada do restaurante'
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    $ aa_audio_event('e07', 'line', 0, phase=0)
    "O funcionário pediu que eu saísse. Eu tentei contar a história. Ele repetiu o pedido, agora mais devagar."
    $ aa_audio_event('e07', 'line', 1, phase=0)
    y "João, para. Não precisa ir atrás."
    $ aa_audio_event('e07', 'line', 2, phase=0)
    "Joãozão parou. Nem a briga que eu estava tentando fabricar aconteceu do jeito que eu precisava."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e07', 'line', 3, phase=0)
        "Vanessa veio até a porta e perguntou se eu tinha me machucado. Eu disse que tinham me desrespeitado. Ela ficou em silêncio, depois chamou a mãe e foi esperar o carro."
    $ aa_audio_event('e07', 'line', 4, phase=0)
    $ aa_location = 'Entrada do restaurante'
    $ aa_stage_action = 'Feka grava o áudio na calçada, já fora do restaurante.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.14, 0.74, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    "Na calçada, o frio veio depois da vergonha."
    $ aa_audio_event('e07', 'line', 4, phase=1)
    $ aa_phone_remember('audio')
    "Enviei um áudio dizendo que tinham me desrespeitado. Ouvi antes de enviar o segundo. Minha voz parecia satisfeita por finalmente ter um culpado."
    $ aa_audio_event('e07', 'line', 5, phase=0)
    $ aa_location = 'Entrada do restaurante'
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'audio_resposta'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('audio_resposta')
    show screen aa_phone_view('audio_resposta')
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    "No grupo, alguém respondeu ‘complicado’. Eu guardei aquela palavra como apoio."
    $ aa_audio_event('e07', 'line', 6, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'chegou'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('chegou')
    show screen aa_phone_view('chegou')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Mais tarde Vanessa perguntou por mensagem se eu tinha chegado. Eu quase usei a preocupação dela para contar minha versão inteira. Ela acrescentou que precisava ficar sem conversar naquela noite."
    jump z07

label e08:
    $ aa_node = 'e08'
    $ aa_location = '22h16 · Celular'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e08'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1336)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e08')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 1
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_sozinho'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_dois'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sozinho'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e08', 'line', 0, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_dois'
        else:
            $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_levantar'
        show screen aa_location_display
        "Vanessa perguntou se eu ia continuar no celular. Eu disse que já ia. Quando ela anunciou que iria embora, respondi sem levantar os olhos."
    $ aa_audio_event('e08', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
        $ aa_table_party = 0
        $ aa_phone_pov = True
        $ aa_phone_kind = 'enquadramento'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg6_phone_table at aa_phone_camera
        with Dissolve(0.25)
        $ aa_phone_remember('enquadramento')
        show screen aa_phone_view('enquadramento')
        $ aa_last_art = 'cg6_phone_table'
    else:
        $ aa_stage_action = 'Só então a cadeira fica vazia.'
        $ aa_table_party = 0
        $ aa_phone_pov = True
        $ aa_phone_kind = 'enquadramento'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg6_phone_table at aa_phone_camera
        with Dissolve(0.25)
        $ aa_phone_remember('enquadramento')
        show screen aa_phone_view('enquadramento')
        $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    "Fotografei os copos que ainda estavam na mesa. Deixei as cadeiras fora do enquadramento."
    $ aa_audio_event('e08', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    "Escrevi que a noite tinha sido boa. Fiquei olhando as visualizações."
    if aa_matches(aa_state, {'bond': {'ne': 'mantido'}}):
        $ aa_audio_event('e08', 'line', 3, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'marcacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('marcacao')
            show screen aa_phone_view('marcacao')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'A mensagem desmonta a publicação feliz.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'marcacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('marcacao')
            show screen aa_phone_view('marcacao')
            $ aa_last_art = 'cg6_phone_table'
        show screen aa_location_display
        "Vanessa mandou uma mensagem pedindo que eu não a marcasse. Não tinha palavrão. Apaguei a marcação e deixei a publicação."
    $ aa_audio_event('e08', 'line', 4, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    "Yasmin não respondeu. Eu disse a mim mesmo que ela devia ter visto."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e08', 'line', 5, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Outro público para a versão menor da história.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Na manhã seguinte, contei a um colega que Vanessa estava estranha. Ele não conhecia o começo da história. Era por isso que eu tinha escolhido contar a ele."
    if aa_matches(aa_state, {'bond': 'mantido'}):
        $ aa_present = ()
        call aa_advance_clock(2400)
        $ aa_audio_event('e08', 'line', 6, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Ela procura confirmação pela mensagem, apesar da publicação falsa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'visita_post'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('visita_post')
        show screen aa_phone_view('visita_post')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "Vanessa respondeu à publicação perguntando se a visita à mudança ainda estava combinada. Eu mandei que sim. Ela não comentou as cadeiras que eu tinha escondido."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        jump z08
    if aa_matches(aa_state, {'bond': 'mantido'}):
        jump b_post_visit
    jump b_post_define

label e09:
    $ aa_node = 'e09'
    $ aa_location = '22h10 · Entrada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e09'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e09')
    $ aa_stage_action = 'Yasmin se dirige a Vanessa; Joãozão aguarda.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    $ aa_audio_event('e09', 'line', 0, phase=0)
    "Chamei Yasmin quando ela e Joãozão chegaram à porta."
    $ aa_audio_event('e09', 'line', 1, phase=0)
    f "Você podia pelo menos pedir desculpa pelo que falou."
    $ aa_audio_event('e09', 'line', 2, phase=0)
    "Yasmin olhou para Vanessa. Eu fiquei esperando que olhasse para mim."
    $ aa_audio_event('e09', 'line', 3, phase=0)
    $ aa_stage_action = 'Yasmin olha para Vanessa, Feka fora do centro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.12, 0.52, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    y "Eu fiz uma piada e te coloquei no meio. Foi escroto. Desculpa."
    $ aa_audio_event('e09', 'line', 4, phase=0)
    v "Eu... tá. Foi ruim. Mas eu preciso falar com ele também."
    $ aa_audio_event('e09', 'line', 5, phase=0)
    $ aa_stage_action = 'Cada uma segue seu caminho; ninguém posa para Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    "Vanessa esperou eu perguntar se queria companhia até o carro. Disse que sim."
    $ aa_audio_event('e09', 'line', 5, phase=1)
    "Depois pediu que eu não fosse junto. Yasmin e Joãozão seguiram para a rua."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e09', 'line', 6, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A interpretação continua difícil no dia seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, tentei lembrar a noite sem dividir as pessoas entre quem me humilhou e quem devia ter me salvado. Não consegui o tempo todo."
    jump b_apology

label e10:
    $ aa_node = 'e10'
    $ aa_location = '22h14 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e10'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1334)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e10')
    $ aa_stage_action = 'Vanessa anuncia o carro antes de sair.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('e10', 'line', 0, phase=0)
    v "Meu carro chegou. Você vai falar alguma coisa antes de eu ir?"
    $ aa_audio_event('e10', 'line', 1, phase=0)
    "Eu disse que não sabia. Vanessa ficou mais um instante. Depois foi embora, olhando o celular enquanto caminhava."
    $ aa_audio_event('e10', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
        $ aa_table_party = 1
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_sozinho'
    else:
        $ aa_stage_action = 'Feka volta à sobremesa com duas colheres e uma cadeira vazia.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    "Voltei à mesa. O pudim continuava lá, com as duas colheres. O garçom perguntou se podia tirar. Eu disse que ainda estava comendo."
    $ aa_audio_event('e10', 'line', 3, phase=0)
    "Não fiz uma cena. Não disse uma última mentira. Também não disse o que devia. Consegui passar pela noite deixando o trabalho para os outros."
    $ aa_audio_event('e10', 'line', 4, phase=0)
    $ aa_location = 'Mais tarde · Cozinha compartilhada'
    $ aa_stage_action = 'Panela limpa por outra pessoa: repetir o espaço, mudar o objeto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha_noite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha_noite'
    show screen aa_location_display
    "Em casa, a cozinha estava limpa. Um dos moradores tinha lavado minha panela. Senti alívio antes de sentir vergonha."
    $ aa_audio_event('e10', 'line', 5, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A pergunta chega depois da saída, quando Feka já voltou.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_phone_remember('cheguei')
    "Ela mandou “cheguei” naquela noite. Respondi “que bom”."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e10', 'line', 5, phase=1)
    $ aa_phone_remember('terminou')
    "No dia seguinte perguntou se a gente tinha terminado. Eu tinha conseguido adiar até a obrigação de responder isso."
    jump b_answer

label v00:
    $ aa_node = 'v00'
    $ aa_location = '21h39 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['v00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1299)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('v00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('v00', 'line', 0, phase=0)
    v "Você ainda quer estar comigo?"
    $ aa_audio_event('v00', 'line', 1, phase=0)
    "Ela perguntou sem olhar para Yasmin. Não havia outra pessoa que pudesse responder por mim."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('v00', 'line', 2, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        v "Ir à mudança é uma coisa. Eu tô perguntando da gente."
    if aa_matches(aa_state, {'promised': False}):
        $ aa_audio_event('v00', 'line', 3, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        v "Amanhã eu pego a chave. Eu tinha pensado em você lá."
    $ aa_audio_event('v00', 'line', 4, phase=0)
    "Eu imaginei voltar para o meu quarto sem ter com quem conversar. Era mais fácil pensar nisso do que no que ela tinha acabado de ouvir."
    if aa_matches(aa_state, {'comfort_lie': True}):
        $ aa_audio_event('v00', 'line', 5, phase=0)
        v "Você acabou de dizer que quer ficar comigo. Eu preciso saber se posso contar com isso amanhã também."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar que continuo com ela e manter a visita de amanhã.":
            $ aa_audio_event('v00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'v00', 0)
            jump v02
        "Pedir um tempo e oferecer uma conversa, sem prometer namoro.":
            $ aa_audio_event('v00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'v00', 1)
            $ aa_audio_event('v00', 'response', 0, 1)
            v "Tempo até quando?"
            $ aa_audio_event('v00', 'response', 1, 1)
            f "Não tenho uma data. Não quero inventar uma pra você esperar."
            $ aa_audio_event('v00', 'response', 2, 1)
            "Ela ficou em silêncio."
            $ aa_audio_event('v00', 'response', 3, 1)
            v "Tá. Hoje eu vou sozinha. Amanhã eu penso se quero conversar."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('v00', 'response', 4, 1)
                v "Agora você precisa de tempo? Eu tinha acabado de tentar acreditar em você."
            jump k00
        "Dizer que quero terminar, sem pedir que ela me console.":
            $ aa_audio_event('v00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'v00', 2)
            $ aa_audio_event('v00', 'response', 0, 2)
            f "Eu quero terminar. Não quero pedir que você espere eu virar outra pessoa."
            $ aa_audio_event('v00', 'response', 1, 2)
            v "Então fala que terminou. Não fica dizendo que é por mim."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('v00', 'response', 2, 2)
                v "Por que disse que gostava de mim, então? Era só pra eu parar de perguntar?"
            jump v01

label v02:
    $ aa_node = 'v02'
    $ aa_location = '21h43 · Mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['v02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1303)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('v02')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'hesitated': True}):
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_hesita'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_hesita'
                    else:
                        $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_hesita_antes'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('v02', 'line', 0, phase=0)
    f "Eu continuo com você. Amanhã eu vou lá."
    $ aa_audio_event('v02', 'line', 1, phase=0)
    v "Eu quero continuar. Mas a gente vai ter que voltar nessa conversa."
    $ aa_audio_event('v02', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'hesitated': True}):
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_hesita'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_hesita'
                    else:
                        $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_hesita_antes'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Assenti. Vanessa soltou um pouco os ombros, sem se aproximar."
    $ aa_audio_event('v02', 'line', 3, phase=0)
    v "Eu não acredito direito em você agora."
    $ aa_audio_event('v02', 'line', 4, phase=0)
    f "Eu sei."
    $ aa_audio_event('v02', 'line', 5, phase=0)
    v "Mas eu não quero ir pra casa achando que nunca mais vou te ver assim."
    if aa_matches(aa_state, {'hesitated': True}):
        $ aa_audio_event('v02', 'line', 6, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        "Ela deixou a bolsa ao lado da cadeira. Eu devia ter sentido o peso da promessa. Primeiro senti alívio."
    $ aa_audio_event('v02', 'line', 7, phase=0)
    v "Fica aqui até a conta. Por favor."
    if aa_matches(aa_state, {'comfort_lie': True}):
        $ aa_audio_event('v02', 'line', 8, phase=0)
        "Ela estava contando com a certeza que eu tinha fingido. Eu ainda não tinha corrigido uma palavra."
    jump k00

label v01:
    $ aa_node = 'v01'
    $ aa_location = '21h43 · Salão'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['v01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1303)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('v01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_hesita'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_hesita_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'bond': 'indefinido'}):
        $ aa_audio_event('v01', 'line', 0, phase=0)
        v "Eu vou embora hoje. Não consigo decidir o resto sentada aqui."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        $ aa_audio_event('v01', 'line', 1, phase=0)
        v "Então terminou. Eu ouvi. Só não fica voltando atrás para eu te acalmar."
    $ aa_audio_event('v01', 'line', 2, phase=0)
    "Ela mandou uma mensagem para a mãe. Pediu que ficasse acordada até ela chegar."
    $ aa_audio_event('v01', 'line', 3, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pagamento com os quatro à mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_pagamento at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_pagamento'
        else:
            $ aa_stage_action = 'Vanessa paga ainda sentada.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_pagamento'
    show screen aa_location_display
    "Chamou o garçom e pagou o que tinha pedido. Eu ofereci pagar. Ela disse que já estava passando o cartão."
    $ aa_audio_event('v01', 'line', 4, phase=0)
    v "Eu vou pedir a matéria pra outra pessoa amanhã. Se eu falar com você cedo, vou acabar fingindo que não aconteceu."
    $ aa_audio_event('v01', 'line', 5, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa de pé no corredor leste, com bolsa e casaco; três continuam sentados.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_vanessa_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_vanessa_saida'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa de pé no corredor leste, com bolsa e casaco; três continuam sentados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_vanessa_saida at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_vanessa_saida'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Levanta com uma bolsa e seu casaco.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_levantar_corrigida at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_levantar_corrigida'
            else:
                $ aa_stage_action = 'Ela leva bolsa e casaco.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_levantar'
    show screen aa_location_display
    "Vanessa pegou o casaco e a bolsa. Ficou um instante segurando o encosto antes de se afastar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('v01', 'line', 6, phase=0)
        "Yasmin e Joãozão continuaram sentados. Vanessa manteve os olhos na saída."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('v01', 'line', 7, phase=0)
        "Ela passou pela outra mesa sem parar."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Deixar ela sair.":
            $ aa_audio_event('v01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'v01', 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Vanessa ausente; Yasmin e Joãozão permanecem.'
                    $ aa_table_party = 3
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg4_pudim_tres at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg4_pudim_tres'
                else:
                    $ aa_stage_action = 'Vanessa saiu fisicamente.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sozinho'
            jump k00
        "Chamar por ela alto, obrigando o salão a olhar.":
            $ aa_audio_event('v01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'v01', 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Vanessa ausente; Yasmin e Joãozão permanecem.'
                    $ aa_table_party = 3
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg4_pudim_tres at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg4_pudim_tres'
                else:
                    $ aa_stage_action = 'Vanessa saiu fisicamente.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sozinho'
            jump k00

label jl00:
    $ aa_node = 'jl00'
    $ aa_location = '21h51 · O pedido'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['jl00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1311)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('jl00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_emprestimo'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_juntas'
        else:
            $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_separadas'
    show screen aa_location_display
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('jl00', 'line', 0, phase=0)
        "Deixei a conta entre os copos. Joãozão olhou o papel, depois olhou para mim."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('jl00', 'line', 1, phase=0)
        "Avisei Vanessa que ia falar com Joãozão. Atravessei até a mesa deles com o celular na mão. Yasmin recolheu o copo para eu não esbarrar."
    $ aa_audio_event('jl00', 'line', 2, phase=0)
    f "Você consegue me fazer um Pix? Só até amanhã."
    $ aa_audio_event('jl00', 'line', 3, phase=0)
    j "De quanto?"
    $ aa_audio_event('jl00', 'line', 4, phase=0)
    f "Faltou um pouco pra fechar a conta."
    $ aa_audio_event('jl00', 'line', 5, phase=0)
    j "Quanto, Feka?"
    $ aa_audio_event('jl00', 'line', 6, phase=0)
    "Eu olhei para Yasmin antes de responder. Ela não respondeu por mim."
    $ aa_audio_event('jl00', 'line', 7, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_emprestimo'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_juntas'
        else:
            $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_separadas'
    show screen aa_location_display
    f "Sessenta."
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('jl00', 'line', 8, phase=0)
        j "Depois dessa confusão, você quer que eu te empreste dinheiro?"
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('jl00', 'line', 9, phase=0)
        f "Eu sei. Não tô pedindo pra você esquecer."
    if aa_matches(aa_state, {'heat': {'lte': 1}}):
        $ aa_audio_event('jl00', 'line', 10, phase=0)
        j "Você tá sem dinheiro pra pagar a conta?"
    if aa_matches(aa_state, {'heat': {'lte': 1}}):
        $ aa_audio_event('jl00', 'line', 11, phase=0)
        f "Pra pagar tudo. Eu achei que dava."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('jl00', 'line', 12, phase=0)
        v "Eu trouxe dinheiro pra minha parte."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('jl00', 'line', 13, phase=0)
        "Vanessa continuava na nossa mesa. Ela tinha oferecido completar a conta. Eu tinha vindo pedir a ele."
    $ aa_audio_event('jl00', 'line', 14, phase=0)
    y "Deixa ele responder, João."
    $ aa_audio_event('jl00', 'line', 15, phase=0)
    "Eu quase agradeci a ela. Ainda queria aproveitar aquele momento para alguma coisa."
    $ aa_audio_event('jl00', 'line', 16, phase=0)
    j "Eu consigo mandar sessenta. Amanhã até meio-dia você devolve. Dá mesmo ou você tá falando amanhã só pra sair daqui?"
    $ aa_audio_event('jl00', 'line', 17, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_emprestimo'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_juntas'
        else:
            $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_separadas'
    show screen aa_location_display
    "Ele desbloqueou o celular e esperou. Não tinha transferido nada. Agora eu precisava responder com um prazo que pudesse cumprir."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Assumir os sessenta reais e combinar amanhã até meio-dia.":
            $ aa_audio_event('jl00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'jl00', 0)
            $ aa_audio_event('jl00', 'response', 0, 0)
            f "Amanhã até meio-dia. Pode mandar."
            $ aa_audio_event('jl00', 'response', 1, 0)
            "Abri minha chave Pix e mostrei. Joãozão conferiu meu nome em voz alta. Esperei ele terminar."
            $ aa_audio_event('jl00', 'response', 2, 0)
            $ aa_finance_event('joao_loan')
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = 'emprestimo_pix'
                $ aa_dialogue_side = False
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_phone_remember('emprestimo_pix')
                show screen aa_phone_view('emprestimo_pix')
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            "Entraram sessenta reais. Joãozão perguntou se tinha chegado. Eu disse que sim."
            $ aa_audio_event('jl00', 'response', 3, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            j "Pronto. Me devolve pelo próprio Pix."
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_audio_event('jl00', 'response', 4, 0)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Guardei o celular. A conta continuava entre nós. Pedi a máquina e paguei."
            if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
                $ aa_audio_event('jl00', 'response', 5, 0)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Voltei para Vanessa. Ela afastou a cadeira para eu sentar. Pedi a máquina e paguei."
            $ aa_audio_event('jl00', 'response', 6, 0)
            v "Você podia ter dividido comigo. Não precisava pedir a ele."
            $ aa_audio_event('jl00', 'response', 7, 0)
            "Eu tinha conseguido pagar por ela. Não consegui olhar para ela quando agradeceu ao garçom."
            jump k01
        "Aceitar, mas pedir que ele não fique cobrando na frente dos outros.":
            $ aa_audio_event('jl00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'jl00', 1)
            $ aa_audio_event('jl00', 'response', 0, 1)
            f "Só não fica me cobrando na frente de todo mundo."
            $ aa_audio_event('jl00', 'response', 1, 1)
            j "Você que veio pedir aqui. Amanhã, se pagar, eu não preciso cobrar."
            $ aa_audio_event('jl00', 'response', 2, 1)
            "Yasmin olhou para o celular dele. Eu fiquei esperando uma defesa que não veio."
            $ aa_audio_event('jl00', 'response', 3, 1)
            f "Amanhã até meio-dia. Pode mandar."
            $ aa_audio_event('jl00', 'response', 4, 1)
            "Abri minha chave Pix e mostrei. Joãozão conferiu meu nome em voz alta. Esperei ele terminar."
            $ aa_audio_event('jl00', 'response', 5, 1)
            $ aa_finance_event('joao_loan')
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = 'emprestimo_pix'
                $ aa_dialogue_side = False
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_phone_remember('emprestimo_pix')
                show screen aa_phone_view('emprestimo_pix')
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            "Entraram sessenta reais. Joãozão perguntou se tinha chegado. Eu disse que sim."
            $ aa_audio_event('jl00', 'response', 6, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            j "Pronto. Me devolve pelo próprio Pix."
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_audio_event('jl00', 'response', 7, 1)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Guardei o celular. A conta continuava entre nós. Pedi a máquina e paguei."
            if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
                $ aa_audio_event('jl00', 'response', 8, 1)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Voltei para Vanessa. Ela afastou a cadeira para eu sentar. Pedi a máquina e paguei."
            $ aa_audio_event('jl00', 'response', 9, 1)
            v "Você podia ter dividido comigo. Não precisava pedir a ele."
            $ aa_audio_event('jl00', 'response', 10, 1)
            "Eu tinha conseguido pagar por ela. Não consegui olhar para ela quando agradeceu ao garçom."
            jump k01
        "Desistir do empréstimo e dividir a conta com Vanessa.":
            $ aa_audio_event('jl00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'jl00', 2)
            $ aa_audio_event('jl00', 'response', 0, 2)
            f "Deixa. Eu vou dividir com ela."
            $ aa_audio_event('jl00', 'response', 1, 2)
            j "Tá."
            if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
                $ aa_audio_event('jl00', 'response', 2, 2)
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Voltei à minha cadeira antes de chamar o garçom."
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_audio_event('jl00', 'response', 3, 2)
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Afastei a conta para o garçom conseguir pegar."
            jump k01

label cr00:
    $ aa_node = 'cr00'
    $ aa_location = '22h10 · Entrada do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['cr00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('cr00')
    $ aa_location = '22h10 · Entrada do restaurante'
    $ aa_stage_action = 'Esperam o carro sob a cobertura.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('cr00', 'line', 0, phase=0)
    f "Eu não vou sumir. Amanhã eu saio da aula e vou direto pra mudança."
    $ aa_audio_event('cr00', 'line', 1, phase=0)
    v "Me manda quando acordar. Pra eu saber que você não mudou de ideia."
    $ aa_audio_event('cr00', 'line', 2, phase=0)
    "Ela guardou o telefone. Ficamos sob a cobertura, ouvindo os pneus passarem na água."
    $ aa_audio_event('cr00', 'line', 3, phase=0)
    $ aa_location = '22h10 · Entrada do restaurante'
    $ aa_stage_action = 'Esperam o carro sob a cobertura.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    v "Você pode me abraçar um pouco?"
    $ aa_audio_event('cr00', 'line', 4, phase=0)
    "Vanessa deu meio passo e esperou. Eu tirei as mãos dos bolsos."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Abraçá-la e ficar ali, sem apressar a despedida.":
            $ aa_audio_event('cr00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'cr00', 0)
            $ aa_audio_event('cr00', 'response', 0, 0)
            $ aa_stage_action = 'Vanessa pede um abraço; Feka corresponde e os dois permanecem abraçados.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg10_abraco_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg10_abraco_espera'
            "Ela passou os braços pela minha cintura. Abracei de volta. Ficamos assim enquanto o telefone vibrava dentro da bolsa."
            $ aa_audio_event('cr00', 'response', 1, 0)
            v "Só mais um pouco."
            $ aa_audio_event('cr00', 'response', 2, 0)
            f "Tá."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('cr00', 'response', 3, 0)
                "Eu tinha passado a última hora repetindo o que ela queria ouvir. Agora ela se agarrava a mim, e eu ainda não sabia sustentar aquilo fora daquele abraço."
            if aa_matches(aa_state, {'comfort_lie': False}):
                $ aa_audio_event('cr00', 'response', 4, 0)
                "Ela não voltou atrás no que tinha dito à mesa. Eu não pedi que voltasse."
            $ aa_audio_event('cr00', 'response', 5, 0)
            "Esperei que ela afrouxasse os braços antes de me afastar. Vanessa pegou o celular para conferir a placa."
            jump cr01
        "Dizer que prefiro esperar ao lado dela, sem abraçar.":
            $ aa_audio_event('cr00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'cr00', 1)
            $ aa_audio_event('cr00', 'response', 0, 1)
            f "Eu fico aqui com você. Mas agora eu prefiro não abraçar."
            $ aa_audio_event('cr00', 'response', 1, 1)
            "Ela recolheu as mãos e segurou a alça da bolsa."
            $ aa_audio_event('cr00', 'response', 2, 1)
            v "Tá. Só não vai embora sem falar."
            $ aa_audio_event('cr00', 'response', 3, 1)
            f "Eu vou esperar."
            jump cr01

label cr01:
    $ aa_node = 'cr01'
    $ aa_location = '22h12 · No carro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['cr01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1332)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('cr01')
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'Os dois no banco traseiro, ainda separados.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    $ aa_audio_event('cr01', 'line', 0, phase=0)
    "O carro parou. Vanessa perguntou se eu ia com ela até em casa. Eu disse que sim. Conferimos a placa, entramos e colocamos os cintos."
    $ aa_audio_event('cr01', 'line', 1, phase=0)
    "No carro, ela virou o rosto para mim. Eu olhava a rua. A bolsa ficou apertada no colo dela."
    $ aa_audio_event('cr01', 'line', 2, phase=0)
    v "Você ainda tá pensando nela?"
    $ aa_audio_event('cr01', 'line', 3, phase=0)
    "Demorei. Vanessa disse que não precisava responder naquele momento."
    if aa_matches(aa_state, {'truth': True}):
        $ aa_audio_event('cr01', 'line', 4, phase=0)
        "Eu tinha contado por que começara a namorar. Mesmo assim ela tinha aberto espaço no carro."
    if aa_matches(aa_state, {'truth': False}):
        $ aa_audio_event('cr01', 'line', 5, phase=0)
        "Ela não sabia que eu tinha dito aquilo só para fazê-la parar de perguntar. Eu deixei que continuasse comigo sem saber."
    $ aa_audio_event('cr01', 'line', 6, phase=0)
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'Os dois no banco traseiro, ainda separados.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    v "Posso encostar em você?"
    $ aa_audio_event('cr01', 'line', 7, phase=0)
    "Ela manteve a bolsa no colo. Eu ainda tinha espaço para dizer que não."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que sim e oferecer o ombro.":
            $ aa_audio_event('cr01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'cr01', 0)
            $ aa_audio_event('cr01', 'response', 0, 0)
            f "Pode."
            $ aa_audio_event('cr01', 'response', 1, 0)
            "Antes de o motorista arrancar, ela passou para o assento do meio e prendeu o cinto de novo. Tirei meu braço do caminho."
            $ aa_audio_event('cr01', 'response', 2, 0)
            $ aa_stage_action = 'Vanessa no assento central, encostada no ombro de Feka; ambos de cinto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg10_carro_ombro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg10_carro_ombro'
            "Vanessa apoiou a cabeça no meu ombro. Deixei minha mão junto da dela. O carro saiu devagar."
            $ aa_audio_event('cr01', 'response', 3, 0)
            v "Eu tava precisando disso."
            $ aa_audio_event('cr01', 'response', 4, 0)
            "Ficamos assim por algumas ruas. Quando ela apertou minha mão, apertei de volta."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('cr01', 'response', 5, 0)
                "Ser abraçado era bom. Eu queria que bastasse para tornar verdade o que tinha dito."
            if aa_matches(aa_state, {'comfort_lie': False, 'truth': False}):
                $ aa_audio_event('cr01', 'response', 6, 0)
                "Eu gostava de ter ela perto. Por alguns instantes, quis acreditar que aquilo respondia à pergunta sobre Yasmin."
            if aa_matches(aa_state, {'comfort_lie': False, 'truth': True}):
                $ aa_audio_event('cr01', 'response', 7, 0)
                "Eu tinha contado a verdade à mesa. Ainda não sabia o que dizer sobre continuar pensando em Yasmin. Fiquei com a mão junto da dela."
            $ aa_audio_event('cr01', 'response', 8, 0)
            v "Vou deixar o celular com som de manhã."
            $ aa_audio_event('cr01', 'response', 9, 0)
            f "Mando quando acordar."
            $ aa_audio_event('cr01', 'response', 10, 0)
            "Perto da rua dela, o motorista perguntou em qual portão devia parar. Vanessa indicou a casa."
            $ aa_audio_event('cr01', 'response', 11, 0)
            v "Hoje é só até aqui, tá? Amanhã a gente se vê."
            $ aa_audio_event('cr01', 'response', 12, 0)
            f "Tá."
            $ aa_audio_event('cr01', 'response', 13, 0)
            $ aa_finance_event('return_home')
            "[aa_financial_line('return_home')]"
            jump e03
        "Pedir que fiquem cada um no seu lugar por enquanto.":
            $ aa_audio_event('cr01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'cr01', 1)
            $ aa_audio_event('cr01', 'response', 0, 1)
            f "Prefiro ficar assim por enquanto. Não é pra você descer. Eu vou com você."
            $ aa_audio_event('cr01', 'response', 1, 1)
            v "Tá. Eu perguntei porque queria. Não precisa ficar com pena."
            $ aa_audio_event('cr01', 'response', 2, 1)
            "O motorista arrancou. Eu fiquei ao lado dela, sem fingir que a distância não tinha feito diferença."
            $ aa_audio_event('cr01', 'response', 3, 1)
            "Perto da rua dela, o motorista perguntou em qual portão devia parar. Vanessa indicou a casa."
            $ aa_audio_event('cr01', 'response', 4, 1)
            v "Hoje é só até aqui, tá? Amanhã a gente se vê."
            $ aa_audio_event('cr01', 'response', 5, 1)
            f "Tá."
            $ aa_audio_event('cr01', 'response', 6, 1)
            $ aa_finance_event('return_home')
            "[aa_financial_line('return_home')]"
            jump e03

label h00:
    $ aa_node = 'h00'
    $ aa_location = '21h22 · Mesa junto ao vidro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h00'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1282)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h00')
    $ aa_location = '21h22 · Mesa junto ao vidro'
    $ aa_stage_action = 'Feka olha apenas para Vanessa; pudim entre os dois.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_mesa_escolha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_mesa_escolha'
    show screen aa_location_display
    $ aa_audio_event('h00', 'line', 0, phase=0)
    f "Eu não sabia que ela estaria aqui. A indicação foi dela. Mas eu escolhi este lugar pensando em você."
    $ aa_audio_event('h00', 'line', 1, phase=0)
    $ aa_location = '21h22 · Mesa junto ao vidro'
    $ aa_stage_action = 'Feka olha apenas para Vanessa; pudim entre os dois.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_mesa_escolha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_mesa_escolha'
    show screen aa_location_display
    "Eu tinha guardado o nome do restaurante por causa de Yasmin. Não contei essa parte."
    $ aa_audio_event('h00', 'line', 2, phase=0)
    v "Você consegue falar isso olhando pra mim?"
    $ aa_audio_event('h00', 'line', 3, phase=0)
    "Olhei para ela. Vanessa continuava apertando o guardanapo."
    $ aa_audio_event('h00', 'line', 4, phase=0)
    f "Consigo. Eu quero estar aqui com você."
    $ aa_audio_event('h00', 'line', 5, phase=0)
    v "Eu quero acreditar. Só não quero passar o resto da noite perguntando."
    $ aa_audio_event('h00', 'line', 6, phase=0)
    "Ela soltou o guardanapo, mas ainda não pegou a colher. Esperei."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Retomar o combinado da mudança e ficar conversando com ela.":
            $ aa_audio_event('h00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h00', 0)
            $ aa_audio_event('h00', 'response', 0, 0)
            f "Amanhã eu saio da aula e vou te ajudar com as caixas."
            $ aa_audio_event('h00', 'response', 1, 0)
            v "Tá. Me avisa antes de sair? Eu fico esperando."
            $ aa_audio_event('h00', 'response', 2, 0)
            f "Aviso. Você me manda o endereço."
            $ aa_audio_event('h00', 'response', 3, 0)
            "Vanessa respirou fundo e puxou o pudim de volta para o meio da mesa."
            jump h01
        "Prometer que Yasmin nunca mais vai importar." if aa_matches(aa_state, {'chosen_vanessa': False}):
            $ aa_audio_event('h00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h00', 1)
            $ aa_audio_event('h00', 'response', 0, 1)
            f "Ela não vai importar mais. Nunca."
            $ aa_audio_event('h00', 'response', 1, 1)
            v "Você tava olhando pra ela agora há pouco. Como é que eu vou acreditar nesse nunca?"
            $ aa_audio_event('h00', 'response', 2, 1)
            "Abri a boca para repetir. Parei quando vi a cara dela."
            jump v00
        "Pedir que Vanessa aceite a resposta sem perguntar mais.":
            $ aa_audio_event('h00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'h00', 2)
            $ aa_audio_event('h00', 'response', 0, 2)
            f "Eu já respondi. Você precisa confiar em mim."
            $ aa_audio_event('h00', 'response', 1, 2)
            v "Eu estava tentando."
            jump r02

label h01:
    $ aa_node = 'h01'
    $ aa_location = '21h35 · Mesa junto ao vidro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h01'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1295)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h01')
    $ aa_location = '21h35 · Mesa junto ao vidro'
    $ aa_stage_action = 'Os dois dividem o pudim e retomam uma conversa pequena.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_pudim_compartilhado at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_pudim_compartilhado'
    show screen aa_location_display
    $ aa_audio_event('h01', 'line', 0, phase=0)
    "Vanessa pegou uma das colheres. Eu esperei ela provar antes de pegar a outra."
    $ aa_audio_event('h01', 'line', 1, phase=0)
    v "A toalha atrás da sua porta era a de banho."
    $ aa_audio_event('h01', 'line', 2, phase=0)
    f "Eu sei."
    $ aa_audio_event('h01', 'line', 3, phase=0)
    v "Você sabia quando me respondeu?"
    $ aa_audio_event('h01', 'line', 4, phase=0)
    f "Sabia."
    $ aa_audio_event('h01', 'line', 5, phase=0)
    $ aa_location = '21h35 · Mesa junto ao vidro'
    $ aa_stage_action = 'Os dois dividem o pudim e retomam uma conversa pequena.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_pudim_compartilhado at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_pudim_compartilhado'
    show screen aa_location_display
    "Ela riu pelo nariz. Eu ri também. Vanessa cortou outro pedaço do pudim e empurrou o prato um pouco para mim."
    $ aa_audio_event('h01', 'line', 6, phase=0)
    v "Da próxima vez eu levo uma toalha na bolsa."
    $ aa_audio_event('h01', 'line', 7, phase=0)
    f "Eu tenho outra. Só preciso lembrar de lavar."
    $ aa_audio_event('h01', 'line', 8, phase=0)
    "Ela balançou a cabeça, sorrindo. Terminamos a sobremesa conversando sobre a bagunça do meu quarto."
    jump k00

label h02:
    $ aa_node = 'h02'
    $ aa_location = '22h02 · Entrada do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h02'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1322)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h02')
    $ aa_location = '22h02 · Entrada do restaurante'
    $ aa_stage_action = 'Sob a cobertura, Feka convida Vanessa para voltar com ele.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_convite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_convite'
    show screen aa_location_display
    $ aa_audio_event('h02', 'line', 0, phase=0)
    "Na entrada, Vanessa vestiu o casaco. Eu abri o aplicativo antes que ela precisasse pedir que eu esperasse."
    $ aa_audio_event('h02', 'line', 1, phase=0)
    f "Quer voltar comigo? Para a moradia."
    $ aa_audio_event('h02', 'line', 2, phase=0)
    v "Você quer mesmo que eu vá?"
    $ aa_audio_event('h02', 'line', 3, phase=0)
    f "Eu quero que você vá. A gente dorme, toma café e vai pra faculdade junto."
    $ aa_audio_event('h02', 'line', 4, phase=0)
    $ aa_location = '22h02 · Entrada do restaurante'
    $ aa_stage_action = 'Sob a cobertura, Feka convida Vanessa para voltar com ele.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_convite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_convite'
    show screen aa_location_display
    "Vanessa segurou a manga do meu casaco. Ainda não tinha guardado o celular."
    $ aa_audio_event('h02', 'line', 5, phase=0)
    v "E depois da aula você vai comigo pro apartamento."
    $ aa_audio_event('h02', 'line', 6, phase=0)
    f "Vou."
    $ aa_audio_event('h02', 'line', 7, phase=0)
    "Ela olhou o aplicativo aberto na minha mão e esperou eu confirmar o destino. A corrida até a moradia estava em dezoito reais."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar o convite e chamar o carro para os dois.":
            $ aa_audio_event('h02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h02', 0)
            $ aa_audio_event('h02', 'response', 0, 0)
            f "Eu quero você lá."
            $ aa_audio_event('h02', 'response', 1, 0)
            v "Tá. Então eu vou."
            $ aa_audio_event('h02', 'response', 2, 0)
            "Chamei um carro para a moradia. Vanessa avisou a mãe que dormiria comigo. Depois guardou o telefone e ficou ao meu lado sob a cobertura."
            jump h03
        "Recuar e dizer que talvez seja melhor cada um ir para casa.":
            $ aa_audio_event('h02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h02', 1)
            $ aa_audio_event('h02', 'response', 0, 1)
            f "Talvez seja melhor você ir pra casa. Eu não quero confundir mais."
            $ aa_audio_event('h02', 'response', 1, 1)
            v "Você já convidou. Mas tá. Eu chamo o meu."
            jump s00

label h03:
    $ aa_node = 'h03'
    $ aa_location = '22h12 · No carro'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h03'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1332)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h03')
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'No carro parado, conversam antes da escolha de contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    $ aa_audio_event('h03', 'line', 0, phase=0)
    "Conferimos a placa e entramos. Cada um sentou junto de uma janela. Colocamos os cintos; Vanessa manteve a bolsa no colo."
    $ aa_audio_event('h03', 'line', 1, phase=0)
    v "Eu achei que ia voltar sozinha hoje."
    $ aa_audio_event('h03', 'line', 2, phase=0)
    f "Eu tô gostando de você vir comigo."
    $ aa_audio_event('h03', 'line', 3, phase=0)
    v "Eu também. Só vou precisar sair cedo pra aula."
    $ aa_audio_event('h03', 'line', 4, phase=0)
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'No carro parado, conversam antes da escolha de contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    "Confirmei o endereço da moradia com o motorista. Ele ainda estava acertando o trajeto no aplicativo."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Oferecer o ombro e deixar a mão junto da dela.":
            $ aa_audio_event('h03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h03', 0)
            $ aa_audio_event('h03', 'response', 0, 0)
            f "Pode encostar, se quiser."
            $ aa_audio_event('h03', 'response', 1, 0)
            $ aa_stage_action = 'Contato escolhido; os dois de cinto, bolsa no colo de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg13_carro_feliz at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg13_carro_feliz'
            "Com o carro ainda parado, Vanessa passou para o assento do meio e prendeu o cinto outra vez. Apoiou a cabeça no meu ombro e segurou minha mão sobre a bolsa. O motorista saiu devagar."
            $ aa_audio_event('h03', 'response', 2, 0)
            v "Assim tá bom."
            jump h04
        "Viajar ao lado dela e conversar até chegar.":
            $ aa_audio_event('h03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h03', 1)
            $ aa_audio_event('h03', 'response', 0, 1)
            "O motorista saiu devagar. Vanessa contou que tinha etiquetado três caixas como “cozinha” e esquecido qual delas guardava os pratos."
            $ aa_audio_event('h03', 'response', 1, 1)
            f "A gente abre as três."
            $ aa_audio_event('h03', 'response', 2, 1)
            v "Eu espero que não estejam no fundo da última."
            jump h04

label h04:
    $ aa_node = 'h04'
    $ aa_location = '22h31 · Moradia universitária'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h04'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1351)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_finance_event('ride_home')
    $ aa_audio_enter('h04')
    $ aa_location = '22h31 · Moradia universitária'
    $ aa_stage_action = 'Os dois retornam ao mesmo quarto; casacos molhados na cadeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_quarto_chegada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_quarto_chegada'
    show screen aa_location_display
    $ aa_audio_event('h04', 'line', 0, phase=0)
    "Chegamos à moradia e atravessamos a sala. Alguém ria atrás de uma das portas. Na cozinha, a panela continuava na pia."
    $ aa_audio_event('h04', 'line', 1, phase=0)
    $ aa_location = '22h31 · Moradia universitária'
    $ aa_stage_action = 'Os dois retornam ao mesmo quarto; casacos molhados na cadeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_quarto_chegada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_quarto_chegada'
    show screen aa_location_display
    "No quarto, Vanessa deixou a bolsa na mesma ponta da cama onde tinha começado a noite. Pendurei os dois casacos na cadeira."
    $ aa_audio_event('h04', 'line', 2, phase=0)
    v "Eu trouxe escova de dente. Não trouxe roupa pra dormir."
    $ aa_audio_event('h04', 'line', 3, phase=0)
    f "Tenho uma camiseta limpa."
    $ aa_audio_event('h04', 'line', 4, phase=0)
    v "Limpa de verdade?"
    $ aa_audio_event('h04', 'line', 5, phase=0)
    f "Ainda na gaveta."
    $ aa_audio_event('h04', 'line', 6, phase=0)
    "Separei uma toalha limpa e entreguei junto com a camiseta. Enquanto ela se trocava no banheiro, tirei a roupa do jantar e vesti uma camiseta."
    $ aa_audio_event('h04', 'line', 7, phase=0)
    "Ela voltou com a roupa dobrada e guardou na bolsa. Depois foi a minha vez de usar o banheiro."
    jump h05

label h05:
    $ aa_node = 'h05'
    $ aa_location = '23h05 · Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h05'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1385)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h05')
    $ aa_location = '23h05 · Quarto de Feka'
    $ aa_stage_action = 'Sentados na cama, conversam antes de dormir.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cama_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cama_conversa'
    show screen aa_location_display
    $ aa_audio_event('h05', 'line', 0, phase=0)
    "Sentamos na cama. Vanessa puxou o cobertor para perto e olhou a hora no celular."
    $ aa_audio_event('h05', 'line', 1, phase=0)
    v "Põe o alarme pras sete e cinco? O meu tá quase sem bateria."
    $ aa_audio_event('h05', 'line', 2, phase=0)
    f "Ponho. Pode usar meu carregador também."
    $ aa_audio_event('h05', 'line', 3, phase=0)
    v "E não desliga pra dormir de novo."
    $ aa_audio_event('h05', 'line', 4, phase=0)
    f "Se eu fizer isso, pode me acordar."
    $ aa_audio_event('h05', 'line', 5, phase=0)
    $ aa_location = '23h05 · Quarto de Feka'
    $ aa_stage_action = 'Sentados na cama, conversam antes de dormir.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cama_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cama_conversa'
    show screen aa_location_display
    "Acertei o alarme e liguei o telefone dela no carregador. Vanessa levou a mão aos óculos, mas parou antes de tirar."
    $ aa_audio_event('h05', 'line', 6, phase=0)
    v "Posso dormir perto?"
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Abraçá-la e perguntar se está confortável.":
            $ aa_audio_event('h05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h05', 0)
            $ aa_audio_event('h05', 'response', 0, 0)
            f "Pode. Assim tá confortável?"
            $ aa_audio_event('h05', 'response', 1, 0)
            v "Tá."
            $ aa_audio_event('h05', 'response', 2, 0)
            $ aa_stage_action = 'A luz se apaga; elipse para a manhã.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene black at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'black'
            "Ela deixou os óculos no criado-mudo. Deitamos, e Vanessa se acomodou perto do meu peito. Ajustei o cobertor sobre os dois e apaguei a luz."
            jump h06
        "Dividir o cobertor e deixar que ela escolha a distância.":
            $ aa_audio_event('h05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h05', 1)
            $ aa_audio_event('h05', 'response', 0, 1)
            f "Pode chegar quando quiser."
            $ aa_audio_event('h05', 'response', 1, 1)
            $ aa_stage_action = 'A luz se apaga; aproximação no escuro, sem pressupor abraço.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene black at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'black'
            "Ela guardou os óculos e deitou. Dividi o cobertor e apaguei a luz. Alguns minutos depois, a mão dela encontrou a minha no escuro."
            jump h06

label h06:
    $ aa_node = 'h06'
    $ aa_location = '07h05 · Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h06'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1865)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h06')
    $ aa_location = '07h05 · Quarto de Feka'
    $ aa_stage_action = 'Manhã clara; os dois acordam no mesmo quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_acordar_juntos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_acordar_juntos'
    show screen aa_location_display
    $ aa_audio_event('h06', 'line', 0, phase=0)
    $ aa_location = '07h05 · Quarto de Feka'
    $ aa_stage_action = 'Manhã clara; os dois acordam no mesmo quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_acordar_juntos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_acordar_juntos'
    show screen aa_location_display
    "O alarme tocou com o quarto já claro. Vanessa dormia ao meu lado, segurando a barra da minha camiseta."
    $ aa_audio_event('h06', 'line', 1, phase=0)
    "Ela abriu os olhos quando tentei alcançar o celular."
    $ aa_audio_event('h06', 'line', 2, phase=0)
    v "Já tá na hora?"
    $ aa_audio_event('h06', 'line', 3, phase=0)
    f "Tá. Vou pôr mais dois minutos."
    $ aa_audio_event('h06', 'line', 4, phase=0)
    "Mostrei a hora. Ela soltou a camiseta e escondeu o rosto no travesseiro."
    $ aa_audio_event('h06', 'line', 5, phase=0)
    v "Só dois?"
    $ aa_audio_event('h06', 'line', 6, phase=0)
    f "Dois. Você mesma falou pra gente não se atrasar."
    $ aa_audio_event('h06', 'line', 7, phase=0)
    "Ela riu sem tirar o rosto do travesseiro. Fiquei deitado ao lado dela até o alarme tocar outra vez."
    $ aa_present = ()
    $ aa_audio_event('h06', 'line', 8, phase=0)
    "Vanessa levou a roupa dobrada para o banheiro. Enquanto ela se trocava, fui colocar a água do café."
    jump h07

label h07:
    $ aa_node = 'h07'
    $ aa_location = '07h25 · Cozinha compartilhada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h07'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1885)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h07')
    $ aa_location = '07h25 · Cozinha compartilhada'
    $ aa_stage_action = 'Café simples na cozinha compartilhada; panela agora limpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cafe_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cafe_cozinha'
    show screen aa_location_display
    $ aa_audio_event('h07', 'line', 0, phase=0)
    "Enquanto a água esquentava, lavei a panela da pia. Vanessa fez duas torradas e sentou. Procurei minha caneca em dois armários."
    $ aa_audio_event('h07', 'line', 1, phase=0)
    v "É aquela atrás de você?"
    $ aa_audio_event('h07', 'line', 2, phase=0)
    $ aa_location = '07h25 · Cozinha compartilhada'
    $ aa_stage_action = 'Café simples na cozinha compartilhada; panela agora limpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cafe_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cafe_cozinha'
    show screen aa_location_display
    f "É. Passei por ela duas vezes."
    $ aa_audio_event('h07', 'line', 3, phase=0)
    "Ela riu e puxou minha torrada para longe da beirada. Servi o café nas duas canecas."
    $ aa_audio_event('h07', 'line', 4, phase=0)
    v "Minha mãe vai receber o frete de manhã. Disse que deixa comida pra gente também."
    $ aa_audio_event('h07', 'line', 5, phase=0)
    f "Então a gente come lá depois de abrir as caixas."
    $ aa_audio_event('h07', 'line', 6, phase=0)
    v "Tá. Vou avisar que você vai comer comigo."
    $ aa_audio_event('h07', 'line', 7, phase=0)
    $ aa_phone_remember('almoco_mudanca')
    "Vanessa escreveu a mensagem e me mostrou antes de mandar. Confirmei. Ela enviou e pegou a torrada."
    jump h08

label h08:
    $ aa_node = 'h08'
    $ aa_location = '07h55 · Saída da moradia'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h08'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1915)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h08')
    $ aa_location = '07h55 · Saída da moradia'
    $ aa_stage_action = 'Saem juntos com cadernos e um guarda-chuva.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_faculdade at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_faculdade'
    show screen aa_location_display
    $ aa_audio_event('h08', 'line', 0, phase=0)
    "Antes de sair, Vanessa deixou a camiseta emprestada no cesto. Pegamos os cadernos, as bolsas e o guarda-chuva."
    $ aa_audio_event('h08', 'line', 1, phase=0)
    $ aa_location = '07h55 · Saída da moradia'
    $ aa_stage_action = 'Saem juntos com cadernos e um guarda-chuva.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_faculdade at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_faculdade'
    show screen aa_location_display
    $ aa_phone_remember('endereco')
    "A chuva tinha parado. Caminhamos até a faculdade. Ela me mostrou no celular o endereço do apartamento e o ônibus que saía de lá."
    $ aa_audio_event('h08', 'line', 2, phase=0)
    v "A gente pega esse depois da aula. Para a uma quadra."
    $ aa_audio_event('h08', 'line', 3, phase=0)
    f "Você já foi por esse caminho?"
    $ aa_audio_event('h08', 'line', 4, phase=0)
    v "Na visita. Minha mãe quase passou do ponto."
    $ aa_audio_event('h08', 'line', 5, phase=0)
    f "Então você me avisa onde descer."
    $ aa_audio_event('h08', 'line', 6, phase=0)
    "Ela segurou meu braço para atravessarmos a rua. Entramos na sala antes do professor e sentamos juntos."
    jump h09

label h09:
    $ aa_node = 'h09'
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h09'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2400)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_finance_event('bus_campus')
    $ aa_audio_enter('h09')
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chegam juntos ao apartamento; a última caixa está no corredor.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_chegada_mudanca'
    show screen aa_location_display
    $ aa_audio_event('h09', 'line', 0, phase=0)
    "Depois da aula, pegamos o ônibus e caminhamos da parada até o prédio. A mãe de Vanessa já tinha ido embora. Buscamos a chave na portaria e subimos."
    $ aa_audio_event('h09', 'line', 1, phase=0)
    v "Minha mãe disse que ficou uma caixa no corredor. O resto já tá lá dentro."
    $ aa_audio_event('h09', 'line', 2, phase=0)
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chegam juntos ao apartamento; a última caixa está no corredor.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_chegada_mudanca'
    show screen aa_location_display
    "Vanessa abriu a porta. Peguei a caixa antes que ela pedisse."
    $ aa_audio_event('h09', 'line', 3, phase=0)
    v "Essa vai perto da janela. Espera, eu tiro a cadeira."
    $ aa_audio_event('h09', 'line', 4, phase=0)
    f "Tá. Cuidado com a bolsa no chão."
    $ aa_audio_event('h09', 'line', 5, phase=0)
    "Levei a caixa para dentro. Vanessa afastou a cadeira, fechou a porta e olhou a sala cheia de coisas."
    $ aa_audio_event('h09', 'line', 6, phase=0)
    v "Agora é meu."
    $ aa_audio_event('h09', 'line', 7, phase=0)
    f "Agora é seu."
    jump h10

label h10:
    $ aa_node = 'h10'
    $ aa_location = 'Depois da aula · Apartamento de Vanessa · Mudança'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['h10'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2400)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h10')
    $ aa_location = 'Depois da aula · Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Trabalham lado a lado entre caixas abertas e louça.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_trabalho_mudanca'
    show screen aa_location_display
    $ aa_audio_event('h10', 'line', 0, phase=0)
    "Tirei o casaco. Vanessa vestiu uma blusa de manga comprida que achou na mala. Abrimos as caixas da cozinha até encontrar os pratos."
    $ aa_audio_event('h10', 'line', 1, phase=0)
    $ aa_location = 'Depois da aula · Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Trabalham lado a lado entre caixas abertas e louça.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_trabalho_mudanca'
    show screen aa_location_display
    "Eu desembrulhei os copos; ela escolheu a prateleira. Depois empurramos a mesa alguns centímetros para liberar a passagem."
    $ aa_audio_event('h10', 'line', 2, phase=0)
    v "Você acha que cabe uma cadeira do outro lado?"
    $ aa_audio_event('h10', 'line', 3, phase=0)
    f "Se a mesa ficar assim, cabe."
    $ aa_audio_event('h10', 'line', 4, phase=0)
    v "Então deixa assim."
    $ aa_audio_event('h10', 'line', 5, phase=0)
    "Colocamos as duas cadeiras no lugar. Passei entre a mesa e a parede para conferir. Vanessa veio atrás, segurando os pratos."
    $ aa_audio_event('h10', 'line', 6, phase=0)
    v "Vou esquentar a comida. Você pega os talheres naquela caixa?"
    $ aa_audio_event('h10', 'line', 7, phase=0)
    f "Pego. Tem pano pra limpar a mesa?"
    jump e11

label e11:
    $ aa_node = 'e11'
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e11'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2460)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('e11')
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Refeição simples entre caixas; duas cadeiras e dois pratos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_refeicao_feliz at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_refeicao_feliz'
    show screen aa_location_display
    $ aa_audio_event('e11', 'line', 0, phase=0)
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Refeição simples entre caixas; duas cadeiras e dois pratos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_refeicao_feliz at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_refeicao_feliz'
    show screen aa_location_display
    "Limpamos a mesa e sentamos para comer. Vanessa contou o que queria comprar primeiro. Eu estava com fome e pedi que passasse a travessa."
    $ aa_audio_event('e11', 'line', 1, phase=0)
    "Ela serviu mais um pouco para mim e ficou com o que restava. Disse que a mãe sempre fazia comida demais. Dessa vez tinha dado certo."
    $ aa_audio_event('e11', 'line', 2, phase=0)
    "Meu celular continuava no bolso. Ainda faltava montar uma prateleira; perguntei onde ela tinha guardado as ferramentas."
    $ aa_audio_event('e11', 'line', 3, phase=0)
    v "Você volta amanhã?"
    $ aa_audio_event('e11', 'line', 4, phase=0)
    f "Depois da aula."
    $ aa_audio_event('e11', 'line', 5, phase=0)
    v "Tá. Eu faço café."
    $ aa_audio_event('e11', 'line', 6, phase=0)
    "Vanessa sorriu e continuou comendo. Encostei meu pé no dela por baixo da mesa. Ela deixou o pé ali."
    jump w_louca

label d00:
    $ aa_node = 'd00'
    $ aa_location = '22h06 · Perto da recepção'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d00'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1326)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d00')
    $ aa_stage_action = 'O pedido para sair'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    $ aa_audio_event('d00', 'line', 0, phase=0)
    $ aa_stage_action = 'O pedido para sair'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    "O funcionário ficou ao meu lado. Yasmin pegou a bolsa e foi em direção à saída. Joãozão acompanhou, sem tirar os olhos de mim."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d00', 'line', 1, phase=0)
        "Vanessa parou junto à recepção. Segurava o casaco e o celular."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d00', 'line', 2, phase=0)
        $ aa_stage_action = 'O pedido para sair'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_recepcao'
        show screen aa_location_display
        "Vanessa já tinha ido embora. Eu não tinha ninguém ali que ainda esperasse alguma coisa de mim."
    $ aa_audio_event('d00', 'line', 3, phase=0)
    f "Agora você vai fingir que nem me conhece?"
    $ aa_audio_event('d00', 'line', 4, phase=0)
    y "Eu te conheço. Por isso eu tô pedindo pra você me deixar ir."
    $ aa_audio_event('d00', 'line', 5, phase=0)
    f "Depois de tudo que eu fiz por você."
    $ aa_audio_event('d00', 'line', 6, phase=0)
    y "Eu não te pedi pra me esperar na saída da escola. Pedi pra parar."
    if aa_matches(aa_state, {'past_read': True}):
        $ aa_audio_event('d00', 'line', 7, phase=0)
        "Eu lembrava daquela mensagem. Mesmo assim, procurei no rosto dela alguma hesitação."
    $ aa_audio_event('d00', 'line', 8, phase=0)
    y "E agora você tá fazendo de novo. Eu digo que não quero, você continua."
    $ aa_audio_event('d00', 'line', 9, phase=0)
    j "Acabou, Feka. Sai da frente."
    $ aa_audio_event('d00', 'line', 10, phase=0)
    f "Você gosta de assistir, né? De me ver assim."
    $ aa_audio_event('d00', 'line', 11, phase=0)
    y "Eu quero ir embora."
    $ aa_audio_event('d00', 'line', 12, phase=0)
    "O funcionário apontou a porta e pediu que eu deixasse a passagem livre. Eu podia sair por ela também."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Deixar a passagem livre e sair.":
            $ aa_audio_event('d00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd00', 0)
            jump e07
        "Passar na frente de Yasmin e exigir que ela me escute.":
            $ aa_audio_event('d00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd00', 1)
            jump d01

label d01:
    $ aa_node = 'd01'
    $ aa_location = '22h07 · Recepção'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d01'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1327)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d01')
    $ aa_stage_action = 'A passagem'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    $ aa_audio_event('d01', 'line', 0, phase=0)
    $ aa_stage_action = 'A passagem'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    "Dei dois passos e parei entre Yasmin e a porta. Ela parou também. O funcionário veio atrás de mim."
    $ aa_audio_event('d01', 'line', 1, phase=0)
    y "Sai da frente."
    $ aa_audio_event('d01', 'line', 2, phase=0)
    $ aa_stage_action = 'A passagem'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    f "Um minuto. Você não consegue me dar um minuto?"
    $ aa_audio_event('d01', 'line', 3, phase=0)
    y "Não. Eu não quero conversar com você."
    $ aa_audio_event('d01', 'line', 4, phase=0)
    j "Você tá impedindo ela de sair."
    $ aa_audio_event('d01', 'line', 5, phase=0)
    f "Eu só quero me despedir."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d01', 'line', 6, phase=0)
        v "Feka. Deixa ela passar. Vem pra cá."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d01', 'line', 7, phase=0)
        "Vanessa falava baixo, como se ainda pudesse fazer aquilo caber numa conversa nossa."
    $ aa_audio_event('d01', 'line', 8, phase=0)
    "Yasmin tentou passar pelo meu lado. Eu virei junto. Ela levantou a mão aberta, antes que eu chegasse perto."
    $ aa_audio_event('d01', 'line', 9, phase=0)
    y "Não encosta em mim."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Recuar e deixar Yasmin passar.":
            $ aa_audio_event('d01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd01', 0)
            jump d_stop
        "Tentar abraçá-la mesmo depois da recusa.":
            $ aa_audio_event('d01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd01', 1)
            jump d02

label d02:
    $ aa_node = 'd02'
    $ aa_location = '22h08 · Recepção'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d02'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1328)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d02')
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    $ aa_audio_event('d02', 'line', 0, phase=0)
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    "Abri os braços. Yasmin se afastou. Minha mão pegou no braço dela antes que eu conseguisse encostar o resto do corpo."
    $ aa_audio_event('d02', 'line', 1, phase=0)
    y "Me solta."
    $ aa_audio_event('d02', 'line', 2, phase=0)
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    "Ela puxou o braço. Eu continuei segurando. Não tinha nada de abraço na posição em que ficamos."
    $ aa_audio_event('d02', 'line', 3, phase=0)
    j "Tira a mão dela. Agora."
    $ aa_audio_event('d02', 'line', 4, phase=0)
    "O funcionário estendeu a mão na minha direção. Yasmin olhava para os meus dedos, não para mim."
    $ aa_audio_event('d02', 'line', 5, phase=0)
    f "Eu não vou machucar ninguém."
    $ aa_audio_event('d02', 'line', 6, phase=0)
    y "Então solta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Soltar o braço e me afastar.":
            $ aa_audio_event('d02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd02', 0)
            jump d_stop
        "Continuar segurando e mandar Joãozão ficar fora disso.":
            $ aa_audio_event('d02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd02', 1)
            jump d03

label d_stop:
    $ aa_node = 'd_stop'
    $ aa_location = '22h09 · Saída do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d_stop'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1329)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d_stop')
    $ aa_stage_action = 'Feka afastado, mãos baixas; Yasmin protegida pela distância, sem contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    if aa_matches(aa_state, {'unwanted_contact': True}):
        $ aa_audio_event('d_stop', 'line', 0, phase=0)
        $ aa_stage_action = 'Feka afastado, mãos baixas; Yasmin protegida pela distância, sem contato.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_recuo'
        show screen aa_location_display
        "Soltei o braço. Yasmin foi para trás do funcionário e esfregou o lugar onde eu tinha segurado."
    if aa_matches(aa_state, {'unwanted_contact': False}):
        $ aa_audio_event('d_stop', 'line', 1, phase=0)
        "Afastei os pés da passagem. Yasmin passou longe do meu ombro e foi para perto do funcionário."
    $ aa_audio_event('d_stop', 'line', 2, phase=0)
    $ aa_stage_action = 'Feka afastado, mãos baixas; Yasmin protegida pela distância, sem contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    y "Eu não quero mensagem. Não quero pedido de desculpa na minha porta. Me deixa em paz."
    $ aa_audio_event('d_stop', 'line', 3, phase=0)
    j "Vai embora."
    $ aa_audio_event('d_stop', 'line', 4, phase=0)
    "O funcionário me acompanhou até a calçada. Yasmin ficou lá dentro, falando com a recepcionista."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d_stop', 'line', 5, phase=0)
        v "Eu vou sozinha. Não vem comigo."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d_stop', 'line', 6, phase=0)
        "Vanessa atravessou a entrada sem pegar minha mão. Eu tinha parado. Ela ainda estava com medo de que eu recomeçasse."
    $ aa_audio_event('d_stop', 'line', 7, phase=0)
    "Na calçada, peguei o celular. Não havia ninguém me impedindo de mandar outra mensagem. Guardei antes de abrir a conversa."
    jump z13

label d03:
    $ aa_node = 'd03'
    $ aa_location = '22h08 · Recepção'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d03'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1328)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d03')
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    $ aa_audio_event('d03', 'line', 0, phase=0)
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    f "Fica fora disso. Eu tô falando com ela."
    $ aa_audio_event('d03', 'line', 1, phase=0)
    $ aa_stage_action = 'Após um único golpe, Feka no chão; funcionário separa os envolvidos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_queda at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_queda'
    show screen aa_location_display
    "Yasmin tentou puxar o braço outra vez. Eu apertei a mão. Joãozão avançou e me acertou no rosto."
    $ aa_audio_event('d03', 'line', 2, phase=0)
    $ aa_stage_action = 'Após um único golpe, Feka no chão; funcionário separa os envolvidos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_queda at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_queda'
    show screen aa_location_display
    "Soltei na hora. Bati na lateral de uma cadeira e caí sentado. O barulho da cadeira veio antes de eu entender onde estava."
    $ aa_audio_event('d03', 'line', 3, phase=0)
    "Levei a mão à boca. Havia sangue no dedo. Eu olhei para Joãozão, esperando outro golpe."
    $ aa_audio_event('d03', 'line', 4, phase=0)
    "O funcionário entrou entre nós. Joãozão ficou parado do outro lado, respirando pela boca."
    $ aa_audio_event('d03', 'line', 5, phase=0)
    y "João, chega!"
    $ aa_audio_event('d03', 'line', 6, phase=0)
    j "Ele não soltava você."
    $ aa_audio_event('d03', 'line', 7, phase=0)
    y "Eu sei. Fica longe dele agora."
    $ aa_audio_event('d03', 'line', 8, phase=0)
    "Yasmin se afastou dos dois e pediu à recepcionista que chamasse a polícia. Disse que queria contar o que tinha acontecido."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d03', 'line', 9, phase=0)
        $ aa_stage_action = 'Vanessa se agacha sem tocar Feka; sua fala só ocorre quando ela permaneceu no restaurante.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_vanessa at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_vanessa'
        show screen aa_location_display
        v "Você tá conseguindo me ouvir?"
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d03', 'line', 10, phase=0)
        "Vanessa se agachou a uma distância que eu não consegui diminuir sem parecer que ia agarrá-la também."
    $ aa_audio_event('d03', 'line', 11, phase=0)
    f "Você viu o que ele fez?"
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d03', 'line', 12, phase=0)
        v "Vi. Eu também vi o que você fez."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d03', 'line', 13, phase=0)
        "O funcionário disse que tinha visto a discussão desde o primeiro pedido para sair."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que eu só queria abraçar Yasmin.":
            $ aa_audio_event('d03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd03', 0)
            $ aa_audio_event('d03', 'response', 0, 0)
            f "Eu só fui dar um abraço. Ele veio pra cima de mim."
            $ aa_audio_event('d03', 'response', 1, 0)
            y "Eu falei pra não encostar. Depois pedi pra soltar."
            $ aa_audio_event('d03', 'response', 2, 0)
            "Ninguém respondeu à palavra abraço. O funcionário pediu que eu continuasse sentado."
            jump d04
        "Dizer que segurei o braço dela e pedir ajuda para levantar.":
            $ aa_audio_event('d03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd03', 1)
            $ aa_audio_event('d03', 'response', 0, 1)
            f "Eu segurei o braço dela. Me ajuda a levantar."
            $ aa_audio_event('d03', 'response', 1, 1)
            "O funcionário pediu que eu esperasse e trouxe um guardanapo. Yasmin não veio até mim."
            jump d04

label d04:
    $ aa_node = 'd04'
    $ aa_location = '22h24 · Entrada do restaurante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d04'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1344)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d04')
    $ aa_stage_action = 'Cada um de um lado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_policia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_policia'
    show screen aa_location_display
    $ aa_audio_event('d04', 'line', 0, phase=0)
    $ aa_stage_action = 'Cada um de um lado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_policia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_policia'
    show screen aa_location_display
    "A recepcionista tinha chamado ajuda e me mantido sentado. Quando os policiais chegaram, o funcionário mostrou onde cada um estava."
    $ aa_audio_event('d04', 'line', 1, phase=0)
    "Um deles ficou comigo. O outro ouviu Yasmin perto da porta. Joãozão esperou junto ao balcão, longe dela e de mim."
    $ aa_audio_event('d04', 'line', 2, phase=0)
    $ aa_stage_action = 'Cada um de um lado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_policia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_policia'
    show screen aa_location_display
    "Perguntaram se eu estava passando mal. Mostrei a boca e disse que o rosto doía. Providenciaram uma avaliação antes de continuarmos."
    $ aa_audio_event('d04', 'line', 3, phase=0)
    f "Eu faço Direito."
    $ aa_audio_event('d04', 'line', 4, phase=0)
    "O policial esperou. Depois perguntou meu nome completo. Eu dei o nome da faculdade antes de perceber que não era isso."
    $ aa_audio_event('d04', 'line', 5, phase=0)
    y "Eu quero que conste que ele me segurou. Eu pedi pra me soltar."
    $ aa_audio_event('d04', 'line', 6, phase=0)
    j "Eu dei o soco. Não vou dizer que não dei."
    $ aa_audio_event('d04', 'line', 7, phase=0)
    "Joãozão falou com o outro policial. Não parecia satisfeito. Yasmin continuou olhando para quem anotava."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 8, phase=0)
        v "Eu vou contar o que eu vi. Não vou falar que foi só um abraço."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 9, phase=0)
        f "Você vai ficar comigo?"
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 10, phase=0)
        v "Vou esperar terminar isso aqui. Depois minha mãe vem me buscar. Eu não consigo ficar com você."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 11, phase=0)
        "Ela chorava enquanto falava. Quando tentei chamar de novo, foi para perto da recepcionista."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d04', 'line', 12, phase=0)
        "Pensei em ligar para Vanessa. Ela já tinha ido embora antes daquilo. Eu teria que começar contando por que ainda estava ali."
    $ aa_audio_event('d04', 'line', 13, phase=0)
    "Depois da avaliação, explicaram que iríamos à delegacia para registrar os relatos. Joãozão também teria que contar sobre o golpe. Não houve uma decisão ali no restaurante sobre quem tinha razão."
    jump d05

label d05:
    $ aa_node = 'd05'
    $ aa_location = 'Mais tarde · A caminho da delegacia'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d05'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1400)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d05')
    $ aa_stage_action = 'O banco de trás'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_viatura at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_viatura'
    show screen aa_location_display
    $ aa_audio_event('d05', 'line', 0, phase=0)
    $ aa_stage_action = 'O banco de trás'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_viatura at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_viatura'
    show screen aa_location_display
    "Saí com um policial. Yasmin ficou com o outro, terminando de explicar. Joãozão não veio no mesmo carro que eu."
    $ aa_audio_event('d05', 'line', 1, phase=0)
    "Entrei no banco de trás e coloquei o cinto. A porta fechou. No vidro, meu rosto aparecia por cima das luzes da rua."
    $ aa_audio_event('d05', 'line', 2, phase=0)
    $ aa_stage_action = 'O banco de trás'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_viatura at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_viatura'
    show screen aa_location_display
    "O guardanapo estava amassado na minha mão. Eu tinha vergonha de perguntar onde jogar."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d05', 'line', 3, phase=0)
        "Vanessa tinha chamado a mãe. Não me pediu para mandar mensagem quando chegasse."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d05', 'line', 4, phase=0)
        "O celular de Vanessa continuava longe de mim, como já estava antes do golpe. Ela não sabia que eu ia parar ali."
    $ aa_audio_event('d05', 'line', 5, phase=0)
    "Pensei em dizer que ele tinha me batido do nada. Eu conseguia montar a frase. O difícil era tirar minha mão do braço de Yasmin da lembrança."
    jump d06

label d06:
    $ aa_node = 'd06'
    $ aa_location = 'Depois da meia-noite · Delegacia'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['d06'])
    $ aa_phone_active = False
    $ aa_present = ()
    call aa_advance_clock(1460)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('d06')
    $ aa_stage_action = 'Feka aguarda na recepção, separado do outro casal.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    $ aa_audio_event('d06', 'line', 0, phase=0)
    $ aa_stage_action = 'Feka aguarda na recepção, separado do outro casal.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    "Na recepção, pediram meu documento. Sentei numa cadeira de plástico até chamarem meu nome. O funcionário do restaurante tinha deixado um contato."
    $ aa_audio_event('d06', 'line', 1, phase=0)
    "Yasmin e Joãozão chegaram depois. Foram orientados a esperar em outro lugar. Eu não fui falar com eles."
    $ aa_audio_event('d06', 'line', 2, phase=0)
    $ aa_stage_action = 'Relato individual à mesa, sem Yasmin ou Joãozão presentes.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_depoimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_depoimento'
    show screen aa_location_display
    "Quando me chamaram, sentei diante de uma mesa com um computador. A pessoa que me atendia pediu que eu contasse desde o começo."
    $ aa_audio_event('d06', 'line', 3, phase=0)
    f "Ele me deu um soco."
    $ aa_audio_event('d06', 'line', 4, phase=0)
    "Anotou. Depois perguntou o que tinha acontecido antes do soco."
    if aa_matches(aa_state, {'incident_account': 'negou'}):
        $ aa_audio_event('d06', 'line', 5, phase=0)
        "Eu já tinha dito que era só um abraço. A frase estava pronta para ser usada outra vez."
    if aa_matches(aa_state, {'incident_account': 'admitiu'}):
        $ aa_audio_event('d06', 'line', 6, phase=0)
        "No restaurante eu tinha admitido que segurei o braço dela. Agora precisava repetir sem diminuir o que fiz."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Contar que impedi a passagem e continuei segurando depois do pedido para soltar.":
            $ aa_audio_event('d06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd06', 0)
            $ aa_audio_event('d06', 'response', 0, 0)
            f "Eu parei na frente dela. Ela mandou eu sair. Depois eu peguei no braço. Ela pediu pra soltar e eu não soltei."
            $ aa_audio_event('d06', 'response', 1, 0)
            "Eu tinha começado pelo soco. Agora quem anotava voltou algumas linhas."
            jump e12
        "Omitir que ela pediu para eu soltar e dizer que Joãozão me atacou sem motivo.":
            $ aa_audio_event('d06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd06', 1)
            $ aa_audio_event('d06', 'response', 0, 1)
            f "Eu fui me despedir. Ele me bateu sem motivo."
            $ aa_audio_event('d06', 'response', 1, 1)
            "Perguntaram se eu tinha tocado nela. Disse que sim. Perguntaram o que ela falou. Fiquei olhando para o teclado."
            jump e12

label e12:
    $ aa_node = 'e12'
    $ aa_location = 'Madrugada · Sala de espera da delegacia'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e12'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1490)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('e12')
    $ aa_stage_action = 'Sem ninguém para confirmar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    $ aa_audio_event('e12', 'line', 0, phase=0)
    $ aa_stage_action = 'Sem ninguém para confirmar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    "Voltei para a cadeira de plástico. Ainda precisava esperar. Ninguém tinha dito que aquilo estava resolvido."
    if aa_matches(aa_state, {'station_account': 'completo'}):
        $ aa_audio_event('e12', 'line', 1, phase=0)
        "Eu tinha contado o que fiz. Isso não tirou a dor do rosto nem fez Yasmin querer me ouvir."
    if aa_matches(aa_state, {'station_account': 'omitiu'}):
        $ aa_audio_event('e12', 'line', 2, phase=0)
        $ aa_stage_action = 'Sem ninguém para confirmar'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_espera'
        show screen aa_location_display
        "Eu tinha omitido o pedido dela. O relato de Yasmin e o do funcionário não dependiam de eu concordar com eles."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e12', 'line', 3, phase=0)
        $ aa_phone_remember('depois_agressao')
        "Vanessa mandou uma mensagem: \"Cheguei com minha mãe. Hoje não me procura. Amanhã eu vejo como falar com você.\""
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('e12', 'line', 4, phase=0)
        "Abri a conversa com Vanessa. Ela tinha saído antes da confusão. Não contei onde estava."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('e12', 'line', 5, phase=0)
        "Eu tinha prometido ajudar na mudança. Olhei a hora. Ela teria que resolver aquilo sem poder contar comigo."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_transients()
        "[aa_financial_line('joao_epilogue')]"
    if aa_matches(aa_state, {'bill': 'vanessa'}):
        $ aa_audio_event('e12', 'line', 7, phase=0)
        "Vanessa tinha completado a conta no cartão. Eu ainda precisava devolver o dinheiro que pedi emprestado."
    $ aa_audio_event('e12', 'line', 8, phase=0)
    "Abri uma mensagem nova para dizer que tinham acabado com a minha noite. Apaguei. Depois escrevi só que precisava de alguém para me buscar quando pudesse sair."
    $ aa_audio_event('e12', 'line', 9, phase=0)
    "Fiquei segurando o celular. Do outro lado da sala, chamaram um nome que não era o meu."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E12 · Sem ninguém para confirmar"
    return

label z04:
    $ aa_node = 'z04'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z04'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2650)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z04')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O espaço pedido'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_audio_event('z04', 'line', 0, phase=0)
    "A conversa ficou aberta na tela. Eu tinha terminado. Não havia uma resposta escondida que mudasse o que eu disse."
    $ aa_audio_event('z04', 'line', 1, phase=0)
    "Separei a matéria para mandar pelo grupo. O resto do caderno ficou comigo."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E04 · Cadeira vazia"
    return

label z05:
    $ aa_node = 'z05'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z05'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2040)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z05')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Uma resposta para Vanessa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_audio_event('z05', 'line', 0, phase=0)
    "Na segunda de manhã, deixei a conversa antiga de Yasmin e abri a de Vanessa."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('z05', 'line', 1, phase=0)
        "Ela tinha respondido à visita cancelada. Eu ainda não tinha respondido a ela."
    if aa_matches(aa_state, {'promised': False, 'v_gone': False}):
        $ aa_audio_event('z05', 'line', 2, phase=0)
        "Ela queria saber se eu pretendia falar sobre nós. Eu tinha mandado que fosse embora sozinha."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('z05', 'line', 3, phase=0)
        "Ela já tinha saído antes da minha última tentativa com Yasmin. Eu não podia falar como se tivesse visto aquela parte."
    $ aa_chapter_message({'id': 'week_z05_out', 'sender': 'Vanessa', 'body': 'Não consigo continuar o namoro. Não vou pedir que você me espere.', 'outgoing': True})
    $ aa_audio_event('z05', 'line', 4, phase=0)
    "Escrevi que não conseguia continuar o namoro e que não ia pedir que esperasse por mim."
    $ aa_chapter_message({'id': 'week_z05_in', 'sender': 'Vanessa', 'body': 'Eu queria que desse. Mas não quero continuar esperando você escolher outra pessoa.', 'outgoing': False})
    $ aa_audio_event('z05', 'line', 5, phase=0)
    "Vanessa respondeu: \"Eu queria que desse. Mas não quero continuar esperando você escolher outra pessoa.\""
    $ aa_audio_event('z05', 'line', 6, phase=0)
    "Li duas vezes. Não procurei uma frase para fazer com que ela me consolasse."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E05 · A mesma resposta"
    return

label z06:
    $ aa_node = 'z06'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z06'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2460)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z06')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O que não volta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('z06', 'line', 0, phase=0)
    "Depois da aula, abri o caderno antes de procurar o celular. Havia uma página de Vanessa com correções que eu ainda não tinha passado a limpo."
    $ aa_audio_event('z06', 'line', 1, phase=0)
    "Mandei uma mensagem. Disse que não queria sustentar o namoro enquanto esperava descobrir se queria estar nele."
    $ aa_chapter_message({'id': 'week_z06_in', 'sender': 'Vanessa', 'body': 'Então é um término. Eu preciso que você diga desse jeito.', 'outgoing': False})
    $ aa_audio_event('z06', 'line', 2, phase=0)
    "Ela respondeu: \"Então é um término. Eu preciso que você diga desse jeito.\""
    $ aa_chapter_message({'id': 'week_z06_out', 'sender': 'Vanessa', 'body': 'É. Eu quero terminar. Sinto muito.', 'outgoing': True})
    $ aa_audio_event('z06', 'line', 3, phase=0)
    "Escrevi: \"É. Eu quero terminar. Sinto muito.\""
    $ aa_audio_event('z06', 'line', 4, phase=0)
    "Pedi autorização para devolver o caderno pela colega que sentava com ela. Vanessa disse que podia deixar com a Marina."
    $ aa_audio_event('z06', 'line', 5, phase=0)
    "Passei minhas anotações a limpo. Na capa dela, não deixei bilhete."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E06 · Sem plateia"
    return

label z07:
    $ aa_node = 'z07'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z07'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2160)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z07')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'A versão enviada'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('z07', 'line', 0, phase=0)
    "O áudio ainda estava no grupo. Eu abri a conversa com Vanessa e tentei contar outra vez o quanto tinham me desrespeitado."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('z07', 'line', 1, phase=0)
        "Ela tinha visto a discussão. Escreveu que não ia confirmar uma história em que eu só tinha ficado parado."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('z07', 'line', 2, phase=0)
        "Ela respondeu que tinha ido embora antes e não podia confirmar o que eu estava dizendo."
    $ aa_chapter_message({'id': 'week_z07_in', 'sender': 'Vanessa', 'body': 'Eu não quero continuar namorando. Não quero passar o dia tentando te acalmar sobre Yasmin.', 'outgoing': False})
    $ aa_audio_event('z07', 'line', 3, phase=0)
    "Depois veio outra mensagem: \"Eu não quero continuar namorando. Não quero passar o dia tentando te acalmar sobre Yasmin.\""
    $ aa_audio_event('z07', 'line', 4, phase=0)
    "Comecei a escrever que ela estava me abandonando quando eu mais precisava. Parei com o polegar sobre o teclado."
    $ aa_audio_event('z07', 'line', 5, phase=0)
    "Apaguei. O áudio que eu já tinha mandado não desapareceu junto."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E07 · Fora do salão"
    return

label z08:
    $ aa_node = 'z08'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z08'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2460)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z08')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'A publicação fica'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('z08', 'line', 0, phase=0)
    "No meu perfil, os copos ainda pareciam uma noite acompanhada. Na conversa, Vanessa tinha pedido que eu tirasse a marcação."
    $ aa_audio_event('z08', 'line', 1, phase=0)
    "Eu já tinha feito isso. Também tinha terminado o namoro. Nenhuma das pessoas que viram a foto precisava saber para que fosse verdade."
    $ aa_audio_event('z08', 'line', 2, phase=0)
    "Guardei o aparelho. A cadeira do outro lado da escrivaninha continuou vazia."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E08 · Uma noite ótima"
    return

label z13:
    $ aa_node = 'z13'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z13'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2040)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z13')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Depois de parar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_audio_event('z13', 'line', 0, phase=0)
    "Na manhã seguinte, não abri a conversa de Yasmin. Abri a de Vanessa."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('z13', 'line', 1, phase=0)
        "Ela tinha visto o que aconteceu. Disse que eu parei, mas que não conseguia esquecer como precisei ser mandado embora."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('z13', 'line', 2, phase=0)
        "Ela tinha ido embora antes. Contei que tinha impedido Yasmin de sair e que o funcionário me acompanhou até a rua."
    if aa_matches(aa_state, {'v_gone': True, 'unwanted_contact': True}):
        $ aa_audio_event('z13', 'line', 3, phase=0)
        "Contei também que segurei o braço dela antes de soltar."
    $ aa_chapter_message({'id': 'week_z13_in', 'sender': 'Vanessa', 'body': 'Eu ainda gosto de você. Mas não quero continuar esse namoro. Preciso ficar longe disso.', 'outgoing': False})
    $ aa_audio_event('z13', 'line', 4, phase=0)
    "Vanessa escreveu: \"Eu ainda gosto de você. Mas não quero continuar esse namoro. Preciso ficar longe disso.\""
    $ aa_audio_event('z13', 'line', 5, phase=0)
    "Eu tinha parado antes do golpe. Isso não me dava uma tarde na casa dela."
    $ aa_audio_event('z13', 'line', 6, phase=0)
    "Mandei que tinha entendido. Deixei a conversa fechada enquanto me arrumava para a aula."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E13 · A passagem livre"
    return

label b_wait:
    $ aa_node = 'b_wait'
    $ aa_location = 'Quarto de Feka · terça'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_wait'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3360)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_wait')
    $ aa_location = 'Moradia universitária'
    $ aa_stage_action = 'Até quinta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('b_wait', 'line', 0, phase=0)
    "Na terça, estudei na moradia antes de ir à faculdade. Vanessa tinha marcado quinta. Na segunda, a mudança aconteceu sem mim."
    $ aa_present = ()
    call aa_advance_clock(3380)
    $ aa_audio_event('b_wait', 'line', 1, phase=0)
    $ aa_location = 'Campus de Direito'
    $ aa_audio_ambient('AMB15')
    $ aa_stage_action = 'Transição para a aula; Vanessa com Marina, distante de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_aula_separados at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_aula_separados'
    show screen aa_location_display
    "Na sala, o professor distribuiu um trabalho para sexta. Anotei minha parte. Vanessa combinou a dela com Marina, a colega que sentava perto da janela."
    $ aa_audio_event('b_wait', 'line', 2, phase=0)
    "Quando a aula terminou, Vanessa me perguntou onde tinha ficado uma referência. Mostrei a página. Ela agradeceu e voltou para a colega."
    $ aa_audio_event('b_wait', 'line', 3, phase=0)
    "Eu queria perguntar se a quinta ainda estava de pé. O horário continuava escrito na nossa conversa."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Mandar só a referência que ela pediu e respeitar o dia combinado.":
            $ aa_audio_event('b_wait', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_wait', 0)
            $ aa_audio_event('b_wait', 'response', 0, 0)
            "Mandei o número da página. Depois fui terminar minha parte do trabalho."
            jump b_thursday
        "Perguntar de novo se ela ainda quer me ver.":
            $ aa_audio_event('b_wait', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_wait', 1)
            jump b_wait_reply

label b_wait_reply:
    $ aa_node = 'b_wait_reply'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_wait_reply'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3960)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_wait_reply')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O dia combinado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_wait_repeat', 'sender': 'Vanessa', 'body': 'Quinta, Feka. Eu pedi esses dias. Ficar respondendo isso toda hora não ajuda.', 'outgoing': False})
    $ aa_audio_event('b_wait_reply', 'line', 0, phase=0)
    "Vanessa respondeu: \"Quinta, Feka. Eu pedi esses dias. Ficar respondendo isso toda hora não ajuda.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Responder que entendi e esperar.":
            $ aa_audio_event('b_wait_reply', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_wait_reply', 0)
            $ aa_audio_event('b_wait_reply', 'response', 0, 0)
            "Escrevi que esperaria. Não mandei outra pergunta na quarta."
            jump b_thursday
        "Dizer que ela precisa decidir agora.":
            $ aa_audio_event('b_wait_reply', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_wait_reply', 1)
            $ aa_audio_event('b_wait_reply', 'response', 0, 1)
            v "Então eu prefiro parar. Eu pedi uns dias e você não consegue me dar isso."
            jump z_bridge

label b_space:
    $ aa_node = 'b_space'
    $ aa_location = 'Quarto de Feka'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_space'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3960)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_space')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Respeitar a distância'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_audio_event('b_space', 'line', 0, phase=0)
    "Na terça, Vanessa me cumprimentou na sala e sentou com Marina. Não havia convite para ir ao apartamento."
    $ aa_audio_event('b_space', 'line', 1, phase=0)
    "À noite, o pedido dela continuava no celular: por enquanto, não queria me ver fora da aula."
    $ aa_audio_event('b_space', 'line', 2, phase=0)
    "Eu podia mandar a matéria. Não precisava transformar cada arquivo numa pergunta sobre o namoro."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Respeitar o pedido e cuidar das minhas aulas.":
            $ aa_audio_event('b_space', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_space', 0)
            $ aa_audio_event('b_space', 'response', 0, 0)
            "Mandei a matéria pelo grupo. Na quarta, fiz o trabalho na biblioteca e fui para casa."
            jump b_space_invite
        "Insistir para conversar antes de ela estar pronta.":
            $ aa_audio_event('b_space', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_space', 1)
            $ aa_audio_event('b_space', 'response', 0, 1)
            "Pedi mais uma conversa. Ela respondeu que tinha acabado de pedir o contrário e que queria terminar."
            jump z_bridge

label b_space_invite:
    $ aa_node = 'b_space_invite'
    $ aa_location = 'Campus de Direito'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_space_invite'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6480)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_space_invite')
    $ aa_location = 'Campus de Direito'
    $ aa_stage_action = 'O convite dela'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_space_invite', 'sender': 'Vanessa', 'body': 'Podemos conversar depois da aula? Perto do jardim. Não quero ir pra sua casa.', 'outgoing': False})
    $ aa_audio_event('b_space_invite', 'line', 0, phase=0)
    "Na quinta, chegou uma mensagem: \"Podemos conversar depois da aula? Perto do jardim. Não quero ir pra sua casa.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Aceitar o lugar e o horário.":
            $ aa_audio_event('b_space_invite', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_space_invite', 0)
            $ aa_audio_event('b_space_invite', 'response', 0, 0)
            "Confirmei. Guardei o celular e voltei para a sala."
            jump b_thursday
        "Responder que prefiro encerrar o namoro.":
            $ aa_audio_event('b_space_invite', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_space_invite', 1)
            $ aa_audio_event('b_space_invite', 'response', 0, 1)
            "Disse que queria terminar. Ela respondeu que tinha entendido e pediu que eu não mudasse isso no dia seguinte."
            jump z_bridge

label b_apology:
    $ aa_node = 'b_apology'
    $ aa_location = 'Campus de Direito'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_apology'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2160)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('b_apology')
    $ aa_location = 'Campus de Direito'
    $ aa_stage_action = 'A conversa ainda é nossa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_corredor at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_corredor'
    show screen aa_location_display
    $ aa_audio_event('b_apology', 'line', 0, phase=0)
    "Na segunda, Vanessa ficou junto à porta depois da aula. Eu me aproximei sem pegar na mão dela."
    $ aa_audio_event('b_apology', 'line', 1, phase=0)
    v "Eu queria agradecer por você ter pedido pra ela parar com a piada. Mas a desculpa dela não responde o que você me contou."
    $ aa_audio_event('b_apology', 'line', 2, phase=0)
    f "Eu sei."
    $ aa_audio_event('b_apology', 'line', 3, phase=0)
    v "Você sabe ou vai dizer que ficou tudo bem porque ela pediu desculpa?"
    $ aa_audio_event('b_apology', 'line', 4, phase=0)
    "Uma turma saiu da sala ao lado. Esperamos o barulho passar."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Propor uma conversa sobre nós, quando ela quiser.":
            $ aa_audio_event('b_apology', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_apology', 0)
            $ aa_audio_event('b_apology', 'response', 0, 0)
            f "Eu quero falar da gente. Se você quiser."
            $ aa_audio_event('b_apology', 'response', 1, 0)
            v "Quinta, depois da aula. Até lá eu preciso pensar."
            $ aa_audio_event('b_apology', 'response', 2, 0)
            "Combinamos o banco perto do jardim."
            jump b_wait
        "Dizer que já fiz o suficiente por ela.":
            $ aa_audio_event('b_apology', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_apology', 1)
            $ aa_audio_event('b_apology', 'response', 0, 1)
            v "Então a gente não tem a mesma ideia do que aconteceu. Eu quero terminar."
            jump z_bridge
        "Dizer que não quero continuar o namoro.":
            $ aa_audio_event('b_apology', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b_apology', 2)
            $ aa_audio_event('b_apology', 'response', 0, 2)
            f "Eu não quero continuar."
            $ aa_audio_event('b_apology', 'response', 1, 2)
            v "Tá. Dói ouvir isso, mas eu preciso ouvir."
            jump z_bridge

label b_answer:
    $ aa_node = 'b_answer'
    $ aa_location = 'Quarto de Feka'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_answer'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2040)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_answer')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Responder à pergunta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_audio_event('b_answer', 'line', 0, phase=0)
    "A pergunta dela continuava sem resposta: a gente tinha terminado?"
    $ aa_audio_event('b_answer', 'line', 1, phase=0)
    "Eu tinha lido. Não podia culpar uma notificação que não chegou."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que quero conversar e ouvir se ela ainda quer tentar.":
            $ aa_audio_event('b_answer', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_answer', 0)
            $ aa_audio_event('b_answer', 'response', 0, 0)
            "Escrevi que queria conversar. Pedi desculpa por deixar a resposta para ela."
            jump b_answer_reply
        "Responder que quero terminar.":
            $ aa_audio_event('b_answer', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_answer', 1)
            $ aa_audio_event('b_answer', 'response', 0, 1)
            "Escrevi que queria terminar. Vanessa respondeu: \"Tá. Era isso que eu estava tentando saber.\""
            jump z_bridge
        "Deixar a pergunta sem resposta outra vez.":
            $ aa_audio_event('b_answer', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b_answer', 2)
            $ aa_audio_event('b_answer', 'response', 0, 2)
            "À tarde, ela escreveu que ia considerar o namoro encerrado. Eu não tinha respondido nem com uma desculpa."
            jump z_bridge

label b_answer_reply:
    $ aa_node = 'b_answer_reply'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_answer_reply'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2160)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_answer_reply')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Um horário possível'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_answer_meet', 'sender': 'Vanessa', 'body': 'Quinta eu consigo falar. Hoje tem mudança. Não aparece lá sem combinar.', 'outgoing': False})
    $ aa_audio_event('b_answer_reply', 'line', 0, phase=0)
    "Ela respondeu: \"Quinta eu consigo falar. Hoje tem mudança. Não aparece lá sem combinar.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar quinta e respeitar a mudança dela.":
            $ aa_audio_event('b_answer_reply', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_answer_reply', 0)
            $ aa_audio_event('b_answer_reply', 'response', 0, 0)
            "Respondi que sim. A mudança daquele dia ficou com ela e a mãe."
            jump b_wait
        "Exigir uma resposta sobre namoro agora.":
            $ aa_audio_event('b_answer_reply', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_answer_reply', 1)
            $ aa_audio_event('b_answer_reply', 'response', 0, 1)
            "Ela escreveu que não queria continuar. Dessa vez a resposta estava dada."
            jump z_bridge

label b_post_define:
    $ aa_node = 'b_post_define'
    $ aa_location = 'Quarto de Feka'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_post_define'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2460)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_post_define')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'A foto não responde'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('b_post_define', 'line', 0, phase=0)
    "Na publicação, eu tinha companhia. Na conversa com Vanessa, não sabia dizer se ainda tinha um namoro."
    $ aa_audio_event('b_post_define', 'line', 1, phase=0)
    "Ela tinha pedido que eu tirasse a marcação. Eu tirei. A legenda continuou."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Reconhecer a publicação falsa e pedir uma conversa sem garantir a volta.":
            $ aa_audio_event('b_post_define', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_post_define', 0)
            $ aa_chapter_phone_action('withdraw_post')
            $ aa_audio_event('b_post_define', 'response', 0, 0)
            "Apaguei a publicação. Mandei que tinha usado a foto para fingir que a noite estava bem."
            jump b_post_request
        "Insistir que ela está exagerando por causa de uma foto.":
            $ aa_audio_event('b_post_define', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_post_define', 1)
            $ aa_audio_event('b_post_define', 'response', 0, 1)
            "Vanessa respondeu que não era a foto. Disse que queria terminar."
            jump z_bridge
        "Dizer que quero encerrar o namoro.":
            $ aa_audio_event('b_post_define', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b_post_define', 2)
            $ aa_audio_event('b_post_define', 'response', 0, 2)
            "Escrevi que queria terminar. Ela pediu que eu não publicasse mais nada usando a nossa relação."
            jump z_bridge

label b_post_request:
    $ aa_node = 'b_post_request'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_post_request'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2580)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_post_request')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Depois de apagar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_post_request', 'sender': 'Vanessa', 'body': 'Podemos conversar quinta. Eu não quero fingir que foi só a postagem.', 'outgoing': False})
    $ aa_audio_event('b_post_request', 'line', 0, phase=0)
    "Vanessa respondeu: \"Podemos conversar quinta. Eu não quero fingir que foi só a postagem.\""
    $ aa_audio_event('b_post_request', 'line', 1, phase=0)
    "Confirmei. A visita à mudança não tinha sido combinada entre nós. Eu não fui."
    jump b_wait

label b_post_visit:
    $ aa_node = 'b_post_visit'
    $ aa_location = 'Quarto de Feka'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_post_visit'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2410)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('b_post_visit')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'A visita que ainda falta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('b_post_visit', 'line', 0, phase=0)
    "Eu tinha acabado de confirmar a visita. Ainda estava na moradia. Vanessa esperava no apartamento desde depois da aula."
    $ aa_audio_event('b_post_visit', 'line', 1, phase=0)
    "Ela mandou o endereço de novo e perguntou quanto tempo eu levaria."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Avisar que estou saindo e ir ajudar.":
            $ aa_audio_event('b_post_visit', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_post_visit', 0)
            $ aa_audio_event('b_post_visit', 'response', 0, 0)
            "Avisei que sairia agora e fui a pé. O endereço ficava a vinte minutos da moradia."
            jump b_post_arrival
        "Inventar um compromisso e cancelar.":
            $ aa_audio_event('b_post_visit', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_post_visit', 1)
            $ aa_audio_event('b_post_visit', 'response', 0, 1)
            "Ela respondeu: \"Você confirmou agora há pouco. Eu não quero mais ficar esperando assim. Não quero continuar esse namoro.\""
            jump z_bridge

label b_post_arrival:
    $ aa_node = 'b_post_arrival'
    $ aa_location = 'Apartamento de Vanessa · entrada'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_post_arrival'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2435)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('b_post_arrival')
    $ aa_location = 'Apartamento de Vanessa · entrada'
    $ aa_stage_action = 'Feka chega de mãos livres; Vanessa mantém a porta aberta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_porta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_porta'
    show screen aa_location_display
    $ aa_audio_event('b_post_arrival', 'line', 0, phase=0)
    "Cheguei sem caixa nas mãos. A mãe de Vanessa já tinha levado a última para dentro. Toquei a campainha."
    $ aa_audio_event('b_post_arrival', 'line', 1, phase=0)
    v "Achei que você não vinha mais."
    $ aa_audio_event('b_post_arrival', 'line', 2, phase=0)
    f "Eu falei que vinha."
    $ aa_audio_event('b_post_arrival', 'line', 3, phase=0)
    v "Você também falou que a noite tinha sido ótima."
    $ aa_audio_event('b_post_arrival', 'line', 4, phase=0)
    "Fiquei no batente. Ela abriu um pouco mais a porta, mas ainda esperou minha resposta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Admitir que a publicação foi para parecer bem.":
            $ aa_audio_event('b_post_arrival', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_post_arrival', 0)
            $ aa_chapter_phone_action('withdraw_post')
            $ aa_audio_event('b_post_arrival', 'response', 0, 0)
            f "Eu queria parecer bem. Não foi justo com você. Vou tirar."
            $ aa_audio_event('b_post_arrival', 'response', 1, 0)
            v "Tira. E entra, eu preciso guardar esses copos. A conversa não acabou."
            $ aa_audio_event('b_post_arrival', 'response', 2, 0)
            "Apaguei a publicação antes de guardar o telefone."
            jump b_post_boxes
        "Dizer que continuo com ela e pedir para deixar a foto para lá.":
            $ aa_audio_event('b_post_arrival', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_post_arrival', 1)
            $ aa_audio_event('b_post_arrival', 'response', 0, 1)
            f "Eu tô aqui. Quero continuar com você."
            $ aa_audio_event('b_post_arrival', 'response', 1, 1)
            v "Eu também quero. Mas não gostei de ver você fingindo. Não vou comentar aquela foto."
            jump b_post_boxes
        "Dizer que não vou entrar se ela continuar cobrando.":
            $ aa_audio_event('b_post_arrival', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b_post_arrival', 2)
            $ aa_audio_event('b_post_arrival', 'response', 0, 2)
            v "Então é melhor ir. Eu não quero continuar um namoro em que não posso perguntar isso."
            jump z_bridge

label b_post_boxes:
    $ aa_node = 'b_post_boxes'
    $ aa_location = 'Apartamento de Vanessa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_post_boxes'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2460)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('b_post_boxes')
    $ aa_location = 'Apartamento de Vanessa'
    $ aa_stage_action = 'Fazer a visita acontecer'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_trabalho_mudanca'
    show screen aa_location_display
    $ aa_audio_event('b_post_boxes', 'line', 0, phase=0)
    "Entrei e deixei a mochila junto da porta. Ela apontou a caixa dos copos. Tirei um de cada vez do papel; Vanessa levou para o armário."
    $ aa_audio_event('b_post_boxes', 'line', 1, phase=0)
    v "Minha mãe deixou comida. Você quer comer antes de ir?"
    $ aa_audio_event('b_post_boxes', 'line', 2, phase=0)
    f "Quero."
    $ aa_audio_event('b_post_boxes', 'line', 3, phase=0)
    $ aa_location = 'Apartamento de Vanessa'
    $ aa_audio_ambient('AMB16')
    $ aa_stage_action = 'Refeição depois de guardar a louça.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_refeicao_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_refeicao_mudanca'
    show screen aa_location_display
    "Terminamos de guardar os copos, limpamos a mesa e esquentamos a comida. Vanessa sentou de frente para mim."
    $ aa_audio_event('b_post_boxes', 'line', 4, phase=0)
    v "Se você não quiser vir outro dia, me fala antes. Eu fico contando com você."
    $ aa_audio_event('b_post_boxes', 'line', 5, phase=0)
    f "Eu aviso."
    $ aa_audio_event('b_post_boxes', 'line', 6, phase=0)
    "Comemos. A foto já tinha tomado tempo suficiente daquela tarde."
    jump w_louca

label b_thursday:
    $ aa_node = 'b_thursday'
    $ aa_location = 'Campus de Direito · jardim'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_thursday'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6730)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('b_thursday')
    $ aa_location = 'Campus de Direito · jardim'
    $ aa_stage_action = 'A conversa de quinta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quinta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quinta'
    show screen aa_location_display
    $ aa_audio_event('b_thursday', 'line', 0, phase=0)
    "Na quarta, terminei minha parte do trabalho. Na quinta, depois da aula, esperei perto do banco que tínhamos combinado. Vanessa saiu do prédio com a mochila num ombro. Sentei só depois dela."
    $ aa_audio_event('b_thursday', 'line', 1, phase=0)
    v "Eu fiquei ensaiando o que falar. Achei que ia chegar aqui e pedir pra você voltar antes de terminar a primeira frase."
    $ aa_audio_event('b_thursday', 'line', 2, phase=0)
    f "Não precisa falar depressa."
    $ aa_audio_event('b_thursday', 'line', 3, phase=0)
    v "Eu gosto de você. E tenho medo de me acostumar com qualquer coisa só pra não ficar sem você."
    $ aa_audio_event('b_thursday', 'line', 4, phase=0)
    "Ela ajeitou a alça da mochila no colo. Não era um convite para eu puxá-la para perto."
    if aa_matches(aa_state, {'truth': True}):
        $ aa_audio_event('b_thursday', 'line', 5, phase=0)
        v "Você me contou por que começou a namorar comigo. Eu não vou fingir que não ouvi."
    if aa_matches(aa_state, {'truth': False}):
        $ aa_audio_event('b_thursday', 'line', 6, phase=0)
        v "Ainda tem coisa do jantar que eu não entendi. Eu não quero voltar só pra parar de perguntar."
    $ aa_audio_event('b_thursday', 'line', 7, phase=0)
    v "Eu quero tentar. Devagar. Sem você prometer todo dia que nunca vai embora."
    $ aa_audio_event('b_thursday', 'line', 8, phase=0)
    f "O que seria devagar pra você?"
    $ aa_audio_event('b_thursday', 'line', 9, phase=0)
    v "Sexta depois da aula. Um café. Você vai se quiser ir. E, se não puder, avisa."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Aceitar o café e combinar uma visita de cada vez.":
            $ aa_audio_event('b_thursday', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b_thursday', 0)
            $ aa_audio_event('b_thursday', 'response', 0, 0)
            f "Eu quero ir na sexta. Posso chegar às quatro."
            $ aa_audio_event('b_thursday', 'response', 1, 0)
            v "Pode. Quatro. É isso que eu consigo combinar agora."
            jump b_agreed
        "Garantir que ela nunca mais vai precisar duvidar de mim.":
            $ aa_audio_event('b_thursday', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b_thursday', 1)
            $ aa_audio_event('b_thursday', 'response', 0, 1)
            v "Eu quero acreditar. Mas eu acabei de pedir um café, não um nunca."
            $ aa_audio_event('b_thursday', 'response', 1, 1)
            f "Sexta às quatro, então."
            $ aa_audio_event('b_thursday', 'response', 2, 1)
            v "Tá. Eu quero tentar."
            jump b_agreed
        "Dizer que não quero retomar o namoro.":
            $ aa_audio_event('b_thursday', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b_thursday', 2)
            $ aa_audio_event('b_thursday', 'response', 0, 2)
            f "Eu não quero continuar o namoro. Não seria justo aceitar a sexta como se quisesse."
            $ aa_audio_event('b_thursday', 'response', 1, 2)
            v "Tá. Obrigada por falar aqui, antes de me deixar esperando."
            jump z_bridge

label b_agreed:
    $ aa_node = 'b_agreed'
    $ aa_location = 'Campus de Direito · jardim'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['b_agreed'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6750)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('b_agreed')
    $ aa_location = 'Campus de Direito · jardim'
    $ aa_stage_action = 'Levantar do banco'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quinta_perto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quinta_perto'
    show screen aa_location_display
    $ aa_audio_event('b_agreed', 'line', 0, phase=0)
    "Vanessa olhou para minha mão no banco e encostou a dela por cima. Deixei ali."
    $ aa_audio_event('b_agreed', 'line', 1, phase=0)
    v "Eu não quero começar essa tentativa com você me levando pra sua casa."
    $ aa_audio_event('b_agreed', 'line', 2, phase=0)
    f "A gente se vê amanhã."
    $ aa_audio_event('b_agreed', 'line', 3, phase=0)
    $ aa_location = 'Campus de Direito · jardim'
    $ aa_audio_ambient('AMB15')
    $ aa_stage_action = 'Despedida depois da conversa aceita; proximidade não implica pernoite.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_despedida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_despedida'
    show screen aa_location_display
    "Ficamos mais um pouco. Quando ela levantou, peguei minha mochila. Caminhamos até a saída e seguimos por ruas diferentes."
    jump c3_morning

label z_bridge:
    $ aa_node = 'z_bridge'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z_bridge'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(12120)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z_bridge')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Uma resposta dada'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('z_bridge', 'line', 0, phase=0)
    "Na segunda seguinte, a conversa continuava encerrada. Na faculdade, eu ainda veria Vanessa. Não combinamos outra visita."
    if aa_matches(aa_state, {'visit_missed': True}):
        $ aa_audio_event('z_bridge', 'line', 1, phase=0)
        "Eu tinha deixado de ir depois de confirmar. Dizer que pretendia ajudar não significava ter ajudado."
    $ aa_audio_event('z_bridge', 'line', 2, phase=0)
    "Passei a matéria para o grupo, sem anexar uma mensagem só para ela. Depois voltei ao meu caderno."
    if aa_matches(aa_state, {'final_contact': 'end'}):
        $ aa_audio_event('z_bridge', 'line', 3, phase=0)
        "Eu tinha dito que queria terminar. Não podia esperar que Vanessa decidisse por mim o contrário."
    if aa_matches(aa_state, {'final_contact': {'ne': 'end'}}):
        $ aa_audio_event('z_bridge', 'line', 4, phase=0)
        "Eu queria uma resposta diferente. A que tinha recebido já era uma resposta."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E14 · Uma resposta dada"
    return

label w_louca:
    $ aa_node = 'w_louca'
    $ aa_location = 'Apartamento de Vanessa · cozinha'
    if aa_state['chapter'] < 2:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 2\nA primeira semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_louca'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2490)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_louca')
    $ aa_location = 'Apartamento de Vanessa · cozinha'
    $ aa_stage_action = 'Depois de comer'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_louca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_louca'
    show screen aa_location_display
    if aa_matches(aa_state, {'chapter_origin': 'e03'}):
        $ aa_audio_event('w_louca', 'line', 0, phase=0)
        "Tirei a jaqueta antes de levar os pratos à pia. Vanessa pegou o pano e ficou ao meu lado."
    $ aa_audio_event('w_louca', 'line', 1, phase=0)
    "A água demorou a esquentar. Passei a esponja no primeiro prato e entreguei um copo para Vanessa secar."
    $ aa_audio_event('w_louca', 'line', 2, phase=0)
    v "Não põe esse no alto. Eu uso todo dia."
    $ aa_audio_event('w_louca', 'line', 3, phase=0)
    f "Aqui?"
    $ aa_audio_event('w_louca', 'line', 4, phase=0)
    v "Aqui. Agora a cozinha é minha e eu posso reclamar do armário."
    $ aa_audio_event('w_louca', 'line', 5, phase=0)
    "Ela encostou o copo na prateleira de baixo. Havia lugar para outro ao lado."
    if aa_matches(aa_state, {'chapter_origin': 'e11'}):
        $ aa_audio_event('w_louca', 'line', 6, phase=0)
        v "Eu gostei de acordar com você hoje."
    if aa_matches(aa_state, {'chapter_origin': 'e11'}):
        $ aa_audio_event('w_louca', 'line', 7, phase=0)
        f "Eu também."
    if aa_matches(aa_state, {'chapter_origin': 'e11'}):
        $ aa_audio_event('w_louca', 'line', 8, phase=0)
        v "Mesmo com aqueles dois minutos de alarme?"
    if aa_matches(aa_state, {'chapter_origin': 'e11'}):
        $ aa_audio_event('w_louca', 'line', 9, phase=0)
        f "Aquela parte foi péssima."
    if aa_matches(aa_state, {'chapter_origin': 'e03', 'relationship_phase': 'repair'}):
        $ aa_audio_event('w_louca', 'line', 10, phase=0)
        v "Eu ainda penso no que você me contou ontem. Mas gostei que você veio hoje."
    if aa_matches(aa_state, {'chapter_origin': 'e03', 'relationship_phase': 'repair'}):
        $ aa_audio_event('w_louca', 'line', 11, phase=0)
        f "Eu queria vir."
    if aa_matches(aa_state, {'chapter_origin': 'e03', 'relationship_phase': 'repair'}):
        $ aa_audio_event('w_louca', 'line', 12, phase=0)
        v "Então fala assim. Não precisa dizer que vai resolver tudo."
    if aa_matches(aa_state, {'comfort_lie': True}):
        $ aa_audio_event('w_louca', 'line', 13, phase=0)
        v "Quando você diz que quer ficar comigo, eu fico tentando acreditar logo. Aí pergunto de novo."
    if aa_matches(aa_state, {'comfort_lie': True}):
        $ aa_audio_event('w_louca', 'line', 14, phase=0)
        "Eu podia reconhecer a certeza que tinha fingido. Continuei esfregando uma marca no prato."
    $ aa_audio_event('w_louca', 'line', 15, phase=0)
    "Terminamos a louça. Vanessa guardou o pano e mostrou a prateleira que ainda faltava firmar."
    $ aa_audio_event('w_louca', 'line', 16, phase=0)
    v "Hoje chega. Amanhã eu vejo isso."
    jump w_door

label w_door:
    $ aa_node = 'w_door'
    $ aa_location = 'Apartamento de Vanessa · porta'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_door'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2520)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_door')
    $ aa_location = 'Apartamento de Vanessa · porta'
    $ aa_stage_action = 'Antes de descer'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_porta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_porta'
    show screen aa_location_display
    $ aa_audio_event('w_door', 'line', 0, phase=0)
    "Peguei a mochila e fui até a porta. Vanessa segurou a maçaneta por dentro. Eu ainda não tinha saído."
    $ aa_audio_event('w_door', 'line', 1, phase=0)
    v "Você chegou a ver o corredor? Não faz barulho nenhum. Na outra casa sempre tinha alguém."
    $ aa_audio_event('w_door', 'line', 2, phase=0)
    f "Tá estranhando?"
    $ aa_audio_event('w_door', 'line', 3, phase=0)
    v "Um pouco. Também tô gostando. As duas coisas."
    if aa_matches(aa_state, {'visit_plan': 'tuesday'}):
        $ aa_audio_event('w_door', 'line', 4, phase=0)
        v "Então amanhã tem café, depois da aula."
    if aa_matches(aa_state, {'visit_plan': ''}):
        $ aa_audio_event('w_door', 'line', 5, phase=0)
        v "Você quer voltar amanhã? Posso fazer café depois da aula."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Combinar o café de terça e avisar antes de sair.":
            $ aa_audio_event('w_door', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_door', 0)
            $ aa_audio_event('w_door', 'response', 0, 0)
            f "Amanhã, depois da aula. Te aviso quando estiver saindo."
            $ aa_audio_event('w_door', 'response', 1, 0)
            v "Tá. Não vou deixar o café pronto duas horas antes, então."
            jump w_night
        "Dizer que prefiro voltar na sexta e combinar esse dia.":
            $ aa_audio_event('w_door', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_door', 1)
            $ aa_audio_event('w_door', 'response', 0, 1)
            f "Amanhã preciso estudar. Pode ser sexta, às quatro?"
            $ aa_audio_event('w_door', 'response', 1, 1)
            v "Eu queria amanhã. Mas pode. Vou me organizar pra sexta."
            $ aa_audio_event('w_door', 'response', 2, 1)
            "Ela repetiu o horário e abriu espaço para eu passar."
            jump w_night
        "Prometer que vou estar lá todos os dias.":
            $ aa_audio_event('w_door', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'w_door', 2)
            $ aa_audio_event('w_door', 'response', 0, 2)
            f "Vou vir todo dia. Você não vai ficar sozinha."
            $ aa_audio_event('w_door', 'response', 1, 2)
            v "Todo dia mesmo?"
            $ aa_audio_event('w_door', 'response', 2, 2)
            f "Todo dia."
            $ aa_audio_event('w_door', 'response', 3, 2)
            "Ela sorriu. Eu ainda não tinha olhado minha semana."
            jump w_night

label w_night:
    $ aa_node = 'w_night'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_night'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2740)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('w_night')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'A primeira noite dela'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_audio_event('w_night', 'line', 0, phase=0)
    "Voltei a pé, tomei banho e deixei o caderno aberto na escrivaninha. O telefone vibrou enquanto eu procurava uma caneta."
    $ aa_chapter_message({'id': 'week_first_night', 'sender': 'Vanessa', 'body': 'Achei o interruptor do corredor. Agora só falta parar de achar que todo barulho é alguém na porta.', 'outgoing': False})
    $ aa_audio_event('w_night', 'line', 1, phase=0)
    "Era Vanessa: \"Achei o interruptor do corredor. Agora só falta parar de achar que todo barulho é alguém na porta.\""
    $ aa_audio_event('w_night', 'line', 2, phase=0)
    "Ela mandou uma risada depois. Comecei a responder só com outra."
    $ aa_audio_event('w_night', 'line', 3, phase=0)
    "Chegou mais uma mensagem: perguntou se podia me ligar por uns minutos."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Ligar e conversar um pouco antes de voltar a estudar.":
            $ aa_audio_event('w_night', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_night', 0)
            $ aa_audio_event('w_night', 'response', 0, 0)
            "Liguei. Vanessa contou que a geladeira fazia um estalo e me perguntou se a minha também fazia."
            $ aa_audio_event('w_night', 'response', 1, 0)
            f "Faz. Mas na cozinha todo mundo põe a culpa na panela."
            $ aa_audio_event('w_night', 'response', 2, 0)
            v "A sua panela?"
            $ aa_audio_event('w_night', 'response', 3, 0)
            f "A minha."
            $ aa_audio_event('w_night', 'response', 4, 0)
            "Rimos. Combinamos desligar quando ela fosse tomar banho. Depois terminei a página que estava lendo."
            jump w_class
        "Dizer que ela pode ligar a qualquer hora e que sempre vou atender.":
            $ aa_audio_event('w_night', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_night', 1)
            $ aa_audio_event('w_night', 'response', 0, 1)
            "Ela ligou na hora. Falamos por quase uma hora. Quando disse que precisava desligar, ela perguntou se já estava incomodando."
            $ aa_audio_event('w_night', 'response', 1, 1)
            f "Não. Só preciso estudar."
            $ aa_audio_event('w_night', 'response', 2, 1)
            v "Tá. Eu sei. Você falou qualquer hora e eu me empolguei."
            $ aa_audio_event('w_night', 'response', 3, 1)
            "Fiquei mais um pouco, sem desfazer a promessa."
            jump w_class
        "Responder que hoje preciso estudar e combinar falar amanhã.":
            $ aa_audio_event('w_night', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'w_night', 2)
            $ aa_audio_event('w_night', 'response', 0, 2)
            "Escrevi que precisava terminar uma leitura, mas podia falar amanhã depois da aula. Ela respondeu \"tá\" e depois \"boa noite\"."
            $ aa_audio_event('w_night', 'response', 1, 2)
            "Mandei boa noite também. Ela não precisava ouvir uma mentira para receber uma resposta."
            jump w_class

label w_class:
    $ aa_node = 'w_class'
    $ aa_location = 'Campus de Direito · sala'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_class'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3380)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_class')
    $ aa_location = 'Campus de Direito · sala'
    $ aa_stage_action = 'Uma parte para cada um'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_aula at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_aula'
    show screen aa_location_display
    $ aa_audio_event('w_class', 'line', 0, phase=0)
    "Na terça, encontrei Vanessa na sala. Ela tinha trocado a blusa e prendia a manga do casaco com o polegar enquanto procurava uma página."
    $ aa_audio_event('w_class', 'line', 1, phase=0)
    v "Dormi. Demorei um pouco, mas dormi."
    $ aa_audio_event('w_class', 'line', 2, phase=0)
    "O professor distribuiu um trabalho para entregar na sexta. Não era longo. Isso foi o bastante para eu querer deixar para quinta."
    $ aa_audio_event('w_class', 'line', 3, phase=0)
    "Marina, a colega de Vanessa, virou na cadeira à nossa frente e perguntou se faríamos juntos."
    $ aa_audio_event('w_class', 'line', 4, phase=0)
    m "Três partes. Uma pra cada um, e a gente confere as referências antes de entregar."
    $ aa_audio_event('w_class', 'line', 5, phase=0)
    v "Pode ser. Eu fico com essa aqui."
    $ aa_audio_event('w_class', 'line', 6, phase=0)
    "Vanessa apontou a segunda parte. Marina já estava anotando a primeira."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Assumir a terceira parte e combinar a revisão.":
            $ aa_audio_event('w_class', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_class', 0)
            $ aa_audio_event('w_class', 'response', 0, 0)
            f "Eu faço a terceira. A gente olha junto antes de sexta."
            $ aa_audio_event('w_class', 'response', 1, 0)
            m "Quinta de manhã eu consigo."
            $ aa_audio_event('w_class', 'response', 2, 0)
            v "Fechado."
            jump w_library
        "Oferecer revisar tudo, mesmo sem ter começado minha parte.":
            $ aa_audio_event('w_class', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_class', 1)
            $ aa_audio_event('w_class', 'response', 0, 1)
            f "Manda tudo pra mim que eu reviso."
            $ aa_audio_event('w_class', 'response', 1, 1)
            m "Primeiro termina a tua. Não quero descobrir um erro meia hora antes de entregar."
            $ aa_audio_event('w_class', 'response', 2, 1)
            "Eu ri como se a frase tivesse sido para outra pessoa."
            jump w_library
        "Pedir que Vanessa faça minha parte comigo, porque ela entende melhor.":
            $ aa_audio_event('w_class', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'w_class', 2)
            $ aa_audio_event('w_class', 'response', 0, 2)
            v "Eu posso te explicar onde começa. Não vou fazer duas partes."
            $ aa_audio_event('w_class', 'response', 1, 2)
            f "Eu não pedi isso."
            $ aa_audio_event('w_class', 'response', 2, 2)
            v "Então ótimo. Você escreve a sua e me mostra."
            jump w_library

label w_library:
    $ aa_node = 'w_library'
    $ aa_location = 'Campus de Direito · biblioteca'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_library'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3720)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_library')
    $ aa_location = 'Campus de Direito · biblioteca'
    $ aa_stage_action = 'A página em branco'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_biblioteca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_biblioteca'
    show screen aa_location_display
    $ aa_audio_event('w_library', 'line', 0, phase=0)
    "Depois da aula e do almoço, fomos à biblioteca. Marina tinha outro compromisso. Vanessa abriu o livro; eu abri o arquivo em branco."
    $ aa_audio_event('w_library', 'line', 1, phase=0)
    v "Você já leu essa parte?"
    $ aa_audio_event('w_library', 'line', 2, phase=0)
    f "Por cima."
    $ aa_audio_event('w_library', 'line', 3, phase=0)
    v "Por cima da capa?"
    $ aa_audio_event('w_library', 'line', 4, phase=0)
    "Olhei a capa. Ela esperou até eu rir."
    $ aa_audio_event('w_library', 'line', 5, phase=0)
    v "Começa aqui. Eu preciso terminar a minha também."
    $ aa_audio_event('w_library', 'line', 6, phase=0)
    "Copiei a referência e comecei a escrever. Vanessa voltou para o próprio caderno. Ficamos um tempo sem conversar."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Terminar meu rascunho e conferir a referência antes de sair.":
            $ aa_audio_event('w_library', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_library', 0)
            $ aa_audio_event('w_library', 'response', 0, 0)
            "Escrevi uma página e meia. Li em voz baixa, cortei uma frase que não dizia nada e mostrei só a dúvida."
            $ aa_audio_event('w_library', 'response', 1, 0)
            v "Agora eu consigo te ajudar. Essa parte aqui tá clara."
            $ aa_audio_event('w_library', 'response', 2, 0)
            "Anotei o que faltava conferir na quinta."
            jump w_after_library
        "Fechar o caderno e deixar para a véspera.":
            $ aa_audio_event('w_library', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_library', 1)
            $ aa_audio_event('w_library', 'response', 0, 1)
            "Disse que faria em casa. Vanessa pediu que eu mandasse antes da revisão de quinta."
            $ aa_audio_event('w_library', 'response', 1, 1)
            f "Mando."
            $ aa_audio_event('w_library', 'response', 2, 1)
            "Salvei o arquivo com duas linhas. O nome dele parecia mais completo do que o texto."
            jump w_after_library

label w_after_library:
    $ aa_node = 'w_after_library'
    $ aa_location = 'Campus de Direito · corredor'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_after_library'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3820)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_after_library')
    $ aa_location = 'Campus de Direito · corredor'
    $ aa_stage_action = 'Sair da biblioteca'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_corredor at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_corredor'
    show screen aa_location_display
    $ aa_audio_event('w_after_library', 'line', 0, phase=0)
    "Devolvemos os livros. Vanessa conferiu a mochila e me esperou junto à porta da sala."
    if aa_matches(aa_state, {'visit_plan': 'tuesday'}):
        $ aa_audio_event('w_after_library', 'line', 1, phase=0)
        v "Eu vou pra casa. Você vem pro café?"
    if aa_matches(aa_state, {'visit_plan': 'tuesday'}):
        $ aa_audio_event('w_after_library', 'line', 2, phase=0)
        f "Vou. Só passo na moradia para deixar os livros que não preciso."
    if aa_matches(aa_state, {'visit_plan': 'tuesday'}):
        $ aa_audio_event('w_after_library', 'line', 3, phase=0)
        "Saímos juntos da biblioteca. Na porta do prédio, cada um foi para o seu lado."
    if aa_matches(aa_state, {'visit_plan': 'friday'}):
        $ aa_audio_event('w_after_library', 'line', 4, phase=0)
        v "Eu vou pra casa. Sexta a gente se vê lá."
    if aa_matches(aa_state, {'visit_plan': 'friday'}):
        $ aa_audio_event('w_after_library', 'line', 5, phase=0)
        f "Sexta, às quatro."
    if aa_matches(aa_state, {'visit_plan': 'friday'}):
        $ aa_audio_event('w_after_library', 'line', 6, phase=0)
        "Caminhamos até a saída da faculdade. Ela seguiu para o apartamento; eu fui para a moradia."
    if aa_matches(aa_state, {'visit_plan': 'tuesday'}):
        jump w_coffee
    jump w_own_evening

label w_coffee:
    $ aa_node = 'w_coffee'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_coffee'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3880)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_coffee')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'Café sem ocasião'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_cafe at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_cafe'
    show screen aa_location_display
    $ aa_audio_event('w_coffee', 'line', 0, phase=0)
    "Passei na moradia e avisei quando saí. Uma hora depois da biblioteca, já estava sentado à mesa de Vanessa. Ela deixou a caneca ao lado da minha e puxou o prato de pão para o meio. As caixas vazias estavam dobradas contra a parede."
    $ aa_audio_event('w_coffee', 'line', 1, phase=0)
    v "Eu comprei o pão antes de você avisar. Só o café que eu esperei."
    $ aa_audio_event('w_coffee', 'line', 2, phase=0)
    f "E se eu não viesse?"
    $ aa_audio_event('w_coffee', 'line', 3, phase=0)
    v "Eu ia comer pão. Muito triste, mas alimentada."
    $ aa_audio_event('w_coffee', 'line', 4, phase=0)
    "Ri. Vanessa arrancou um pedaço e empurrou o prato para mim."
    $ aa_audio_event('w_coffee', 'line', 5, phase=0)
    v "Minha mãe ligou de manhã pra perguntar onde eu guardei os pratos. Ela guardou metade dos pratos."
    $ aa_audio_event('w_coffee', 'line', 6, phase=0)
    f "Você falou isso?"
    $ aa_audio_event('w_coffee', 'line', 7, phase=0)
    v "Não. Abri o armário e procurei."
    $ aa_audio_event('w_coffee', 'line', 8, phase=0)
    "Conversamos sobre a casa até o café esfriar. Havia uma coisa boa em ela me contar algo que eu não precisava corrigir."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Perguntar o que ela quer fazer com a sala.":
            $ aa_audio_event('w_coffee', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_coffee', 0)
            $ aa_audio_event('w_coffee', 'response', 0, 0)
            v "Quero tirar as caixas e ter lugar pra receber gente. A Marina quer vir no sábado."
            $ aa_audio_event('w_coffee', 'response', 1, 0)
            f "Vocês vão estudar?"
            $ aa_audio_event('w_coffee', 'response', 2, 0)
            v "Talvez meia hora. O resto eu quero reclamar da faculdade."
            jump w_shelf
        "Perguntar se ela está feliz de eu ter voltado.":
            $ aa_audio_event('w_coffee', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_coffee', 1)
            $ aa_audio_event('w_coffee', 'response', 0, 1)
            v "Tô. Por isso fiz café."
            $ aa_audio_event('w_coffee', 'response', 1, 1)
            f "Só perguntei."
            $ aa_audio_event('w_coffee', 'response', 2, 1)
            v "Eu sei. Agora pega o pão antes que eu coma tudo."
            $ aa_audio_event('w_coffee', 'response', 3, 1)
            "Ela me entregou o prato. Aceitei sem pedir uma frase maior."
            jump w_shelf

label w_shelf:
    $ aa_node = 'w_shelf'
    $ aa_location = 'Apartamento de Vanessa · estante'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_shelf'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3910)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_shelf')
    $ aa_location = 'Apartamento de Vanessa · estante'
    $ aa_stage_action = 'Uma prateleira torta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_prateleira at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_prateleira'
    show screen aa_location_display
    $ aa_audio_event('w_shelf', 'line', 0, phase=0)
    "Depois do café, tirei a camisa de cima e peguei a chave de fenda. Uma prateleira da estante mexia quando Vanessa apoiava um livro. Me agachei junto à lateral."
    $ aa_audio_event('w_shelf', 'line', 1, phase=0)
    v "Eu segurei e apertei ao mesmo tempo. Acho que não apertei nada."
    $ aa_audio_event('w_shelf', 'line', 2, phase=0)
    f "Segura desse lado. Eu tento aqui."
    $ aa_audio_event('w_shelf', 'line', 3, phase=0)
    "Apertei um parafuso. Vanessa apoiou a lateral e ficou olhando para a minha mão."
    $ aa_audio_event('w_shelf', 'line', 4, phase=0)
    v "Agora para de mexer."
    $ aa_audio_event('w_shelf', 'line', 5, phase=0)
    f "Já parei."
    $ aa_audio_event('w_shelf', 'line', 6, phase=0)
    v "Você. A estante ainda tá mexendo."
    $ aa_audio_event('w_shelf', 'line', 7, phase=0)
    "Troquei o parafuso pelo que tinha sobrado no saco. Dessa vez a prateleira ficou firme. Ela pôs um livro e esperou. Não caiu."
    $ aa_audio_event('w_shelf', 'line', 8, phase=0)
    v "Tá bom. Amanhã eu arrumo o resto."
    $ aa_audio_event('w_shelf', 'line', 9, phase=0)
    "Eu já tinha pegado outro livro quando ela disse isso."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Deixar a arrumação do jeito que ela quer e combinar a hora de ir.":
            $ aa_audio_event('w_shelf', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_shelf', 0)
            $ aa_audio_event('w_shelf', 'response', 0, 0)
            f "Quer que eu deixe esses aqui?"
            $ aa_audio_event('w_shelf', 'response', 1, 0)
            v "Quero. Vou escolher a ordem depois."
            $ aa_audio_event('w_shelf', 'response', 2, 0)
            "Deixei o livro. Guardamos a ferramenta e fomos lavar as mãos."
            jump w_tuesday_exit
        "Continuar arrumando e dizer que desse jeito fica melhor.":
            $ aa_audio_event('w_shelf', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_shelf', 1)
            $ aa_audio_event('w_shelf', 'response', 0, 1)
            "Coloquei os livros por tamanho. Vanessa tirou dois e pôs de volta na mesa."
            $ aa_audio_event('w_shelf', 'response', 1, 1)
            v "Eu falei que queria fazer. Não precisa resolver a minha casa inteira."
            $ aa_audio_event('w_shelf', 'response', 2, 1)
            "Parei. Ainda tive vontade de explicar por que a minha ordem era melhor."
            jump w_tuesday_exit

label w_tuesday_exit:
    $ aa_node = 'w_tuesday_exit'
    $ aa_location = 'Apartamento de Vanessa · cozinha'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_tuesday_exit'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3970)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_tuesday_exit')
    $ aa_location = 'Apartamento de Vanessa · cozinha'
    $ aa_stage_action = 'O resto da noite'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_prateleira at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_prateleira'
    show screen aa_location_display
    $ aa_audio_event('w_tuesday_exit', 'line', 0, phase=0)
    "Guardamos a chave de fenda. Vanessa verificou o horário no telefone e disse que precisava lavar roupa."
    $ aa_audio_event('w_tuesday_exit', 'line', 1, phase=0)
    v "Eu ia pedir pra você ficar mais. Mas, se eu não lavar hoje, amanhã não tem o que vestir."
    $ aa_audio_event('w_tuesday_exit', 'line', 2, phase=0)
    f "Então eu vou. A gente se fala depois."
    $ aa_audio_event('w_tuesday_exit', 'line', 3, phase=0)
    v "Tá. Gostei do café."
    $ aa_audio_event('w_tuesday_exit', 'line', 4, phase=0)
    "Ela me acompanhou até a porta. Dei um beijo no rosto dela e desci."
    $ aa_present = ()
    call aa_advance_clock(4020)
    $ aa_present = ()
    $ aa_audio_event('w_tuesday_exit', 'line', 5, phase=0)
    $ aa_location = 'Quarto de Feka'
    $ aa_audio_ambient('AMB01')
    $ aa_stage_action = 'Feka volta à moradia depois da visita.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    "Na moradia, troquei de roupa e abri o caderno."
    jump w_midweek

label w_own_evening:
    $ aa_node = 'w_own_evening'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_own_evening'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(3960)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('w_own_evening')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O dia combinado continua'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('w_own_evening', 'line', 0, phase=0)
    "Na moradia, deixei a mochila no chão e abri o caderno. A visita estava combinada para sexta. Não precisava inventar outra para provar que queria vê-la."
    $ aa_audio_event('w_own_evening', 'line', 1, phase=0)
    "Vanessa escreveu que tinha dobrado as caixas vazias e liberado um canto da sala."
    $ aa_audio_event('w_own_evening', 'line', 2, phase=0)
    "Perguntei se já dava para receber gente. Ela disse que queria receber a Marina no sábado e voltou a arrumar as coisas."
    jump w_midweek

label w_midweek:
    $ aa_node = 'w_midweek'
    $ aa_location = 'Campus de Direito · biblioteca'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_midweek'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6360)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('w_midweek')
    $ aa_location = 'Campus de Direito · biblioteca'
    $ aa_stage_action = 'A revisão de quinta'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_biblioteca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_biblioteca'
    show screen aa_location_display
    $ aa_audio_event('w_midweek', 'line', 0, phase=0)
    "Na quarta, tivemos aula e seguimos com nossas tarefas. Na quinta de manhã, levamos os rascunhos para a revisão."
    if aa_matches(aa_state, {'task_done': True}):
        $ aa_audio_event('w_midweek', 'line', 1, phase=0)
        "Minha parte estava pronta. Vanessa apontou uma referência incompleta; completei antes de passar o arquivo para Marina."
    if aa_matches(aa_state, {'task_done': True}):
        $ aa_audio_event('w_midweek', 'line', 2, phase=0)
        m "Agora sim. Amanhã a gente só confere e entrega."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('w_midweek', 'line', 3, phase=0)
        "Abri o arquivo quase vazio. Marina olhou para a tela e depois para mim."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('w_midweek', 'line', 4, phase=0)
        m "Você falou que ia mandar antes de hoje."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('w_midweek', 'line', 5, phase=0)
        v "Eu perguntei duas vezes se precisava de alguma coisa."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('w_midweek', 'line', 6, phase=0)
        f "Eu sei."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('w_midweek', 'line', 7, phase=0)
        "Vanessa fechou o próprio caderno. Esperei que ela oferecesse fazer. Ela não ofereceu."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Conferir o que já fiz e guardar o arquivo para sexta." if aa_matches(aa_state, {'task_done': True}):
            $ aa_audio_event('w_midweek', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_midweek', 0)
            $ aa_audio_event('w_midweek', 'response', 0, 0)
            "Salvei a versão revisada. Marina ficou com uma cópia. Não havia trabalho para Vanessa fazer por mim."
            jump w_thursday
        "Assumir o atraso e terminar minha parte ainda hoje." if aa_matches(aa_state, {'task_done': False}):
            $ aa_audio_event('w_midweek', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_midweek', 1)
            $ aa_audio_event('w_midweek', 'response', 0, 1)
            f "Eu atrasei. Vou terminar na moradia. Mando hoje antes das seis."
            $ aa_audio_event('w_midweek', 'response', 1, 1)
            v "Eu consigo conferir às seis. Depois vou fazer minhas coisas."
            $ aa_audio_event('w_midweek', 'response', 2, 1)
            f "Tá."
            jump w_work_repair
        "Pedir que Vanessa resolva para não comprometer o grupo." if aa_matches(aa_state, {'task_done': False}):
            $ aa_audio_event('w_midweek', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'w_midweek', 2)
            $ aa_audio_event('w_midweek', 'response', 0, 2)
            v "Não. Isso é pra você não comprometer o grupo. Eu fiz a minha parte."
            $ aa_audio_event('w_midweek', 'response', 1, 2)
            m "Entrega a sua separado se não terminar. Vou mandar a nossa amanhã."
            $ aa_audio_event('w_midweek', 'response', 2, 2)
            "Anotei o prazo de novo, como se fosse uma informação nova."
            jump w_thursday

label w_work_repair:
    $ aa_node = 'w_work_repair'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_work_repair'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6660)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('w_work_repair')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Terminar a minha parte'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('w_work_repair', 'line', 0, phase=0)
    "Voltei para a moradia com as páginas que tinha copiado. Sentei à escrivaninha e deixei o telefone virado para baixo."
    $ aa_audio_event('w_work_repair', 'line', 1, phase=0)
    "Levei mais tempo do que prometi a mim mesmo, mas terminei antes das seis. Mandei a parte que faltava e a referência corrigida."
    $ aa_audio_event('w_work_repair', 'line', 2, phase=0)
    "Vanessa respondeu que tinha recebido. Marina escreveu que incluiria no arquivo. Ninguém precisou dizer que eu tinha sido muito responsável."
    jump w_thursday

label w_thursday:
    $ aa_node = 'w_thursday'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_thursday'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6860)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('w_thursday')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Continuar a semana'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_audio_event('w_thursday', 'line', 0, phase=0)
    "Na quinta à noite, Vanessa ligou para combinar a sexta. Já não havia caixas no caminho entre a mesa e a porta."
    if aa_matches(aa_state, {'visit_plan': 'friday'}):
        $ aa_audio_event('w_thursday', 'line', 1, phase=0)
        "Ela me contou da sala pelo telefone. Eu ainda não tinha voltado depois da mudança."
    $ aa_audio_event('w_thursday', 'line', 2, phase=0)
    v "Amanhã, às quatro. Você ainda vem?"
    $ aa_audio_event('w_thursday', 'line', 3, phase=0)
    f "Vou."
    $ aa_audio_event('w_thursday', 'line', 4, phase=0)
    v "Tá. Quero ter uma tarde em que a gente não esteja montando alguma coisa."
    if aa_matches(aa_state, {'chapter_origin': 'e08'}):
        $ aa_audio_event('w_thursday', 'line', 5, phase=0)
        "Lembrei do colega para quem tinha dito que ela estava estranha. Aquela frase ainda estava com ele, sem o começo da história."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar o horário e perguntar o que ela quer fazer.":
            $ aa_audio_event('w_thursday', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_thursday', 0)
            $ aa_audio_event('w_thursday', 'response', 0, 0)
            v "Café. Depois a gente decide. Eu tô aprendendo a não marcar o resto da vida antes de sexta."
            $ aa_audio_event('w_thursday', 'response', 1, 0)
            "Ri. Ela riu também e disse boa noite."
            jump c3_morning
        "Contar a parte da história que ainda escondi." if aa_matches(aa_state, {'truth': False}):
            $ aa_audio_event('w_thursday', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_thursday', 1)
            $ aa_audio_event('w_thursday', 'response', 0, 1)
            f "Antes da sexta, tem uma coisa do jantar que eu não te contei direito."
            $ aa_audio_event('w_thursday', 'response', 1, 1)
            v "É sobre Yasmin?"
            $ aa_audio_event('w_thursday', 'response', 2, 1)
            f "É."
            $ aa_audio_event('w_thursday', 'response', 3, 1)
            v "Então fala. Eu tô ouvindo."
            jump w_truth
        "Prometer que daqui em diante vou compensar tudo.":
            $ aa_audio_event('w_thursday', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'w_thursday', 2)
            $ aa_audio_event('w_thursday', 'response', 0, 2)
            v "Eu queria saber do café, Feka. Você fala tudo e eu não sei o que esperar amanhã."
            $ aa_audio_event('w_thursday', 'response', 1, 2)
            f "Amanhã eu vou às quatro."
            $ aa_audio_event('w_thursday', 'response', 2, 2)
            v "Então tá. Vamos começar por isso."
            jump c3_morning

label w_truth:
    $ aa_node = 'w_truth'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_truth'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(6870)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('w_truth')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Dizer por telefone'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_audio_event('w_truth', 'line', 0, phase=0)
    f "Eu guardei o nome do restaurante por causa dela. E, quando comecei a namorar você, eu queria não estar sozinho. Eu devia ter contado sem esperar você perguntar."
    $ aa_audio_event('w_truth', 'line', 1, phase=0)
    "Vanessa ficou em silêncio. Eu ouvi uma cadeira mexer do outro lado."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('w_truth', 'line', 2, phase=0)
        f "Eu também vi a publicação antes de sair. Sabia que eles podiam estar lá."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('w_truth', 'line', 3, phase=0)
        f "Eu não sabia que ela estaria no restaurante. Isso não muda por que escolhi o lugar."
    $ aa_audio_event('w_truth', 'line', 4, phase=0)
    v "E agora? Você tá me contando porque quer terminar?"
    $ aa_audio_event('w_truth', 'line', 5, phase=0)
    f "Não quero terminar. Quero continuar. Mas não queria que você seguisse acreditando no que eu falei daquele jeito."
    $ aa_audio_event('w_truth', 'line', 6, phase=0)
    v "Eu preciso desligar. Posso continuar gostando de você e não conseguir conversar agora."
    $ aa_audio_event('w_truth', 'line', 7, phase=0)
    f "Pode."
    $ aa_audio_event('w_truth', 'line', 8, phase=0)
    "Ela desligou primeiro. Não liguei de volta."
    jump w_truth_reply

label w_truth_reply:
    $ aa_node = 'w_truth_reply'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['w_truth_reply'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(7680)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('w_truth_reply')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O café depois da conversa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_truth_coffee', 'sender': 'Vanessa', 'body': 'Eu ainda quero que você venha às quatro. Só não chega fingindo que ontem não aconteceu.', 'outgoing': False})
    $ aa_audio_event('w_truth_reply', 'line', 0, phase=0)
    "Na manhã seguinte, Vanessa escreveu: \"Eu ainda quero que você venha às quatro. Só não chega fingindo que ontem não aconteceu.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar a visita e aceitar conversar no ritmo dela.":
            $ aa_audio_event('w_truth_reply', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'w_truth_reply', 0)
            $ aa_audio_event('w_truth_reply', 'response', 0, 0)
            "Confirmei. Depois me arrumei para ir à aula."
            jump c3_morning
        "Dizer que é melhor terminar.":
            $ aa_audio_event('w_truth_reply', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'w_truth_reply', 1)
            $ aa_audio_event('w_truth_reply', 'response', 0, 1)
            "Respondi que queria terminar. Ela disse que não me esperaria à tarde."
            jump z_bridge

label c3_morning:
    $ aa_node = 'c3_morning'
    $ aa_location = 'Campus de Direito · sala'
    if aa_state['chapter'] < 3:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 3\nO que ficou combinado"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_morning'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(7750)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_morning')
    $ aa_location = 'Campus de Direito · sala'
    $ aa_stage_action = 'O que ficou combinado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_aula at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_aula'
    show screen aa_location_display
    $ aa_audio_event('c3_morning', 'line', 0, phase=0)
    "Na sexta, o professor pediu os trabalhos. Antes de pensar na visita da tarde, precisei abrir o arquivo."
    if aa_matches(aa_state, {'task_done': True}):
        $ aa_audio_event('c3_morning', 'line', 1, phase=0)
        "A minha parte estava no documento. Entregamos. Vanessa guardou o caderno e disse que queria passar o fim de semana sem olhar para aquele título."
    if aa_matches(aa_state, {'task_done': True}):
        $ aa_audio_event('c3_morning', 'line', 2, phase=0)
        f "Eu já tava quase dando nome de gente pra ele."
    if aa_matches(aa_state, {'task_done': True}):
        $ aa_audio_event('c3_morning', 'line', 3, phase=0)
        v "Não. Você vai ter saudade e querer trazer pra casa."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('c3_morning', 'line', 4, phase=0)
        "Minha parte ainda estava incompleta. Marina entregou o que ela e Vanessa tinham feito. O professor pediu que eu mandasse a minha até o fim da manhã, com o atraso registrado."
    if aa_matches(aa_state, {'task_done': False}):
        $ aa_audio_event('c3_morning', 'line', 5, phase=0)
        v "Não foi surpresa. Eu queria que você parasse de dizer que tá tudo pronto quando não tá."
    jump c3_work_gate

label c3_work_gate:
    $ aa_node = 'c3_work_gate'
    $ aa_location = 'Campus de Direito · corredor'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_work_gate'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(7860)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_work_gate')
    $ aa_location = 'Campus de Direito · corredor'
    $ aa_stage_action = 'Antes de ir embora'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_corredor at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_corredor'
    show screen aa_location_display
    $ aa_audio_event('c3_work_gate', 'line', 0, phase=0)
    "No intervalo, abri a mochila. Ainda havia tempo antes da visita."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Encerrar o trabalho já entregue e confirmar a tarde." if aa_matches(aa_state, {'task_done': True}):
            $ aa_audio_event('c3_work_gate', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_work_gate', 0)
            $ aa_audio_event('c3_work_gate', 'response', 0, 0)
            "Guardei a cópia. Depois da última aula, avisei Vanessa que estava a caminho."
            jump c3_arrival
        "Ficar para terminar e entregar minha parte com atraso." if aa_matches(aa_state, {'task_done': False}):
            $ aa_audio_event('c3_work_gate', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_work_gate', 1)
            $ aa_audio_event('c3_work_gate', 'response', 0, 1)
            "Fiquei na biblioteca até enviar. O atraso ficou registrado. Avisei Vanessa que ainda chegaria às quatro, como combinado."
            jump c3_arrival
        "Deixar a entrega incompleta e dizer que não vou ao apartamento." if aa_matches(aa_state, {'task_done': False}):
            $ aa_audio_event('c3_work_gate', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c3_work_gate', 2)
            $ aa_audio_event('c3_work_gate', 'response', 0, 2)
            "Saí da faculdade sem enviar o trabalho e avisei que não iria à tarde."
            jump c3_cancel

label c3_arrival:
    $ aa_node = 'c3_arrival'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_arrival'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8165)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_arrival')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'Às quatro'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sexta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sexta'
    show screen aa_location_display
    $ aa_audio_event('c3_arrival', 'line', 0, phase=0)
    "Depois da aula, passei na moradia, tomei banho e troquei de roupa. Fui ao endereço de Vanessa no horário combinado. Ela abriu a porta e apontou onde eu podia deixar a mochila."
    if aa_matches(aa_state, {'move_status': {'ne': 'done'}}):
        $ aa_audio_event('c3_arrival', 'line', 1, phase=0)
        "Era a primeira vez que entrava ali. A mudança já tinha acabado. A mesa cabia perto da janela, como ela tinha me contado."
    if aa_matches(aa_state, {'move_status': 'done'}):
        $ aa_audio_event('c3_arrival', 'line', 2, phase=0)
        "As caixas abertas tinham sumido. A passagem até a janela estava livre."
    $ aa_audio_event('c3_arrival', 'line', 3, phase=0)
    "Sentamos. Ela trouxe as canecas e abriu o caderno numa lista de coisas para a casa. Tirei o celular para conferir o banco."
    $ aa_audio_event('c3_arrival', 'line', 4, phase=0)
    v "Quero ver o que dá pra comprar agora e o que fica pro mês que vem. Não precisa comprar nada pra mim."
    $ aa_audio_event('c3_arrival', 'line', 5, phase=0)
    f "Eu não ia prometer."
    $ aa_audio_event('c3_arrival', 'line', 6, phase=0)
    v "Ótimo. Já começou melhor."
    if aa_matches(aa_state, {'reservation_explained': True}):
        $ aa_audio_event('c3_arrival', 'line', 7, phase=0)
        v "Eu fiquei pensando no que você me contou. Ainda tô triste. Não quero passar a tarde fingindo, mas também não quero passar só falando do jantar."
    if aa_matches(aa_state, {'reservation_explained': True}):
        $ aa_audio_event('c3_arrival', 'line', 8, phase=0)
        f "A gente pode ir devagar."
    jump c3_money_j

label c3_money_j:
    $ aa_node = 'c3_money_j'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_money_j'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8170)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_money_j')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'O dinheiro de Joãozão'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sexta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sexta'
    show screen aa_location_display
    $ aa_audio_event('c3_money_j', 'line', 0, phase=0)
    "Olhei a lista de transferências antes de fechar o aplicativo."
    if aa_matches(aa_state, {'j_debt_open': True}):
        $ aa_audio_event('c3_money_j', 'line', 1, phase=0)
        "O empréstimo de Joãozão ainda estava aberto. O prazo tinha passado na segunda."
    if aa_matches(aa_state, {'j_debt_status': 'paid'}):
        $ aa_audio_event('c3_money_j', 'line', 2, phase=0)
        "Eu tinha devolvido a Joãozão dentro do prazo. A conversa não tinha cobrança nova."
    if aa_matches(aa_state, {'j_debt_status': 'paid_late'}):
        $ aa_audio_event('c3_money_j', 'line', 3, phase=0)
        "Eu tinha devolvido a Joãozão, mas depois do prazo. O comprovante e o atraso continuavam registrados."
    if aa_matches(aa_state, {'j_debt_status': 'none'}):
        $ aa_audio_event('c3_money_j', 'line', 4, phase=0)
        "Eu não tinha empréstimo de Joãozão. Não havia nada para acertar com ele."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Devolver os R$ 60 agora, sem puxar outro assunto." if aa_matches(aa_state, {'can_repay_j': True}):
            $ aa_audio_event('c3_money_j', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_money_j', 0)
            $ aa_world = aa_fm.repay(aa_world, 'joaozao', in_person='joaozao' in aa_present)
            $ aa_state = aa_financial_state(aa_state, aa_world)
            $ aa_audio_event('c3_money_j', 'response', 0, 0)
            "Enviei os sessenta. Não usei a transferência para perguntar por Yasmin. O comprovante apareceu na tela."
            jump c3_money_v
        "Admitir que ainda não devolvi e manter a dívida registrada." if aa_matches(aa_state, {'j_debt_open': True}):
            $ aa_audio_event('c3_money_j', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_money_j', 1)
            $ aa_audio_event('c3_money_j', 'response', 0, 1)
            "A cobrança continuou aberta. Eu não tinha pago e não mandei uma frase que fingisse o contrário."
            jump c3_money_v
        "Concluir a consulta e voltar à conversa." if aa_matches(aa_state, {'j_debt_open': False}):
            $ aa_audio_event('c3_money_j', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c3_money_j', 2)
            $ aa_audio_event('c3_money_j', 'response', 0, 2)
            "Voltei para a lista que Vanessa tinha aberto."
            jump c3_money_v

label c3_money_v:
    $ aa_node = 'c3_money_v'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_money_v'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8175)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_money_v')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'O dinheiro de Vanessa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sexta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sexta'
    show screen aa_location_display
    $ aa_audio_event('c3_money_v', 'line', 0, phase=0)
    v "Eu separei o dinheiro do mês. Quero conseguir olhar essa lista sem achar que tudo depende de outra pessoa."
    if aa_matches(aa_state, {'v_debt_open': True}):
        $ aa_audio_event('c3_money_v', 'line', 1, phase=0)
        v "Falta você me devolver os sessenta de domingo. Hoje é sexta."
    if aa_matches(aa_state, {'v_debt_open': True}):
        $ aa_audio_event('c3_money_v', 'line', 2, phase=0)
        "Ela não pediu desculpa por cobrar. Ficou com a mão no próprio caderno, esperando."
    if aa_matches(aa_state, {'v_debt_status': 'paid'}):
        $ aa_audio_event('c3_money_v', 'line', 3, phase=0)
        v "Eu já vi a devolução. Obrigada. Agora essa parte tá certa."
    if aa_matches(aa_state, {'v_debt_status': 'none'}):
        $ aa_audio_event('c3_money_v', 'line', 4, phase=0)
        "Não havia empréstimo de Vanessa para devolver. Nosso dinheiro tinha ficado separado na conta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Devolver os R$ 60 pelo banco." if aa_matches(aa_state, {'can_repay_v': True}):
            $ aa_audio_event('c3_money_v', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_money_v', 0)
            $ aa_world = aa_fm.repay(aa_world, 'vanessa', in_person='vanessa' in aa_present)
            $ aa_state = aa_financial_state(aa_state, aa_world)
            $ aa_audio_event('c3_money_v', 'response', 0, 0)
            f "Mandei agora."
            $ aa_audio_event('c3_money_v', 'response', 1, 0)
            v "Recebi. Obrigada."
            $ aa_audio_event('c3_money_v', 'response', 2, 0)
            "Ela conferiu e riscou o item da lista. Não perguntou se eu queria alguma coisa em troca."
            jump c3_afternoon
        "Avisar que ainda não vou devolver e assumir que o combinado está pendente." if aa_matches(aa_state, {'v_debt_open': True}):
            $ aa_audio_event('c3_money_v', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_money_v', 1)
            $ aa_audio_event('c3_money_v', 'response', 0, 1)
            f "Eu ainda não vou conseguir te devolver agora."
            $ aa_audio_event('c3_money_v', 'response', 1, 1)
            v "Eu contei com esse dinheiro. Não quero ter que perguntar todo dia."
            $ aa_audio_event('c3_money_v', 'response', 2, 1)
            f "Eu sei."
            $ aa_audio_event('c3_money_v', 'response', 3, 1)
            v "Então não me pede outra coisa emprestada enquanto isso não estiver resolvido."
            jump c3_afternoon
        "Dizer que ela está estragando a visita por causa de dinheiro." if aa_matches(aa_state, {'v_debt_open': True}):
            $ aa_audio_event('c3_money_v', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c3_money_v', 2)
            $ aa_audio_event('c3_money_v', 'response', 0, 2)
            f "Eu vim aqui e você vai ficar falando de sessenta reais?"
            $ aa_audio_event('c3_money_v', 'response', 1, 2)
            v "Eu emprestei sessenta reais. Não emprestei minha sexta inteira."
            jump c3_money_limit
        "Guardar o telefone e ouvir os planos dela." if aa_matches(aa_state, {'v_debt_open': False}):
            $ aa_audio_event('c3_money_v', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'c3_money_v', 3)
            $ aa_audio_event('c3_money_v', 'response', 0, 3)
            "Guardei o telefone. Vanessa aproximou a lista para eu conseguir ler."
            jump c3_afternoon

label c3_money_limit:
    $ aa_node = 'c3_money_limit'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_money_limit'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8180)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_money_limit')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'A cobrança não é uma briga'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sexta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sexta'
    show screen aa_location_display
    $ aa_audio_event('c3_money_limit', 'line', 0, phase=0)
    v "Eu quero que você fique. Eu também quero meu dinheiro de volta. Não é uma escolha entre os dois."
    $ aa_audio_event('c3_money_limit', 'line', 1, phase=0)
    "Olhei para as canecas. Ela ainda não tinha recolhido a minha."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pedir desculpa por culpá-la e devolver agora." if aa_matches(aa_state, {'can_repay_v': True}):
            $ aa_audio_event('c3_money_limit', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_money_limit', 0)
            $ aa_world = aa_fm.repay(aa_world, 'vanessa', in_person='vanessa' in aa_present)
            $ aa_state = aa_financial_state(aa_state, aa_world)
            $ aa_audio_event('c3_money_limit', 'response', 0, 0)
            f "Você tem razão de cobrar. Desculpa pelo que eu falei. Mandei agora."
            $ aa_audio_event('c3_money_limit', 'response', 1, 0)
            v "Tá. Eu recebi. Só não faz eu me arrepender de perguntar."
            jump c3_afternoon
        "Reconhecer a cobrança e deixar claro que ainda devo.":
            $ aa_audio_event('c3_money_limit', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_money_limit', 1)
            $ aa_audio_event('c3_money_limit', 'response', 0, 1)
            f "Eu ainda devo. Não era pra ter falado desse jeito."
            $ aa_audio_event('c3_money_limit', 'response', 1, 1)
            v "Tá. Eu não vou dizer que recebi se não recebi. Vamos deixar isso claro."
            jump c3_afternoon
        "Insistir que, se gostasse de mim, não cobraria.":
            $ aa_audio_event('c3_money_limit', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c3_money_limit', 2)
            $ aa_audio_event('c3_money_limit', 'response', 0, 2)
            v "Eu gosto de você. Não quero ter que provar pagando. Eu não quero continuar esse namoro. Hoje eu quero que você vá embora."
            jump z_week

label c3_afternoon:
    $ aa_node = 'c3_afternoon'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_afternoon'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8220)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c3_afternoon')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'Uma tarde comum'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sexta_cafe at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sexta_cafe'
    show screen aa_location_display
    $ aa_audio_event('c3_afternoon', 'line', 0, phase=0)
    "Pus o telefone virado para baixo. Vanessa fechou a lista e perguntou se eu queria mais café."
    $ aa_audio_event('c3_afternoon', 'line', 1, phase=0)
    f "Se ainda tiver."
    $ aa_audio_event('c3_afternoon', 'line', 2, phase=0)
    v "Tem. Eu tava esperando você pedir. Não sabia se você ainda queria."
    $ aa_audio_event('c3_afternoon', 'line', 3, phase=0)
    f "Podia ter perguntado."
    $ aa_audio_event('c3_afternoon', 'line', 4, phase=0)
    v "Tô perguntando agora."
    $ aa_audio_event('c3_afternoon', 'line', 5, phase=0)
    "Ri e entreguei a caneca. Vanessa foi buscar mais café. Quando voltou, ficamos conversando à mesa."
    if aa_matches(aa_state, {'money_response': 'pending'}):
        $ aa_audio_event('c3_afternoon', 'line', 6, phase=0)
        "Eu ainda precisava pagar o que devia. Aquela conversa não tinha retirado o valor da conta."
    $ aa_audio_event('c3_afternoon', 'line', 7, phase=0)
    v "A Marina vem amanhã à tarde. Minha mãe passa de manhã. Você quer almoçar aqui antes?"
    $ aa_audio_event('c3_afternoon', 'line', 8, phase=0)
    f "Você quer que eu venha?"
    $ aa_audio_event('c3_afternoon', 'line', 9, phase=0)
    v "Quero. Pro almoço. Depois quero ficar um pouco com a Marina."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Aceitar o almoço e respeitar o resto da tarde delas.":
            $ aa_audio_event('c3_afternoon', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_afternoon', 0)
            $ aa_audio_event('c3_afternoon', 'response', 0, 0)
            f "Quero. Venho pro almoço e depois vou estudar."
            $ aa_audio_event('c3_afternoon', 'response', 1, 0)
            v "Tá. Me ajuda com uma coisa simples. Eu ainda não sei fazer comida pra uma pessoa, imagina duas."
            jump c4_morning
        "Aceitar, mas perguntar se não posso ficar o dia todo.":
            $ aa_audio_event('c3_afternoon', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_afternoon', 1)
            $ aa_audio_event('c3_afternoon', 'response', 0, 1)
            v "Eu queria conversar com ela também."
            $ aa_audio_event('c3_afternoon', 'response', 1, 1)
            f "Eu não atrapalho."
            $ aa_audio_event('c3_afternoon', 'response', 2, 1)
            v "Não é atrapalhar. É ter um tempo com a minha amiga. Vem almoçar, depois a gente combina outra hora."
            $ aa_audio_event('c3_afternoon', 'response', 3, 1)
            "Aceitei o almoço. A resposta sobre a tarde já estava dada."
            jump c4_morning
        "Dizer que prefiro estudar sábado e combinar domingo.":
            $ aa_audio_event('c3_afternoon', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c3_afternoon', 2)
            $ aa_audio_event('c3_afternoon', 'response', 0, 2)
            f "Sábado quero estudar. Posso vir domingo?"
            $ aa_audio_event('c3_afternoon', 'response', 1, 2)
            v "Pode. Depois do almoço, às três."
            $ aa_audio_event('c3_afternoon', 'response', 2, 2)
            "Combinamos. Ela me acompanhou até a porta quando terminei o café."
            jump c4_own

label c3_cancel:
    $ aa_node = 'c3_cancel'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_cancel'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8160)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c3_cancel')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Uma falta avisada'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_cancel_friday', 'sender': 'Vanessa', 'body': 'Você tá cancelando porque não terminou o trabalho ou porque não quer me ver?', 'outgoing': False})
    $ aa_audio_event('c3_cancel', 'line', 0, phase=0)
    "Vanessa perguntou: \"Você tá cancelando porque não terminou o trabalho ou porque não quer me ver?\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Assumir que deixei tudo para depois e pedir para combinar outro dia.":
            $ aa_audio_event('c3_cancel', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_cancel', 0)
            $ aa_audio_event('c3_cancel', 'response', 0, 0)
            "Disse que deixei o trabalho para a última hora. Pedi desculpa por cancelar a visita. Não pedi que ela terminasse o texto."
            jump c3_retry
        "Dizer que ela não precisa saber de tudo que faço.":
            $ aa_audio_event('c3_cancel', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_cancel', 1)
            $ aa_audio_event('c3_cancel', 'response', 0, 1)
            "Ela respondeu que não queria saber de tudo, só da visita que eu tinha acabado de cancelar. Disse que não queria continuar namorando. Li a mensagem sem responder."
            jump z_week

label c3_retry:
    $ aa_node = 'c3_retry'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c3_retry'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(8340)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c3_retry')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Remarcar de verdade'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_audio_event('c3_retry', 'line', 0, phase=0)
    "Terminei o trabalho e enviei com atraso. Só depois voltei à conversa de Vanessa."
    $ aa_chapter_message({'id': 'week_retry_sunday', 'sender': 'Vanessa', 'body': 'Amanhã vou receber a Marina. Domingo às três pode ser. Mas eu não quero cancelar minhas coisas de novo esperando você.', 'outgoing': False})
    $ aa_audio_event('c3_retry', 'line', 1, phase=0)
    "Ela escreveu: \"Amanhã vou receber a Marina. Domingo às três pode ser. Mas eu não quero cancelar minhas coisas de novo esperando você.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar domingo às três e cumprir esse novo combinado.":
            $ aa_audio_event('c3_retry', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c3_retry', 0)
            $ aa_audio_event('c3_retry', 'response', 0, 0)
            "Confirmei. Deixei o horário anotado no caderno."
            jump c4_own
        "Recusar o horário e dizer que prefiro terminar.":
            $ aa_audio_event('c3_retry', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c3_retry', 1)
            $ aa_audio_event('c3_retry', 'response', 0, 1)
            "Disse que queria terminar. Ela respondeu que não me esperaria no domingo."
            jump z_week

label c4_morning:
    $ aa_node = 'c4_morning'
    $ aa_location = 'Quarto de Feka'
    if aa_state['chapter'] < 4:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 4\nO primeiro fim de semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_morning'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9280)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c4_morning')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O primeiro fim de semana'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('c4_morning', 'line', 0, phase=0)
    "No sábado, acordei sem o despertador. Tomei café na cozinha compartilhada e voltei para o quarto."
    $ aa_audio_event('c4_morning', 'line', 1, phase=0)
    "Separei o caderno para estudar mais tarde. O almoço era na casa de Vanessa; a tarde, ela tinha combinado com Marina."
    $ aa_chapter_message({'id': 'week_saturday_ready', 'sender': 'Vanessa', 'body': 'Minha mãe acabou de ir. Pode vir perto do meio-dia. O almoço vai ser uma experiência.', 'outgoing': False})
    $ aa_audio_event('c4_morning', 'line', 2, phase=0)
    "Vanessa escreveu: \"Minha mãe acabou de ir. Pode vir perto do meio-dia. O almoço vai ser uma experiência.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Avisar quando vou sair e perguntar se falta alguma coisa.":
            $ aa_audio_event('c4_morning', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_morning', 0)
            $ aa_audio_event('c4_morning', 'response', 0, 0)
            "Perguntei se precisava levar algo. Ela disse que já tinha comprado tudo e que precisava de alguém para lavar a salada."
            $ aa_audio_event('c4_morning', 'response', 1, 0)
            f "Essa parte eu consigo."
            $ aa_audio_event('c4_morning', 'response', 2, 0)
            v "Eu também acho. Por isso escolhi."
            jump c4_cook
        "Confirmar o almoço e deixar o caderno pronto para a volta.":
            $ aa_audio_event('c4_morning', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_morning', 1)
            $ aa_audio_event('c4_morning', 'response', 0, 1)
            "Confirmei o horário. Marquei a página onde queria continuar quando voltasse e guardei a caneta."
            jump c4_cook

label c4_cook:
    $ aa_node = 'c4_cook'
    $ aa_location = 'Apartamento de Vanessa · cozinha'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_cook'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9350)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_cook')
    $ aa_location = 'Apartamento de Vanessa · cozinha'
    $ aa_stage_action = 'Preparar o almoço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_cozinha'
    show screen aa_location_display
    $ aa_audio_event('c4_cook', 'line', 0, phase=0)
    "Avisei antes de sair e fui a pé. Vanessa abriu a porta, pegou minha mochila e indicou a cadeira onde podia deixá-la."
    $ aa_audio_event('c4_cook', 'line', 1, phase=0)
    "Lavei as mãos. Ela me passou os tomates e ficou junto da panela. Não havia mais caixa entre a geladeira e a mesa."
    $ aa_audio_event('c4_cook', 'line', 2, phase=0)
    v "Eu fiz arroz demais."
    $ aa_audio_event('c4_cook', 'line', 3, phase=0)
    f "Dá pra guardar."
    $ aa_audio_event('c4_cook', 'line', 4, phase=0)
    v "Dá pra abrir um restaurante."
    $ aa_audio_event('c4_cook', 'line', 5, phase=0)
    "Olhei dentro da panela. Dei razão a ela e voltei para a pia."
    $ aa_audio_event('c4_cook', 'line', 6, phase=0)
    v "Minha mãe perguntou se eu queria que ela fizesse. Eu disse que conseguia."
    $ aa_audio_event('c4_cook', 'line', 7, phase=0)
    f "E consegue."
    $ aa_audio_event('c4_cook', 'line', 8, phase=0)
    v "Espera comer antes de falar isso."
    $ aa_audio_event('c4_cook', 'line', 9, phase=0)
    "Lavei os tomates e cortei a salada. Vanessa baixou o fogo e pediu que eu levasse os pratos para a mesa."
    jump c4_lunch

label c4_lunch:
    $ aa_node = 'c4_lunch'
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_lunch'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9390)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_lunch')
    $ aa_location = 'Apartamento de Vanessa · mesa'
    $ aa_stage_action = 'Arroz para mais dois'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_almoco at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_almoco'
    show screen aa_location_display
    $ aa_audio_event('c4_lunch', 'line', 0, phase=0)
    "Sentamos depois de apagar o fogo. Vanessa provou antes de mim e ficou esperando minha primeira garfada."
    $ aa_audio_event('c4_lunch', 'line', 1, phase=0)
    f "Tá bom."
    $ aa_audio_event('c4_lunch', 'line', 2, phase=0)
    v "Bom mesmo ou bom de namorado?"
    $ aa_audio_event('c4_lunch', 'line', 3, phase=0)
    f "Tá um pouco sem sal."
    $ aa_audio_event('c4_lunch', 'line', 4, phase=0)
    "Ela provou outra vez, fez uma careta e pegou o saleiro."
    $ aa_audio_event('c4_lunch', 'line', 5, phase=0)
    v "Tá. Bom de namorado."
    $ aa_audio_event('c4_lunch', 'line', 6, phase=0)
    "Rimos. Ela pôs sal no próprio prato e me passou. Continuei comendo."
    $ aa_audio_event('c4_lunch', 'line', 7, phase=0)
    v "Eu gostei de fazer isso. Mesmo com arroz pra mais dois."
    $ aa_audio_event('c4_lunch', 'line', 8, phase=0)
    f "Semana que vem eu faço uma coisa."
    $ aa_audio_event('c4_lunch', 'line', 9, phase=0)
    v "Antes me fala o que é. Preciso saber se compro pão."
    $ aa_audio_event('c4_lunch', 'line', 10, phase=0)
    "Falamos da comida que cada um sabia fazer. A lista dela era maior. A minha dependia bastante de uma frigideira."
    $ aa_audio_event('c4_lunch', 'line', 11, phase=0)
    "Depois de comer, guardamos o que sobrou em dois potes. Lavei a louça enquanto ela secava a mesa."
    jump c4_depart

label c4_depart:
    $ aa_node = 'c4_depart'
    $ aa_location = 'Apartamento de Vanessa · porta'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_depart'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9490)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_depart')
    $ aa_location = 'Apartamento de Vanessa · porta'
    $ aa_stage_action = 'A tarde de Vanessa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sabado_porta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sabado_porta'
    show screen aa_location_display
    $ aa_audio_event('c4_depart', 'line', 0, phase=0)
    "Marina avisou que estava saindo de casa. Peguei minha mochila. Vanessa veio comigo até a porta."
    $ aa_audio_event('c4_depart', 'line', 1, phase=0)
    v "Gostei que você veio."
    $ aa_audio_event('c4_depart', 'line', 2, phase=0)
    f "Eu também gostei."
    $ aa_audio_event('c4_depart', 'line', 3, phase=0)
    "Ela puxou a própria manga. Ficou um instante segurando a maçaneta."
    $ aa_audio_event('c4_depart', 'line', 4, phase=0)
    v "Você não tá indo chateado, né?"
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que gostei do almoço e que elas podem aproveitar a tarde.":
            $ aa_audio_event('c4_depart', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_depart', 0)
            $ aa_audio_event('c4_depart', 'response', 0, 0)
            f "Não. A gente combinou isso. Vou estudar um pouco."
            $ aa_audio_event('c4_depart', 'response', 1, 0)
            v "Tá. Domingo você quer vir de novo? Às três."
            $ aa_audio_event('c4_depart', 'response', 2, 0)
            f "Quero."
            $ aa_audio_event('c4_depart', 'response', 3, 0)
            "Ela se aproximou, me beijou e abriu a porta. Desci sem esperar que pedisse outra vez para eu ficar."
            jump c4_own
        "Dizer que me sinto deixado de lado e pedir que cancele com Marina.":
            $ aa_audio_event('c4_depart', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_depart', 1)
            $ aa_audio_event('c4_depart', 'response', 0, 1)
            f "Parece que eu tenho hora pra sair."
            $ aa_audio_event('c4_depart', 'response', 1, 1)
            v "A gente combinou antes. Ela também é minha amiga."
            $ aa_audio_event('c4_depart', 'response', 2, 1)
            f "Eu podia ficar."
            $ aa_audio_event('c4_depart', 'response', 3, 1)
            "Vanessa baixou os olhos para o telefone. Marina ainda estava a caminho."
            jump c4_cancel_friend
        "Dizer que quero ficar mais, mas aceitar o horário combinado.":
            $ aa_audio_event('c4_depart', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_depart', 2)
            $ aa_audio_event('c4_depart', 'response', 0, 2)
            f "Eu queria ficar mais. Mas não tô chateado com você. Vocês combinaram."
            $ aa_audio_event('c4_depart', 'response', 1, 2)
            v "Eu fico com medo de você ir e não querer voltar."
            $ aa_audio_event('c4_depart', 'response', 2, 2)
            f "Eu quero voltar. Domingo às três serve?"
            $ aa_audio_event('c4_depart', 'response', 3, 2)
            v "Serve."
            $ aa_audio_event('c4_depart', 'response', 4, 2)
            "Ela me beijou antes de eu sair. Não precisou cancelar a tarde para me ouvir dizer domingo."
            jump c4_own

label c4_cancel_friend:
    $ aa_node = 'c4_cancel_friend'
    $ aa_location = 'Apartamento de Vanessa · porta'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_cancel_friend'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9495)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_cancel_friend')
    $ aa_location = 'Apartamento de Vanessa · porta'
    $ aa_stage_action = 'Desmarcar com outra pessoa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sabado_porta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sabado_porta'
    show screen aa_location_display
    $ aa_audio_event('c4_cancel_friend', 'line', 0, phase=0)
    v "Se você vai ficar assim, eu posso pedir pra ela vir outro dia."
    $ aa_audio_event('c4_cancel_friend', 'line', 1, phase=0)
    "Ela começou a digitar e parou. A mensagem ainda não tinha sido enviada."
    $ aa_audio_event('c4_cancel_friend', 'line', 2, phase=0)
    v "Eu não queria desmarcar. Ela separou a tarde."
    $ aa_audio_event('c4_cancel_friend', 'line', 3, phase=0)
    "Minha mochila continuava no ombro. Eu podia ir embora sem transformar aquilo num castigo."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Pedir desculpa pela pressão e manter a visita de Marina.":
            $ aa_audio_event('c4_cancel_friend', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_cancel_friend', 0)
            $ aa_audio_event('c4_cancel_friend', 'response', 0, 0)
            f "Não desmarca. Eu pedi sabendo que vocês tinham combinado. Desculpa."
            $ aa_audio_event('c4_cancel_friend', 'response', 1, 0)
            v "Tá. Eu quero ver você também. Só não quero ter que escolher toda vez."
            $ aa_audio_event('c4_cancel_friend', 'response', 2, 0)
            f "Domingo às três?"
            $ aa_audio_event('c4_cancel_friend', 'response', 3, 0)
            v "Pode ser."
            $ aa_audio_event('c4_cancel_friend', 'response', 4, 0)
            "Ela apagou a frase. Dei um beijo nela e fui para a moradia."
            jump c4_own
        "Aceitar que ela desmarque e ficar no lugar da amiga.":
            $ aa_audio_event('c4_cancel_friend', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_cancel_friend', 1)
            $ aa_audio_event('c4_cancel_friend', 'response', 0, 1)
            f "Se você quiser, a gente fica junto."
            $ aa_audio_event('c4_cancel_friend', 'response', 1, 1)
            "Ela mandou a mensagem. Marina respondeu que estava na esquina e que voltaria para casa. Vanessa deixou o telefone na mesa."
            jump c4_stay
        "Dizer que prefiro terminar se não posso ficar.":
            $ aa_audio_event('c4_cancel_friend', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_cancel_friend', 2)
            $ aa_audio_event('c4_cancel_friend', 'response', 0, 2)
            f "Então é melhor a gente terminar."
            $ aa_audio_event('c4_cancel_friend', 'response', 1, 2)
            v "Por causa de uma tarde?"
            $ aa_audio_event('c4_cancel_friend', 'response', 2, 2)
            f "Eu não quero continuar."
            $ aa_audio_event('c4_cancel_friend', 'response', 3, 2)
            "Ela afastou a mão da maçaneta. Saí. Não esperei que corresse atrás de mim."
            jump z_week

label c4_stay:
    $ aa_node = 'c4_stay'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_stay'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9540)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_stay')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'A tarde desmarcada'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_stay', 'line', 0, phase=0)
    "Guardei a mochila de novo. Sentamos no sofá. Vanessa trouxe água, embora ainda houvesse dois copos limpos na mesa."
    $ aa_audio_event('c4_stay', 'line', 1, phase=0)
    v "A Marina ficou chateada."
    $ aa_audio_event('c4_stay', 'line', 2, phase=0)
    f "Você explica depois."
    $ aa_audio_event('c4_stay', 'line', 3, phase=0)
    v "Eu já expliquei. Falei que ia ficar com você."
    $ aa_audio_event('c4_stay', 'line', 4, phase=0)
    "Eu tinha conseguido ficar. Esperei que ela parecesse contente do mesmo jeito que no almoço."
    $ aa_audio_event('c4_stay', 'line', 5, phase=0)
    v "Escolhe alguma coisa pra assistir."
    $ aa_audio_event('c4_stay', 'line', 6, phase=0)
    "Escolhi. Vimos metade sem conversar muito. Mais tarde, ela perguntou se eu voltaria no domingo."
    $ aa_audio_event('c4_stay', 'line', 7, phase=0)
    f "Volto. Às três."
    $ aa_present = ()
    call aa_advance_clock(9780)
    $ aa_present = ()
    $ aa_audio_event('c4_stay', 'line', 8, phase=0)
    $ aa_location = 'Quarto de Feka'
    $ aa_audio_ambient('AMB01')
    $ aa_stage_action = 'Volta à moradia no começo da noite.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    "Voltei para a moradia no começo da noite. Vanessa mandou boa noite antes de eu dormir."
    jump c4_sunday

label c4_own:
    $ aa_node = 'c4_own'
    $ aa_location = 'Quarto de Feka'
    if aa_state['chapter'] < 4:
        window hide
        hide screen aa_location_display
        hide screen aa_phone_view
        $ aa_phone_active = False
        centered "Capítulo 4\nO primeiro fim de semana"
        window auto
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_own'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9600)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c4_own')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Uma tarde na moradia'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    if aa_matches(aa_state, {'weekend_plan': 'sunday'}):
        $ aa_audio_event('c4_own', 'line', 0, phase=0)
        "No sábado, fiquei na moradia. A visita estava combinada para domingo, às três."
    if aa_matches(aa_state, {'weekend_plan': {'ne': 'sunday'}}):
        $ aa_audio_event('c4_own', 'line', 1, phase=0)
        "Voltei do almoço e sentei à escrivaninha. Vanessa estava com Marina. Eu tinha uma leitura para terminar."
    $ aa_audio_event('c4_own', 'line', 2, phase=0)
    "Um dos moradores perguntou se eu ia usar a panela. Eu disse que não e lembrei da pia. Lavei antes de voltar para o quarto."
    $ aa_audio_event('c4_own', 'line', 3, phase=0)
    "Consegui terminar um capítulo. O telefone ficou ao lado do caderno, sem precisar tocar para eu continuar lendo."
    $ aa_present = ()
    call aa_advance_clock(9790)
    $ aa_chapter_message({'id': 'week_saturday_night', 'sender': 'Vanessa', 'body': 'A Marina foi embora. A gente falou muito e estudou quase nada. Amanhã às três continua?', 'outgoing': False})
    $ aa_audio_event('c4_own', 'line', 4, phase=0)
    $ aa_location = 'Quarto de Feka'
    $ aa_audio_ambient('AMB01')
    $ aa_stage_action = 'A mensagem chega depois do estudo; quarto já à noite.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    "No começo da noite, Vanessa mandou: \"A Marina foi embora. A gente falou muito e estudou quase nada. Amanhã às três continua?\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Confirmar o encontro de domingo.":
            $ aa_audio_event('c4_own', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_own', 0)
            $ aa_audio_event('c4_own', 'response', 0, 0)
            "Confirmei e contei que tinha terminado a leitura. Ela mandou um áudio reclamando da mesma matéria. Ouvi antes de ir jantar."
            jump c4_sunday
        "Cobrar por que ela passou a tarde sem falar comigo.":
            $ aa_audio_event('c4_own', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_own', 1)
            $ aa_audio_event('c4_own', 'response', 0, 1)
            "Escrevi que ela tinha sumido. Vanessa respondeu que estava com Marina, como tinha avisado."
            jump c4_night_call

label c4_night_call:
    $ aa_node = 'c4_night_call'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_night_call'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(9800)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('c4_night_call')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'Responder sem vigiar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    $ aa_chapter_message({'id': 'week_saturday_limit', 'sender': 'Vanessa', 'body': 'Eu te avisei da tarde. Não quero ficar olhando o celular pra saber se você vai ficar bravo.', 'outgoing': False})
    $ aa_audio_event('c4_night_call', 'line', 0, phase=0)
    "Ela escreveu: \"Eu te avisei da tarde. Não quero ficar olhando o celular pra saber se você vai ficar bravo.\""
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Reconhecer que ela tinha avisado e manter o encontro.":
            $ aa_audio_event('c4_night_call', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_night_call', 0)
            $ aa_audio_event('c4_night_call', 'response', 0, 0)
            "Disse que ela tinha razão. Não pedi uma lista do que tinha feito. Confirmamos o domingo."
            jump c4_sunday
        "Dizer que só preciso de uma mensagem sempre que ela sair.":
            $ aa_audio_event('c4_night_call', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_night_call', 1)
            $ aa_audio_event('c4_night_call', 'response', 0, 1)
            "Vanessa respondeu que tentaria avisar. Depois perguntou se eu ainda ia no domingo. Confirmei."
            jump c4_sunday
        "Encerrar o namoro na conversa.":
            $ aa_audio_event('c4_night_call', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_night_call', 2)
            $ aa_audio_event('c4_night_call', 'response', 0, 2)
            "Disse que queria terminar. Ela respondeu que não me esperaria no dia seguinte."
            jump z_week

label c4_sunday:
    $ aa_node = 'c4_sunday'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_sunday'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(10985)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_sunday')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'Domingo às três'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_sunday', 'line', 0, phase=0)
    "No domingo, avisei antes de sair. Vanessa abriu a porta poucos minutos depois das três. Deixei a mochila na cadeira e sentei no sofá enquanto ela buscava água."
    $ aa_audio_event('c4_sunday', 'line', 1, phase=0)
    "Ela sentou ao meu lado. O sofá era pequeno; ainda assim, havia espaço entre nós."
    if aa_matches(aa_state, {'weekend_cancelled_friend': True}):
        $ aa_audio_event('c4_sunday', 'line', 2, phase=0)
        v "Eu falei com Marina. A gente vai tentar outra tarde. Eu não gostei de ter desmarcado daquele jeito."
    if aa_matches(aa_state, {'weekend_cancelled_friend': True}):
        $ aa_audio_event('c4_sunday', 'line', 3, phase=0)
        f "Ela tá brava comigo?"
    if aa_matches(aa_state, {'weekend_cancelled_friend': True}):
        $ aa_audio_event('c4_sunday', 'line', 4, phase=0)
        v "Ela combinou comigo. Eu que tive que pedir desculpa."
    if aa_matches(aa_state, {'weekend_cancelled_friend': False}):
        $ aa_audio_event('c4_sunday', 'line', 5, phase=0)
        v "Foi bom receber a Marina. Eu tava precisando falar de outra coisa além de mudança e namoro."
    if aa_matches(aa_state, {'weekend_cancelled_friend': False}):
        $ aa_audio_event('c4_sunday', 'line', 6, phase=0)
        f "Vocês ficaram muito tempo?"
    if aa_matches(aa_state, {'weekend_cancelled_friend': False}):
        $ aa_audio_event('c4_sunday', 'line', 7, phase=0)
        v "Até ela precisar ir. Eu gostei."
    $ aa_audio_event('c4_sunday', 'line', 8, phase=0)
    v "E você? Conseguiu fazer suas coisas?"
    if aa_matches(aa_state, {'weekend_studied': True}):
        $ aa_audio_event('c4_sunday', 'line', 9, phase=0)
        "Contei da leitura e da panela que finalmente tinha lavado. Vanessa riu antes de eu terminar."
    if aa_matches(aa_state, {'weekend_studied': False}):
        $ aa_audio_event('c4_sunday', 'line', 10, phase=0)
        "Disse que tinha acabado voltando sem estudar. Ela olhou o caderno na mochila e disse que eu ainda podia ler um pouco quando chegasse em casa."
    $ aa_audio_event('c4_sunday', 'line', 11, phase=0)
    v "Então essa semana rendeu."
    jump c4_debts

label c4_debts:
    $ aa_node = 'c4_debts'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_debts'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(10995)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_debts')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'O que ainda está em aberto'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_debts', 'line', 0, phase=0)
    "Antes de guardar o telefone, abri o banco e conferi as transferências."
    if aa_matches(aa_state, {'j_debt_open': True}):
        $ aa_audio_event('c4_debts', 'line', 1, phase=0)
        "Eu ainda devia a Joãozão. Devolver agora não mudaria o atraso, mas encerraria o empréstimo."
    if aa_matches(aa_state, {'v_debt_open': True}):
        $ aa_audio_event('c4_debts', 'line', 2, phase=0)
        v "Você conseguiu ver o dinheiro que falta? Era pra sexta."
    if aa_matches(aa_state, {'v_debt_open': True}):
        $ aa_audio_event('c4_debts', 'line', 3, phase=0)
        "Eu ainda não tinha devolvido o que Vanessa completou no jantar."
    if aa_matches(aa_state, {'j_debt_open': False, 'v_debt_open': False}):
        $ aa_audio_event('c4_debts', 'line', 4, phase=0)
        "Não havia empréstimo em aberto. Guardei o telefone depois de conferir."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Devolver a Joãozão agora." if aa_matches(aa_state, {'can_repay_j': True}):
            $ aa_audio_event('c4_debts', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_debts', 0)
            $ aa_world = aa_fm.repay(aa_world, 'joaozao', in_person='joaozao' in aa_present)
            $ aa_state = aa_financial_state(aa_state, aa_world)
            $ aa_audio_event('c4_debts', 'response', 0, 0)
            "Enviei o valor. O aplicativo confirmou. Não havia razão para manter a conversa aberta depois disso."
            jump c4_debts_done
        "Devolver a Vanessa agora e reconhecer o atraso." if aa_matches(aa_state, {'can_repay_v': True}):
            $ aa_audio_event('c4_debts', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_debts', 1)
            $ aa_world = aa_fm.repay(aa_world, 'vanessa', in_person='vanessa' in aa_present)
            $ aa_state = aa_financial_state(aa_state, aa_world)
            $ aa_audio_event('c4_debts', 'response', 0, 1)
            f "Eu atrasei. Mandei agora. Desculpa por deixar você esperando."
            $ aa_audio_event('c4_debts', 'response', 1, 1)
            v "Recebi. Obrigada. Da próxima vez, fala antes do dia passar."
            jump c4_debts_done
        "Assumir que a dívida continua e não pedir novo empréstimo." if aa_matches(aa_state, {'j_debt_open': True}):
            $ aa_audio_event('c4_debts', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_debts', 2)
            $ aa_audio_event('c4_debts', 'response', 0, 2)
            "Fechei o banco sem fazer a transferência. A pendência continuava sendo minha."
            jump c4_debts_done
        "Assumir que ainda não devolvi a Vanessa." if aa_matches(aa_state, {'v_debt_open': True}):
            $ aa_audio_event('c4_debts', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'c4_debts', 3)
            $ aa_audio_event('c4_debts', 'response', 0, 3)
            f "Ainda tá pendente. Eu sei que você contou com esse dinheiro."
            $ aa_audio_event('c4_debts', 'response', 1, 3)
            v "Tá. Eu não vou te emprestar mais. Não quero que vire isso toda semana."
            jump c4_debts_done
        "Guardar o celular e continuar a visita." if aa_matches(aa_state, {'j_debt_open': False, 'v_debt_open': False}):
            $ aa_audio_event('c4_debts', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'c4_debts', 4)
            jump c4_debts_done

label c4_debts_done:
    $ aa_node = 'c4_debts_done'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_debts_done'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11005)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_debts_done')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'O domingo continua'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_debts_done', 'line', 0, phase=0)
    "Deixei o aparelho de lado. Vanessa pôs o copo na mesinha. Ficou olhando para mim por um instante."
    $ aa_audio_event('c4_debts_done', 'line', 1, phase=0)
    v "Eu queria ficar perto um pouco. Sem decidir a semana toda agora."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Perguntar se ela quer encostar e oferecer o ombro.":
            $ aa_audio_event('c4_debts_done', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_debts_done', 0)
            $ aa_audio_event('c4_debts_done', 'response', 0, 0)
            f "Quer encostar aqui?"
            $ aa_audio_event('c4_debts_done', 'response', 1, 0)
            v "Quero."
            $ aa_audio_event('c4_debts_done', 'response', 2, 0)
            "Afastei o braço para ela se ajeitar."
            jump c4_close
        "Dizer que quero conversar antes de nos aproximarmos.":
            $ aa_audio_event('c4_debts_done', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_debts_done', 1)
            $ aa_audio_event('c4_debts_done', 'response', 0, 1)
            f "Quero ficar com você. Só queria falar uma coisa antes."
            $ aa_audio_event('c4_debts_done', 'response', 1, 1)
            v "Tá. Pode falar."
            jump c4_talk
        "Dizer que hoje prefiro ficar sentado assim, mas continuar a visita.":
            $ aa_audio_event('c4_debts_done', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_debts_done', 2)
            $ aa_audio_event('c4_debts_done', 'response', 0, 2)
            f "Hoje eu prefiro ficar assim. Não quero ir embora."
            $ aa_audio_event('c4_debts_done', 'response', 1, 2)
            v "Tá. Eu perguntei porque queria. Você pode dizer."
            $ aa_audio_event('c4_debts_done', 'response', 2, 2)
            "Ela deixou o copo na mesa e virou um pouco o corpo para mim."
            jump c4_talk

label c4_close:
    $ aa_node = 'c4_close'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_close'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11010)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_close')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'Ficar perto'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa'
    show screen aa_location_display
    $ aa_audio_event('c4_close', 'line', 0, phase=0)
    "Vanessa encostou a cabeça no meu ombro e ajeitou as pernas no sofá. Pousei minha mão perto da dela. Ela entrelaçou os dedos nos meus."
    $ aa_audio_event('c4_close', 'line', 1, phase=0)
    v "Assim tá bom."
    $ aa_audio_event('c4_close', 'line', 2, phase=0)
    f "Tá."
    $ aa_audio_event('c4_close', 'line', 3, phase=0)
    "Ficamos quietos por um tempo. Eu conseguia ouvir alguém arrastando uma cadeira no andar de cima."
    $ aa_audio_event('c4_close', 'line', 4, phase=0)
    v "Eles também tão mudando, pelo jeito."
    $ aa_audio_event('c4_close', 'line', 5, phase=0)
    f "Ou a mesa nunca fica boa."
    $ aa_audio_event('c4_close', 'line', 6, phase=0)
    "Ela riu sem levantar a cabeça."
    jump c4_plan

label c4_talk:
    $ aa_node = 'c4_talk'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_talk'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11010)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_talk')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'Sem procurar a resposta certa'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_talk', 'line', 0, phase=0)
    v "Você tá pensando em terminar?"
    $ aa_audio_event('c4_talk', 'line', 1, phase=0)
    "A pergunta veio depressa. Ela tinha aceitado esperar eu falar, mas já estava tentando se preparar para a resposta."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Dizer que quero continuar e combinar o próximo encontro sem prometer tudo.":
            $ aa_audio_event('c4_talk', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_talk', 0)
            $ aa_audio_event('c4_talk', 'response', 0, 0)
            f "Não quero terminar. Quero continuar vendo você. Só não quero prometer uma semana inteira sem saber se consigo."
            $ aa_audio_event('c4_talk', 'response', 1, 0)
            v "Eu fico com medo quando você fala assim. Mas é pior esperar uma coisa que você prometeu e não vem."
            $ aa_audio_event('c4_talk', 'response', 2, 0)
            f "A gente combina um dia."
            $ aa_audio_event('c4_talk', 'response', 3, 0)
            v "Tá."
            jump c4_plan
        "Dizer que nunca vou deixar que ela fique sozinha.":
            $ aa_audio_event('c4_talk', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_talk', 1)
            $ aa_audio_event('c4_talk', 'response', 0, 1)
            f "Não vou deixar você sozinha. Você sempre vai poder contar comigo."
            $ aa_audio_event('c4_talk', 'response', 1, 1)
            v "Eu quero muito acreditar nisso."
            $ aa_audio_event('c4_talk', 'response', 2, 1)
            "Ela se aproximou um pouco. Eu ainda não tinha dito a que horas precisava ir."
            jump c4_plan
        "Dizer que não quero continuar o namoro.":
            $ aa_audio_event('c4_talk', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_talk', 2)
            $ aa_audio_event('c4_talk', 'response', 0, 2)
            f "Eu não quero continuar o namoro."
            $ aa_audio_event('c4_talk', 'response', 1, 2)
            v "Eu queria que você dissesse outra coisa. Mas eu não vou pedir pra você falar que sim."
            $ aa_audio_event('c4_talk', 'response', 2, 2)
            "Peguei minha mochila. Vanessa ficou junto ao sofá enquanto eu saía."
            jump z_week

label c4_plan:
    $ aa_node = 'c4_plan'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_plan'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11050)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_plan')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'A próxima semana'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_plan', 'line', 0, phase=0)
    "Vanessa sentou direita para alcançar o copo. Aproveitei para olhar o relógio. Eu precisava voltar antes do jantar na moradia."
    $ aa_audio_event('c4_plan', 'line', 1, phase=0)
    v "Na terça eu quero passar na minha mãe. Você pode vir na quarta, depois da aula?"
    $ aa_audio_event('c4_plan', 'line', 2, phase=0)
    f "Posso."
    $ aa_audio_event('c4_plan', 'line', 3, phase=0)
    v "Tá. E a gente se vê na faculdade antes."
    if aa_matches(aa_state, {'daily_promise': True}):
        $ aa_audio_event('c4_plan', 'line', 4, phase=0)
        v "Quando você diz sempre, eu fico esperando mesmo. Não sei quando posso contar."
    if aa_matches(aa_state, {'daily_promise': True}):
        $ aa_audio_event('c4_plan', 'line', 5, phase=0)
        "Eu precisava dizer o que podia cumprir."
    if aa_matches(aa_state, {'relationship_phase': 'repair'}):
        $ aa_audio_event('c4_plan', 'line', 6, phase=0)
        v "Sobre o que você contou do jantar... eu ainda penso nisso. Hoje foi bom. Eu consigo gostar de hoje sem ter esquecido."
    if aa_matches(aa_state, {'chapter_origin': 'e08', 'public_corrected': False}):
        $ aa_audio_event('c4_plan', 'line', 7, phase=0)
        v "Eu também queria que você tirasse aquela publicação. Não quero aparecer dizendo que foi uma noite ótima."
    $ aa_state = aa_financial_state(aa_state, aa_world)
    menu:
        "Combinar quarta e corrigir as promessas que não consigo cumprir.":
            $ aa_audio_event('c4_plan', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c4_plan', 0)
            $ aa_audio_event('c4_plan', 'response', 0, 0)
            f "Quarta eu consigo. Nos outros dias a gente pode se falar, mas eu não vou prometer estar aqui todos os dias."
            $ aa_audio_event('c4_plan', 'response', 1, 0)
            v "Tá. Eu prefiro saber."
            $ aa_audio_event('c4_plan', 'response', 2, 0)
            "Anotei o horário. Ela contou o que queria fazer na casa da mãe."
            jump c4_next
        "Prometer que vou largar qualquer coisa quando ela precisar.":
            $ aa_audio_event('c4_plan', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c4_plan', 1)
            $ aa_audio_event('c4_plan', 'response', 0, 1)
            f "Se você precisar, eu largo o que estiver fazendo e venho."
            $ aa_audio_event('c4_plan', 'response', 1, 1)
            v "Mesmo?"
            $ aa_audio_event('c4_plan', 'response', 2, 1)
            f "Mesmo."
            $ aa_audio_event('c4_plan', 'response', 3, 1)
            "Ela guardou o telefone sem anotar só a quarta. Eu tinha dado uma resposta maior do que a pergunta."
            jump e17
        "Corrigir a publicação e a versão que contei ao colega." if aa_matches(aa_state, {'chapter_origin': 'e08', 'public_story_corrected': False}):
            $ aa_audio_event('c4_plan', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c4_plan', 2)
            $ aa_chapter_phone_action('withdraw_post')
            $ aa_audio_event('c4_plan', 'response', 0, 2)
            f "Eu também falei pra um colega que você tava estranha. Sem contar o que eu tinha feito."
            $ aa_audio_event('c4_plan', 'response', 1, 2)
            v "Então ele acha que eu estraguei o jantar?"
            $ aa_audio_event('c4_plan', 'response', 2, 2)
            f "Eu deixei ele achar. Vou corrigir."
            $ aa_audio_event('c4_plan', 'response', 3, 2)
            "Deixei o perfil sem a publicação. Escrevi ao colega que tinha sido injusto com Vanessa e que o problema daquela noite não tinha começado com ela."
            $ aa_audio_event('c4_plan', 'response', 4, 2)
            v "Eu não gostei de saber disso agora. Mas obrigada por não deixar daquele jeito."
            $ aa_audio_event('c4_plan', 'response', 5, 2)
            "Não pedi que agradecesse mais. A quarta continuava combinada; a conversa tinha ficado menos leve."
            jump c4_next

label c4_next:
    $ aa_node = 'c4_next'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['c4_next'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11060)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('c4_next')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'Fechar o domingo'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('c4_next', 'line', 0, phase=0)
    "Vanessa terminou a água. Tínhamos mais um pouco de tempo antes de eu precisar ir."
    if aa_matches(aa_state, {'relationship_phase': 'repair'}):
        jump e16
    if aa_matches(aa_state, {'j_debt_open': True}):
        jump e16
    if aa_matches(aa_state, {'v_debt_open': True}):
        jump e16
    if aa_matches(aa_state, {'chapter_origin': 'e08', 'public_corrected': False}):
        jump e16
    if aa_matches(aa_state, {'chapter_origin': 'e08', 'public_story_corrected': False}):
        jump e16
    if aa_matches(aa_state, {'week_pressure': {'gte': 2}}):
        jump e16
    if aa_matches(aa_state, {'weekend_cancelled_friend': True}):
        jump e16
    jump e15

label e15:
    $ aa_node = 'e15'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e15'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11080)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('e15')
    if aa_matches(aa_state, {'weekend_close': False}):
        $ aa_location = 'Apartamento de Vanessa · sofá'
        $ aa_stage_action = 'Domingo em casa'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg16_sofa_distancia'
    else:
        $ aa_location = 'Apartamento de Vanessa · sofá'
        $ aa_stage_action = 'Domingo em casa'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg16_sofa at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg16_sofa'
    show screen aa_location_display
    if aa_matches(aa_state, {'weekend_close': True}):
        $ aa_audio_event('e15', 'line', 0, phase=0)
        "Vanessa voltou a encostar no meu ombro e começou a contar uma história da escola."
    if aa_matches(aa_state, {'weekend_close': False}):
        $ aa_audio_event('e15', 'line', 1, phase=0)
        "Vanessa se ajeitou no sofá e começou a contar uma história da escola. Fiquei virado para ela, ouvindo."
    $ aa_audio_event('e15', 'line', 2, phase=0)
    v "Eu fingia que sabia jogar vôlei só pra ficar com minhas amigas."
    $ aa_audio_event('e15', 'line', 3, phase=0)
    f "Funcionava?"
    $ aa_audio_event('e15', 'line', 4, phase=0)
    v "Elas gostavam de mim. No jogo, não."
    $ aa_audio_event('e15', 'line', 5, phase=0)
    "Ri. Ela riu também e terminou a história."
    $ aa_audio_event('e15', 'line', 6, phase=0)
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_audio_ambient('AMB16')
    $ aa_stage_action = 'Domingo: os dois levantam, recolhem os copos e se despedem.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sabado_porta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sabado_porta'
    show screen aa_location_display
    "Quando deu a hora, levantei sem pressa. Levamos os copos para a pia. Vanessa me beijou junto da porta e disse que tinha gostado do domingo."
    $ aa_audio_event('e15', 'line', 7, phase=0)
    f "Eu também. Quarta eu venho."
    $ aa_audio_event('e15', 'line', 8, phase=0)
    v "Amanhã a gente se vê na aula."
    $ aa_audio_event('e15', 'line', 9, phase=0)
    "Desci. Na rua, percebi que estava com fome. Pensei no jantar da moradia e no que podia cozinhar na quarta."
    $ aa_present = ()
    call aa_advance_clock(11220)
    $ aa_present = ()
    $ aa_audio_event('e15', 'line', 10, phase=0)
    $ aa_location = 'Quarto de Feka'
    $ aa_audio_ambient('AMB01')
    $ aa_stage_action = 'Feka volta à moradia; o encontro seguinte está combinado.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_quarto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_quarto'
    show screen aa_location_display
    "Quando cheguei, avisei. Ela respondeu que ia escolher uma receita fácil. Abri a mensagem rindo."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E15 · Domingo em casa — fim do capítulo 4"
    return

label e16:
    $ aa_node = 'e16'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e16'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11080)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('e16')
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_stage_action = 'Uma visita de cada vez'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sofa_distancia'
    show screen aa_location_display
    $ aa_audio_event('e16', 'line', 0, phase=0)
    v "Eu quero que você volte na quarta."
    $ aa_audio_event('e16', 'line', 1, phase=0)
    f "Eu quero vir."
    if aa_matches(aa_state, {'relationship_phase': 'repair'}):
        $ aa_audio_event('e16', 'line', 2, phase=0)
        v "E quero poder perguntar uma coisa do jantar sem você achar que eu estraguei o dia."
    if aa_matches(aa_state, {'v_debt_open': True}):
        $ aa_audio_event('e16', 'line', 3, phase=0)
        v "Antes disso, preciso que você resolva o dinheiro. Eu não quero misturar uma coisa com a outra."
    if aa_matches(aa_state, {'j_debt_open': True}):
        $ aa_audio_event('e16', 'line', 4, phase=0)
        "O empréstimo de Joãozão ainda estava no aplicativo. Eu teria que resolver sem usar Vanessa para pedir mais prazo."
    if aa_matches(aa_state, {'weekend_cancelled_friend': True}):
        $ aa_audio_event('e16', 'line', 5, phase=0)
        v "Eu ainda vou remarcar com Marina. Dessa vez, não vou cancelar."
    if aa_matches(aa_state, {'chapter_origin': 'e08', 'public_corrected': False}):
        $ aa_audio_event('e16', 'line', 6, phase=0)
        v "Eu falei da publicação. Não esquece depois que sair daqui."
    $ aa_audio_event('e16', 'line', 7, phase=0)
    f "Tá. A quarta tá combinada."
    $ aa_audio_event('e16', 'line', 8, phase=0)
    "Ela pousou a mão perto da minha. Segurei por um instante e depois soltei para pegar a mochila."
    $ aa_audio_event('e16', 'line', 9, phase=0)
    v "Gostei que você veio."
    $ aa_audio_event('e16', 'line', 10, phase=0)
    f "Eu também gostei."
    $ aa_audio_event('e16', 'line', 11, phase=0)
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_audio_ambient('AMB16')
    $ aa_stage_action = 'Despedida combinada depois de reconhecer o que ainda falta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_sabado_porta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_sabado_porta'
    show screen aa_location_display
    "Fomos até a porta. Dei um beijo no rosto dela e desci. Vanessa tinha dito que queria me ver outra vez. Também tinha dito o que ainda precisava mudar."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E16 · Uma visita de cada vez — fim do capítulo 4"
    return

label e17:
    $ aa_node = 'e17'
    $ aa_location = 'Apartamento de Vanessa · sofá'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['e17'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(11080)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('e17')
    if aa_matches(aa_state, {'weekend_close': False}):
        $ aa_location = 'Apartamento de Vanessa · sofá'
        $ aa_stage_action = 'Sempre disponível'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg16_sofa_distancia at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg16_sofa_distancia'
    else:
        $ aa_location = 'Apartamento de Vanessa · sofá'
        $ aa_stage_action = 'Sempre disponível'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg16_sofa at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg16_sofa'
    show screen aa_location_display
    if aa_matches(aa_state, {'weekend_close': True}):
        $ aa_audio_event('e17', 'line', 0, phase=0)
        "Vanessa encostou a cabeça no meu ombro. Passei o braço por trás dela e fiquei."
    if aa_matches(aa_state, {'weekend_close': False}):
        $ aa_audio_event('e17', 'line', 1, phase=0)
        "Vanessa sorriu e deixou o copo na mesa. Continuei sentado com ela."
    $ aa_audio_event('e17', 'line', 2, phase=0)
    v "Eu gosto tanto quando você fala assim."
    $ aa_audio_event('e17', 'line', 3, phase=0)
    f "Eu quero que você fique bem."
    $ aa_audio_event('e17', 'line', 4, phase=0)
    v "Eu fico. Só tenho medo de você chegar em casa e achar que prometeu demais."
    $ aa_audio_event('e17', 'line', 5, phase=0)
    "Disse que não. Podia jantar mais tarde. Escolhi uma coisa para assistirmos e continuei sentado com ela."
    $ aa_audio_event('e17', 'line', 6, phase=0)
    "Eu estava bem ali. Era bom ser necessário, e ela parecia aliviada de poder me pedir mais um pouco."
    $ aa_audio_event('e17', 'line', 7, phase=0)
    "Antes de ir embora, avisei que mandaria mensagem quando chegasse. Vanessa pediu que eu deixasse o som ligado."
    $ aa_audio_event('e17', 'line', 8, phase=0)
    v "Se eu não conseguir dormir, posso ligar?"
    $ aa_audio_event('e17', 'line', 9, phase=0)
    f "Pode."
    $ aa_audio_event('e17', 'line', 10, phase=0)
    "Beijei a testa dela. Eu tinha confirmado outra vez que estaria disponível. Ainda não tinha decidido onde caberiam as minhas outras coisas."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E17 · Sempre disponível — fim do capítulo 4"
    return

label z_week:
    $ aa_node = 'z_week'
    $ aa_location = 'Quarto de Feka'
    $ aa_state = aa_enter_node(aa_state, aa_nodes['z_week'])
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(12120)
    $ aa_state = aa_financial_state(aa_state, aa_world)
    $ aa_present = ()
    $ aa_audio_enter('z_week')
    $ aa_location = 'Quarto de Feka'
    $ aa_stage_action = 'O namoro terminou'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg16_estudo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg16_estudo'
    show screen aa_location_display
    $ aa_audio_event('z_week', 'line', 0, phase=0)
    "Na segunda seguinte, sentei à escrivaninha antes da aula. O último encontro não tinha outro marcado depois dele."
    if aa_matches(aa_state, {'final_contact': 'end'}):
        $ aa_audio_event('z_week', 'line', 1, phase=0)
        "Eu tinha dito que queria terminar. Vanessa não me devia uma tentativa de me convencer do contrário."
    if aa_matches(aa_state, {'final_contact': 'pressure'}):
        $ aa_audio_event('z_week', 'line', 2, phase=0)
        "Vanessa tinha dito que não queria continuar. Eu tinha transformado um combinado numa cobrança sobre o quanto ela gostava de mim."
    $ aa_audio_event('z_week', 'line', 3, phase=0)
    "Ainda estaríamos na mesma turma. Separei o material que precisaria devolver e perguntei, pelo grupo, como entregar."
    $ aa_audio_event('z_week', 'line', 4, phase=0)
    "O dinheiro que estivesse pendente continuaria pendente. Não dependia de ela aceitar me ver fora da faculdade."
    $ aa_audio_event('z_week', 'line', 5, phase=0)
    "Guardei o telefone e saí para a aula. Não havia visita para esperar naquela tarde."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E18 · O namoro terminou"
    return
