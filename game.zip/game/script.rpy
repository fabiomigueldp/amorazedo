# Gerado por tools/build_story.py. Edite a fonte editorial, não este arquivo.
label start:
    $ aa_world_start()
    $ aa_trace = []
    $ aa_state = aa_new_state()
    $ aa_last_art = ""
    $ aa_phone_memory = ()
    $ aa_phone_active = True
    $ aa_audio_reset()
    jump a00

label a00:
    $ aa_node = 'a00'
    $ aa_location = '18h42 · Quarto de Feka'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1122)
    $ aa_present = ()
    $ aa_audio_enter('a00')
    $ aa_stage_action = 'Vanessa larga a bolsa; Feka sentado, ainda sem celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_bolsa'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 0, phase=0)
    "Vanessa deixou a bolsa na minha cama e abriu o zíper."
    $ aa_audio_event('a00', 'line', 1, phase=0)
    $ aa_stage_action = 'Vanessa entrou no banheiro; Feka responde da cama.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_banheiro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_banheiro'
    show screen aa_location_display
    "Ela entrou no banheiro. A torneira fez barulho antes de sair água."
    $ aa_audio_event('a00', 'line', 2, phase=0)
    v "Onde você deixa a toalha de rosto?"
    $ aa_audio_event('a00', 'line', 3, phase=0)
    f "Atrás da porta."
    $ aa_audio_event('a00', 'line', 4, phase=0)
    $ aa_stage_action = 'Ela seca as mãos na toalha de banho; o gancho fica vazio.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.08, 0.83, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "Era a de banho. A de rosto estava no cesto havia três dias. Ela não reclamou."
    $ aa_audio_event('a00', 'line', 5, phase=0)
    "Meu quarto tinha banheiro. A cozinha e a sala eram divididas com gente que sempre sabia quando eu tinha visita."
    $ aa_audio_event('a00', 'line', 6, phase=0)
    $ aa_stage_action = 'Atenção nos cadernos e na escrivaninha, ainda no mesmo espaço.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.2, 0.54, 0.44)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "Na escrivaninha, dois cadernos de Direito. Vanessa tinha corrigido minhas anotações. Antes da última prova, eu tinha esperado com ela no corredor até a mão parar de tremer. Ela ainda falava daquele dia."
    $ aa_audio_event('a00', 'line', 7, phase=0)
    $ aa_stage_action = 'A escolha ocorre antes de Feka pegar o celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    "O celular estava no carregador. Yasmin não tinha me mandado mensagem. Não era preciso uma mensagem para eu pegar o celular."
    menu:
        "Abrir o perfil de Yasmin.":
            $ aa_audio_event('a00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a00', 0)
            jump a01
        "Conferir a conversa antiga com Yasmin.":
            $ aa_audio_event('a00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a00', 1)
            jump a02
        "Deixar o celular e separar a roupa.":
            $ aa_audio_event('a00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a00', 2)
            $ aa_stage_action = 'Ele deixa o telefone e presta atenção no quarto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_brincos'
            $ aa_audio_event('a00', 'response', 0, 2)
            "Afastei o celular com a jaqueta. Não apaguei nada. Só deixei para depois."
            jump a03

label a01:
    $ aa_node = 'a01'
    $ aa_location = '18h46 · Quarto de Feka'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1126)
    $ aa_present = ()
    $ aa_audio_enter('a01')
    $ aa_stage_action = 'Feka pega o celular; Vanessa continua no banheiro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    window hide
    hide screen aa_location_display
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    if aa_last_art != 'cg2_celular':
        show screen aa_cg_continue
        pause
        hide screen aa_cg_continue
    window auto
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    $ aa_audio_event('a01', 'line', 0, phase=0)
    $ aa_stage_action = 'Foto vertical do casal na tela, vista das mãos de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'publicacao'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('publicacao')
    show screen aa_phone_view('publicacao')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    "Os dois de jaleco. Eu já sabia que estudavam juntos. Abri a foto mesmo assim."
    $ aa_audio_event('a01', 'line', 1, phase=0)
    $ aa_stage_action = 'Passa à foto do copo, cardápio e mão de Joãozão; localização legível.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'restaurante'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('restaurante')
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    "A publicação seguinte era de poucos minutos antes."
    $ aa_audio_event('a01', 'line', 2, phase=0)
    "Casa do Pátio. Era o lugar da minha reserva. Eu podia cancelar. Ainda nem tínhamos saído."
    $ aa_audio_event('a01', 'line', 3, phase=0)
    "A ideia de cancelar me deu uma raiva pequena e imediata. Eu tinha passado a semana dizendo que aquele jantar era para Vanessa."
    $ aa_audio_event('a01', 'line', 4, phase=0)
    $ aa_stage_action = 'Vanessa chama fora do quadro; ele ainda olha a publicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'restaurante'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('restaurante')
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    v "Você viu meu brinco? O pequeno."
    $ aa_audio_event('a01', 'line', 5, phase=0)
    $ aa_stage_action = 'Retorno ao quarto após a interrupção; telefone ainda nas mãos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    "Eu respondi que não sem levantar os olhos."
    menu:
        "Fechar a publicação. Agora eu sei que ela está lá.":
            $ aa_audio_event('a01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a01', 0)
            jump a03
        "Ficar olhando mais um pouco.":
            $ aa_audio_event('a01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a01', 1)
            jump a02

label a02:
    $ aa_node = 'a02'
    $ aa_location = '18h51 · Quarto de Feka'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1131)
    $ aa_present = ()
    $ aa_audio_enter('a02')
    $ aa_stage_action = 'Conversa antiga na tela física; nenhum pensamento atribuído a Yasmin.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'conversa'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    $ aa_phone_remember('conversa')
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    $ aa_audio_event('a02', 'line', 0, phase=0)
    "A conversa era antiga. Não o suficiente para eu ter esquecido o que ela dizia."
    $ aa_audio_event('a02', 'line', 1, phase=0)
    y "Feka, não me espera na saída de novo. Eu não combinei nada com você."
    $ aa_audio_event('a02', 'line', 2, phase=0)
    "Embaixo, eu tinha escrito que estava só passando. Eu lembrava de ter chegado cedo."
    $ aa_audio_event('a02', 'line', 3, phase=0)
    "Conheci Yasmin no ensino médio. Durante anos, qualquer coisa serviu: uma resposta curta, uma foto nova, o lugar onde ela dizia que ia estar."
    $ aa_audio_event('a02', 'line', 4, phase=0)
    "Eu chamava aquilo de gostar de alguém. A palavra não dizia quanto trabalho eu dava a ela."
    $ aa_audio_event('a02', 'line', 5, phase=0)
    $ aa_stage_action = 'A voz de Vanessa devolve o quarto ao primeiro plano.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    v "Feka?"
    menu:
        "Guardar o celular e responder.":
            $ aa_audio_event('a02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a02', 0)
            jump a03
        "Reler minha resposta, procurando alguma defesa.":
            $ aa_audio_event('a02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a02', 1)
            jump a03

label a03:
    $ aa_node = 'a03'
    $ aa_location = '19h02 · Quarto e banheiro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1142)
    $ aa_present = ()
    $ aa_audio_enter('a03')
    $ aa_stage_action = 'Celular abaixado; toalha devolvida; Vanessa termina o brinco.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    $ aa_audio_event('a03', 'line', 0, phase=0)
    "Vanessa pendurou a toalha úmida no banheiro. Ainda mexia no fecho do brinco, perto da porta. O casaco e a bolsa estavam na cama."
    $ aa_audio_event('a03', 'line', 1, phase=0)
    v "Achei o brinco. Tava na minha bolsa."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a03', 'line', 2, phase=0)
        v "Você nem olhou quando eu perguntei. Ficou no celular."
    if aa_matches(aa_state, {'late': True}):
        $ aa_audio_event('a03', 'line', 3, phase=0)
        v "Você ficou quieto. Achei que tinha desistido de sair."
    $ aa_audio_event('a03', 'line', 4, phase=0)
    $ aa_stage_action = 'Último ajuste do brinco antes de atravessar o quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.13, 0.83, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    "Ela terminou de colocar o brinco, atravessou o quarto e pegou o casaco."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a03', 'line', 5, phase=0)
        "Eu sabia onde Yasmin estava. Vanessa só sabia onde íamos jantar."
    $ aa_audio_event('a03', 'line', 6, phase=0)
    $ aa_stage_action = 'Feka levanta, veste a jaqueta e acerta a gola; cadeira livre.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    "Levantei e vesti a jaqueta escura. Vanessa me olhou enquanto eu acertava a gola."
    $ aa_audio_event('a03', 'line', 7, phase=0)
    $ aa_stage_action = 'O olhar de Vanessa acompanha a escolha da roupa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.1, 0.27, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    v "Essa? Você não vai sentir calor?"
    $ aa_audio_event('a03', 'line', 8, phase=0)
    v "Eu demorei muito?"
    $ aa_audio_event('a03', 'line', 9, phase=0)
    f "Não."
    $ aa_audio_event('a03', 'line', 10, phase=0)
    "Ela olhou para o meu rosto para conferir. Eu estava terminando de arrumar a gola."
    menu:
        "Perguntar se ela prefere a camiseta.":
            $ aa_audio_event('a03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a03', 0)
            $ aa_stage_action = 'Ela espera que a escolha da roupa encerre a distração.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_quarto_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_quarto_espera'
            $ aa_audio_event('a03', 'response', 0, 0)
            v "Eu gosto da camiseta. Mas essa também fica boa."
            $ aa_audio_event('a03', 'response', 1, 0)
            "Ela esperou eu escolher. Eu tinha perguntado por costume."
            jump a04
        "Dizer que já está bom e elogiar o cabelo dela.":
            $ aa_audio_event('a03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a03', 1)
            $ aa_stage_action = 'Feka finalmente olha para ela; sorriso breve, casaco no braço.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_quarto_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_quarto_espera'
            $ aa_audio_event('a03', 'response', 0, 1)
            f "Seu cabelo ficou bonito."
            $ aa_audio_event('a03', 'response', 1, 1)
            v "É? Eu achei que você nem tinha visto."
            $ aa_audio_event('a03', 'response', 2, 1)
            "Ela sorriu. Eu devia ter olhado antes de falar."
            jump a04
        "Conferir pelo celular uma foto minha que Yasmin já curtiu.":
            $ aa_audio_event('a03', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a03', 2)
            $ aa_stage_action = 'Foto antiga ampliável; ele bloqueia antes de Vanessa se aproximar.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = 'comparacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_phone_remember('comparacao')
            show screen aa_phone_view('comparacao')
            $ aa_last_art = 'cg2_quarto_jaqueta'
            $ aa_audio_event('a03', 'response', 0, 2)
            "Ampliei a foto para ver a roupa."
            $ aa_audio_event('a03', 'response', 1, 2)
            $ aa_stage_action = 'Tela bloqueada; Vanessa volta a ocupar a cena.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_jaqueta'
            "Vanessa passou atrás de mim para buscar a bolsa. Bloqueei a tela antes de ela chegar perto."
            jump a04

label a04:
    $ aa_node = 'a04'
    $ aa_location = '19h13 · Cozinha compartilhada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1153)
    $ aa_present = ()
    $ aa_audio_enter('a04')
    $ aa_stage_action = 'Feka junto à panela; Vanessa diante da geladeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    $ aa_audio_event('a04', 'line', 0, phase=0)
    "Na cozinha, alguém tinha deixado uma panela dentro da pia. Passei duas vezes por ela como se não fosse minha."
    $ aa_audio_event('a04', 'line', 1, phase=0)
    $ aa_stage_action = 'Vanessa começa a falar; a panela fica no campo periférico.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.06, 0.78, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    v "Amanhã eu pego a chave."
    $ aa_audio_event('a04', 'line', 2, phase=0)
    f "Do apartamento?"
    $ aa_audio_event('a04', 'line', 3, phase=0)
    v "Não. Da prefeitura."
    $ aa_audio_event('a04', 'line', 4, phase=0)
    "Eu ri atrasado. Ela abriu a geladeira, viu uma garrafa com o nome de outro morador e fechou."
    $ aa_audio_event('a04', 'line', 5, phase=0)
    $ aa_stage_action = 'A geladeira é fechada; conversa continua entre os dois.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    v "Vou poder comprar uma coisa e encontrar a mesma coisa quando voltar."
    $ aa_audio_event('a04', 'line', 6, phase=0)
    "Estudávamos Direito na mesma turma. Eu sabia as matérias em que Vanessa ia bem. Não sabia quem tinha ido ver o apartamento com ela."
    menu:
        "Perguntar como foi a visita e deixar ela contar.":
            $ aa_audio_event('a04', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a04', 0)
            jump a05
        "Brincar que agora vou ter onde dormir.":
            $ aa_audio_event('a04', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a04', 1)
            jump a05
        "Avisar que precisamos sair, olhando o celular.":
            $ aa_audio_event('a04', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a04', 2)
            $ aa_stage_action = 'Uma olhada no relógio encerra a escuta.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = 'relogio'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_phone_remember('relogio')
            show screen aa_phone_view('relogio')
            $ aa_last_art = 'cg2_cozinha_fechada'
            $ aa_audio_event('a04', 'response', 0, 2)
            v "Eu já estou pronta. Você também? Então vamos."
            jump a05

label a05:
    $ aa_node = 'a05'
    $ aa_location = '19h22 · Cozinha compartilhada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1162)
    $ aa_present = ()
    $ aa_audio_enter('a05')
    $ aa_stage_action = 'Geladeira fechada; Vanessa mostra o orçamento no celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    if aa_matches(aa_state, {'heard': True}):
        $ aa_audio_event('a05', 'line', 0, phase=0)
        v "Fui com a minha mãe. É pequeno. Não tem onde pôr uma mesa grande. Mas a porta fecha."
    if aa_matches(aa_state, {'claimed_space': True}):
        $ aa_audio_event('a05', 'line', 1, phase=0)
        v "Vai querer ir mesmo ou tá só falando?"
    $ aa_audio_event('a05', 'line', 2, phase=0)
    $ aa_stage_action = 'Orçamento na mão dela, não na tela de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'orcamento'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.1, 0.74, 0.48)
    with Dissolve(0.25)
    $ aa_phone_remember('orcamento')
    show screen aa_phone_view('orcamento')
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    "Ela virou o celular para mim. Tinha separado o dinheiro da caução e do frete. Para o jantar, sobravam noventa reais."
    $ aa_audio_event('a05', 'line', 3, phase=0)
    $ aa_stage_action = 'Voltar a Vanessa: ela explica o limite do orçamento.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    v "Cada um paga o seu, tá? Posso gastar até noventa hoje. O dinheiro da mudança eu não quero mexer."
    $ aa_audio_event('a05', 'line', 4, phase=0)
    "Yasmin tinha recomendado o restaurante no grupo três semanas antes. Guardei o nome. Para Vanessa, disse que tinha pensado nela."
    $ aa_audio_event('a05', 'line', 5, phase=0)
    f "Meu pai vai mandar cem reais amanhã de manhã."
    $ aa_audio_event('a05', 'line', 6, phase=0)
    v "Minha mãe vai ajudar com a mudança de manhã. Você podia ir depois da aula."
    $ aa_audio_event('a05', 'line', 7, phase=0)
    "Ela disse isso enquanto guardava o celular, sem olhar para mim."
    menu:
        "Combinar que cada um paga o seu.":
            $ aa_audio_event('a05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a05', 0)
            $ aa_audio_event('a05', 'response', 0, 0)
            f "Combinado. Cada um o seu."
            $ aa_audio_event('a05', 'response', 1, 0)
            v "Obrigada. Prefiro saber antes."
            jump a06
        "Insistir que hoje eu pago tudo.":
            $ aa_audio_event('a05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a05', 1)
            $ aa_audio_event('a05', 'response', 0, 1)
            f "Hoje deixa comigo."
            $ aa_audio_event('a05', 'response', 1, 1)
            v "Tem certeza?"
            $ aa_audio_event('a05', 'response', 2, 1)
            f "Tenho."
            $ aa_audio_event('a05', 'response', 3, 1)
            "Consegui dizer sem conferir o saldo outra vez."
            jump a06
        "Dizer que estou apertado e combinar de dividir a conta.":
            $ aa_audio_event('a05', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a05', 2)
            $ aa_audio_event('a05', 'response', 0, 2)
            v "Tudo bem. Eu falei de jantar, não de te quebrar."
            jump a06

label a06:
    $ aa_node = 'a06'
    $ aa_location = '19h30 · Hall do apartamento'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1170)
    $ aa_present = ()
    $ aa_audio_enter('a06')
    $ aa_stage_action = 'Casaco vestido, caderno entrando na bolsa, chave com Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall'
    show screen aa_location_display
    $ aa_audio_event('a06', 'line', 0, phase=0)
    "Vanessa vestiu o casaco, guardou o caderno na bolsa e conferiu a chave, o celular e a carteira. Fiquei esperando que terminasse sem me perguntar mais nada."
    $ aa_audio_event('a06', 'line', 1, phase=0)
    $ aa_stage_action = 'A bolsa se fecha; Vanessa levanta os olhos para perguntar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    v "Foi você mesmo que descobriu esse lugar?"
    $ aa_audio_event('a06', 'line', 2, phase=0)
    "A pergunta podia acabar ali. Isso era o que eu queria: que uma pergunta acabasse antes de chegar onde doía."
    menu:
        "Contar que Yasmin indicou o lugar e que eu vi que ela está lá." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a06', 0)
            jump a07
        "Contar que quem indicou foi uma menina de quem eu gostei." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a06', 1)
            jump a07
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a06', 2)
            $ aa_audio_event('a06', 'response', 0, 2)
            f "Achei por acaso. Vi o lugar e pensei na gente."
            jump a08
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'a06', 3)
            $ aa_audio_event('a06', 'response', 0, 3)
            f "Achei por acaso. Vi o lugar e pensei na gente."
            jump a08
        "Dizer que uma amiga da escola compartilhou o restaurante num grupo." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'a06', 4)
            $ aa_audio_event('a06', 'response', 0, 4)
            f "Uma amiga da escola mandou no grupo. Achei o lugar legal."
            $ aa_audio_event('a06', 'response', 1, 4)
            v "Ah. Pensei que você já tivesse ido."
            $ aa_audio_event('a06', 'response', 2, 4)
            f "Não. Vai ser a primeira vez."
            jump a08
        "Dizer que uma amiga da escola compartilhou o restaurante num grupo." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'a06', 5)
            $ aa_audio_event('a06', 'response', 0, 5)
            f "Uma amiga da escola mandou no grupo. Achei o lugar legal."
            $ aa_audio_event('a06', 'response', 1, 5)
            v "Ah. Pensei que você já tivesse ido."
            $ aa_audio_event('a06', 'response', 2, 5)
            f "Não. Vai ser a primeira vez."
            jump a08

label a07:
    $ aa_node = 'a07'
    $ aa_location = '19h34 · Hall do apartamento'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1174)
    $ aa_present = ()
    $ aa_audio_enter('a07')
    $ aa_stage_action = 'Vanessa interrompe a saída e olha para Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.08, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    $ aa_audio_event('a07', 'line', 0, phase=0)
    v "De quem você gostou?"
    $ aa_audio_event('a07', 'line', 1, phase=0)
    $ aa_stage_action = 'Contracampo de Feka antes de dizer o nome.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.14, 0.74, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    f "Yasmin. A gente estudou junto no ensino médio."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a07', 'line', 2, phase=0)
        v "E você ia me levar sabendo que ela está lá?"
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('a07', 'line', 3, phase=0)
        $ aa_stage_action = 'A pergunta pede uma resposta suportável.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_hall_duvida'
        show screen aa_location_display
        v "Mas você não gosta mais dela, né?"
    $ aa_audio_event('a07', 'line', 4, phase=0)
    $ aa_stage_action = 'A distância entre ambos reaparece no plano aberto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    "Eu quase disse que não havia motivo para ciúme. Ela ainda não tinha falado de ciúme."
    menu:
        "Admitir que ainda penso nela e deixar Vanessa decidir.":
            $ aa_audio_event('a07', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a07', 0)
            jump a09
        "Dizer que é passado e manter a reserva.":
            $ aa_audio_event('a07', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a07', 1)
            jump a08

label a09:
    $ aa_node = 'a09'
    $ aa_location = '19h38 · Hall do apartamento'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1178)
    $ aa_present = ()
    $ aa_audio_enter('a09')
    $ aa_stage_action = 'Vanessa busca uma garantia antes de sair; bolsa nas mãos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('a09', 'line', 0, phase=0)
    v "Ainda pensa como?"
    $ aa_audio_event('a09', 'line', 1, phase=0)
    "Não respondi. O silêncio fez o serviço que eu estava adiando."
    $ aa_audio_event('a09', 'line', 2, phase=0)
    $ aa_stage_action = 'Ela ainda deseja ir ao jantar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.08, 0.3, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    v "Eu quero ir com você. Só não quero chegar lá e ficar sobrando."
    $ aa_audio_event('a09', 'line', 3, phase=0)
    v "E não pede foto se a gente estiver brigado. Eu vou acabar aceitando e depois vou odiar a foto."
    menu:
        "Ir, aceitando esse limite.":
            $ aa_audio_event('a09', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a09', 0)
            $ aa_audio_event('a09', 'response', 0, 0)
            f "Tá. Sem foto."
            $ aa_audio_event('a09', 'response', 1, 0)
            v "Mas você ainda quer ir comigo?"
            $ aa_audio_event('a09', 'response', 2, 0)
            f "Quero."
            $ aa_audio_event('a09', 'response', 3, 0)
            "Era verdade que eu queria ir. Deixei a resposta inteira por conta dela."
            jump a08
        "Cancelar e encerrar o encontro sem pedir que ela me console.":
            $ aa_audio_event('a09', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a09', 1)
            jump e00

label a08:
    $ aa_node = 'a08'
    $ aa_location = '19h48 · A caminho do restaurante'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1188)
    $ aa_present = ()
    $ aa_audio_enter('a08')
    $ aa_stage_action = 'Ambos caminham; Vanessa puxa a manga do casaco.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    $ aa_audio_event('a08', 'line', 0, phase=0)
    "Na rua, Vanessa puxou a própria manga sobre a mão. Perguntei se estava com frio. Ela disse que não era nada."
    if aa_matches(aa_state, {'ambush': True}):
        $ aa_audio_event('a08', 'line', 1, phase=0)
        "A tela do meu celular continuava escura. Eu sabia tudo que precisava saber para fingir uma surpresa."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('a08', 'line', 2, phase=0)
        "Fiquei procurando alguma coisa para dizer. Vanessa andava ao meu lado, e eu já estava deixando que ela fizesse o esforço de puxar conversa."
    $ aa_audio_event('a08', 'line', 3, phase=0)
    $ aa_stage_action = 'A promessa sobre a aula acontece enquanto caminham.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.06, 0.65, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    v "Amanhã, se eu faltar na primeira aula, você pega a matéria?"
    $ aa_audio_event('a08', 'line', 4, phase=0)
    f "Pego."
    $ aa_audio_event('a08', 'line', 5, phase=0)
    "Ela perguntou se eu mandaria a matéria mesmo se não desse para ir à mudança. Falei que sim. Ela disse obrigada duas vezes."
    jump b00

label b00:
    $ aa_node = 'b00'
    $ aa_location = '20h10 · Entrada do restaurante'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1210)
    $ aa_present = ()
    $ aa_audio_enter('b00')
    $ aa_stage_action = 'Feka reconhece Joãozão e depois Yasmin enquanto Vanessa espera uma explicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg11_recepcao_reconhecimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg11_recepcao_reconhecimento'
    show screen aa_location_display
    $ aa_audio_event('b00', 'line', 0, phase=0)
    "A primeira coisa que vi foi Joãozão. Depois a mão de Yasmin no braço dele. Achei essa ordem injusta."
    $ aa_audio_event('b00', 'line', 1, phase=0)
    $ aa_stage_action = 'Feka reconhece Joãozão e depois Yasmin enquanto Vanessa espera uma explicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg11_recepcao_reconhecimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg11_recepcao_reconhecimento'
    show screen aa_location_display
    "Vanessa tirou o casaco e parou ao meu lado, com ele no braço. A recepcionista perguntou o nome da reserva. Eu disse meu nome baixo demais e precisei repetir."
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('b00', 'line', 2, phase=0)
        v "É ela?"
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('b00', 'line', 3, phase=0)
        v "Você conhece alguém?"
    menu:
        "Responder Vanessa e perguntar se ela quer cumprimentar os dois.":
            $ aa_audio_event('b00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b00', 0)
            if aa_matches(aa_state, {'v_knows': True}):
                $ aa_audio_event('b00', 'response', 0, 0)
                $ aa_stage_action = 'Feka se volta para Vanessa antes de se aproximarem da mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg11_entrada_conversa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg11_entrada_conversa'
                f "É ela. Se você não quiser falar com eles, a gente vai direto pra nossa mesa."
            if aa_matches(aa_state, {'v_knows': False, 'group_source': True}):
                $ aa_audio_event('b00', 'response', 1, 0)
                $ aa_stage_action = 'Feka se volta para Vanessa antes de se aproximarem da mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg11_entrada_conversa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg11_entrada_conversa'
                f "É a amiga do grupo. O namorado dela é o Joãozão. Se você quiser, a gente vai direto pra nossa mesa."
            if aa_matches(aa_state, {'v_knows': False, 'group_source': False}):
                $ aa_audio_event('b00', 'response', 2, 0)
                $ aa_stage_action = 'Feka se volta para Vanessa antes de se aproximarem da mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg11_entrada_conversa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg11_entrada_conversa'
                f "É a Yasmin. A gente estudou junto. Se você não quiser falar com eles, a gente vai direto pra nossa mesa."
            $ aa_audio_event('b00', 'response', 3, 0)
            v "Eles já viram a gente. Vamos só dar boa noite. Depois a gente senta."
            $ aa_audio_event('b00', 'response', 4, 0)
            "Vanessa ajeitou o casaco no braço e esperou que eu andasse ao lado dela."
            jump b01
        "Ir até a mesa e apresentar Vanessa como minha namorada.":
            $ aa_audio_event('b00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b00', 1)
            $ aa_audio_event('b00', 'response', 0, 1)
            "Fui até a mesa sem responder à pergunta de Vanessa. Esperei Yasmin olhar para nós."
            jump b01
        "Puxar Vanessa para perto antes que Yasmin olhe.":
            $ aa_audio_event('b00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b00', 2)
            $ aa_audio_event('b00', 'response', 0, 2)
            "Passei o braço pela cintura de Vanessa. O corpo dela endureceu por um instante. Ela ajeitou o casaco e ficou perto de mim."
            jump b01

label b01:
    $ aa_node = 'b01'
    $ aa_location = '20h14 · Salão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1214)
    $ aa_present = ()
    $ aa_audio_enter('b01')
    $ aa_stage_action = 'Joãozão continua sentado; Feka e Vanessa estão de pé.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.08, 0.73, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    $ aa_audio_event('b01', 'line', 0, phase=0)
    y "Feka? Oi."
    $ aa_audio_event('b01', 'line', 1, phase=0)
    "Vanessa virou o rosto para mim. Eu senti um alívio absurdo: Yasmin tinha lembrado meu nome."
    if aa_matches(aa_state, {'group_source': True}):
        $ aa_audio_event('b01', 'line', 2, phase=0)
        y "Você veio conhecer o restaurante? Eu mandei no grupo da escola faz um tempo."
    if aa_matches(aa_state, {'group_source': False}):
        $ aa_audio_event('b01', 'line', 3, phase=0)
        y "Faz tempo."
    $ aa_audio_event('b01', 'line', 4, phase=0)
    j "Boa noite."
    $ aa_audio_event('b01', 'line', 5, phase=0)
    $ aa_stage_action = 'Joãozão não oferece a mão; Feka transforma o gesto em ajuste da cadeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cumprimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cumprimento'
    show screen aa_location_display
    "Joãozão não levantou. Fui apertar uma mão que ele não tinha oferecido. Consertei o movimento mexendo na cadeira."
    if aa_matches(aa_state, {'introduced': True}):
        $ aa_audio_event('b01', 'line', 6, phase=0)
        $ aa_stage_action = 'Joãozão continua sentado; Feka e Vanessa estão de pé.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg_chegada at aa_camera(1.08, 0.73, 0.35)
        with Dissolve(0.25)
        $ aa_last_art = 'cg_chegada'
        show screen aa_location_display
        f "Essa é a Vanessa, minha namorada."
    if aa_matches(aa_state, {'introduced': True}):
        $ aa_audio_event('b01', 'line', 7, phase=0)
        "Ela se aproximou um pouco. Eu vi o sorriso chegar antes de ela cumprimentar Yasmin."
    if aa_matches(aa_state, {'introduced': False}):
        $ aa_audio_event('b01', 'line', 8, phase=0)
        v "Vanessa."
    $ aa_audio_event('b01', 'line', 9, phase=0)
    y "Yasmin. Vocês se conhecem de onde?"
    $ aa_audio_event('b01', 'line', 10, phase=0)
    v "Da faculdade. Direito."
    $ aa_audio_event('b01', 'line', 11, phase=0)
    "Ela respondeu antes de eu descobrir uma forma de dizer aquilo que parecesse importante."
    if aa_matches(aa_state, {'group_source': True}):
        $ aa_audio_event('b01', 'line', 12, phase=0)
        v "É a amiga que mandou no grupo?"
    if aa_matches(aa_state, {'group_source': True}):
        $ aa_audio_event('b01', 'line', 13, phase=0)
        f "É."
    menu:
        "Dizer que vamos deixar os dois jantarem.":
            $ aa_audio_event('b01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b01', 0)
            $ aa_audio_event('b01', 'response', 0, 0)
            f "A gente vai sentar. Bom jantar."
            $ aa_audio_event('b01', 'response', 1, 0)
            y "Pra vocês também."
            $ aa_audio_event('b01', 'response', 2, 0)
            $ aa_stage_action = 'O garçom conduz Feka e Vanessa para a mesa junto ao vidro.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg11_ir_mesa_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg11_ir_mesa_dois'
            "Um garçom nos conduziu até a mesa junto ao vidro. Vanessa foi ao meu lado. Olhei para trás uma vez."
            jump p00
        "Sugerir que juntemos as mesas.":
            $ aa_audio_event('b01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b01', 1)
            $ aa_audio_event('b01', 'response', 0, 1)
            f "Se não atrapalhar, a gente pode juntar as mesas."
            $ aa_audio_event('b01', 'response', 1, 1)
            j "A gente já fez o pedido."
            $ aa_audio_event('b01', 'response', 2, 1)
            f "Tudo bem."
            $ aa_audio_event('b01', 'response', 3, 1)
            $ aa_stage_action = 'O garçom começa a unir as mesas antes de Vanessa responder.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg11_juntar_mesas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg11_juntar_mesas'
            "Chamei o garçom. Ele começou a arrastar uma mesa vazia antes de Vanessa responder."
            jump c00
        "Pedir um minuto com Yasmin antes de sentar.":
            $ aa_audio_event('b01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b01', 2)
            $ aa_audio_event('b01', 'response', 0, 2)
            f "Yasmin, posso falar com você um minuto?"
            $ aa_audio_event('b01', 'response', 1, 2)
            y "Aqui?"
            $ aa_audio_event('b01', 'response', 2, 2)
            f "Num lugar mais quieto."
            $ aa_audio_event('b01', 'response', 3, 2)
            $ aa_stage_action = 'Vanessa é conduzida sozinha à mesa enquanto Feka segue Yasmin.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg11_deixar_vanessa at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg11_deixar_vanessa'
            "Yasmin pegou a bolsa e caminhou até a porta da varanda. Eu fui atrás. A recepcionista mostrou nossa mesa para Vanessa."
            $ aa_audio_event('b01', 'response', 4, 2)
            v "Feka, a mesa..."
            $ aa_audio_event('b01', 'response', 5, 2)
            f "Eu já volto."
            $ aa_audio_event('b01', 'response', 6, 2)
            "Vanessa sentou sem tirar o casaco do braço. Depois dobrou o tecido sobre a cadeira vazia."
            jump t00

label p00:
    $ aa_node = 'p00'
    $ aa_location = '20h25 · Mesa junto ao vidro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1225)
    $ aa_present = ()
    $ aa_audio_enter('p00')
    $ aa_stage_action = 'Dois sentados. Feka vê o salão por trás de Vanessa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_menu_antes at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    $ aa_audio_event('p00', 'line', 0, phase=0)
    "Pedi uma mesa de onde dava para ver o salão. Vanessa sentou de costas para Yasmin. Eu podia ter escolhido o outro lado."
    if aa_matches(aa_state, {'source_truth': False, 'group_source': False}):
        $ aa_audio_event('p00', 'line', 1, phase=0)
        v "Então foi ela que indicou."
    if aa_matches(aa_state, {'source_truth': True}):
        $ aa_audio_event('p00', 'line', 2, phase=0)
        v "Você prefere sentar do outro lado? Eu troco."
    $ aa_audio_event('p00', 'line', 3, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio aberto entre os dois. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Cardápio aberto entre os dois.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    "Ela abriu o cardápio sem olhar os pratos. Eu conhecia o gesto: na aula, fazia isso quando queria que alguém terminasse logo."
    if aa_matches(aa_state, {'group_source': True, 'source_truth': False}):
        $ aa_audio_event('p00', 'line', 4, phase=0)
        v "É a amiga do grupo. E você escolheu sentar de frente pra mesa dela."
    menu:
        "Pedir para trocar de cadeira e contar a origem da reserva.":
            $ aa_audio_event('p00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p00', 0)
            $ aa_stage_action = 'Troca efetiva dos lugares; manter até o fim desse diálogo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_menu at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_menu'
            $ aa_audio_event('p00', 'response', 0, 0)
            "Trocamos de cadeira. A mesa de Yasmin ficou atrás de mim; o vidro, à minha direita."
            $ aa_audio_event('p00', 'response', 1, 0)
            f "Foi indicação dela. Eu peguei o nome no grupo e fiz a reserva."
            jump p01
        "Dizer que muita gente indica restaurante.":
            $ aa_audio_event('p00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p00', 1)
            $ aa_audio_event('p00', 'response', 0, 1)
            f "Muita gente indica restaurante. Não tem nada demais."
            $ aa_audio_event('p00', 'response', 1, 1)
            v "Eu tô falando de você. Por que escolheu justo esse?"
            jump p01
        "Fazer um elogio alto o suficiente para a outra mesa ouvir.":
            $ aa_audio_event('p00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p00', 2)
            $ aa_audio_event('p00', 'response', 0, 2)
            f "Você tá linda hoje."
            $ aa_audio_event('p00', 'response', 1, 2)
            v "Por que você tá falando alto?"
            jump p01

label p01:
    $ aa_node = 'p01'
    $ aa_location = '20h34 · Mesa junto ao vidro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1234)
    $ aa_present = ()
    $ aa_audio_enter('p01')
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    $ aa_audio_event('p01', 'line', 0, phase=0)
    "Fizemos o pedido quando o garçom voltou. Vanessa escolheu primeiro. Eu pedi o mesmo e esperei ele se afastar."
    $ aa_audio_event('p01', 'line', 1, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    "Vanessa fechou o cardápio e deixou as mãos em cima dele. Esperou que eu olhasse para ela."
    if aa_matches(aa_state, {'claimed_space': True}):
        $ aa_audio_event('p01', 'line', 2, phase=0)
        v "Você falou de dormir lá. Eu fiquei pensando se era sério."
    $ aa_audio_event('p01', 'line', 3, phase=0)
    v "Eu queria falar do apartamento. Eu quero morar lá. Só não queria que você parasse de ir me ver."
    $ aa_audio_event('p01', 'line', 4, phase=0)
    f "Você tá com medo de ficar sozinha lá?"
    $ aa_audio_event('p01', 'line', 5, phase=0)
    v "Tô. De chegar, fechar a porta e não ter ninguém pra contar como foi o dia."
    $ aa_audio_event('p01', 'line', 6, phase=0)
    "Eu podia perguntar da mudança. Fiquei esperando que ela me dissesse quanto espaço pretendia me dar."
    $ aa_audio_event('p01', 'line', 7, phase=0)
    v "Eu queria falar disso hoje."
    menu:
        "Pedir que conte o que mais a preocupa.":
            $ aa_audio_event('p01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p01', 0)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p01', 'response', 0, 0)
            f "O que mais te preocupa nessa mudança?"
            $ aa_audio_event('p01', 'response', 1, 0)
            v "Eu sei resolver as coisas. Tenho medo é de não fazer falta."
            $ aa_audio_event('p01', 'response', 2, 0)
            "Ela riu depois da frase. Eu não ri junto."
            jump p02
        "Prometer ir amanhã e combinar outras visitas.":
            $ aa_audio_event('p01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p01', 1)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p01', 'response', 0, 1)
            f "Você não vai ficar sozinha. Amanhã eu vou lá. Depois a gente combina os outros dias."
            $ aa_audio_event('p01', 'response', 1, 1)
            v "Você fala sério?"
            $ aa_audio_event('p01', 'response', 2, 1)
            "Assenti. Ela começou a falar dos horários em que eu poderia ir. Eu ainda não tinha pensado em nenhum."
            jump p02
        "Procurar a mesa de Yasmin enquanto Vanessa fala.":
            $ aa_audio_event('p01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p01', 2)
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '20h45 · Mesa junto ao vidro'
                $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_procura_troca'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '20h45 · Mesa junto ao vidro'
                    $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_procura_troca'
                else:
                    $ aa_location = '20h45 · Mesa junto ao vidro'
                    $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg12_procura_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_procura_antes'
            $ aa_audio_event('p01', 'response', 0, 2)
            "Ela parou no meio de uma frase. Eu só percebi quando o silêncio durou."
            jump p02

label p02:
    $ aa_node = 'p02'
    $ aa_location = '20h45 · Mesa junto ao vidro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1245)
    $ aa_present = ()
    $ aa_audio_enter('p02')
    if aa_matches(aa_state, {'route': 'varanda'}):
        $ aa_location = '20h45 · Mesa junto ao vidro'
        $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg12_procura_troca'
    else:
        if aa_matches(aa_state, {'seat_swapped': True}):
            $ aa_location = '20h45 · Mesa junto ao vidro'
            $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_procura_troca'
        else:
            $ aa_location = '20h45 · Mesa junto ao vidro'
            $ aa_stage_action = 'Feka desvia o olhar; a composição revela simultaneamente seu alvo e a reação de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_procura_antes at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_procura_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'seat_swapped': False, 'table_focus': 'yasmin'}):
        $ aa_audio_event('p02', 'line', 0, phase=0)
        "Outro movimento atrás de Vanessa puxou meu olhar. Eu já tinha escolhido procurar Yasmin uma vez; fiz de novo."
    if aa_matches(aa_state, {'seat_swapped': False, 'table_focus': {'ne': 'yasmin'}}):
        $ aa_audio_event('p02', 'line', 1, phase=0)
        "Um movimento atrás de Vanessa puxou meu olhar para a mesa de Yasmin antes que eu decidisse se queria olhar."
    if aa_matches(aa_state, {'seat_swapped': True, 'table_focus': 'yasmin'}):
        $ aa_audio_event('p02', 'line', 2, phase=0)
        "Ouvi uma cadeira arrastar atrás de mim. Virei de novo para procurar Yasmin, mesmo depois de trocar de lugar."
    if aa_matches(aa_state, {'seat_swapped': True, 'table_focus': {'ne': 'yasmin'}}):
        $ aa_audio_event('p02', 'line', 3, phase=0)
        "Ouvi uma cadeira arrastar atrás de mim. Virei antes de perceber que tinha virado."
    $ aa_audio_event('p02', 'line', 4, phase=0)
    v "Você fica diferente quando olha pra lá."
    $ aa_audio_event('p02', 'line', 5, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    f "Diferente como?"
    $ aa_audio_event('p02', 'line', 6, phase=0)
    v "Você fica esperando ela olhar. Eu tô bem aqui."
    $ aa_audio_event('p02', 'line', 7, phase=0)
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    "Quis rir para tornar a frase pequena. Ela não estava brincando."
    menu:
        "Contar que insisti por anos, mesmo depois de ela dizer não.":
            $ aa_audio_event('p02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p02', 0)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 0)
            f "Eu insisti. Não foi uma semana. Foram anos. Ela pediu que eu parasse."
            $ aa_audio_event('p02', 'response', 1, 0)
            v "E parou?"
            $ aa_audio_event('p02', 'response', 2, 0)
            "Fiquei olhando o copo. Ela esperou. Eu não respondi."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('p02', 'response', 3, 0)
                v "Quando você falou de uma amiga, eu não entendi que tinha acontecido tudo isso."
            jump i00
        "Chamar de uma paixão boba de escola.":
            $ aa_audio_event('p02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p02', 1)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 1)
            f "Foi uma paixão boba de escola. Já passou."
            $ aa_audio_event('p02', 'response', 1, 1)
            v "Então me fala olhando pra mim."
            $ aa_audio_event('p02', 'response', 2, 1)
            "Olhei. Ela esperou. Eu não repeti."
            jump i00
        "Dizer que Vanessa está procurando problema.":
            $ aa_audio_event('p02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p02', 2)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 2)
            v "Eu não quero brigar. Eu só queria que você olhasse pra mim."
            $ aa_audio_event('p02', 'response', 1, 2)
            "Ela abaixou a voz e parou de perguntar. Quando o garçom voltou, falou comigo como se qualquer frase pudesse começar outra briga."
            jump i00
        "Reconhecer que fiquei olhando para Yasmin e prestar atenção em Vanessa." if aa_matches(aa_state, {'source_truth': True, 'table_focus': 'vanessa', 'used': False, 'trust': {'gte': 2}}):
            $ aa_audio_event('p02', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'p02', 3)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 3)
            f "Você tem razão. Eu fiquei olhando pra lá. Desculpa."
            $ aa_audio_event('p02', 'response', 1, 3)
            f "Eu quero estar aqui com você."
            $ aa_audio_event('p02', 'response', 2, 3)
            v "Então fica aqui. Comigo."
            $ aa_audio_event('p02', 'response', 3, 3)
            f "Eu fico."
            $ aa_audio_event('p02', 'response', 4, 3)
            "Voltei a olhar para Vanessa e tirei a mão do celular. Ela ainda esperou um pouco antes de continuar."
            jump i00

label c00:
    $ aa_node = 'c00'
    $ aa_location = '20h25 · Mesas aproximadas'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1225)
    $ aa_present = ()
    $ aa_audio_enter('c00')
    $ aa_stage_action = 'Mesa C é aproximada pelo sul de B; Feka e Vanessa aguardam no corredor leste.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_juntar_mesas at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_juntar_mesas'
    show screen aa_location_display
    $ aa_audio_event('c00', 'line', 0, phase=0)
    $ aa_stage_action = 'Mesa C é aproximada pelo sul de B; Feka e Vanessa aguardam no corredor leste.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_juntar_mesas at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_juntar_mesas'
    show screen aa_location_display
    "O garçom trouxe a mesa vazia do lado do corredor e encostou na ponta da mesa deles. Joãozão repetiu que eles já tinham feito o pedido."
    $ aa_audio_event('c00', 'line', 1, phase=0)
    y "Se a Vanessa quiser."
    $ aa_audio_event('c00', 'line', 2, phase=0)
    v "Por mim tudo bem. Se vocês quiserem."
    $ aa_audio_event('c00', 'line', 3, phase=0)
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    "Vanessa concordou. Sentamos um de frente para o outro na mesa acrescentada, sem fazer Yasmin e Joãozão mudarem de lugar. O garçom anotou nosso pedido. Pedi que trouxesse tudo junto antes de olhar para Vanessa."
    $ aa_audio_event('c00', 'line', 4, phase=0)
    y "Vocês fazem os trabalhos juntos também?"
    $ aa_audio_event('c00', 'line', 5, phase=0)
    f "Faço dupla com ela sempre que dá."
    $ aa_audio_event('c00', 'line', 6, phase=0)
    v "Quando responde minhas mensagens, né?"
    $ aa_audio_event('c00', 'line', 7, phase=0)
    "Yasmin riu. Vanessa sorriu para mim, esperando que eu respondesse."
    menu:
        "Admitir que a crítica de Vanessa é justa.":
            $ aa_audio_event('c00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c00', 0)
            $ aa_audio_event('c00', 'response', 0, 0)
            f "É. Eu demoro mesmo. Desculpa."
            $ aa_audio_event('c00', 'response', 1, 0)
            v "Às vezes eu preciso saber no mesmo dia, Feka."
            jump c01
        "Explicar que ela está brincando.":
            $ aa_audio_event('c00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c00', 1)
            $ aa_audio_event('c00', 'response', 0, 1)
            f "Ela tá brincando."
            $ aa_audio_event('c00', 'response', 1, 1)
            v "Não, eu fico esperando você responder."
            $ aa_audio_event('c00', 'response', 2, 1)
            "Ela mexeu no guardanapo."
            jump c01
        "Puxar uma lembrança minha com Yasmin.":
            $ aa_audio_event('c00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c00', 2)
            $ aa_audio_event('c00', 'response', 0, 2)
            f "Lembra daquela festa depois da prova, Yasmin?"
            $ aa_audio_event('c00', 'response', 1, 2)
            y "Você ficou até o fim, né?"
            $ aa_audio_event('c00', 'response', 2, 2)
            f "Fiquei."
            jump c01

label c01:
    $ aa_node = 'c01'
    $ aa_location = '20h38 · Mesa dos quatro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1238)
    $ aa_present = ()
    $ aa_audio_enter('c01')
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'table_topic': {'ne': 'festa'}}):
        $ aa_audio_event('c01', 'line', 0, phase=0)
        y "Comigo era o contrário. Eu nem precisava chamar, ele já aparecia."
    if aa_matches(aa_state, {'table_topic': 'festa'}):
        $ aa_audio_event('c01', 'line', 1, phase=0)
        y "Você tava em todas. Bastava eu falar que ia."
    $ aa_audio_event('c01', 'line', 2, phase=0)
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    "Yasmin falou olhando para Vanessa."
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('c01', 'line', 3, phase=0)
        v "Vocês saíam juntos?"
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('c01', 'line', 4, phase=0)
        v "Isso foi na época que você me contou?"
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('c01', 'line', 5, phase=0)
        y "Não. Ele perguntava onde eu ia e aparecia lá."
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('c01', 'line', 6, phase=0)
        y "Na escola. Ele perguntava onde eu ia e aparecia lá."
    $ aa_audio_event('c01', 'line', 7, phase=0)
    j "Yasmin, deixa."
    $ aa_audio_event('c01', 'line', 8, phase=0)
    "Joãozão olhou para ela. Eu fiquei olhando para o cardápio fechado."
    menu:
        "Dizer que não era uma coincidência e assumir a insistência.":
            $ aa_audio_event('c01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c01', 0)
            $ aa_audio_event('c01', 'response', 0, 0)
            f "Eu ia porque ela ia. Não era por acaso."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('c01', 'response', 1, 0)
                v "Você falou de uma amiga. Por que não me contou essa parte antes?"
            if aa_matches(aa_state, {'group_source': False, 'source_truth': False}):
                $ aa_audio_event('c01', 'response', 2, 0)
                v "Você não me contou isso."
            if aa_matches(aa_state, {'source_truth': True, 'group_source': False}):
                $ aa_audio_event('c01', 'response', 3, 0)
                v "Você disse que gostava dela. Não falou que ficava indo atrás."
            $ aa_audio_event('c01', 'response', 4, 0)
            f "Fiquei com vergonha."
            $ aa_audio_event('c01', 'response', 5, 0)
            v "Eu preferia saber por você."
            $ aa_audio_event('c01', 'response', 6, 0)
            "Eu disse que sabia. Vanessa baixou os olhos e soltou o guardanapo."
            jump c02
        "Pedir a Yasmin que pare de fazer disso uma piada.":
            $ aa_audio_event('c01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c01', 1)
            $ aa_audio_event('c01', 'response', 0, 1)
            f "Você precisa contar isso desse jeito?"
            $ aa_audio_event('c01', 'response', 1, 1)
            y "Tá. Desculpa."
            $ aa_audio_event('c01', 'response', 2, 1)
            v "Mas aconteceu?"
            $ aa_audio_event('c01', 'response', 3, 1)
            f "Aconteceu."
            $ aa_audio_event('c01', 'response', 4, 1)
            "Vanessa esperou. Não acrescentei nada."
            jump c02
        "Dizer que Yasmin gostava da atenção.":
            $ aa_audio_event('c01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c01', 2)
            $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conversa_quatro'
            $ aa_audio_event('c01', 'response', 0, 2)
            f "Você também gostava. Nunca foi só comigo."
            $ aa_audio_event('c01', 'response', 1, 2)
            y "Eu te pedi pra parar, Feka."
            $ aa_audio_event('c01', 'response', 2, 2)
            "Joãozão se virou para mim. Baixei a voz."
            $ aa_audio_event('c01', 'response', 3, 2)
            f "Tá. Deixa."
            jump c02

label c02:
    $ aa_node = 'c02'
    $ aa_location = '20h49 · Mesa dos quatro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1249)
    $ aa_present = ()
    $ aa_audio_enter('c02')
    $ aa_stage_action = 'Quatro nos assentos de B+C; conversa antes do serviço.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_conversa_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_conversa_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'table_history': 'culpou'}):
        $ aa_audio_event('c02', 'line', 0, phase=0)
        "Vanessa continuou olhando para mim até o garçom chegar."
    $ aa_audio_event('c02', 'line', 1, phase=0)
    $ aa_stage_action = 'Garçom atende pela lateral leste; Vanessa recolhe as mãos para o prato.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_servir_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_servir_quatro'
    show screen aa_location_display
    "O garçom pediu licença. Vanessa afastou o copo para ele apoiar os pratos."
    $ aa_audio_event('c02', 'line', 2, phase=0)
    "O garçom colocou meu prato na minha frente. Recolhi os braços para ele passar e puxei o prato um pouco para perto."
    $ aa_audio_event('c02', 'line', 3, phase=0)
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    "O garçom desejou bom apetite e saiu. Joãozão experimentou a carne. Yasmin mostrou o prato para ele."
    $ aa_audio_event('c02', 'line', 4, phase=0)
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    y "Quer provar o meu?"
    $ aa_audio_event('c02', 'line', 5, phase=0)
    j "Daqui a pouco."
    $ aa_audio_event('c02', 'line', 6, phase=0)
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    "Yasmin voltou ao prato. Peguei o celular que estava ao lado do meu."
    menu:
        "Sugerir uma foto." if aa_matches(aa_state, {'no_photo': False}):
            $ aa_audio_event('c02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c02', 0)
            $ aa_audio_event('c02', 'response', 0, 0)
            f "Vamos tirar uma foto?"
            jump c03
        "Guardar o celular.":
            $ aa_audio_event('c02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c02', 1)
            $ aa_audio_event('c02', 'response', 0, 1)
            "Deixei o celular no bolso."
            jump i00
        "Oferecer pagar a mesa inteira para mudar o clima.":
            $ aa_audio_event('c02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c02', 2)
            $ aa_audio_event('c02', 'response', 0, 2)
            f "Hoje eu pago. De vocês também."
            $ aa_audio_event('c02', 'response', 1, 2)
            j "Não precisa. A nossa conta a gente paga."
            $ aa_audio_event('c02', 'response', 2, 2)
            f "A sua eu pago, Vanessa."
            $ aa_audio_event('c02', 'response', 3, 2)
            v "Tem certeza?"
            $ aa_audio_event('c02', 'response', 4, 2)
            f "Tenho."
            $ aa_audio_event('c02', 'response', 5, 2)
            "Guardei o celular sem abrir o aplicativo do banco."
            jump i00
        "Pedir uma foto, mesmo tendo combinado que não pediria." if aa_matches(aa_state, {'no_photo': True}):
            $ aa_audio_event('c02', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'c02', 3)
            $ aa_audio_event('c02', 'response', 0, 3)
            f "Vamos tirar uma foto?"
            jump c03

label c03:
    $ aa_node = 'c03'
    $ aa_location = '20h52 · Mesa dos quatro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1252)
    $ aa_present = ()
    $ aa_audio_enter('c03')
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'no_photo': True}):
        $ aa_audio_event('c03', 'line', 0, phase=0)
        v "Feka, a gente combinou que não."
    if aa_matches(aa_state, {'no_photo': True}):
        $ aa_audio_event('c03', 'line', 1, phase=0)
        "Baixei o celular. Vanessa olhou para Yasmin e depois para o prato."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        $ aa_audio_event('c03', 'line', 2, phase=0)
        v "Uma só. Me mostra antes de postar."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'gte': 2}}):
        $ aa_audio_event('c03', 'line', 3, phase=0)
        v "Tá. Peraí."
    if aa_matches(aa_state, {'no_photo': False}):
        $ aa_audio_event('c03', 'line', 4, phase=0)
        j "Eu tiro."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'gte': 2}}):
        $ aa_audio_event('c03', 'line', 5, phase=0)
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'foto'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('foto')
        show screen aa_phone_view('foto')
        $ aa_last_art = 'cg14_refeicao_quatro'
        show screen aa_location_display
        $ aa_phone_remember('foto')
        "Joãozão pegou meu celular e se levantou. Contornei a ponta livre da mesa para ficar ao lado de Vanessa. Yasmin se inclinou para entrar no quadro, e ele tirou a foto."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        $ aa_audio_event('c03', 'line', 6, phase=0)
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'foto_hesita'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('foto_hesita')
        show screen aa_phone_view('foto_hesita')
        $ aa_last_art = 'cg14_refeicao_quatro'
        show screen aa_location_display
        $ aa_phone_remember('foto_hesita')
        "Entreguei o celular a Joãozão, que se levantou. Contornei a ponta da mesa e fiquei ao lado de Vanessa. Yasmin se inclinou para caber no quadro. Vanessa sorriu até ele baixar o aparelho."
    $ aa_audio_event('c03', 'line', 7, phase=0)
    window hide None
    $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
    $ aa_table_party = 4
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg14_refeicao_quatro'
    window auto
    show screen aa_location_display
    "Guardei o celular e me acomodei de novo na cadeira, de frente para Vanessa."
    jump i00

label t00:
    $ aa_node = 't00'
    $ aa_location = '20h24 · Porta da varanda'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1224)
    $ aa_present = ()
    $ aa_audio_enter('t00')
    $ aa_stage_action = 'Yasmin mantém distância junto à porta; Vanessa ficou na mesa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    $ aa_audio_event('t00', 'line', 0, phase=0)
    y "Você pediu um minuto. Fala daqui."
    $ aa_audio_event('t00', 'line', 1, phase=0)
    "Yasmin ficou do lado de dentro. Vanessa tinha sentado à mesa, com o casaco no colo."
    $ aa_audio_event('t00', 'line', 2, phase=0)
    f "Você tá bem?"
    $ aa_audio_event('t00', 'line', 3, phase=0)
    y "Tava jantando."
    $ aa_audio_event('t00', 'line', 4, phase=0)
    "Eu esperei que ela perguntasse de mim. Ela segurou a bolsa com as duas mãos."
    $ aa_audio_event('t00', 'line', 5, phase=0)
    $ aa_stage_action = 'A recusa pertence a Yasmin.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.13, 0.28, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    y "Feka, eu não quero ficar com você. Isso não mudou. E você tá aqui com uma pessoa."
    menu:
        "Dizer que entendi e voltar para Vanessa.":
            $ aa_audio_event('t00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't00', 0)
            jump t01
        "Perguntar se ela falaria isso se Joãozão não estivesse ali.":
            $ aa_audio_event('t00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't00', 1)
            jump t01
        "Dizer que ela não precisava me humilhar.":
            $ aa_audio_event('t00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't00', 2)
            jump t01

label t01:
    $ aa_node = 't01'
    $ aa_location = '20h28 · Porta da varanda'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1228)
    $ aa_present = ()
    $ aa_audio_enter('t01')
    $ aa_stage_action = 'Yasmin conclui a resposta antes de Joãozão entrar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    if aa_matches(aa_state, {'insisted': True}):
        $ aa_audio_event('t01', 'line', 0, phase=0)
        y "Eu falei antes de namorar ele. Você lembra."
    if aa_matches(aa_state, {'stopped_joke': True}):
        $ aa_audio_event('t01', 'line', 1, phase=0)
        y "Eu não te humilhei, Feka. Só falei o que você já sabia."
    $ aa_audio_event('t01', 'line', 2, phase=0)
    $ aa_stage_action = 'Joãozão entra só agora; Yasmin continua no próprio lugar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_joao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_joao_r1'
    show screen aa_location_display
    j "Tá acontecendo alguma coisa?"
    $ aa_audio_event('t01', 'line', 3, phase=0)
    "O corpo de Joãozão ocupou o espaço que eu estava usando para imaginar uma conversa diferente."
    $ aa_audio_event('t01', 'line', 4, phase=0)
    $ aa_stage_action = 'Yasmin interrompe a tentativa de falar por ela.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_joao_r1 at aa_camera(1.1, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_joao_r1'
    show screen aa_location_display
    y "Já respondi. Eu mesma."
    menu:
        "Sair do caminho e voltar à mesa.":
            $ aa_audio_event('t01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't01', 0)
            jump t02
        "Dizer a Joãozão que ele não manda em mim.":
            $ aa_audio_event('t01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't01', 1)
            $ aa_audio_event('t01', 'response', 0, 1)
            j "Eu perguntei se estava acontecendo alguma coisa."
            $ aa_audio_event('t01', 'response', 1, 1)
            "Ele não tinha precisado levantar a voz para eu perceber a minha."
            jump t02
        "Pedir que ele deixe Yasmin terminar de falar.":
            $ aa_audio_event('t01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't01', 2)
            $ aa_audio_event('t01', 'response', 0, 2)
            y "Eu já terminei. Agora quero voltar."
            jump t02

label t02:
    $ aa_node = 't02'
    $ aa_location = '20h33 · Mesa de Vanessa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1233)
    $ aa_present = ()
    $ aa_audio_enter('t02')
    $ aa_stage_action = 'Vanessa sentada; meio copo e casaco na cadeira de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    $ aa_audio_event('t02', 'line', 0, phase=0)
    "O copo de Vanessa estava pela metade. Ela tinha dobrado o casaco sobre a cadeira que eu devia estar usando."
    $ aa_audio_event('t02', 'line', 1, phase=0)
    $ aa_stage_action = 'Reprovação sentada; não substituir por retrato de pé.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.1, 0.62, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    v "Achei que você não ia voltar. Vamos pedir? Eu esperei você."
    $ aa_audio_event('t02', 'line', 2, phase=0)
    "Eu procurei uma resposta engraçada. Todas pioravam a pergunta."
    $ aa_audio_event('t02', 'line', 3, phase=0)
    $ aa_stage_action = 'Feka senta; casaco devolvido à cadeira dela, cardápio fechado.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_mesa_escuta_troca'
    show screen aa_location_display
    "Devolvi o casaco à cadeira dela e sentei. Vanessa sorriu, depois perguntou o que tinha demorado tanto."
    $ aa_audio_event('t02', 'line', 4, phase=0)
    "Quando o garçom passou, fizemos o pedido. Vanessa precisou perguntar o meu duas vezes. Eu ainda estava pensando no que tinha acontecido na varanda."
    menu:
        "Pedir desculpa pelo tempo e contar o que fui fazer.":
            $ aa_audio_event('t02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't02', 0)
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('t02', 'response', 0, 0)
                f "Desculpa ter te deixado esperando. Eu fui falar com a Yasmin porque ainda penso nela."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('t02', 'response', 1, 0)
                v "A amiga do grupo."
            if aa_matches(aa_state, {'group_source': True}):
                $ aa_audio_event('t02', 'response', 2, 0)
                f "É. Eu devia ter explicado antes de sair da mesa."
            jump i00
        "Dizer que foi só uma conversa de escola.":
            $ aa_audio_event('t02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't02', 1)
            jump i00
        "Reclamar que Joãozão é agressivo.":
            $ aa_audio_event('t02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't02', 2)
            jump i00

label i00:
    $ aa_node = 'i00'
    $ aa_location = '21h02 · Entre os pratos'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1262)
    $ aa_present = ()
    $ aa_audio_enter('i00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '20h53 · Mesa B+C'
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_refeicao_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_location = '20h53 · Mesa dos quatro'
            $ aa_stage_action = 'Retomam a refeição depois da escolha; celular guardado.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_pratos'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '20h49 · Mesa'
                $ aa_stage_action = 'Aguardam a comida; ainda não há pratos servidos.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '20h49 · Mesa'
                    $ aa_stage_action = 'Aguardam a comida; ainda não há pratos servidos.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_escuta_troca'
                else:
                    $ aa_location = '20h49 · Mesa'
                    $ aa_stage_action = 'Aguardam a comida; ainda não há pratos servidos.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'route': 'separadas'}):
        $ aa_audio_event('i00', 'line', 0, phase=0)
        "O garçom passou com uma bandeja para outra mesa. Vanessa acompanhou com os olhos, depois voltou a olhar para mim."
    if aa_matches(aa_state, {'route': 'varanda'}):
        $ aa_audio_event('i00', 'line', 1, phase=0)
        "Esperamos a comida. Vanessa mexia no guardanapo. Eu pensava numa forma de retomar o jantar sem voltar ao assunto da varanda."
    if aa_matches(aa_state, {'route': 'juntas', 'photo_asked': True}):
        $ aa_audio_event('i00', 'line', 2, phase=0)
        "Cortei um pedaço do frango. Ainda estava quente."
    if aa_matches(aa_state, {'route': 'juntas', 'photo_asked': False}):
        $ aa_audio_event('i00', 'line', 3, phase=0)
        "Yasmin puxou o copo para perto. Comecei a comer."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 4, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h50 · Mesa'
            $ aa_stage_action = 'Chegada dos pratos à mesa de dois.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg8_servir_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg8_servir_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h50 · Mesa'
                $ aa_stage_action = 'Chegada dos pratos à mesa de dois.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg8_servir_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg8_servir_troca'
            else:
                $ aa_location = '20h50 · Mesa'
                $ aa_stage_action = 'Chegada dos pratos à mesa de dois.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg8_servir_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg8_servir_antes'
        show screen aa_location_display
        "Nossos pratos chegaram. Recolhi as mãos; Vanessa afastou o copo para o garçom terminar de servir."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 5, phase=0)
        v "Obrigada."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 6, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'O serviço terminou; os dois começam a comer.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg7_mesa_pratos_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'O serviço terminou; os dois começam a comer.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'O serviço terminou; os dois começam a comer.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_antes'
        show screen aa_location_display
        "O garçom se afastou. Peguei o garfo e comecei a comer. Vanessa cortou o frango em pedaços pequenos."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 7, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_refeicao_quatro'
        else:
            $ aa_location = '20h54 · Mesa dos quatro'
            $ aa_stage_action = 'A refeição avança com os quatro presentes.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg8_comer_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg8_comer_quatro'
        show screen aa_location_display
        "Joãozão pediu o sal. Passei por cima dos pratos, com cuidado para não esbarrar nos copos."
    $ aa_audio_event('i00', 'line', 8, phase=0)
    "Vanessa separava os pedaços com o garfo antes de comer."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 9, phase=0)
        "Yasmin provou um pedaço da carne de Joãozão. Eu acompanhei a mão dela e demorei a voltar para o meu prato."
    if aa_matches(aa_state, {'route': 'varanda'}):
        $ aa_audio_event('i00', 'line', 10, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_refeicao_procura_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_antes'
        show screen aa_location_display
        "Yasmin estava atrás de mim. Esperei Vanessa baixar os olhos e virei para procurar a outra mesa."
    if aa_matches(aa_state, {'route': 'separadas', 'table_focus': 'vanessa'}):
        $ aa_audio_event('i00', 'line', 11, phase=0)
        "Eu ainda sabia exatamente onde Yasmin estava. Quando ouvi a mesa dela, mantive os olhos no prato."
    if aa_matches(aa_state, {'route': 'separadas', 'table_focus': 'promise'}):
        $ aa_audio_event('i00', 'line', 12, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_refeicao_procura_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_antes'
        show screen aa_location_display
        "Quando ouvi uma cadeira na mesa de Yasmin, olhei de relance e voltei ao prato antes que Vanessa levantasse os olhos."
    if aa_matches(aa_state, {'route': 'separadas', 'table_focus': 'yasmin'}):
        $ aa_audio_event('i00', 'line', 13, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h54 · Mesa'
            $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_refeicao_procura_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_troca'
            else:
                $ aa_location = '20h54 · Mesa'
                $ aa_stage_action = 'Durante a refeição, Feka procura Yasmin e Vanessa percebe o gesto.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg12_refeicao_procura_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_refeicao_procura_antes'
        show screen aa_location_display
        "Esperei Vanessa baixar os olhos para procurar Yasmin de novo."
    $ aa_audio_event('i00', 'line', 14, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_refeicao_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_location = '20h58 · Mesa dos quatro'
            $ aa_stage_action = 'Os quatro continuam comendo, sem nova fotografia.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg8_comer_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg8_comer_quatro'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '20h58 · Mesa'
                $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_troca'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '20h58 · Mesa'
                    $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_pratos_troca'
                else:
                    $ aa_location = '20h58 · Mesa'
                    $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_pratos_antes'
    show screen aa_location_display
    f "Tá bom o seu?"
    if aa_matches(aa_state, {'trust': {'lte': 1}}):
        $ aa_audio_event('i00', 'line', 15, phase=0)
        v "Tá."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': True}):
        $ aa_audio_event('i00', 'line', 16, phase=0)
        v "Tá."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': 'culpou'}):
        $ aa_audio_event('i00', 'line', 17, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Refeição na mesma mesa B+C; Yasmin está à diagonal de Feka.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_refeicao_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_refeicao_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '20h58 · Mesa dos quatro'
                $ aa_stage_action = 'Os quatro continuam comendo, sem nova fotografia.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg8_comer_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg8_comer_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_location = '20h58 · Mesa'
                    $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg7_mesa_pratos_troca'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_location = '20h58 · Mesa'
                        $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                        $ aa_table_party = 2
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg7_mesa_pratos_troca'
                    else:
                        $ aa_location = '20h58 · Mesa'
                        $ aa_stage_action = 'A comida diminui enquanto a conversa para.'
                        $ aa_table_party = 2
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg7_mesa_pratos_antes'
        show screen aa_location_display
        v "Tá."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 18, phase=0)
        v "Tá. Quer provar?"
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 19, phase=0)
        f "Quero."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 20, phase=0)
        "Ela cortou um pedaço e deixou na beirada do meu prato. Dei um pouco do meu para ela."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 21, phase=0)
        v "Tá. E o seu?"
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 22, phase=0)
        f "Tá bom também."
    if aa_matches(aa_state, {'trust': {'gte': 2}, 'photo_boundary_broken': False, 'table_history': {'ne': 'culpou'}, 'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 23, phase=0)
        "Vanessa assentiu e cortou outro pedaço."
    $ aa_audio_event('i00', 'line', 24, phase=0)
    "Quando paramos de comer, o garçom perguntou se podia retirar os pratos. Vanessa ainda tinha um pouco de comida. Disse que podia."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('i00', 'line', 25, phase=0)
        $ aa_location = '21h02 · Mesa B+C · Entre os pratos'
        $ aa_stage_action = 'Pratos recolhidos; Yasmin segue para noroeste, Joãozão para o balcão a leste.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_saida'
        show screen aa_location_display
        "O garçom recolheu os quatro pratos. Yasmin disse que ia tomar um ar e saiu pelo corredor em direção à passagem da varanda. Joãozão avisou que ia pedir água no balcão. Vanessa e eu ficamos nos nossos lugares."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('i00', 'line', 26, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_location = '21h02 · Entre os pratos'
            $ aa_stage_action = 'Pratos recolhidos; dois lugares vazios mostram a ausência temporária do casal.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_intervalo at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_intervalo'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_location = '21h02 · Entre os pratos'
                $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_papel'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_location = '21h02 · Entre os pratos'
                    $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_papel'
                else:
                    $ aa_location = '21h02 · Entre os pratos'
                    $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_papel_antes'
        show screen aa_location_display
        "Ele recolheu nossos pratos e talheres. Na outra mesa, Yasmin se levantou e foi até a porta da varanda; Joãozão seguiu para o balcão."
    $ aa_audio_event('i00', 'line', 27, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h03 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_intervalo at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_intervalo'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_papel at aa_camera(1.07, 0.5, 0.43)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_papel'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_papel at aa_camera(1.07, 0.5, 0.43)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_papel'
                else:
                    $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_papel_antes at aa_camera(1.07, 0.5, 0.43)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    "Vanessa tirou da bolsa um papel dobrado e abriu sobre a mesa. Tinha medidas anotadas e um desenho de um quarto."
    menu:
        "Ficar com Vanessa.":
            $ aa_audio_event('i00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'i00', 0)
            $ aa_audio_event('i00', 'response', 0, 0)
            f "Deixa eu ver essas medidas."
            $ aa_audio_event('i00', 'response', 1, 0)
            "Vanessa virou o papel para que eu pudesse ler. Continuei sentado."
            jump iv
        "Conversar com Joãozão, sem plateia.":
            $ aa_audio_event('i00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'i00', 1)
            $ aa_audio_event('i00', 'response', 0, 1)
            f "Vou falar um minuto com o Joãozão."
            $ aa_audio_event('i00', 'response', 1, 1)
            v "Tá. Eu espero aqui."
            $ aa_audio_event('i00', 'response', 2, 1)
            $ aa_stage_action = 'Dois homens de pé, mãos abertas; sem plateia.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_balcao_r1'
            "Afastei a cadeira, contornei a ponta livre da mesa e segui pelo corredor até o balcão. Joãozão acabava de pedir água."
            jump ij
        "Procurar Yasmin no corredor.":
            $ aa_audio_event('i00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'i00', 2)
            $ aa_audio_event('i00', 'response', 0, 2)
            "Afastei a cadeira. Vanessa parou com a mão em cima do papel."
            $ aa_audio_event('i00', 'response', 1, 2)
            v "Você vai falar com ela?"
            $ aa_audio_event('i00', 'response', 2, 2)
            f "Só um minuto."
            $ aa_audio_event('i00', 'response', 3, 2)
            $ aa_stage_action = 'Feka chega à passagem da varanda; Yasmin fica à esquerda, junto ao acesso oeste.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg12_varanda_r1 at aa_camera(1.07, 0.3, 0.32)
            with Dissolve(0.25)
            $ aa_last_art = 'cg12_varanda_r1'
            "Ela dobrou o papel sem responder. Contornei a mesa e segui pelo corredor até a passagem da varanda. Yasmin ainda estava do lado de dentro."
            jump iy

label iv:
    $ aa_node = 'iv'
    $ aa_location = '21h06 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1266)
    $ aa_present = ()
    $ aa_audio_enter('iv')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_papel_espera'
            else:
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    $ aa_audio_event('iv', 'line', 0, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_papel_espera'
            else:
                $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    "O desenho mostrava a cama encostada na parede. Vanessa apontou a medida do espaço que sobrava."
    $ aa_audio_event('iv', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_papel'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Ela busca a confirmação da visita.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.07, 0.52, 0.38)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Ela busca a confirmação da visita.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_papel_espera at aa_camera(1.07, 0.52, 0.38)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_papel_espera'
            else:
                $ aa_stage_action = 'Ela busca a confirmação da visita.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_papel_antes at aa_camera(1.07, 0.52, 0.38)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_papel_antes'
    show screen aa_location_display
    v "E amanhã? Você consegue ir depois da aula?"
    $ aa_audio_event('iv', 'line', 2, phase=0)
    f "Sua mãe fica até que horas?"
    $ aa_audio_event('iv', 'line', 3, phase=0)
    v "Só de manhã. Ela tem que ir embora antes do almoço."
    $ aa_audio_event('iv', 'line', 4, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h06 · Mesa B+C'
        $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_intervalo_guardado'
    else:
        $ aa_stage_action = 'Ela dobra e guarda o papel antes da escolha.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_papel_guardado at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_papel_guardado'
    show screen aa_location_display
    "Ela dobrou o papel pela mesma marca e guardou na bolsa. Esperou minha resposta."
    menu:
        "Perguntar o que ela queria desta noite e ouvir.":
            $ aa_audio_event('iv', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'iv', 0)
            $ aa_audio_event('iv', 'response', 0, 0)
            v "Eu queria comer com você. Contar do apartamento. Hoje parece que eu preciso acertar tudo que falo pra você ficar."
            $ aa_audio_event('iv', 'response', 1, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Dizer que eu também estou tendo uma noite difícil.":
            $ aa_audio_event('iv', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'iv', 1)
            $ aa_audio_event('iv', 'response', 0, 1)
            v "Eu sei."
            $ aa_audio_event('iv', 'response', 1, 1)
            "Ela começou a perguntar o que tinha acontecido com Yasmin. Parou."
            $ aa_audio_event('iv', 'response', 2, 1)
            v "Mas eu também tô aqui."
            $ aa_audio_event('iv', 'response', 3, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Confirmar a ajuda e combinar depois da aula.":
            $ aa_audio_event('iv', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'iv', 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_papel_espera'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_papel_antes'
            $ aa_audio_event('iv', 'response', 0, 2)
            v "Então eu te mando o endereço. Posso esperar você depois da aula?"
            $ aa_audio_event('iv', 'response', 1, 2)
            f "Pode."
            $ aa_audio_event('iv', 'response', 2, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_papel'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Ela tirou o papel da bolsa outra vez. Eu tinha dado uma hora à promessa e evitado o resto da conversa."
            $ aa_audio_event('iv', 'response', 3, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Vanessa guardou o papel outra vez. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00

label ij:
    $ aa_node = 'ij'
    $ aa_location = '21h06 · Balcão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1266)
    $ aa_present = ()
    $ aa_audio_enter('ij')
    $ aa_stage_action = 'Dois homens de pé, mãos abertas; sem plateia.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    $ aa_audio_event('ij', 'line', 0, phase=0)
    j "Você veio falar dela comigo? Eu não quero ficar vigiando vocês."
    $ aa_audio_event('ij', 'line', 1, phase=0)
    f "Então não fica."
    $ aa_audio_event('ij', 'line', 2, phase=0)
    $ aa_stage_action = 'Joãozão responde à provocação sem avançar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.12, 0.74, 0.31)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    j "Ela já pediu pra você parar. E você vem falar comigo. Quer que eu faça o quê?"
    $ aa_audio_event('ij', 'line', 3, phase=0)
    "Eu tinha preparado uma fala sobre ciúme. Ela não servia para responder àquilo."
    $ aa_audio_event('ij', 'line', 4, phase=0)
    $ aa_stage_action = 'A referência a Vanessa faz o plano voltar aos dois.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    j "E a Vanessa tá sentada lá, cara."
    menu:
        "Admitir minha insistência e pedir que não faça uma cena.":
            $ aa_audio_event('ij', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'ij', 0)
            $ aa_audio_event('ij', 'response', 0, 0)
            j "Então escuta quando ela pede. Não precisa vir explicar pra mim."
            $ aa_audio_event('ij', 'response', 1, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Dizer que Yasmin sabe responder por ela.":
            $ aa_audio_event('ij', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'ij', 1)
            $ aa_audio_event('ij', 'response', 0, 1)
            j "Sabe. E já respondeu. Você sabe disso melhor do que eu."
            $ aa_audio_event('ij', 'response', 1, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Chamar Joãozão de inseguro, falando alto.":
            $ aa_audio_event('ij', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'ij', 2)
            $ aa_audio_event('ij', 'response', 0, 2)
            f "Você é muito inseguro, cara."
            $ aa_audio_event('ij', 'response', 1, 2)
            "Duas pessoas no balcão olharam. Joãozão largou o copo e me encarou. Dei um passo para trás."
            $ aa_audio_event('ij', 'response', 2, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00

label iy:
    $ aa_node = 'iy'
    $ aa_location = '21h06 · Corredor'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1266)
    $ aa_present = ()
    $ aa_audio_enter('iy')
    $ aa_stage_action = 'Feka chega à passagem da varanda; Yasmin fica à esquerda, junto ao acesso oeste.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.07, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    $ aa_audio_event('iy', 'line', 0, phase=0)
    y "Você deixou sua namorada na mesa."
    $ aa_audio_event('iy', 'line', 1, phase=0)
    "Não consegui dizer que era só um minuto. Yasmin já conhecia a duração dos meus minutos."
    $ aa_audio_event('iy', 'line', 2, phase=0)
    f "Você me acha uma pessoa tão ruim assim?"
    $ aa_audio_event('iy', 'line', 3, phase=0)
    $ aa_stage_action = 'A segunda recusa tem menos espaço para negociação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_varanda_r1 at aa_camera(1.17, 0.28, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_varanda_r1'
    show screen aa_location_display
    y "Eu não quero ter que te avaliar para poder jantar."
    $ aa_audio_event('iy', 'line', 4, phase=0)
    "Essa resposta eu não podia transformar em quase. Ela nem estava falando de amor."
    menu:
        "Parar de pedir uma resposta diferente.":
            $ aa_audio_event('iy', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'iy', 0)
            $ aa_audio_event('iy', 'response', 0, 0)
            f "Tá. Eu vou voltar."
            $ aa_audio_event('iy', 'response', 1, 0)
            y "Volta."
            $ aa_audio_event('iy', 'response', 2, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Pedir só que ela admita que já me deu esperança.":
            $ aa_audio_event('iy', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'iy', 1)
            $ aa_audio_event('iy', 'response', 0, 1)
            y "Eu preciso pedir desculpa por você ter entendido o que quis?"
            $ aa_audio_event('iy', 'response', 1, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00
        "Dizer que estou com Vanessa e não preciso dela.":
            $ aa_audio_event('iy', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'iy', 2)
            $ aa_audio_event('iy', 'response', 0, 2)
            y "Então por que você tá aqui falando comigo?"
            $ aa_audio_event('iy', 'response', 1, 2)
            "Eu tinha deixado Vanessa esperando para vir dizer que não precisava de Yasmin. Fiquei sem resposta."
            $ aa_audio_event('iy', 'response', 2, 2)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_location = '21h06 · Mesa B+C'
                $ aa_stage_action = 'Vanessa guarda o papel e espera, sem mudar de cadeira.'
                $ aa_table_party = 2
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_intervalo_guardado at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_intervalo_guardado'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_location = '21h06 · Mesa B+C'
                    $ aa_stage_action = 'Feka e Vanessa permanecem em C, frente a frente; assentos de B vazios, papel aberto.'
                    $ aa_table_party = 2
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_intervalo_papel at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_intervalo_papel'
                else:
                    if aa_matches(aa_state, {'route': 'varanda'}):
                        $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_papel_espera'
                    else:
                        if aa_matches(aa_state, {'seat_swapped': True}):
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg5_papel_espera'
                        else:
                            $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = True
                            hide screen aa_phone_view
                            scene cg12_papel_antes at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg12_papel_antes'
            "Voltei pelo corredor e sentei de frente para Vanessa. Ela já tinha guardado o papel. Quando o garçom passou, pedi um pudim com duas colheres."
            jump r00

label r00:
    $ aa_node = 'r00'
    $ aa_location = '21h18 · A mesa de Vanessa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1278)
    $ aa_present = ()
    $ aa_audio_enter('r00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pudim na mesa C; Yasmin e Joãozão ainda ausentes, cadeiras de B vazias.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_dois'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pudim chega perto de Vanessa; as cadeiras centrais ainda estão vazias.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_privado at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_privado'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa'
                else:
                    $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_antes'
    show screen aa_location_display
    $ aa_audio_event('r00', 'line', 0, phase=0)
    "O garçom trouxe o pudim com duas colheres e completou a água. Vanessa não tinha dito que queria sobremesa. Eu queria conseguir chegar à sobremesa."
    $ aa_audio_event('r00', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pudim na mesa C; Yasmin e Joãozão ainda ausentes, cadeiras de B vazias.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_dois'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pudim afastado, dois lugares ainda vazios.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Vanessa afastou o prato. Não levantou a voz. Eu precisei me inclinar para ouvir."
    if aa_matches(aa_state, {'presence_told': False}):
        $ aa_audio_event('r00', 'line', 2, phase=0)
        v "Você sabia que ela estaria aqui?"
    if aa_matches(aa_state, {'presence_told': True}):
        $ aa_audio_event('r00', 'line', 3, phase=0)
        v "Você me disse que ela estaria aqui. Eu quero entender por que quis vir mesmo assim."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r00', 'line', 4, phase=0)
        "Eu sabia. Vi no quarto, enquanto ela procurava o brinco."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r00', 'line', 5, phase=0)
        "Não sabia. Percebi o quanto queria usar essa resposta para encerrar todo o resto."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r00', 'line', 6, phase=0)
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
        show screen aa_location_display
        "Yasmin voltou da passagem da varanda; Joãozão veio do balcão. Os dois puxaram as próprias cadeiras na outra ponta das mesas unidas. Vanessa esperou o barulho parar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r00', 'line', 7, phase=0)
        v "Fala baixo. Eu tô ouvindo."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('r00', 'line', 8, phase=0)
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sobremesa_afastada'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        "Yasmin e Joãozão voltaram para a outra mesa; as cadeiras arrastaram no piso."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}, 'interval': 'vanessa', 'present_choice': False}):
        $ aa_audio_event('r00', 'line', 9, phase=0)
        "Olhei na direção do barulho e voltei para Vanessa antes que ela precisasse me esperar."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}, 'interval': 'joaozao'}):
        $ aa_audio_event('r00', 'line', 10, phase=0)
        "Acompanhei os dois até se sentarem. Depois procurei Vanessa outra vez."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}, 'interval': 'yasmin'}):
        $ aa_audio_event('r00', 'line', 11, phase=0)
        "Acompanhei Yasmin até ela se sentar. Vanessa esperou até eu parar."
    if aa_matches(aa_state, {'route': 'separadas', 'interval': 'vanessa', 'present_choice': True}):
        $ aa_audio_event('r00', 'line', 12, phase=0)
        "Ouvi as cadeiras, mas continuei olhando para Vanessa. Ela esperava minha resposta."
    menu:
        "Admitir que vi a publicação e quis encontrá-la." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('r00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r00', 0)
            $ aa_audio_event('r00', 'response', 0, 0)
            f "Eu vi a publicação antes de sair de casa. Sabia que ela estava aqui e quis vir mesmo assim."
            jump r01
        "Dizer que não sabia, mas escolhi o lugar por causa dela." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('r00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r00', 1)
            $ aa_audio_event('r00', 'response', 0, 1)
            f "Eu não sabia que ela ia estar aqui. Mas guardei o nome do restaurante por causa dela."
            jump r01
        "Falar só da indicação e esconder o que vi no celular." if aa_matches(aa_state, {'knew': True, 'presence_told': False}):
            $ aa_audio_event('r00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r00', 2)
            jump r02
        "Repetir que foi coincidência e que Vanessa está exagerando.":
            $ aa_audio_event('r00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'r00', 3)
            $ aa_audio_event('r00', 'response', 0, 3)
            f "Foi coincidência encontrar os dois. Você tá exagerando."
            $ aa_audio_event('r00', 'response', 1, 3)
            "Ela deixou de mexer na colher e olhou para mim."
            jump r02
        "Dizer que a indicação veio de Yasmin, mas que escolhi o lugar pensando em Vanessa." if aa_matches(aa_state, {'knew': False, 'route': 'separadas', 'interval': 'vanessa', 'source_truth': True, 'present_choice': True, 'used': False, 'trust': {'gte': 2}}):
            $ aa_audio_event('r00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'r00', 4)
            $ aa_location = '21h22 · Mesa junto ao vidro'
            $ aa_stage_action = 'Feka mantém o olhar em Vanessa enquanto assume a indicação e muda o motivo da reserva.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg13_mesa_escolha at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg13_mesa_escolha'
            jump h00

label r01:
    $ aa_node = 'r01'
    $ aa_location = '21h22 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1282)
    $ aa_present = ()
    $ aa_audio_enter('r01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r01', 'line', 0, phase=0)
        v "Você viu que ela estava aqui e quis vir mesmo assim?"
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r01', 'line', 1, phase=0)
        v "E eu agradecendo por você ter pensado em mim."
    $ aa_audio_event('r01', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Ela olhou para as mãos. Eu achei que fosse chorar e senti uma vontade horrível de que chorasse. Uma pessoa chorando ainda pode aceitar um abraço."
    $ aa_audio_event('r01', 'line', 3, phase=0)
    v "Mas você queria sair comigo também?"
    menu:
        "Admitir que fiquei com ela para não me sentir sozinho.":
            $ aa_audio_event('r01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r01', 0)
            jump r03
        "Dizer que gosto dela, mas estou confuso.":
            $ aa_audio_event('r01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r01', 1)
            jump r02
        "Pedir que ela veja quanto Yasmin me machucou.":
            $ aa_audio_event('r01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r01', 2)
            jump r04
        "Dizer que é com ela que quero ficar, só para acalmá-la.":
            $ aa_audio_event('r01', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'r01', 3)
            $ aa_audio_event('r01', 'response', 0, 3)
            f "Queria. É com você que eu quero ficar. Eu gosto de você."
            $ aa_audio_event('r01', 'response', 1, 3)
            v "Você tá falando isso porque eu tô quase chorando?"
            $ aa_audio_event('r01', 'response', 2, 3)
            f "Não. Tô falando porque é verdade."
            $ aa_audio_event('r01', 'response', 3, 3)
            "Eu queria que ela parasse de perguntar. Disse aquilo olhando para ela, sem procurar Yasmin."
            $ aa_audio_event('r01', 'response', 4, 3)
            "Vanessa soltou o guardanapo que estava apertando. Ainda esperou um pouco antes de responder."
            $ aa_audio_event('r01', 'response', 5, 3)
            v "Tá. Eu quero acreditar em você."
            $ aa_audio_event('r01', 'response', 6, 3)
            "Ela falou mais baixo. Eu senti alívio e fiquei quieto. Por alguns minutos, fingimos que a resposta tinha resolvido a pergunta."
            jump v00

label r02:
    $ aa_node = 'r02'
    $ aa_location = '21h25 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1285)
    $ aa_present = ()
    $ aa_audio_enter('r02')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r02', 'line', 0, phase=0)
    v "Eu tento acreditar. Mas não consigo entender o que você quer comigo."
    $ aa_audio_event('r02', 'line', 1, phase=0)
    v "Se eu parar de perguntar, você fica aqui comigo até a gente ir embora?"
    $ aa_audio_event('r02', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Ela continuava sentada. Parecia esperar um sim. Eu ainda estava escolhendo a parte da pergunta que podia responder."
    menu:
        "Parar de reduzir o problema e contar tudo.":
            $ aa_audio_event('r02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r02', 0)
            jump r03
        "Pedir para terminar o jantar sem falar nisso.":
            $ aa_audio_event('r02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r02', 1)
            if aa_matches(aa_state, {'interval': 'yasmin'}):
                $ aa_audio_event('r02', 'response', 0, 1)
                v "Tá. Mas você foi atrás dela e me deixou esperando. Se quiser sair da mesa, fala comigo antes."
            if aa_matches(aa_state, {'interval': 'joaozao'}):
                $ aa_audio_event('r02', 'response', 1, 1)
                v "Tá. Você foi falar com Joãozão e eu fiquei esperando. Se precisar levantar, me avisa antes."
            if aa_matches(aa_state, {'interval': 'vanessa', 'route': 'varanda'}):
                $ aa_audio_event('r02', 'response', 2, 1)
                v "Tá. Quando a gente chegou, você me deixou esperando pra falar com ela. Agora eu queria ficar com você."
            if aa_matches(aa_state, {'interval': 'vanessa', 'route': {'ne': 'varanda'}}):
                $ aa_audio_event('r02', 'response', 3, 1)
                v "Tá. Você ficou aqui comigo. Eu sei. Só queria sentir que você também quer estar aqui."
            $ aa_audio_event('r02', 'response', 4, 1)
            "Aproximei o pudim. Ela deixou a colher onde estava."
            jump v00
        "Dizer que ela aceitou vir e também fez suas escolhas.":
            $ aa_audio_event('r02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r02', 2)
            jump r05

label r04:
    $ aa_node = 'r04'
    $ aa_location = '21h26 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1286)
    $ aa_present = ()
    $ aa_audio_enter('r04')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r04', 'line', 0, phase=0)
    f "Você não entende o que foram esses anos."
    if aa_matches(aa_state, {'past_told': False}):
        $ aa_audio_event('r04', 'line', 1, phase=0)
        v "Você não me contou o que aconteceu nesses anos. Eu tô tentando entender."
    if aa_matches(aa_state, {'past_told': True}):
        $ aa_audio_event('r04', 'line', 2, phase=0)
        v "Eu lembro do que você contou. Ainda tô tentando entender."
    $ aa_audio_event('r04', 'line', 3, phase=0)
    f "Eu sofri muito."
    $ aa_audio_event('r04', 'line', 4, phase=0)
    v "Eu posso ouvir. Só... você quer ficar comigo ou quer que eu te ajude com ela?"
    $ aa_audio_event('r04', 'line', 5, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Ela tinha baixado a voz para me acalmar. Percebi que eu podia continuar falando dos meus anos ruins e adiar a resposta."
    menu:
        "Admitir o que fiz sem pedir pena.":
            $ aa_audio_event('r04', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r04', 0)
            jump r03
        "Dizer que estou sozinho até quando estou com ela.":
            $ aa_audio_event('r04', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r04', 1)
            jump r05
        "Ficar calado, esperando que ela pare de perguntar.":
            $ aa_audio_event('r04', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r04', 2)
            $ aa_audio_event('r04', 'response', 0, 2)
            "Ela virou o rosto para a janela. Não insisti. Esperei que o silêncio fizesse por mim o que minhas frases não conseguiam."
            jump v00

label r03:
    $ aa_node = 'r03'
    $ aa_location = '21h29 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1289)
    $ aa_present = ()
    $ aa_audio_enter('r03')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r03', 'line', 0, phase=0)
    f "Eu não queria ficar sozinho. Você gostava de estar comigo e eu deixei você achar que era igual."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r03', 'line', 1, phase=0)
        f "Eu vi que ela estava aqui antes de a gente sair."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r03', 'line', 2, phase=0)
        f "Eu não sabia que ia encontrar ela. Mas o lugar tinha a ver com ela desde o começo."
    $ aa_audio_event('r03', 'line', 3, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    v "Mas você gostou de ficar comigo depois?"
    $ aa_audio_event('r03', 'line', 4, phase=0)
    "Olhei para o prato. Ela disse que não precisava ter sido desde o começo. Eu podia dizer que gostava. Ela tinha deixado a resposta pronta para mim."
    menu:
        "Pedir uma chance e prometer esquecer Yasmin.":
            $ aa_audio_event('r03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r03', 0)
            jump r06
        "Ouvir o que Vanessa quer fazer, sem negociar a resposta.":
            $ aa_audio_event('r03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r03', 1)
            jump r06
        "Dizer que contei a verdade e mereço algum crédito.":
            $ aa_audio_event('r03', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r03', 2)
            jump r05

label r06:
    $ aa_node = 'r06'
    $ aa_location = '21h33 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1293)
    $ aa_present = ()
    $ aa_audio_enter('r06')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'bargain': True}):
        $ aa_audio_event('r06', 'line', 0, phase=0)
        v "Se você quer continuar, por que fala como se eu tivesse que te convencer?"
    $ aa_audio_event('r06', 'line', 1, phase=0)
    v "Eu gosto de você. Tô tentando entender o que eu faço com isso agora."
    $ aa_audio_event('r06', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka tenta aproximar a mão; Vanessa recolhe as suas e pede distância.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_limite_mao at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_limite_mao'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_mao_corrigida at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_mao_corrigida'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_mao at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_mao'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg2_mao at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_mao'
                    else:
                        $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_mao_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_mao_antes'
    show screen aa_location_display
    v "Não encosta em mim agora."
    $ aa_audio_event('r06', 'line', 3, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_sobremesa_afastada'
                    else:
                        $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Minha mão já estava indo. Recolhi antes de chegar à dela."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r06', 'line', 4, phase=0)
        "Baixei a voz. Yasmin olhava para o copo; Joãozão, para a recepção. Eles continuavam sentados perto de nós."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('r06', 'line', 5, phase=0)
        "Ninguém na outra mesa teria percebido a diferença."
    $ aa_audio_event('r06', 'line', 6, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    v "Não tô dizendo que nunca mais. Eu só não consigo agora."
    $ aa_audio_event('r06', 'line', 7, phase=0)
    "Ela se apressou em explicar o limite. Eu podia respeitar sem fazê-la pedir desculpa por ele."
    menu:
        "Recolher a mão e ouvir como ela quer seguir.":
            $ aa_audio_event('r06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r06', 0)
            jump v00
        "Dizer que ela não pode me deixar assim depois de eu me abrir.":
            $ aa_audio_event('r06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r06', 1)
            jump r05
        "Pedir desculpa diante dos outros para mostrar que é sério.":
            $ aa_audio_event('r06', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r06', 2)
            jump r07

label r07:
    $ aa_node = 'r07'
    $ aa_location = '21h37 · Salão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1297)
    $ aa_present = ()
    $ aa_audio_enter('r07')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_desculpa_publica'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_publico'
        else:
            $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    $ aa_audio_event('r07', 'line', 0, phase=0)
    "Levantei a voz antes de levantar da cadeira. Contei que estava errado. Eu disse o nome de Vanessa duas vezes."
    $ aa_audio_event('r07', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_desculpa_publica'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_publico'
        else:
            $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_publico_dois at aa_camera(1.12, 0.74, 0.35)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    v "Não faz isso comigo."
    $ aa_audio_event('r07', 'line', 2, phase=0)
    "Yasmin parou de mexer no copo. Joãozão olhou para a recepção. Todo mundo estava prestando atenção em mim. Era uma sensação boa demais para ser uma desculpa limpa."
    $ aa_audio_event('r07', 'line', 3, phase=0)
    v "Senta, por favor. Fala comigo."
    $ aa_audio_event('r07', 'line', 4, phase=0)
    "Ouvir meu pedido em voz alta parecia ter importado. Ela ainda queria que eu parasse."
    menu:
        "Parar quando Vanessa pede e voltar a sentar.":
            $ aa_audio_event('r07', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r07', 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_pudim_quatro'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_desculpa_publica'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 4
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg4_pudim_publico'
                    else:
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_publico_dois'
            $ aa_audio_event('r07', 'response', 0, 0)
            "Sentei e baixei a voz. Vanessa esperou que eu parasse de olhar para os outros."
            jump v00
        "Continuar até todos entenderem meu lado.":
            $ aa_audio_event('r07', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r07', 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_pudim_quatro'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka de pé no lado oeste; Vanessa pede que sente do outro lado.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_desculpa_publica at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_desculpa_publica'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 4
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg4_pudim_publico'
                    else:
                        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_publico_dois'
            $ aa_audio_event('r07', 'response', 0, 1)
            "Continuei falando por cima dela. Quando sentei, Vanessa já tinha puxado a bolsa para perto."
            jump r05

label r05:
    $ aa_node = 'r05'
    $ aa_location = '21h40 · Salão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1300)
    $ aa_present = ()
    $ aa_audio_enter('r05')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('r05', 'line', 0, phase=0)
    v "Eu não aguento você falando comigo desse jeito."
    $ aa_audio_event('r05', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_hesita'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_hesita_antes'
    show screen aa_location_display
    "Ela puxou a bolsa para o colo. O casaco continuou na cadeira."
    $ aa_audio_event('r05', 'line', 2, phase=0)
    v "Eu devia ir embora."
    $ aa_audio_event('r05', 'line', 3, phase=0)
    "Esperei que levantasse. Ela ficou olhando para mim."
    $ aa_audio_event('r05', 'line', 4, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Espera a resposta sem se levantar.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Espera a resposta sem se levantar.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_hesita'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Espera a resposta sem se levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    $ aa_stage_action = 'Espera a resposta sem se levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_hesita_antes'
    show screen aa_location_display
    v "Você quer que eu vá?"
    menu:
        "Parar de argumentar e dar espaço para ela decidir.":
            $ aa_audio_event('r05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r05', 0)
            jump v01
        "Prometer que vou ficar com ela e ir à mudança.":
            $ aa_audio_event('r05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r05', 1)
            jump v02
        "Dizer que ela está fazendo uma cena para me prender.":
            $ aa_audio_event('r05', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r05', 2)
            jump v01

label k00:
    $ aa_node = 'k00'
    $ aa_location = '21h48 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1308)
    $ aa_present = ()
    $ aa_audio_enter('k00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_tres'
        else:
            $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_tres'
            else:
                $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
        else:
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg_conta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_conta_presente'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_conta_presente'
                    else:
                        $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_conta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_conta_antes'
    show screen aa_location_display
    $ aa_audio_event('k00', 'line', 0, phase=0)
    "Abri a conta. Cento e oitenta reais pela minha parte e a de Vanessa, com o serviço e a sobremesa."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 1, phase=0)
        "Eu tinha cento e vinte e tinha prometido pagar pelos dois. Faltavam sessenta."
    if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
        $ aa_audio_event('k00', 'line', 2, phase=0)
        "Eu tinha prometido pagar pelos dois. Ela já tinha pago a parte dela."
    if aa_matches(aa_state, {'debt': False}):
        $ aa_audio_event('k00', 'line', 3, phase=0)
        "Cabia no que tínhamos combinado. Pela primeira vez, uma parte da noite tinha o tamanho certo."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('k00', 'line', 4, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_tres'
            else:
                $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg_conta at aa_camera(1.1, 0.51, 0.45)
                with Dissolve(0.25)
                $ aa_last_art = 'cg_conta'
        show screen aa_location_display
        "Dos cento e oitenta, restavam os meus noventa."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 5, phase=0)
        v "Posso completar os sessenta. Depois você me devolve."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 6, phase=0)
        "Eu ainda podia pedir para dividir a conta. Tinha sido ela quem propôs isso antes de sairmos."
    menu:
        "Pagar minha parte como combinado." if aa_matches(aa_state, {'debt': False}):
            $ aa_audio_event('k00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'k00', 0)
            jump k01
        "Admitir que prometi mais do que podia e pedir divisão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'k00', 1)
            jump k01
        "Pagar minha parte agora que Vanessa acertou a dela." if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
            $ aa_audio_event('k00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'k00', 2)
            jump k01
        "Pedir dinheiro emprestado a Joãozão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'k00', 3)
            jump jl00
        "Reclamar alto do preço para desviar a atenção.":
            $ aa_audio_event('k00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'k00', 4)
            jump k01
        "Aceitar que Vanessa complete o dinheiro e combinar a devolução." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'k00', 5)
            if aa_matches(aa_state, {'route': 'juntas'}):
                if aa_matches(aa_state, {'v_gone': True}):
                    $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                    $ aa_table_party = 3
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_tres'
                else:
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Ela completa a conta antes da saída do casal.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg4_pudim_pagamento at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg4_pudim_pagamento'
                else:
                    $ aa_stage_action = 'Ela completa o pagamento no cartão.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_pagamento'
            $ aa_audio_event('k00', 'response', 0, 5)
            $ aa_finance_event('dinner_vanessa')
            "Paguei cento e vinte. Vanessa completou os sessenta no cartão. Eu disse que devolveria na sexta."
            $ aa_audio_event('k00', 'response', 1, 5)
            v "Tá. Sexta."
            $ aa_audio_event('k00', 'response', 2, 5)
            "Ela repetiu a data. Eu fiz que sim. Já estava arrependido de ter escolhido uma."
            jump k01

label k01:
    $ aa_node = 'k01'
    $ aa_location = '21h55 · Salão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1315)
    $ aa_present = ()
    $ aa_finance_event('settle_dinner')
    $ aa_audio_enter('k01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_tres'
        else:
            $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_conta_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_tres'
            else:
                $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
        else:
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Feka sozinho após Vanessa sair.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sozinho'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_sobremesa'
                    else:
                        $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('k01', 'line', 0, phase=0)
        "A recepção já estava olhando para nossa mesa. O garçom perguntou, pela segunda vez, se precisávamos de alguma coisa."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_event('k01', 'line', 1, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_conta_presente'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_conta_presente'
                    else:
                        $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_conta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_conta_antes'
        show screen aa_location_display
        "O Pix de Joãozão tinha completado o que faltava. Eu precisava devolver os sessenta até meio-dia de amanhã."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_event('k01', 'line', 2, phase=0)
        "Eu tinha pedido dinheiro a ele. Ainda estava tentando aceitar isso."
    if aa_matches(aa_state, {'bill': 'cena'}):
        $ aa_audio_event('k01', 'line', 3, phase=0)
        "O garçom apontou os itens. Eu sabia que estavam certos. Continuei olhando até ele perceber que eu não tinha uma dúvida."
    if aa_matches(aa_state, {'bill': 'cena', 'debt': True, 'v_gone': False}):
        $ aa_finance_event('dinner_split')
        $ aa_audio_event('k01', 'line', 4, phase=0)
        "Vanessa pediu que separassem o que ela tinha consumido. Com a parte dela paga, meu saldo foi suficiente. Eu ainda resmunguei enquanto aproximava o cartão."
    if aa_matches(aa_state, {'bill': 'admitida', 'v_gone': False}):
        $ aa_audio_event('k01', 'line', 5, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            if aa_matches(aa_state, {'v_gone': True}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_conta_quatro'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_conta_presente'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = False
                        hide screen aa_phone_view
                        scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg2_conta_presente'
                    else:
                        $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_conta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_conta_antes'
        show screen aa_location_display
        v "Eu trouxe dinheiro pra minha parte. Por que você insistiu que dava pra pagar tudo?"
    $ aa_audio_event('k01', 'line', 6, phase=0)
    "O salão começava a esvaziar. Do lado de fora, a chuva já tinha diminuído."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('k01', 'line', 7, phase=0)
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Todos saíram da mesa B+C; Feka permanece no mesmo assento oeste.'
            $ aa_table_party = 1
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_sozinho'
        else:
            $ aa_stage_action = 'Pudim na mesa C; Yasmin e Joãozão ainda ausentes, cadeiras de B vazias.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_dois'
        show screen aa_location_display
        "Yasmin recolheu a bolsa. Ela e Joãozão deixaram as cadeiras e foram pagar a conta deles no balcão."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('k01', 'line', 8, phase=0)
        "Na outra mesa, Yasmin recolheu a bolsa. Ela e Joãozão foram ao balcão acertar a conta."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False, 'bond': 'mantido'}):
        $ aa_audio_event('k01', 'line', 9, phase=0)
        v "Sobre amanhã, me avisa antes de sair. Eu te mando o endereço."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False, 'bond': 'mantido'}):
        $ aa_audio_event('k01', 'line', 10, phase=0)
        "Ela guardou o telefone e procurou o casaco."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False, 'bond': 'indefinido'}):
        $ aa_audio_event('k01', 'line', 11, phase=0)
        v "A mudança eu resolvo com a minha mãe. A gente combina outra hora para conversar."
    menu:
        "Perguntar a Vanessa como ela quer ir embora." if aa_matches(aa_state, {'v_gone': False}):
            $ aa_audio_event('k01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'k01', 0)
            jump s00
        "Aceitar que ela foi embora e sair sozinho." if aa_matches(aa_state, {'v_gone': True}):
            $ aa_audio_event('k01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'k01', 1)
            jump e04
        "Tentar uma última conversa com Yasmin.":
            $ aa_audio_event('k01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'k01', 2)
            jump s01
        "Acertar o limite com Joãozão, sem levantar a voz." if aa_matches(aa_state, {'j_limit': True, 'truth': True}):
            $ aa_audio_event('k01', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'k01', 3)
            jump s02
        "Provocar Joãozão na frente de Yasmin.":
            $ aa_audio_event('k01', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'k01', 4)
            jump s03
        "Usar uma foto ou mensagem para fazer a noite parecer boa." if aa_matches(aa_state, {'public': True}):
            $ aa_audio_event('k01', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'k01', 5)
            jump e08
        "Perguntar se Vanessa quer voltar comigo para a moradia." if aa_matches(aa_state, {'tender_lie': True, 'chosen_vanessa': True, 'bond': 'mantido', 'contact': 'juntos', 'promised': True, 'bill': 'dividida', 'v_gone': False}):
            $ aa_audio_event('k01', 'choice', 6, 6)
            $ aa_state = aa_choose(aa_state, 'k01', 6)
            jump h02

label s00:
    $ aa_node = 's00'
    $ aa_location = '22h02 · Entrada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1322)
    $ aa_present = ()
    $ aa_audio_enter('s00')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('s00', 'line', 0, phase=0)
    "Vanessa conferiu o destino no aplicativo. Depois baixou o telefone e me olhou."
    if aa_matches(aa_state, {'bond': 'mantido'}):
        $ aa_audio_event('s00', 'line', 1, phase=0)
        v "Você espera comigo?"
    if aa_matches(aa_state, {'bond': {'ne': 'mantido'}}):
        $ aa_audio_event('s00', 'line', 2, phase=0)
        v "Eu vou sozinha. Mas espera o carro chegar?"
    $ aa_audio_event('s00', 'line', 3, phase=0)
    $ aa_stage_action = 'Após pedir companhia, ela volta a conferir a placa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'carro'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('carro')
    show screen aa_phone_view('carro')
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    "Eu disse que esperava. Ela virou a tela para mim: o carro ainda estava a quatro minutos."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('s00', 'line', 4, phase=0)
        $ aa_stage_action = 'Telefone baixo; a resposta é dada a Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_saida_espera'
        show screen aa_location_display
        v "Se você mudar de ideia sobre amanhã, fala. Não some."
    if aa_matches(aa_state, {'promised': False}):
        $ aa_audio_event('s00', 'line', 5, phase=0)
        $ aa_stage_action = 'Telefone baixo; a resposta é dada a Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_saida_espera'
        show screen aa_location_display
        v "Amanhã a gente vai se ver na aula. Eu não sei como vai ser."
    menu:
        "Dizer que quero encerrar o namoro.":
            $ aa_audio_event('s00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's00', 0)
            $ aa_audio_event('s00', 'response', 0, 0)
            f "Eu quero terminar."
            $ aa_audio_event('s00', 'response', 1, 0)
            v "Você esperou eu chamar o carro pra falar?"
            $ aa_audio_event('s00', 'response', 2, 0)
            "Eu tinha esperado. Não tentei dar outro nome."
            $ aa_audio_event('s00', 'response', 3, 0)
            v "Tá. Então deixa eu ir."
            jump e01
        "Perguntar se ela aceita conversar outro dia, sem exigir namoro." if aa_matches(aa_state, {'truth': True, 'listened': True, 'respect': True, 'heard': True, 'bond': 'indefinido'}):
            $ aa_audio_event('s00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's00', 1)
            jump e02
        "Garantir que não vou sumir e confirmar o combinado de amanhã." if aa_matches(aa_state, {'bond': {'ne': 'terminado'}}):
            $ aa_audio_event('s00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 's00', 2)
            jump cr00
        "Pedir a Yasmin que reconheça a humilhação que causou." if aa_matches(aa_state, {'stopped_joke': True, 'truth': True, 'respect': True, 'route': 'juntas'}):
            $ aa_audio_event('s00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 's00', 3)
            jump e09
        "Ficar calado, esperando Vanessa resolver por mim.":
            $ aa_audio_event('s00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 's00', 4)
            jump e10

label s01:
    $ aa_node = 's01'
    $ aa_location = '22h02 · Perto do balcão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1322)
    $ aa_present = ()
    $ aa_audio_enter('s01')
    $ aa_stage_action = 'Yasmin fecha a bolsa e recusa outra conversa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    $ aa_audio_event('s01', 'line', 0, phase=0)
    f "Yasmin, espera."
    $ aa_audio_event('s01', 'line', 1, phase=0)
    "Ela fechou a bolsa. Não precisou olhar para Joãozão."
    $ aa_audio_event('s01', 'line', 2, phase=0)
    $ aa_stage_action = 'Recusa sem sorriso.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.1, 0.73, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    y "Não."
    $ aa_audio_event('s01', 'line', 3, phase=0)
    "Eu ainda nem tinha feito a pergunta. Percebi que era sempre a mesma."
    menu:
        "Parar ali.":
            $ aa_audio_event('s01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's01', 0)
            jump e05
        "Insistir, falando por cima dela.":
            $ aa_audio_event('s01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's01', 1)
            jump s03

label s02:
    $ aa_node = 's02'
    $ aa_location = '22h03 · Balcão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1323)
    $ aa_present = ()
    $ aa_audio_enter('s02')
    $ aa_stage_action = 'Feka admite o limite; Joãozão não oferece amizade.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    $ aa_audio_event('s02', 'line', 0, phase=0)
    f "Eu não vou procurar ela. Não quero que você fale por mim nem por ela."
    $ aa_audio_event('s02', 'line', 1, phase=0)
    j "Você não vai procurar porque eu mandei?"
    $ aa_audio_event('s02', 'line', 2, phase=0)
    $ aa_stage_action = 'O medo não desaparece depois da frase correta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.13, 0.24, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    "Ele estava perto. Eu continuava com medo. Não precisava fingir que tinha parado de ter para responder."
    menu:
        "Dizer que a resposta dela já basta.":
            $ aa_audio_event('s02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's02', 0)
            jump e06
        "Dizer que Yasmin não merece tudo isso.":
            $ aa_audio_event('s02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's02', 1)
            jump e05

label s03:
    $ aa_node = 's03'
    $ aa_location = '22h04 · Salão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1324)
    $ aa_present = ()
    $ aa_audio_enter('s03')
    $ aa_stage_action = 'Yasmin detém o passo de Joãozão; funcionário se aproxima.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    $ aa_audio_event('s03', 'line', 0, phase=0)
    j "Para de chamar ela. Ela acabou de falar."
    $ aa_audio_event('s03', 'line', 1, phase=0)
    $ aa_stage_action = 'Mostrar a mão de Yasmin no braço, não uma briga.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.08, 0.67, 0.4)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    "Algumas pessoas olharam. Joãozão deu um passo. Yasmin tocou o braço dele e disse para ele não fazer aquilo."
    if aa_matches(aa_state, {'heat': {'gte': 3}}):
        $ aa_audio_event('s03', 'line', 2, phase=0)
        j "Você passou a noite inteira fazendo isso."
    $ aa_audio_event('s03', 'line', 3, phase=0)
    $ aa_stage_action = 'Abrir o plano para incluir o funcionário.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    "Um funcionário veio até nós. Não perguntou quem tinha razão. Perguntou se havia algum problema."
    menu:
        "Baixar a voz e sair.":
            $ aa_audio_event('s03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's03', 0)
            jump e05
        "Continuar provocando, mesmo depois do aviso.":
            $ aa_audio_event('s03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's03', 1)
            $ aa_audio_event('s03', 'response', 0, 1)
            f "Você só sabe falar por ela?"
            $ aa_audio_event('s03', 'response', 1, 1)
            y "Eu falei não. Você ouviu de mim."
            jump d00

label e00:
    $ aa_node = 'e00'
    $ aa_location = '19h45 · Hall do apartamento'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1185)
    $ aa_present = ()
    $ aa_audio_enter('e00')
    $ aa_stage_action = 'Ela tenta adiar a separação antes de chamar o carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('e00', 'line', 0, phase=0)
    "Cancelei a reserva. Vanessa perguntou se eu estava cancelando só o jantar. Eu disse que não sabia continuar o namoro daquele jeito."
    $ aa_audio_event('e00', 'line', 1, phase=0)
    v "Eu podia ficar um pouco. A gente não precisa sair."
    $ aa_audio_event('e00', 'line', 2, phase=0)
    $ aa_location = '19h50 · Cozinha compartilhada'
    $ aa_stage_action = 'Vanessa já foi; a panela permanece. Vazio agora tem causa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha'
    show screen aa_location_display
    "Eu repeti que precisava encerrar. Ela chamou a mãe antes de pedir o carro."
    $ aa_audio_event('e00', 'line', 2, phase=1)
    "Depois que saiu, tirei a jaqueta. A panela continuava na pia."
    $ aa_audio_event('e00', 'line', 3, phase=0)
    "Peguei o celular. A vontade de ver Yasmin não tinha acabado porque eu tinha feito uma coisa certa."
    $ aa_audio_event('e00', 'line', 4, phase=0)
    $ aa_location = '19h55 · Cozinha compartilhada'
    $ aa_stage_action = 'Feka lava a própria panela; encerramento concreto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_lavar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_lavar'
    show screen aa_location_display
    "Deixei o celular na mesa e lavei a panela."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e00', 'line', 4, phase=1)
    $ aa_phone_remember('mudanca_cancelada')
    "Na manhã seguinte, Vanessa perguntou se eu tinha certeza. Respondi que sim. Ela pediu que eu não fosse à mudança."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E00 · A noite que não aconteceu"
    return

label e01:
    $ aa_node = 'e01'
    $ aa_location = '22h10 · Calçada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ()
    $ aa_audio_enter('e01')
    $ aa_stage_action = 'Duas pessoas diante da mesma porta escolhem rumos diferentes.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('e01', 'line', 0, phase=0)
    f "Tá. Eu vou por outro caminho."
    $ aa_audio_event('e01', 'line', 1, phase=0)
    v "Eu vou querer te mandar mensagem. Não responde como se hoje não tivesse acontecido."
    $ aa_audio_event('e01', 'line', 2, phase=0)
    "Esperei uma frase maior. Ela não tinha obrigação de encerrar aquilo de um jeito que me ajudasse."
    $ aa_audio_event('e01', 'line', 3, phase=0)
    $ aa_location = 'Mais tarde · Caminho de volta'
    $ aa_stage_action = 'Sozinho, Feka apaga a cobrança disfarçada de desculpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'rascunho'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('rascunho')
    show screen aa_phone_view('rascunho')
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "No caminho de volta, escrevi que sentia muito."
    $ aa_audio_event('e01', 'line', 4, phase=0)
    $ aa_location = 'Mais tarde · Caminho de volta'
    $ aa_stage_action = 'Campo vazio; a desculpa não foi enviada.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'rascunho_apagado'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('rascunho_apagado')
    show screen aa_phone_view('rascunho_apagado')
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "Apaguei quando percebi que estava esperando uma resposta antes de enviar."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e01', 'line', 5, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Dia seguinte: distância entre os colegas.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'grupo_materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('grupo_materia')
    show screen aa_phone_view('grupo_materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, Vanessa sentou com uma colega. Olhou para meu lugar quando cheguei, mas não me chamou. Mandei a matéria pelo grupo."
    $ aa_audio_event('e01', 'line', 6, phase=0)
    "Eu soube que ela tinha recebido as chaves por outra pessoa."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E01 · Duas contas"
    return

label e02:
    $ aa_node = 'e02'
    $ aa_location = '22h10 · Calçada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ()
    $ aa_audio_enter('e02')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('e02', 'line', 0, phase=0)
    f "Você aceita conversar outro dia? Se não quiser, eu não vou ficar perguntando."
    $ aa_audio_event('e02', 'line', 1, phase=0)
    v "Eu quero. Mas eu vou acabar perguntando se você volta. Preciso pensar antes."
    $ aa_audio_event('e02', 'line', 2, phase=0)
    "Quase chamei aquilo de uma chance. Era uma conversa que ainda não tinha sido aceita."
    $ aa_audio_event('e02', 'line', 3, phase=0)
    v "Na mudança vai minha mãe. Não aparece sem combinar. Eu posso querer te chamar e ainda assim precisar que você não vá."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e02', 'line', 4, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A matéria é enviada sem usar a mensagem como reconciliação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('materia')
    show screen aa_phone_view('materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, mandei a matéria. Ela respondeu que tinha recebido a chave e perguntou se podíamos conversar na quinta, depois da aula."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e02', 'line', 5, phase=0)
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'quinta'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('quinta')
    show screen aa_phone_view('quinta')
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    "Respondi que sim. Não tratei a quinta-feira como a data em que ela seria minha namorada de novo."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E02 · Sem promessa"
    return

label e03:
    $ aa_node = 'e03'
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1920)
    $ aa_present = ()
    $ aa_audio_enter('e03')
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 0, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 1, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    "O celular estava ao lado da minha perna. Eu tinha prometido mandar mensagem quando acordasse. Passei alguns segundos sentado antes de pegar."
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 2, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Só agora pega o celular e confirma a visita.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'visita'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('visita')
    show screen aa_phone_view('visita')
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    "Mandei bom dia e confirmei que iria depois da aula. Vanessa respondeu que ia me esperar."
    $ aa_present = ()
    $ aa_audio_event('e03', 'line', 3, phase=0)
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Conversa fecha; ele precisa se preparar para a aula.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    "Ainda precisava me arrumar e ir para a aula. A visita agora tinha uma hora na minha cabeça. Eu podia passar a manhã inteira procurando uma desculpa."
    $ aa_present = ()
    call aa_advance_clock(2400)
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 4, phase=0)
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chega com uma caixa do corredor; Vanessa abre a porta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_chegada_mudanca'
    show screen aa_location_display
    "Depois da aula, fui ao endereço que ela tinha mandado. Vanessa abriu a porta enquanto eu levantava uma das caixas que o frete tinha deixado no corredor."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 5, phase=0)
    v "Você veio. Minha mãe ficou até agora e acabou de sair. Pode entrar."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 6, phase=0)
    f "Onde ponho essa?"
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 7, phase=0)
    v "Perto da janela. É pesada? Espera, eu tiro a cadeira."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 8, phase=0)
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Caixas abertas; os dois trabalham na cozinha.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_trabalho_mudanca'
    show screen aa_location_display
    "Levei a caixa para dentro. Vanessa afastou a cadeira antes que eu pedisse. A sala era menor do que eu tinha imaginado."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 9, phase=0)
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Ela indica a posição da mesa; diálogo durante o trabalho.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_trabalho_mudanca'
    show screen aa_location_display
    "Abrimos as caixas da cozinha. Eu tirava os copos do papel; ela separava o que ia para o armário. Pela primeira vez desde o jantar, havia uma coisa simples para fazer."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 10, phase=0)
    v "A mesa fica aqui. Você acha que dá pra passar?"
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 11, phase=0)
    f "Se puxar um pouco pra janela, dá."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 12, phase=0)
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Os dois deslocam a mesa; caixas e louça continuam por guardar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_mesa_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_mesa_mudanca'
    show screen aa_location_display
    "Tiramos os copos de cima e empurramos a mesa alguns centímetros. Ela ficou segurando a outra ponta até eu dizer que estava bom."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 13, phase=0)
    v "Você fica pra comer? Minha mãe deixou comida."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 14, phase=0)
    f "Fico."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 15, phase=0)
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Vanessa chega com os dois pratos; antes de sentarem.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_comida_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_comida_mudanca'
    show screen aa_location_display
    "Ela foi buscar os pratos. Antes de servir, perguntou de novo se eu não precisava ir embora."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 16, phase=0)
    f "Eu falei que fico."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 17, phase=0)
    v "Tá. Eu só queria saber."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 18, phase=0)
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Os dois finalmente sentados para comer; caixas ainda abertas.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_refeicao_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_refeicao_mudanca'
    show screen aa_location_display
    "Sentamos. Ela esperou minha primeira garfada antes de começar. As caixas continuavam abertas junto da parede."
    $ aa_present = ('vanessa',)
    $ aa_audio_event('e03', 'line', 19, phase=0)
    "Eu tinha ajudado na mudança. Vanessa agradeceu como se isso confirmasse tudo que eu tinha dito. Senti alívio porque ela ainda não pediu que eu dissesse de novo."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E03 · Continuar"
    return

label e04:
    $ aa_node = 'e04'
    $ aa_location = '22h10 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ()
    $ aa_audio_enter('e04')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
        $ aa_table_party = 1
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_sozinho'
    else:
        $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    $ aa_audio_event('e04', 'line', 0, phase=0)
    "A cadeira ainda estava um pouco afastada. Tive vontade de pôr no lugar, como se isso diminuísse o que tinha acontecido."
    $ aa_audio_event('e04', 'line', 1, phase=0)
    "O garçom perguntou se podia tirar o segundo copo. Respondi que podia. Foi a única decisão que alguém ainda precisava de mim."
    $ aa_audio_event('e04', 'line', 2, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Um caderno na mesa; o de Vanessa foi embora com ela.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Em casa, só o meu caderno estava na escrivaninha. Vanessa tinha guardado o dela na bolsa antes de sairmos."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e04', 'line', 3, phase=0)
    $ aa_location = 'Segunda-feira · Campus de Direito'
    $ aa_stage_action = 'Cumprimento distante no dia seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'so_materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('so_materia')
    show screen aa_phone_view('so_materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Na segunda-feira, Vanessa sentou com uma colega. Me cumprimentou de longe. Depois recebi uma mensagem: queria só a matéria, pelo grupo."
    if aa_matches(aa_state, {'bond': 'indefinido'}):
        $ aa_present = ()
        call aa_advance_clock(2640)
        $ aa_audio_event('e04', 'line', 4, phase=0)
        $ aa_location = 'Segunda-feira à noite · Quarto de Feka'
        $ aa_stage_action = 'Contato posterior não desfaz a saída da noite anterior.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'espaco'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('espaco')
        show screen aa_phone_view('espaco')
        $ aa_last_art = 'cg2_retorno'
        show screen aa_location_display
        "À noite ela escreveu que ainda não sabia terminar, mas não queria me ver fora da aula por enquanto. Respondi que tinha entendido."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        $ aa_audio_event('e04', 'line', 5, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'O término continua explícito.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "A vontade de chamá-la de volta não era um motivo para fingir que o término tinha ficado em dúvida."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E04 · Cadeira vazia"
    return

label e05:
    $ aa_node = 'e05'
    $ aa_location = '22h10 · Entrada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ()
    $ aa_audio_enter('e05')
    $ aa_stage_action = 'Yasmin e Joãozão saem juntos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    show aa_y firm at aa_left
    show aa_j neutral at aa_right
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    $ aa_audio_event('e05', 'line', 0, phase=0)
    "Yasmin foi embora com Joãozão. Não houve uma última olhada. Esperei até a porta fechar mesmo assim."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e05', 'line', 1, phase=0)
        $ aa_stage_action = 'Exibir Vanessa somente se ainda não tiver saído.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        "Quando voltei, Vanessa ainda esperava perto da porta. Perguntou se agora podíamos ir. Eu disse que ela devia ir sem mim. Ela chamou o carro e perguntou outra vez se eu tinha certeza."
    $ aa_audio_event('e05', 'line', 2, phase=0)
    $ aa_stage_action = 'Feka permanece sem conseguir reter ninguém.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    "Eu tinha perdido o jantar de Vanessa e ainda queria que alguém reconhecesse meu sofrimento como a parte principal."
    $ aa_audio_event('e05', 'line', 3, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A toalha úmida retoma o início da noite.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "No quarto, a toalha continuava úmida. Eu lembrava de Vanessa perguntando onde estava. Não lembrava do que respondi."
    $ aa_audio_event('e05', 'line', 4, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A mesma mensagem antiga, agora sem desculpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'conversa'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('conversa')
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Abri a conversa de Yasmin. A mensagem antiga continuava lá, dizendo para eu não esperar na saída. Era uma resposta que eu tinha passado anos fingindo não saber ler."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('e05', 'line', 5, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'A promessa quebrada recebe uma resposta no dia seguinte.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "Eu tinha prometido ir à mudança."
        $ aa_present = ()
        call aa_advance_clock(1980)
        $ aa_audio_event('e05', 'line', 5, phase=1)
        $ aa_phone_remember('promessa')
        "No dia seguinte escrevi que não iria e que não podia pedir que ela me esperasse. Ela respondeu horas depois: “Você falou que ia.”"
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E05 · A mesma resposta"
    return

label e06:
    $ aa_node = 'e06'
    $ aa_location = '22h10 · Balcão e calçada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ('joaozao',)
    $ aa_audio_enter('e06')
    $ aa_stage_action = 'A conversa termina sem aperto de mão.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg12_balcao_r1 at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg12_balcao_r1'
    show screen aa_location_display
    $ aa_audio_event('e06', 'line', 0, phase=0)
    f "Não. Porque ela não quer."
    $ aa_audio_event('e06', 'line', 1, phase=0)
    j "Então faz isso."
    $ aa_audio_event('e06', 'line', 2, phase=0)
    "Ele não me deu a mão. Eu não ofereci a minha. Não havia amizade escondida esperando a frase certa."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_present = ('vanessa',)
        $ aa_audio_event('e06', 'line', 3, phase=0)
        $ aa_stage_action = 'Vanessa tem seu transporte; acordo com Joãozão não a retém.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        "Vanessa tinha chamado o carro. Perguntou se a conversa tinha acabado."
        $ aa_audio_event('e06', 'line', 3, phase=1)
        "Eu disse que sim e esperei até a placa aparecer. Ela foi sozinha."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_present = ()
        $ aa_audio_event('e06', 'line', 4, phase=0)
        $ aa_stage_action = 'O ramo em que ela já saiu permanece vazio.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'bg_calcada'
        show screen aa_location_display
        "Vanessa já tinha ido. Acertar uma coisa não trouxe de volta a outra."
    $ aa_present = ()
    $ aa_audio_event('e06', 'line', 6, phase=0)
    "Eu ia continuar estudando com Vanessa. Yasmin, com ele. Pela primeira vez pensei nisso como a vida deles, não como uma provocação."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False}):
        $ aa_present = ()
        call aa_advance_clock(1980)
        $ aa_present = ()
        $ aa_audio_event('e06', 'line', 7, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'A relação continua indefinida; a promessa é cobrada.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'indefinido'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('indefinido')
        show screen aa_phone_view('indefinido')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "Na manhã seguinte, mandei que não iria à mudança e pedi desculpa por ter prometido. Ela perguntou se eu ainda queria o namoro. Respondi que não sabia e que entendia se ela não quisesse esperar."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_present = ()
        call aa_advance_clock(2400)
        $ aa_present = ()
        $ aa_audio_transients()
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Empréstimo devolvido no dia seguinte.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "[aa_financial_line('joao_epilogue')]"
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E06 · Sem plateia"
    return

label e07:
    $ aa_node = 'e07'
    $ aa_location = '22h12 · Entrada de serviço'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1332)
    $ aa_present = ()
    $ aa_audio_enter('e07')
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    $ aa_audio_event('e07', 'line', 0, phase=0)
    "O funcionário pediu que eu saísse. Eu tentei contar a história. Ele repetiu o pedido, agora mais devagar."
    $ aa_audio_event('e07', 'line', 1, phase=0)
    y "João, para. Não precisa ir atrás."
    $ aa_audio_event('e07', 'line', 2, phase=0)
    "Joãozão parou. Nem a briga que eu estava tentando fabricar aconteceu do jeito que eu precisava."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e07', 'line', 3, phase=0)
        "Vanessa veio até a porta e perguntou se eu tinha me machucado. Eu disse que tinham me desrespeitado. Ela ficou em silêncio, depois chamou a mãe e foi esperar o carro."
    $ aa_audio_event('e07', 'line', 4, phase=0)
    $ aa_stage_action = 'Feka grava o áudio na calçada, já fora do restaurante.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.14, 0.74, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    "Na calçada, o frio veio depois da vergonha."
    $ aa_audio_event('e07', 'line', 4, phase=1)
    $ aa_phone_remember('audio')
    "Enviei um áudio dizendo que tinham me desrespeitado. Ouvi antes de enviar o segundo. Minha voz parecia satisfeita por finalmente ter um culpado."
    $ aa_audio_event('e07', 'line', 5, phase=0)
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'audio_resposta'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('audio_resposta')
    show screen aa_phone_view('audio_resposta')
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    "No grupo, alguém respondeu ‘complicado’. Eu guardei aquela palavra como apoio."
    $ aa_audio_event('e07', 'line', 6, phase=0)
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'chegou'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_phone_remember('chegou')
    show screen aa_phone_view('chegou')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    "Mais tarde Vanessa perguntou por mensagem se eu tinha chegado. Eu quase usei a preocupação dela para contar minha versão inteira. Ela acrescentou que precisava ficar sem conversar naquela noite."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E07 · Fora do salão"
    return

label e08:
    $ aa_node = 'e08'
    $ aa_location = '22h16 · Celular'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1336)
    $ aa_present = ()
    $ aa_audio_enter('e08')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 1
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_sozinho'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sozinho'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sobremesa_afastada'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sobremesa_afastada'
                else:
                    $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e08', 'line', 0, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
        else:
            $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_levantar'
        show screen aa_location_display
        "Vanessa perguntou se eu ia continuar no celular. Eu disse que já ia. Quando ela anunciou que iria embora, respondi sem levantar os olhos."
    $ aa_audio_event('e08', 'line', 1, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
        $ aa_table_party = 0
        $ aa_phone_pov = True
        $ aa_phone_kind = 'enquadramento'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg6_phone_table at aa_phone_camera
        with Dissolve(0.25)
        $ aa_phone_remember('enquadramento')
        show screen aa_phone_view('enquadramento')
        $ aa_last_art = 'cg6_phone_table'
    else:
        $ aa_stage_action = 'Só então a cadeira fica vazia.'
        $ aa_table_party = 0
        $ aa_phone_pov = True
        $ aa_phone_kind = 'enquadramento'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg6_phone_table at aa_phone_camera
        with Dissolve(0.25)
        $ aa_phone_remember('enquadramento')
        show screen aa_phone_view('enquadramento')
        $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    "Fotografei os copos que ainda estavam na mesa. Deixei as cadeiras fora do enquadramento."
    $ aa_audio_event('e08', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado')
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    "Escrevi que a noite tinha sido boa. Fiquei olhando as visualizações."
    if aa_matches(aa_state, {'bond': {'ne': 'mantido'}}):
        $ aa_audio_event('e08', 'line', 3, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'marcacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('marcacao')
            show screen aa_phone_view('marcacao')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'A mensagem desmonta a publicação feliz.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'marcacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('marcacao')
            show screen aa_phone_view('marcacao')
            $ aa_last_art = 'cg6_phone_table'
        show screen aa_location_display
        "Vanessa mandou uma mensagem pedindo que eu não a marcasse. Não tinha palavrão. Apaguei a marcação e deixei a publicação."
    $ aa_audio_event('e08', 'line', 4, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            $ aa_phone_remember('publicado_depois')
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    "Yasmin não respondeu. Eu disse a mim mesmo que ela devia ter visto."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e08', 'line', 5, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Outro público para a versão menor da história.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "Na manhã seguinte, contei a um colega que Vanessa estava estranha. Ele não conhecia o começo da história. Era por isso que eu tinha escolhido contar a ele."
    if aa_matches(aa_state, {'bond': 'mantido'}):
        $ aa_present = ()
        call aa_advance_clock(2400)
        $ aa_audio_event('e08', 'line', 6, phase=0)
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Ela procura confirmação pela mensagem, apesar da publicação falsa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'visita_post'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_phone_remember('visita_post')
        show screen aa_phone_view('visita_post')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        "Vanessa respondeu à publicação perguntando se a visita à mudança ainda estava combinada. Eu mandei que sim. Ela não comentou as cadeiras que eu tinha escondido."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E08 · Uma noite ótima"
    return

label e09:
    $ aa_node = 'e09'
    $ aa_location = '22h10 · Entrada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ()
    $ aa_audio_enter('e09')
    $ aa_stage_action = 'Yasmin se dirige a Vanessa; Joãozão aguarda.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    $ aa_audio_event('e09', 'line', 0, phase=0)
    "Chamei Yasmin quando ela e Joãozão chegaram à porta."
    $ aa_audio_event('e09', 'line', 1, phase=0)
    f "Você podia pelo menos pedir desculpa pelo que falou."
    $ aa_audio_event('e09', 'line', 2, phase=0)
    "Yasmin olhou para Vanessa. Eu fiquei esperando que olhasse para mim."
    $ aa_audio_event('e09', 'line', 3, phase=0)
    $ aa_stage_action = 'Yasmin olha para Vanessa, Feka fora do centro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.12, 0.52, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    y "Eu fiz uma piada e te coloquei no meio. Foi escroto. Desculpa."
    $ aa_audio_event('e09', 'line', 4, phase=0)
    v "Eu... tá. Foi ruim. Mas eu preciso falar com ele também."
    $ aa_audio_event('e09', 'line', 5, phase=0)
    $ aa_stage_action = 'Cada uma segue seu caminho; ninguém posa para Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    "Vanessa esperou eu perguntar se queria companhia até o carro. Disse que sim."
    $ aa_audio_event('e09', 'line', 5, phase=1)
    "Depois pediu que eu não fosse junto. Yasmin e Joãozão seguiram para a rua."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e09', 'line', 6, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A interpretação continua difícil no dia seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    "No dia seguinte, tentei lembrar a noite sem dividir as pessoas entre quem me humilhou e quem devia ter me salvado. Não consegui o tempo todo."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E09 · Não foi por mim"
    return

label e10:
    $ aa_node = 'e10'
    $ aa_location = '22h14 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1334)
    $ aa_present = ()
    $ aa_audio_enter('e10')
    $ aa_stage_action = 'Vanessa anuncia o carro antes de sair.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('e10', 'line', 0, phase=0)
    v "Meu carro chegou. Você vai falar alguma coisa antes de eu ir?"
    $ aa_audio_event('e10', 'line', 1, phase=0)
    "Eu disse que não sabia. Vanessa ficou mais um instante. Depois foi embora, olhando o celular enquanto caminhava."
    $ aa_audio_event('e10', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
        $ aa_table_party = 1
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_sozinho'
    else:
        $ aa_stage_action = 'Feka volta à sobremesa com duas colheres e uma cadeira vazia.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    "Voltei à mesa. O pudim continuava lá, com as duas colheres. O garçom perguntou se podia tirar. Eu disse que ainda estava comendo."
    $ aa_audio_event('e10', 'line', 3, phase=0)
    "Não fiz uma cena. Não disse uma última mentira. Também não disse o que devia. Consegui passar pela noite deixando o trabalho para os outros."
    $ aa_audio_event('e10', 'line', 4, phase=0)
    $ aa_location = 'Mais tarde · Cozinha compartilhada'
    $ aa_stage_action = 'Panela limpa por outra pessoa: repetir o espaço, mudar o objeto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha_noite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha_noite'
    show screen aa_location_display
    "Em casa, a cozinha estava limpa. Um dos moradores tinha lavado minha panela. Senti alívio antes de sentir vergonha."
    $ aa_audio_event('e10', 'line', 5, phase=0)
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A pergunta chega depois da saída, quando Feka já voltou.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_phone_remember('cheguei')
    "Ela mandou “cheguei” naquela noite. Respondi “que bom”."
    $ aa_present = ()
    call aa_advance_clock(1980)
    $ aa_audio_event('e10', 'line', 5, phase=1)
    $ aa_phone_remember('terminou')
    "No dia seguinte perguntou se a gente tinha terminado. Eu tinha conseguido adiar até a obrigação de responder isso."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E10 · Sobremesa fria"
    return

label v00:
    $ aa_node = 'v00'
    $ aa_location = '21h39 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1299)
    $ aa_present = ()
    $ aa_audio_enter('v00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_pergunta'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('v00', 'line', 0, phase=0)
    v "Você ainda quer estar comigo?"
    $ aa_audio_event('v00', 'line', 1, phase=0)
    "Ela perguntou sem olhar para Yasmin. Não havia outra pessoa que pudesse responder por mim."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('v00', 'line', 2, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        v "Ir à mudança é uma coisa. Eu tô perguntando da gente."
    if aa_matches(aa_state, {'promised': False}):
        $ aa_audio_event('v00', 'line', 3, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        v "Amanhã eu pego a chave. Eu tinha pensado em você lá."
    $ aa_audio_event('v00', 'line', 4, phase=0)
    "Eu imaginei voltar para o meu quarto sem ter com quem conversar. Era mais fácil pensar nisso do que no que ela tinha acabado de ouvir."
    if aa_matches(aa_state, {'comfort_lie': True}):
        $ aa_audio_event('v00', 'line', 5, phase=0)
        v "Você acabou de dizer que quer ficar comigo. Eu preciso saber se posso contar com isso amanhã também."
    menu:
        "Confirmar que continuo com ela e manter a visita de amanhã.":
            $ aa_audio_event('v00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'v00', 0)
            jump v02
        "Pedir um tempo e oferecer uma conversa, sem prometer namoro.":
            $ aa_audio_event('v00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'v00', 1)
            $ aa_audio_event('v00', 'response', 0, 1)
            v "Tempo até quando?"
            $ aa_audio_event('v00', 'response', 1, 1)
            f "Não tenho uma data. Não quero inventar uma pra você esperar."
            $ aa_audio_event('v00', 'response', 2, 1)
            "Ela ficou em silêncio."
            $ aa_audio_event('v00', 'response', 3, 1)
            v "Tá. Hoje eu vou sozinha. Amanhã eu penso se quero conversar."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('v00', 'response', 4, 1)
                v "Agora você precisa de tempo? Eu tinha acabado de tentar acreditar em você."
            jump k00
        "Dizer que quero terminar, sem pedir que ela me console.":
            $ aa_audio_event('v00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'v00', 2)
            $ aa_audio_event('v00', 'response', 0, 2)
            f "Eu quero terminar. Não quero pedir que você espere eu virar outra pessoa."
            $ aa_audio_event('v00', 'response', 1, 2)
            v "Então fala que terminou. Não fica dizendo que é por mim."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('v00', 'response', 2, 2)
                v "Por que disse que gostava de mim, então? Era só pra eu parar de perguntar?"
            jump v01

label v02:
    $ aa_node = 'v02'
    $ aa_location = '21h43 · Mesa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1303)
    $ aa_present = ()
    $ aa_audio_enter('v02')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'hesitated': True}):
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_hesita'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_hesita'
                    else:
                        $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_hesita_antes'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    $ aa_audio_event('v02', 'line', 0, phase=0)
    f "Eu continuo com você. Amanhã eu vou lá."
    $ aa_audio_event('v02', 'line', 1, phase=0)
    v "Eu quero continuar. Mas a gente vai ter que voltar nessa conversa."
    $ aa_audio_event('v02', 'line', 2, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'hesitated': True}):
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_hesita'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_hesita'
                    else:
                        $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_hesita_antes'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A confirmação traz alívio incompleto.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
    show screen aa_location_display
    "Assenti. Vanessa soltou um pouco os ombros, sem se aproximar."
    $ aa_audio_event('v02', 'line', 3, phase=0)
    v "Eu não acredito direito em você agora."
    $ aa_audio_event('v02', 'line', 4, phase=0)
    f "Eu sei."
    $ aa_audio_event('v02', 'line', 5, phase=0)
    v "Mas eu não quero ir pra casa achando que nunca mais vou te ver assim."
    if aa_matches(aa_state, {'hesitated': True}):
        $ aa_audio_event('v02', 'line', 6, phase=0)
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_pudim_quatro'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_pudim_pergunta'
            else:
                if aa_matches(aa_state, {'route': 'varanda'}):
                    $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_pergunta'
                else:
                    if aa_matches(aa_state, {'seat_swapped': True}):
                        $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg5_dois_pergunta'
                    else:
                        $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
                        $ aa_table_party = 0
                        $ aa_phone_pov = False
                        $ aa_phone_kind = ''
                        $ aa_dialogue_side = True
                        hide screen aa_phone_view
                        scene cg12_sobremesa_pergunta_antes at aa_camera(1.0, 0.5, 0.5)
                        with Dissolve(0.25)
                        $ aa_last_art = 'cg12_sobremesa_pergunta_antes'
        show screen aa_location_display
        "Ela deixou a bolsa ao lado da cadeira. Eu devia ter sentido o peso da promessa. Primeiro senti alívio."
    $ aa_audio_event('v02', 'line', 7, phase=0)
    v "Fica aqui até a conta. Por favor."
    if aa_matches(aa_state, {'comfort_lie': True}):
        $ aa_audio_event('v02', 'line', 8, phase=0)
        "Ela estava contando com a certeza que eu tinha fingido. Eu ainda não tinha corrigido uma palavra."
    jump k00

label v01:
    $ aa_node = 'v01'
    $ aa_location = '21h43 · Salão'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1303)
    $ aa_present = ()
    $ aa_audio_enter('v01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            if aa_matches(aa_state, {'route': 'varanda'}):
                $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg5_dois_hesita'
            else:
                if aa_matches(aa_state, {'seat_swapped': True}):
                    $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg5_dois_hesita'
                else:
                    $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg12_sobremesa_hesita_antes at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg12_sobremesa_hesita_antes'
    show screen aa_location_display
    if aa_matches(aa_state, {'bond': 'indefinido'}):
        $ aa_audio_event('v01', 'line', 0, phase=0)
        v "Eu vou embora hoje. Não consigo decidir o resto sentada aqui."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        $ aa_audio_event('v01', 'line', 1, phase=0)
        v "Então terminou. Eu ouvi. Só não fica voltando atrás para eu te acalmar."
    $ aa_audio_event('v01', 'line', 2, phase=0)
    "Ela mandou uma mensagem para a mãe. Pediu que ficasse acordada até ela chegar."
    $ aa_audio_event('v01', 'line', 3, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão voltaram aos lugares de B; conversa baixa entre Feka e Vanessa em C.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_pudim_quatro'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pagamento com os quatro à mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_pagamento at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_pagamento'
        else:
            $ aa_stage_action = 'Vanessa paga ainda sentada.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_pagamento'
    show screen aa_location_display
    "Chamou o garçom e pagou o que tinha pedido. Eu ofereci pagar. Ela disse que já estava passando o cartão."
    $ aa_audio_event('v01', 'line', 4, phase=0)
    v "Eu vou pedir a matéria pra outra pessoa amanhã. Se eu falar com você cedo, vou acabar fingindo que não aconteceu."
    $ aa_audio_event('v01', 'line', 5, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa de pé no corredor leste, com bolsa e casaco; três continuam sentados.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_vanessa_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_vanessa_saida'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa de pé no corredor leste, com bolsa e casaco; três continuam sentados.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg14_vanessa_saida at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg14_vanessa_saida'
        else:
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Levanta com uma bolsa e seu casaco.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_levantar_corrigida at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_levantar_corrigida'
            else:
                $ aa_stage_action = 'Ela leva bolsa e casaco.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_levantar'
    show screen aa_location_display
    "Vanessa pegou o casaco e a bolsa. Ficou um instante segurando o encosto antes de se afastar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('v01', 'line', 6, phase=0)
        "Yasmin e Joãozão continuaram sentados. Vanessa manteve os olhos na saída."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('v01', 'line', 7, phase=0)
        "Ela passou pela outra mesa sem parar."
    menu:
        "Deixar ela sair.":
            $ aa_audio_event('v01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'v01', 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Vanessa ausente; Yasmin e Joãozão permanecem.'
                    $ aa_table_party = 3
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg4_pudim_tres at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg4_pudim_tres'
                else:
                    $ aa_stage_action = 'Vanessa saiu fisicamente.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sozinho'
            jump k00
        "Chamar por ela alto, obrigando o salão a olhar.":
            $ aa_audio_event('v01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'v01', 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa saiu com seus pertences; seu assento fica vazio, outros três permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_conta_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_conta_tres'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Vanessa ausente; Yasmin e Joãozão permanecem.'
                    $ aa_table_party = 3
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg4_pudim_tres at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg4_pudim_tres'
                else:
                    $ aa_stage_action = 'Vanessa saiu fisicamente.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg2_sozinho'
            jump k00

label jl00:
    $ aa_node = 'jl00'
    $ aa_location = '21h51 · O pedido'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1311)
    $ aa_present = ()
    $ aa_audio_enter('jl00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_emprestimo'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_juntas'
        else:
            $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_separadas'
    show screen aa_location_display
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('jl00', 'line', 0, phase=0)
        "Deixei a conta entre os copos. Joãozão olhou o papel, depois olhou para mim."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('jl00', 'line', 1, phase=0)
        "Avisei Vanessa que ia falar com Joãozão. Atravessei até a mesa deles com o celular na mão. Yasmin recolheu o copo para eu não esbarrar."
    $ aa_audio_event('jl00', 'line', 2, phase=0)
    f "Você consegue me fazer um Pix? Só até amanhã."
    $ aa_audio_event('jl00', 'line', 3, phase=0)
    j "De quanto?"
    $ aa_audio_event('jl00', 'line', 4, phase=0)
    f "Faltou um pouco pra fechar a conta."
    $ aa_audio_event('jl00', 'line', 5, phase=0)
    j "Quanto, Feka?"
    $ aa_audio_event('jl00', 'line', 6, phase=0)
    "Eu olhei para Yasmin antes de responder. Ela não respondeu por mim."
    $ aa_audio_event('jl00', 'line', 7, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_emprestimo'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_juntas'
        else:
            $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_separadas'
    show screen aa_location_display
    f "Sessenta."
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('jl00', 'line', 8, phase=0)
        j "Depois dessa confusão, você quer que eu te empreste dinheiro?"
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('jl00', 'line', 9, phase=0)
        f "Eu sei. Não tô pedindo pra você esquecer."
    if aa_matches(aa_state, {'heat': {'lte': 1}}):
        $ aa_audio_event('jl00', 'line', 10, phase=0)
        j "Você tá sem dinheiro pra pagar a conta?"
    if aa_matches(aa_state, {'heat': {'lte': 1}}):
        $ aa_audio_event('jl00', 'line', 11, phase=0)
        f "Pra pagar tudo. Eu achei que dava."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('jl00', 'line', 12, phase=0)
        v "Eu trouxe dinheiro pra minha parte."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('jl00', 'line', 13, phase=0)
        "Vanessa continuava na nossa mesa. Ela tinha oferecido completar a conta. Eu tinha vindo pedir a ele."
    $ aa_audio_event('jl00', 'line', 14, phase=0)
    y "Deixa ele responder, João."
    $ aa_audio_event('jl00', 'line', 15, phase=0)
    "Eu quase agradeci a ela. Ainda queria aproveitar aquele momento para alguma coisa."
    $ aa_audio_event('jl00', 'line', 16, phase=0)
    j "Eu consigo mandar sessenta. Amanhã até meio-dia você devolve. Dá mesmo ou você tá falando amanhã só pra sair daqui?"
    $ aa_audio_event('jl00', 'line', 17, phase=0)
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg14_emprestimo'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_juntas'
        else:
            $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg9_emprestimo_separadas'
    show screen aa_location_display
    "Ele desbloqueou o celular e esperou. Não tinha transferido nada. Agora eu precisava responder com um prazo que pudesse cumprir."
    menu:
        "Assumir os sessenta reais e combinar amanhã até meio-dia.":
            $ aa_audio_event('jl00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'jl00', 0)
            $ aa_audio_event('jl00', 'response', 0, 0)
            f "Amanhã até meio-dia. Pode mandar."
            $ aa_audio_event('jl00', 'response', 1, 0)
            "Abri minha chave Pix e mostrei. Joãozão conferiu meu nome em voz alta. Esperei ele terminar."
            $ aa_audio_event('jl00', 'response', 2, 0)
            $ aa_finance_event('joao_loan')
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = 'emprestimo_pix'
                $ aa_dialogue_side = False
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_phone_remember('emprestimo_pix')
                show screen aa_phone_view('emprestimo_pix')
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            "Entraram sessenta reais. Joãozão perguntou se tinha chegado. Eu disse que sim."
            $ aa_audio_event('jl00', 'response', 3, 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            j "Pronto. Me devolve pelo próprio Pix."
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_audio_event('jl00', 'response', 4, 0)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Guardei o celular. A conta continuava entre nós. Pedi a máquina e paguei."
            if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
                $ aa_audio_event('jl00', 'response', 5, 0)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Voltei para Vanessa. Ela afastou a cadeira para eu sentar. Pedi a máquina e paguei."
            $ aa_audio_event('jl00', 'response', 6, 0)
            v "Você podia ter dividido comigo. Não precisava pedir a ele."
            $ aa_audio_event('jl00', 'response', 7, 0)
            "Eu tinha conseguido pagar por ela. Não consegui olhar para ela quando agradeceu ao garçom."
            jump k01
        "Aceitar, mas pedir que ele não fique cobrando na frente dos outros.":
            $ aa_audio_event('jl00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'jl00', 1)
            $ aa_audio_event('jl00', 'response', 0, 1)
            f "Só não fica me cobrando na frente de todo mundo."
            $ aa_audio_event('jl00', 'response', 1, 1)
            j "Você que veio pedir aqui. Amanhã, se pagar, eu não preciso cobrar."
            $ aa_audio_event('jl00', 'response', 2, 1)
            "Yasmin olhou para o celular dele. Eu fiquei esperando uma defesa que não veio."
            $ aa_audio_event('jl00', 'response', 3, 1)
            f "Amanhã até meio-dia. Pode mandar."
            $ aa_audio_event('jl00', 'response', 4, 1)
            "Abri minha chave Pix e mostrei. Joãozão conferiu meu nome em voz alta. Esperei ele terminar."
            $ aa_audio_event('jl00', 'response', 5, 1)
            $ aa_finance_event('joao_loan')
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = 'emprestimo_pix'
                $ aa_dialogue_side = False
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_phone_remember('emprestimo_pix')
                show screen aa_phone_view('emprestimo_pix')
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = 'emprestimo_pix'
                    $ aa_dialogue_side = False
                    $ aa_dialogue_side = True
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_phone_remember('emprestimo_pix')
                    show screen aa_phone_view('emprestimo_pix')
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            "Entraram sessenta reais. Joãozão perguntou se tinha chegado. Eu disse que sim."
            $ aa_audio_event('jl00', 'response', 6, 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Pedido de Pix na mesma mesa; Feka e Joãozão conferem os telefones.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg14_emprestimo at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg14_emprestimo'
            else:
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Pedido ouvido pelos quatro, sem sair da mesa.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_juntas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_juntas'
                else:
                    $ aa_stage_action = 'Feka aborda a outra mesa; Vanessa espera ao fundo.'
                    $ aa_table_party = 0
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg9_emprestimo_separadas at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg9_emprestimo_separadas'
            j "Pronto. Me devolve pelo próprio Pix."
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_audio_event('jl00', 'response', 7, 1)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Guardei o celular. A conta continuava entre nós. Pedi a máquina e paguei."
            if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
                $ aa_audio_event('jl00', 'response', 8, 1)
                $ aa_finance_event('dinner_full')
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Voltei para Vanessa. Ela afastou a cadeira para eu sentar. Pedi a máquina e paguei."
            $ aa_audio_event('jl00', 'response', 9, 1)
            v "Você podia ter dividido comigo. Não precisava pedir a ele."
            $ aa_audio_event('jl00', 'response', 10, 1)
            "Eu tinha conseguido pagar por ela. Não consegui olhar para ela quando agradeceu ao garçom."
            jump k01
        "Desistir do empréstimo e dividir a conta com Vanessa.":
            $ aa_audio_event('jl00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'jl00', 2)
            $ aa_audio_event('jl00', 'response', 0, 2)
            f "Deixa. Eu vou dividir com ela."
            $ aa_audio_event('jl00', 'response', 1, 2)
            j "Tá."
            if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
                $ aa_audio_event('jl00', 'response', 2, 2)
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Voltei à minha cadeira antes de chamar o garçom."
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_audio_event('jl00', 'response', 3, 2)
                if aa_matches(aa_state, {'route': 'juntas'}):
                    $ aa_stage_action = 'Feka abre sua conta; Vanessa está presente e o outro casal continua em B.'
                    $ aa_table_party = 4
                    $ aa_phone_pov = False
                    $ aa_phone_kind = ''
                    $ aa_dialogue_side = False
                    hide screen aa_phone_view
                    scene cg14_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                    with Dissolve(0.25)
                    $ aa_last_art = 'cg14_conta_quatro'
                else:
                    if aa_matches(aa_state, {'route': 'juntas'}):
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
                            $ aa_table_party = 3
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_tres'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 4
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg4_conta_quatro'
                    else:
                        if aa_matches(aa_state, {'v_gone': True}):
                            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg_conta'
                        else:
                            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
                            $ aa_table_party = 0
                            $ aa_phone_pov = False
                            $ aa_phone_kind = ''
                            $ aa_dialogue_side = False
                            hide screen aa_phone_view
                            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
                            with Dissolve(0.25)
                            $ aa_last_art = 'cg2_conta_presente'
                "Afastei a conta para o garçom conseguir pegar."
            jump k01

label cr00:
    $ aa_node = 'cr00'
    $ aa_location = '22h10 · Entrada do restaurante'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1330)
    $ aa_present = ()
    $ aa_audio_enter('cr00')
    $ aa_location = '22h10 · Entrada do restaurante'
    $ aa_stage_action = 'Esperam o carro sob a cobertura.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('cr00', 'line', 0, phase=0)
    f "Eu não vou sumir. Amanhã eu saio da aula e vou direto pra mudança."
    $ aa_audio_event('cr00', 'line', 1, phase=0)
    v "Me manda quando acordar. Pra eu saber que você não mudou de ideia."
    $ aa_audio_event('cr00', 'line', 2, phase=0)
    "Ela guardou o telefone. Ficamos sob a cobertura, ouvindo os pneus passarem na água."
    $ aa_audio_event('cr00', 'line', 3, phase=0)
    $ aa_location = '22h10 · Entrada do restaurante'
    $ aa_stage_action = 'Esperam o carro sob a cobertura.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    v "Você pode me abraçar um pouco?"
    $ aa_audio_event('cr00', 'line', 4, phase=0)
    "Vanessa deu meio passo e esperou. Eu tirei as mãos dos bolsos."
    menu:
        "Abraçá-la e ficar ali, sem apressar a despedida.":
            $ aa_audio_event('cr00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'cr00', 0)
            $ aa_audio_event('cr00', 'response', 0, 0)
            $ aa_stage_action = 'Vanessa pede um abraço; Feka corresponde e os dois permanecem abraçados.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg10_abraco_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg10_abraco_espera'
            "Ela passou os braços pela minha cintura. Abracei de volta. Ficamos assim enquanto o telefone vibrava dentro da bolsa."
            $ aa_audio_event('cr00', 'response', 1, 0)
            v "Só mais um pouco."
            $ aa_audio_event('cr00', 'response', 2, 0)
            f "Tá."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('cr00', 'response', 3, 0)
                "Eu tinha passado a última hora repetindo o que ela queria ouvir. Agora ela se agarrava a mim, e eu ainda não sabia sustentar aquilo fora daquele abraço."
            if aa_matches(aa_state, {'comfort_lie': False}):
                $ aa_audio_event('cr00', 'response', 4, 0)
                "Ela não voltou atrás no que tinha dito à mesa. Eu não pedi que voltasse."
            $ aa_audio_event('cr00', 'response', 5, 0)
            "Esperei que ela afrouxasse os braços antes de me afastar. Vanessa pegou o celular para conferir a placa."
            jump cr01
        "Dizer que prefiro esperar ao lado dela, sem abraçar.":
            $ aa_audio_event('cr00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'cr00', 1)
            $ aa_audio_event('cr00', 'response', 0, 1)
            f "Eu fico aqui com você. Mas agora eu prefiro não abraçar."
            $ aa_audio_event('cr00', 'response', 1, 1)
            "Ela recolheu as mãos e segurou a alça da bolsa."
            $ aa_audio_event('cr00', 'response', 2, 1)
            v "Tá. Só não vai embora sem falar."
            $ aa_audio_event('cr00', 'response', 3, 1)
            f "Eu vou esperar."
            jump cr01

label cr01:
    $ aa_node = 'cr01'
    $ aa_location = '22h12 · No carro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1332)
    $ aa_present = ()
    $ aa_audio_enter('cr01')
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'Os dois no banco traseiro, ainda separados.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    $ aa_audio_event('cr01', 'line', 0, phase=0)
    "O carro parou. Vanessa perguntou se eu ia com ela até em casa. Eu disse que sim. Conferimos a placa, entramos e colocamos os cintos."
    $ aa_audio_event('cr01', 'line', 1, phase=0)
    "No carro, ela virou o rosto para mim. Eu olhava a rua. A bolsa ficou apertada no colo dela."
    $ aa_audio_event('cr01', 'line', 2, phase=0)
    v "Você ainda tá pensando nela?"
    $ aa_audio_event('cr01', 'line', 3, phase=0)
    "Demorei. Vanessa disse que não precisava responder naquele momento."
    if aa_matches(aa_state, {'truth': True}):
        $ aa_audio_event('cr01', 'line', 4, phase=0)
        "Eu tinha contado por que começara a namorar. Mesmo assim ela tinha aberto espaço no carro."
    if aa_matches(aa_state, {'truth': False}):
        $ aa_audio_event('cr01', 'line', 5, phase=0)
        "Ela não sabia que eu tinha dito aquilo só para fazê-la parar de perguntar. Eu deixei que continuasse comigo sem saber."
    $ aa_audio_event('cr01', 'line', 6, phase=0)
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'Os dois no banco traseiro, ainda separados.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    v "Posso encostar em você?"
    $ aa_audio_event('cr01', 'line', 7, phase=0)
    "Ela manteve a bolsa no colo. Eu ainda tinha espaço para dizer que não."
    menu:
        "Dizer que sim e oferecer o ombro.":
            $ aa_audio_event('cr01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'cr01', 0)
            $ aa_audio_event('cr01', 'response', 0, 0)
            f "Pode."
            $ aa_audio_event('cr01', 'response', 1, 0)
            "Antes de o motorista arrancar, ela passou para o assento do meio e prendeu o cinto de novo. Tirei meu braço do caminho."
            $ aa_audio_event('cr01', 'response', 2, 0)
            $ aa_stage_action = 'Vanessa no assento central, encostada no ombro de Feka; ambos de cinto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg10_carro_ombro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg10_carro_ombro'
            "Vanessa apoiou a cabeça no meu ombro. Deixei minha mão junto da dela. O carro saiu devagar."
            $ aa_audio_event('cr01', 'response', 3, 0)
            v "Eu tava precisando disso."
            $ aa_audio_event('cr01', 'response', 4, 0)
            "Ficamos assim por algumas ruas. Quando ela apertou minha mão, apertei de volta."
            if aa_matches(aa_state, {'comfort_lie': True}):
                $ aa_audio_event('cr01', 'response', 5, 0)
                "Ser abraçado era bom. Eu queria que bastasse para tornar verdade o que tinha dito."
            if aa_matches(aa_state, {'comfort_lie': False, 'truth': False}):
                $ aa_audio_event('cr01', 'response', 6, 0)
                "Eu gostava de ter ela perto. Por alguns instantes, quis acreditar que aquilo respondia à pergunta sobre Yasmin."
            if aa_matches(aa_state, {'comfort_lie': False, 'truth': True}):
                $ aa_audio_event('cr01', 'response', 7, 0)
                "Eu tinha contado a verdade à mesa. Ainda não sabia o que dizer sobre continuar pensando em Yasmin. Fiquei com a mão junto da dela."
            $ aa_audio_event('cr01', 'response', 8, 0)
            v "Vou deixar o celular com som de manhã."
            $ aa_audio_event('cr01', 'response', 9, 0)
            f "Mando quando acordar."
            $ aa_audio_event('cr01', 'response', 10, 0)
            "Perto da rua dela, o motorista perguntou em qual portão devia parar. Vanessa indicou a casa."
            $ aa_audio_event('cr01', 'response', 11, 0)
            v "Hoje é só até aqui, tá? Amanhã a gente se vê."
            $ aa_audio_event('cr01', 'response', 12, 0)
            f "Tá."
            $ aa_audio_event('cr01', 'response', 13, 0)
            $ aa_finance_event('return_home')
            "[aa_financial_line('return_home')]"
            jump e03
        "Pedir que fiquem cada um no seu lugar por enquanto.":
            $ aa_audio_event('cr01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'cr01', 1)
            $ aa_audio_event('cr01', 'response', 0, 1)
            f "Prefiro ficar assim por enquanto. Não é pra você descer. Eu vou com você."
            $ aa_audio_event('cr01', 'response', 1, 1)
            v "Tá. Eu perguntei porque queria. Não precisa ficar com pena."
            $ aa_audio_event('cr01', 'response', 2, 1)
            "O motorista arrancou. Eu fiquei ao lado dela, sem fingir que a distância não tinha feito diferença."
            $ aa_audio_event('cr01', 'response', 3, 1)
            "Perto da rua dela, o motorista perguntou em qual portão devia parar. Vanessa indicou a casa."
            $ aa_audio_event('cr01', 'response', 4, 1)
            v "Hoje é só até aqui, tá? Amanhã a gente se vê."
            $ aa_audio_event('cr01', 'response', 5, 1)
            f "Tá."
            $ aa_audio_event('cr01', 'response', 6, 1)
            $ aa_finance_event('return_home')
            "[aa_financial_line('return_home')]"
            jump e03

label h00:
    $ aa_node = 'h00'
    $ aa_location = '21h22 · Mesa junto ao vidro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1282)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h00')
    $ aa_location = '21h22 · Mesa junto ao vidro'
    $ aa_stage_action = 'Feka olha apenas para Vanessa; pudim entre os dois.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_mesa_escolha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_mesa_escolha'
    show screen aa_location_display
    $ aa_audio_event('h00', 'line', 0, phase=0)
    f "Eu não sabia que ela estaria aqui. A indicação foi dela. Mas eu escolhi este lugar pensando em você."
    $ aa_audio_event('h00', 'line', 1, phase=0)
    $ aa_location = '21h22 · Mesa junto ao vidro'
    $ aa_stage_action = 'Feka olha apenas para Vanessa; pudim entre os dois.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_mesa_escolha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_mesa_escolha'
    show screen aa_location_display
    "Eu tinha guardado o nome do restaurante por causa de Yasmin. Não contei essa parte."
    $ aa_audio_event('h00', 'line', 2, phase=0)
    v "Você consegue falar isso olhando pra mim?"
    $ aa_audio_event('h00', 'line', 3, phase=0)
    "Olhei para ela. Vanessa continuava apertando o guardanapo."
    $ aa_audio_event('h00', 'line', 4, phase=0)
    f "Consigo. Eu quero estar aqui com você."
    $ aa_audio_event('h00', 'line', 5, phase=0)
    v "Eu quero acreditar. Só não quero passar o resto da noite perguntando."
    $ aa_audio_event('h00', 'line', 6, phase=0)
    "Ela soltou o guardanapo, mas ainda não pegou a colher. Esperei."
    menu:
        "Retomar o combinado da mudança e ficar conversando com ela.":
            $ aa_audio_event('h00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h00', 0)
            $ aa_audio_event('h00', 'response', 0, 0)
            f "Amanhã eu saio da aula e vou te ajudar com as caixas."
            $ aa_audio_event('h00', 'response', 1, 0)
            v "Tá. Me avisa antes de sair? Eu fico esperando."
            $ aa_audio_event('h00', 'response', 2, 0)
            f "Aviso. Você me manda o endereço."
            $ aa_audio_event('h00', 'response', 3, 0)
            "Vanessa respirou fundo e puxou o pudim de volta para o meio da mesa."
            jump h01
        "Prometer que Yasmin nunca mais vai importar." if aa_matches(aa_state, {'chosen_vanessa': False}):
            $ aa_audio_event('h00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h00', 1)
            $ aa_audio_event('h00', 'response', 0, 1)
            f "Ela não vai importar mais. Nunca."
            $ aa_audio_event('h00', 'response', 1, 1)
            v "Você tava olhando pra ela agora há pouco. Como é que eu vou acreditar nesse nunca?"
            $ aa_audio_event('h00', 'response', 2, 1)
            "Abri a boca para repetir. Parei quando vi a cara dela."
            jump v00
        "Pedir que Vanessa aceite a resposta sem perguntar mais.":
            $ aa_audio_event('h00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'h00', 2)
            $ aa_audio_event('h00', 'response', 0, 2)
            f "Eu já respondi. Você precisa confiar em mim."
            $ aa_audio_event('h00', 'response', 1, 2)
            v "Eu estava tentando."
            jump r02

label h01:
    $ aa_node = 'h01'
    $ aa_location = '21h35 · Mesa junto ao vidro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1295)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h01')
    $ aa_location = '21h35 · Mesa junto ao vidro'
    $ aa_stage_action = 'Os dois dividem o pudim e retomam uma conversa pequena.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_pudim_compartilhado at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_pudim_compartilhado'
    show screen aa_location_display
    $ aa_audio_event('h01', 'line', 0, phase=0)
    "Vanessa pegou uma das colheres. Eu esperei ela provar antes de pegar a outra."
    $ aa_audio_event('h01', 'line', 1, phase=0)
    v "A toalha atrás da sua porta era a de banho."
    $ aa_audio_event('h01', 'line', 2, phase=0)
    f "Eu sei."
    $ aa_audio_event('h01', 'line', 3, phase=0)
    v "Você sabia quando me respondeu?"
    $ aa_audio_event('h01', 'line', 4, phase=0)
    f "Sabia."
    $ aa_audio_event('h01', 'line', 5, phase=0)
    $ aa_location = '21h35 · Mesa junto ao vidro'
    $ aa_stage_action = 'Os dois dividem o pudim e retomam uma conversa pequena.'
    $ aa_table_party = 2
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_pudim_compartilhado at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_pudim_compartilhado'
    show screen aa_location_display
    "Ela riu pelo nariz. Eu ri também. Vanessa cortou outro pedaço do pudim e empurrou o prato um pouco para mim."
    $ aa_audio_event('h01', 'line', 6, phase=0)
    v "Da próxima vez eu levo uma toalha na bolsa."
    $ aa_audio_event('h01', 'line', 7, phase=0)
    f "Eu tenho outra. Só preciso lembrar de lavar."
    $ aa_audio_event('h01', 'line', 8, phase=0)
    "Ela balançou a cabeça, sorrindo. Terminamos a sobremesa conversando sobre a bagunça do meu quarto."
    jump k00

label h02:
    $ aa_node = 'h02'
    $ aa_location = '22h02 · Entrada do restaurante'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1322)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h02')
    $ aa_location = '22h02 · Entrada do restaurante'
    $ aa_stage_action = 'Sob a cobertura, Feka convida Vanessa para voltar com ele.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_convite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_convite'
    show screen aa_location_display
    $ aa_audio_event('h02', 'line', 0, phase=0)
    "Na entrada, Vanessa vestiu o casaco. Eu abri o aplicativo antes que ela precisasse pedir que eu esperasse."
    $ aa_audio_event('h02', 'line', 1, phase=0)
    f "Quer voltar comigo? Para a moradia."
    $ aa_audio_event('h02', 'line', 2, phase=0)
    v "Você quer mesmo que eu vá?"
    $ aa_audio_event('h02', 'line', 3, phase=0)
    f "Eu quero que você vá. A gente dorme, toma café e vai pra faculdade junto."
    $ aa_audio_event('h02', 'line', 4, phase=0)
    $ aa_location = '22h02 · Entrada do restaurante'
    $ aa_stage_action = 'Sob a cobertura, Feka convida Vanessa para voltar com ele.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_convite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_convite'
    show screen aa_location_display
    "Vanessa segurou a manga do meu casaco. Ainda não tinha guardado o celular."
    $ aa_audio_event('h02', 'line', 5, phase=0)
    v "E depois da aula você vai comigo pro apartamento."
    $ aa_audio_event('h02', 'line', 6, phase=0)
    f "Vou."
    $ aa_audio_event('h02', 'line', 7, phase=0)
    "Ela olhou o aplicativo aberto na minha mão e esperou eu confirmar o destino. A corrida até a moradia estava em dezoito reais."
    menu:
        "Confirmar o convite e chamar o carro para os dois.":
            $ aa_audio_event('h02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h02', 0)
            $ aa_audio_event('h02', 'response', 0, 0)
            f "Eu quero você lá."
            $ aa_audio_event('h02', 'response', 1, 0)
            v "Tá. Então eu vou."
            $ aa_audio_event('h02', 'response', 2, 0)
            "Chamei um carro para a moradia. Vanessa avisou a mãe que dormiria comigo. Depois guardou o telefone e ficou ao meu lado sob a cobertura."
            jump h03
        "Recuar e dizer que talvez seja melhor cada um ir para casa.":
            $ aa_audio_event('h02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h02', 1)
            $ aa_audio_event('h02', 'response', 0, 1)
            f "Talvez seja melhor você ir pra casa. Eu não quero confundir mais."
            $ aa_audio_event('h02', 'response', 1, 1)
            v "Você já convidou. Mas tá. Eu chamo o meu."
            jump s00

label h03:
    $ aa_node = 'h03'
    $ aa_location = '22h12 · No carro'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1332)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h03')
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'No carro parado, conversam antes da escolha de contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    $ aa_audio_event('h03', 'line', 0, phase=0)
    "Conferimos a placa e entramos. Cada um sentou junto de uma janela. Colocamos os cintos; Vanessa manteve a bolsa no colo."
    $ aa_audio_event('h03', 'line', 1, phase=0)
    v "Eu achei que ia voltar sozinha hoje."
    $ aa_audio_event('h03', 'line', 2, phase=0)
    f "Eu tô gostando de você vir comigo."
    $ aa_audio_event('h03', 'line', 3, phase=0)
    v "Eu também. Só vou precisar sair cedo pra aula."
    $ aa_audio_event('h03', 'line', 4, phase=0)
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'No carro parado, conversam antes da escolha de contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    "Confirmei o endereço da moradia com o motorista. Ele ainda estava acertando o trajeto no aplicativo."
    menu:
        "Oferecer o ombro e deixar a mão junto da dela.":
            $ aa_audio_event('h03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h03', 0)
            $ aa_audio_event('h03', 'response', 0, 0)
            f "Pode encostar, se quiser."
            $ aa_audio_event('h03', 'response', 1, 0)
            $ aa_stage_action = 'Contato escolhido; os dois de cinto, bolsa no colo de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg13_carro_feliz at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg13_carro_feliz'
            "Com o carro ainda parado, Vanessa passou para o assento do meio e prendeu o cinto outra vez. Apoiou a cabeça no meu ombro e segurou minha mão sobre a bolsa. O motorista saiu devagar."
            $ aa_audio_event('h03', 'response', 2, 0)
            v "Assim tá bom."
            jump h04
        "Viajar ao lado dela e conversar até chegar.":
            $ aa_audio_event('h03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h03', 1)
            $ aa_audio_event('h03', 'response', 0, 1)
            "O motorista saiu devagar. Vanessa contou que tinha etiquetado três caixas como “cozinha” e esquecido qual delas guardava os pratos."
            $ aa_audio_event('h03', 'response', 1, 1)
            f "A gente abre as três."
            $ aa_audio_event('h03', 'response', 2, 1)
            v "Eu espero que não estejam no fundo da última."
            jump h04

label h04:
    $ aa_node = 'h04'
    $ aa_location = '22h31 · Moradia universitária'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1351)
    $ aa_present = ('vanessa',)
    $ aa_finance_event('ride_home')
    $ aa_audio_enter('h04')
    $ aa_location = '22h31 · Moradia universitária'
    $ aa_stage_action = 'Os dois retornam ao mesmo quarto; casacos molhados na cadeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_quarto_chegada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_quarto_chegada'
    show screen aa_location_display
    $ aa_audio_event('h04', 'line', 0, phase=0)
    "Chegamos à moradia e atravessamos a sala. Alguém ria atrás de uma das portas. Na cozinha, a panela continuava na pia."
    $ aa_audio_event('h04', 'line', 1, phase=0)
    $ aa_location = '22h31 · Moradia universitária'
    $ aa_stage_action = 'Os dois retornam ao mesmo quarto; casacos molhados na cadeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_quarto_chegada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_quarto_chegada'
    show screen aa_location_display
    "No quarto, Vanessa deixou a bolsa na mesma ponta da cama onde tinha começado a noite. Pendurei os dois casacos na cadeira."
    $ aa_audio_event('h04', 'line', 2, phase=0)
    v "Eu trouxe escova de dente. Não trouxe roupa pra dormir."
    $ aa_audio_event('h04', 'line', 3, phase=0)
    f "Tenho uma camiseta limpa."
    $ aa_audio_event('h04', 'line', 4, phase=0)
    v "Limpa de verdade?"
    $ aa_audio_event('h04', 'line', 5, phase=0)
    f "Ainda na gaveta."
    $ aa_audio_event('h04', 'line', 6, phase=0)
    "Separei uma toalha limpa e entreguei junto com a camiseta. Enquanto ela se trocava no banheiro, tirei a roupa do jantar e vesti uma camiseta."
    $ aa_audio_event('h04', 'line', 7, phase=0)
    "Ela voltou com a roupa dobrada e guardou na bolsa. Depois foi a minha vez de usar o banheiro."
    jump h05

label h05:
    $ aa_node = 'h05'
    $ aa_location = '23h05 · Quarto de Feka'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1385)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h05')
    $ aa_location = '23h05 · Quarto de Feka'
    $ aa_stage_action = 'Sentados na cama, conversam antes de dormir.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cama_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cama_conversa'
    show screen aa_location_display
    $ aa_audio_event('h05', 'line', 0, phase=0)
    "Sentamos na cama. Vanessa puxou o cobertor para perto e olhou a hora no celular."
    $ aa_audio_event('h05', 'line', 1, phase=0)
    v "Põe o alarme pras sete e cinco? O meu tá quase sem bateria."
    $ aa_audio_event('h05', 'line', 2, phase=0)
    f "Ponho. Pode usar meu carregador também."
    $ aa_audio_event('h05', 'line', 3, phase=0)
    v "E não desliga pra dormir de novo."
    $ aa_audio_event('h05', 'line', 4, phase=0)
    f "Se eu fizer isso, pode me acordar."
    $ aa_audio_event('h05', 'line', 5, phase=0)
    $ aa_location = '23h05 · Quarto de Feka'
    $ aa_stage_action = 'Sentados na cama, conversam antes de dormir.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cama_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cama_conversa'
    show screen aa_location_display
    "Acertei o alarme e liguei o telefone dela no carregador. Vanessa levou a mão aos óculos, mas parou antes de tirar."
    $ aa_audio_event('h05', 'line', 6, phase=0)
    v "Posso dormir perto?"
    menu:
        "Abraçá-la e perguntar se está confortável.":
            $ aa_audio_event('h05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'h05', 0)
            $ aa_audio_event('h05', 'response', 0, 0)
            f "Pode. Assim tá confortável?"
            $ aa_audio_event('h05', 'response', 1, 0)
            v "Tá."
            $ aa_audio_event('h05', 'response', 2, 0)
            $ aa_stage_action = 'A luz se apaga; elipse para a manhã.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene black at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'black'
            "Ela deixou os óculos no criado-mudo. Deitamos, e Vanessa se acomodou perto do meu peito. Ajustei o cobertor sobre os dois e apaguei a luz."
            jump h06
        "Dividir o cobertor e deixar que ela escolha a distância.":
            $ aa_audio_event('h05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'h05', 1)
            $ aa_audio_event('h05', 'response', 0, 1)
            f "Pode chegar quando quiser."
            $ aa_audio_event('h05', 'response', 1, 1)
            $ aa_stage_action = 'A luz se apaga; aproximação no escuro, sem pressupor abraço.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene black at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'black'
            "Ela guardou os óculos e deitou. Dividi o cobertor e apaguei a luz. Alguns minutos depois, a mão dela encontrou a minha no escuro."
            jump h06

label h06:
    $ aa_node = 'h06'
    $ aa_location = '07h05 · Quarto de Feka'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1865)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h06')
    $ aa_location = '07h05 · Quarto de Feka'
    $ aa_stage_action = 'Manhã clara; os dois acordam no mesmo quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_acordar_juntos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_acordar_juntos'
    show screen aa_location_display
    $ aa_audio_event('h06', 'line', 0, phase=0)
    $ aa_location = '07h05 · Quarto de Feka'
    $ aa_stage_action = 'Manhã clara; os dois acordam no mesmo quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_acordar_juntos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_acordar_juntos'
    show screen aa_location_display
    "O alarme tocou com o quarto já claro. Vanessa dormia ao meu lado, segurando a barra da minha camiseta."
    $ aa_audio_event('h06', 'line', 1, phase=0)
    "Ela abriu os olhos quando tentei alcançar o celular."
    $ aa_audio_event('h06', 'line', 2, phase=0)
    v "Já tá na hora?"
    $ aa_audio_event('h06', 'line', 3, phase=0)
    f "Tá. Vou pôr mais dois minutos."
    $ aa_audio_event('h06', 'line', 4, phase=0)
    "Mostrei a hora. Ela soltou a camiseta e escondeu o rosto no travesseiro."
    $ aa_audio_event('h06', 'line', 5, phase=0)
    v "Só dois?"
    $ aa_audio_event('h06', 'line', 6, phase=0)
    f "Dois. Você mesma falou pra gente não se atrasar."
    $ aa_audio_event('h06', 'line', 7, phase=0)
    "Ela riu sem tirar o rosto do travesseiro. Fiquei deitado ao lado dela até o alarme tocar outra vez."
    $ aa_present = ()
    $ aa_audio_event('h06', 'line', 8, phase=0)
    "Vanessa levou a roupa dobrada para o banheiro. Enquanto ela se trocava, fui colocar a água do café."
    jump h07

label h07:
    $ aa_node = 'h07'
    $ aa_location = '07h25 · Cozinha compartilhada'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1885)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h07')
    $ aa_location = '07h25 · Cozinha compartilhada'
    $ aa_stage_action = 'Café simples na cozinha compartilhada; panela agora limpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cafe_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cafe_cozinha'
    show screen aa_location_display
    $ aa_audio_event('h07', 'line', 0, phase=0)
    "Enquanto a água esquentava, lavei a panela da pia. Vanessa fez duas torradas e sentou. Procurei minha caneca em dois armários."
    $ aa_audio_event('h07', 'line', 1, phase=0)
    v "É aquela atrás de você?"
    $ aa_audio_event('h07', 'line', 2, phase=0)
    $ aa_location = '07h25 · Cozinha compartilhada'
    $ aa_stage_action = 'Café simples na cozinha compartilhada; panela agora limpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_cafe_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_cafe_cozinha'
    show screen aa_location_display
    f "É. Passei por ela duas vezes."
    $ aa_audio_event('h07', 'line', 3, phase=0)
    "Ela riu e puxou minha torrada para longe da beirada. Servi o café nas duas canecas."
    $ aa_audio_event('h07', 'line', 4, phase=0)
    v "Minha mãe vai receber o frete de manhã. Disse que deixa comida pra gente também."
    $ aa_audio_event('h07', 'line', 5, phase=0)
    f "Então a gente come lá depois de abrir as caixas."
    $ aa_audio_event('h07', 'line', 6, phase=0)
    v "Tá. Vou avisar que você vai comer comigo."
    $ aa_audio_event('h07', 'line', 7, phase=0)
    $ aa_phone_remember('almoco_mudanca')
    "Vanessa escreveu a mensagem e me mostrou antes de mandar. Confirmei. Ela enviou e pegou a torrada."
    jump h08

label h08:
    $ aa_node = 'h08'
    $ aa_location = '07h55 · Saída da moradia'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1915)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h08')
    $ aa_location = '07h55 · Saída da moradia'
    $ aa_stage_action = 'Saem juntos com cadernos e um guarda-chuva.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_faculdade at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_faculdade'
    show screen aa_location_display
    $ aa_audio_event('h08', 'line', 0, phase=0)
    "Antes de sair, Vanessa deixou a camiseta emprestada no cesto. Pegamos os cadernos, as bolsas e o guarda-chuva."
    $ aa_audio_event('h08', 'line', 1, phase=0)
    $ aa_location = '07h55 · Saída da moradia'
    $ aa_stage_action = 'Saem juntos com cadernos e um guarda-chuva.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_saida_faculdade at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_saida_faculdade'
    show screen aa_location_display
    $ aa_phone_remember('endereco')
    "A chuva tinha parado. Caminhamos até a faculdade. Ela me mostrou no celular o endereço do apartamento e o ônibus que saía de lá."
    $ aa_audio_event('h08', 'line', 2, phase=0)
    v "A gente pega esse depois da aula. Para a uma quadra."
    $ aa_audio_event('h08', 'line', 3, phase=0)
    f "Você já foi por esse caminho?"
    $ aa_audio_event('h08', 'line', 4, phase=0)
    v "Na visita. Minha mãe quase passou do ponto."
    $ aa_audio_event('h08', 'line', 5, phase=0)
    f "Então você me avisa onde descer."
    $ aa_audio_event('h08', 'line', 6, phase=0)
    "Ela segurou meu braço para atravessarmos a rua. Entramos na sala antes do professor e sentamos juntos."
    jump h09

label h09:
    $ aa_node = 'h09'
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2400)
    $ aa_present = ('vanessa',)
    $ aa_finance_event('bus_campus')
    $ aa_audio_enter('h09')
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chegam juntos ao apartamento; a última caixa está no corredor.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_chegada_mudanca'
    show screen aa_location_display
    $ aa_audio_event('h09', 'line', 0, phase=0)
    "Depois da aula, pegamos o ônibus e caminhamos da parada até o prédio. A mãe de Vanessa já tinha ido embora. Buscamos a chave na portaria e subimos."
    $ aa_audio_event('h09', 'line', 1, phase=0)
    v "Minha mãe disse que ficou uma caixa no corredor. O resto já tá lá dentro."
    $ aa_audio_event('h09', 'line', 2, phase=0)
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chegam juntos ao apartamento; a última caixa está no corredor.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_chegada_mudanca'
    show screen aa_location_display
    "Vanessa abriu a porta. Peguei a caixa antes que ela pedisse."
    $ aa_audio_event('h09', 'line', 3, phase=0)
    v "Essa vai perto da janela. Espera, eu tiro a cadeira."
    $ aa_audio_event('h09', 'line', 4, phase=0)
    f "Tá. Cuidado com a bolsa no chão."
    $ aa_audio_event('h09', 'line', 5, phase=0)
    "Levei a caixa para dentro. Vanessa afastou a cadeira, fechou a porta e olhou a sala cheia de coisas."
    $ aa_audio_event('h09', 'line', 6, phase=0)
    v "Agora é meu."
    $ aa_audio_event('h09', 'line', 7, phase=0)
    f "Agora é seu."
    jump h10

label h10:
    $ aa_node = 'h10'
    $ aa_location = 'Depois da aula · Apartamento de Vanessa · Mudança'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2400)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('h10')
    $ aa_location = 'Depois da aula · Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Trabalham lado a lado entre caixas abertas e louça.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_trabalho_mudanca'
    show screen aa_location_display
    $ aa_audio_event('h10', 'line', 0, phase=0)
    "Tirei o casaco. Vanessa vestiu uma blusa de manga comprida que achou na mala. Abrimos as caixas da cozinha até encontrar os pratos."
    $ aa_audio_event('h10', 'line', 1, phase=0)
    $ aa_location = 'Depois da aula · Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Trabalham lado a lado entre caixas abertas e louça.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_trabalho_mudanca'
    show screen aa_location_display
    "Eu desembrulhei os copos; ela escolheu a prateleira. Depois empurramos a mesa alguns centímetros para liberar a passagem."
    $ aa_audio_event('h10', 'line', 2, phase=0)
    v "Você acha que cabe uma cadeira do outro lado?"
    $ aa_audio_event('h10', 'line', 3, phase=0)
    f "Se a mesa ficar assim, cabe."
    $ aa_audio_event('h10', 'line', 4, phase=0)
    v "Então deixa assim."
    $ aa_audio_event('h10', 'line', 5, phase=0)
    "Colocamos as duas cadeiras no lugar. Passei entre a mesa e a parede para conferir. Vanessa veio atrás, segurando os pratos."
    $ aa_audio_event('h10', 'line', 6, phase=0)
    v "Vou esquentar a comida. Você pega os talheres naquela caixa?"
    $ aa_audio_event('h10', 'line', 7, phase=0)
    f "Pego. Tem pano pra limpar a mesa?"
    jump e11

label e11:
    $ aa_node = 'e11'
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(2460)
    $ aa_present = ('vanessa',)
    $ aa_audio_enter('e11')
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Refeição simples entre caixas; duas cadeiras e dois pratos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_refeicao_feliz at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_refeicao_feliz'
    show screen aa_location_display
    $ aa_audio_event('e11', 'line', 0, phase=0)
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Refeição simples entre caixas; duas cadeiras e dois pratos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg13_refeicao_feliz at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg13_refeicao_feliz'
    show screen aa_location_display
    "Limpamos a mesa e sentamos para comer. Vanessa contou o que queria comprar primeiro. Eu estava com fome e pedi que passasse a travessa."
    $ aa_audio_event('e11', 'line', 1, phase=0)
    "Ela serviu mais um pouco para mim e ficou com o que restava. Disse que a mãe sempre fazia comida demais. Dessa vez tinha dado certo."
    $ aa_audio_event('e11', 'line', 2, phase=0)
    "Meu celular continuava no bolso. Ainda faltava montar uma prateleira; perguntei onde ela tinha guardado as ferramentas."
    $ aa_audio_event('e11', 'line', 3, phase=0)
    v "Você volta amanhã?"
    $ aa_audio_event('e11', 'line', 4, phase=0)
    f "Depois da aula."
    $ aa_audio_event('e11', 'line', 5, phase=0)
    v "Tá. Eu faço café."
    $ aa_audio_event('e11', 'line', 6, phase=0)
    "Vanessa sorriu e continuou comendo. Encostei meu pé no dela por baixo da mesa. Ela deixou o pé ali."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E11 · A manhã que continuou"
    return

label d00:
    $ aa_node = 'd00'
    $ aa_location = '22h06 · Perto da recepção'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1326)
    $ aa_present = ()
    $ aa_audio_enter('d00')
    $ aa_stage_action = 'O pedido para sair'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    $ aa_audio_event('d00', 'line', 0, phase=0)
    $ aa_stage_action = 'O pedido para sair'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    "O funcionário ficou ao meu lado. Yasmin pegou a bolsa e foi em direção à saída. Joãozão acompanhou, sem tirar os olhos de mim."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d00', 'line', 1, phase=0)
        "Vanessa parou junto à recepção. Segurava o casaco e o celular."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d00', 'line', 2, phase=0)
        $ aa_stage_action = 'O pedido para sair'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_recepcao'
        show screen aa_location_display
        "Vanessa já tinha ido embora. Eu não tinha ninguém ali que ainda esperasse alguma coisa de mim."
    $ aa_audio_event('d00', 'line', 3, phase=0)
    f "Agora você vai fingir que nem me conhece?"
    $ aa_audio_event('d00', 'line', 4, phase=0)
    y "Eu te conheço. Por isso eu tô pedindo pra você me deixar ir."
    $ aa_audio_event('d00', 'line', 5, phase=0)
    f "Depois de tudo que eu fiz por você."
    $ aa_audio_event('d00', 'line', 6, phase=0)
    y "Eu não te pedi pra me esperar na saída da escola. Pedi pra parar."
    if aa_matches(aa_state, {'past_read': True}):
        $ aa_audio_event('d00', 'line', 7, phase=0)
        "Eu lembrava daquela mensagem. Mesmo assim, procurei no rosto dela alguma hesitação."
    $ aa_audio_event('d00', 'line', 8, phase=0)
    y "E agora você tá fazendo de novo. Eu digo que não quero, você continua."
    $ aa_audio_event('d00', 'line', 9, phase=0)
    j "Acabou, Feka. Sai da frente."
    $ aa_audio_event('d00', 'line', 10, phase=0)
    f "Você gosta de assistir, né? De me ver assim."
    $ aa_audio_event('d00', 'line', 11, phase=0)
    y "Eu quero ir embora."
    $ aa_audio_event('d00', 'line', 12, phase=0)
    "O funcionário apontou a porta e pediu que eu deixasse a passagem livre. Eu podia sair por ela também."
    menu:
        "Deixar a passagem livre e sair.":
            $ aa_audio_event('d00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd00', 0)
            jump e07
        "Passar na frente de Yasmin e exigir que ela me escute.":
            $ aa_audio_event('d00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd00', 1)
            jump d01

label d01:
    $ aa_node = 'd01'
    $ aa_location = '22h07 · Recepção'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1327)
    $ aa_present = ()
    $ aa_audio_enter('d01')
    $ aa_stage_action = 'A passagem'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    $ aa_audio_event('d01', 'line', 0, phase=0)
    $ aa_stage_action = 'A passagem'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    "Dei dois passos e parei entre Yasmin e a porta. Ela parou também. O funcionário veio atrás de mim."
    $ aa_audio_event('d01', 'line', 1, phase=0)
    y "Sai da frente."
    $ aa_audio_event('d01', 'line', 2, phase=0)
    $ aa_stage_action = 'A passagem'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recepcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recepcao'
    show screen aa_location_display
    f "Um minuto. Você não consegue me dar um minuto?"
    $ aa_audio_event('d01', 'line', 3, phase=0)
    y "Não. Eu não quero conversar com você."
    $ aa_audio_event('d01', 'line', 4, phase=0)
    j "Você tá impedindo ela de sair."
    $ aa_audio_event('d01', 'line', 5, phase=0)
    f "Eu só quero me despedir."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d01', 'line', 6, phase=0)
        v "Feka. Deixa ela passar. Vem pra cá."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d01', 'line', 7, phase=0)
        "Vanessa falava baixo, como se ainda pudesse fazer aquilo caber numa conversa nossa."
    $ aa_audio_event('d01', 'line', 8, phase=0)
    "Yasmin tentou passar pelo meu lado. Eu virei junto. Ela levantou a mão aberta, antes que eu chegasse perto."
    $ aa_audio_event('d01', 'line', 9, phase=0)
    y "Não encosta em mim."
    menu:
        "Recuar e deixar Yasmin passar.":
            $ aa_audio_event('d01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd01', 0)
            jump d_stop
        "Tentar abraçá-la mesmo depois da recusa.":
            $ aa_audio_event('d01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd01', 1)
            jump d02

label d02:
    $ aa_node = 'd02'
    $ aa_location = '22h08 · Recepção'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1328)
    $ aa_present = ()
    $ aa_audio_enter('d02')
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    $ aa_audio_event('d02', 'line', 0, phase=0)
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    "Abri os braços. Yasmin se afastou. Minha mão pegou no braço dela antes que eu conseguisse encostar o resto do corpo."
    $ aa_audio_event('d02', 'line', 1, phase=0)
    y "Me solta."
    $ aa_audio_event('d02', 'line', 2, phase=0)
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    "Ela puxou o braço. Eu continuei segurando. Não tinha nada de abraço na posição em que ficamos."
    $ aa_audio_event('d02', 'line', 3, phase=0)
    j "Tira a mão dela. Agora."
    $ aa_audio_event('d02', 'line', 4, phase=0)
    "O funcionário estendeu a mão na minha direção. Yasmin olhava para os meus dedos, não para mim."
    $ aa_audio_event('d02', 'line', 5, phase=0)
    f "Eu não vou machucar ninguém."
    $ aa_audio_event('d02', 'line', 6, phase=0)
    y "Então solta."
    menu:
        "Soltar o braço e me afastar.":
            $ aa_audio_event('d02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd02', 0)
            jump d_stop
        "Continuar segurando e mandar Joãozão ficar fora disso.":
            $ aa_audio_event('d02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd02', 1)
            jump d03

label d_stop:
    $ aa_node = 'd_stop'
    $ aa_location = '22h09 · Saída do restaurante'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1329)
    $ aa_present = ()
    $ aa_audio_enter('d_stop')
    $ aa_stage_action = 'Feka afastado, mãos baixas; Yasmin protegida pela distância, sem contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    if aa_matches(aa_state, {'unwanted_contact': True}):
        $ aa_audio_event('d_stop', 'line', 0, phase=0)
        $ aa_stage_action = 'Feka afastado, mãos baixas; Yasmin protegida pela distância, sem contato.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_recuo'
        show screen aa_location_display
        "Soltei o braço. Yasmin foi para trás do funcionário e esfregou o lugar onde eu tinha segurado."
    if aa_matches(aa_state, {'unwanted_contact': False}):
        $ aa_audio_event('d_stop', 'line', 1, phase=0)
        "Afastei os pés da passagem. Yasmin passou longe do meu ombro e foi para perto do funcionário."
    $ aa_audio_event('d_stop', 'line', 2, phase=0)
    $ aa_stage_action = 'Feka afastado, mãos baixas; Yasmin protegida pela distância, sem contato.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recuo at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recuo'
    show screen aa_location_display
    y "Eu não quero mensagem. Não quero pedido de desculpa na minha porta. Me deixa em paz."
    $ aa_audio_event('d_stop', 'line', 3, phase=0)
    j "Vai embora."
    $ aa_audio_event('d_stop', 'line', 4, phase=0)
    "O funcionário me acompanhou até a calçada. Yasmin ficou lá dentro, falando com a recepcionista."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d_stop', 'line', 5, phase=0)
        v "Eu vou sozinha. Não vem comigo."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d_stop', 'line', 6, phase=0)
        "Vanessa atravessou a entrada sem pegar minha mão. Eu tinha parado. Ela ainda estava com medo de que eu recomeçasse."
    $ aa_audio_event('d_stop', 'line', 7, phase=0)
    "Na calçada, peguei o celular. Não havia ninguém me impedindo de mandar outra mensagem. Guardei antes de abrir a conversa."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E13 · A passagem livre"
    return

label d03:
    $ aa_node = 'd03'
    $ aa_location = '22h08 · Recepção'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1328)
    $ aa_present = ()
    $ aa_audio_enter('d03')
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    $ aa_audio_event('d03', 'line', 0, phase=0)
    $ aa_stage_action = 'Não é um abraço'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_recusa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_recusa'
    show screen aa_location_display
    f "Fica fora disso. Eu tô falando com ela."
    $ aa_audio_event('d03', 'line', 1, phase=0)
    $ aa_stage_action = 'Após um único golpe, Feka no chão; funcionário separa os envolvidos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_queda at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_queda'
    show screen aa_location_display
    "Yasmin tentou puxar o braço outra vez. Eu apertei a mão. Joãozão avançou e me acertou no rosto."
    $ aa_audio_event('d03', 'line', 2, phase=0)
    $ aa_stage_action = 'Após um único golpe, Feka no chão; funcionário separa os envolvidos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_queda at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_queda'
    show screen aa_location_display
    "Soltei na hora. Bati na lateral de uma cadeira e caí sentado. O barulho da cadeira veio antes de eu entender onde estava."
    $ aa_audio_event('d03', 'line', 3, phase=0)
    "Levei a mão à boca. Havia sangue no dedo. Eu olhei para Joãozão, esperando outro golpe."
    $ aa_audio_event('d03', 'line', 4, phase=0)
    "O funcionário entrou entre nós. Joãozão ficou parado do outro lado, respirando pela boca."
    $ aa_audio_event('d03', 'line', 5, phase=0)
    y "João, chega!"
    $ aa_audio_event('d03', 'line', 6, phase=0)
    j "Ele não soltava você."
    $ aa_audio_event('d03', 'line', 7, phase=0)
    y "Eu sei. Fica longe dele agora."
    $ aa_audio_event('d03', 'line', 8, phase=0)
    "Yasmin se afastou dos dois e pediu à recepcionista que chamasse a polícia. Disse que queria contar o que tinha acontecido."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d03', 'line', 9, phase=0)
        v "Você tá conseguindo me ouvir?"
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d03', 'line', 10, phase=0)
        "Vanessa se agachou a uma distância que eu não consegui diminuir sem parecer que ia agarrá-la também."
    $ aa_audio_event('d03', 'line', 11, phase=0)
    f "Você viu o que ele fez?"
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d03', 'line', 12, phase=0)
        v "Vi. Eu também vi o que você fez."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d03', 'line', 13, phase=0)
        "O funcionário disse que tinha visto a discussão desde o primeiro pedido para sair."
    menu:
        "Dizer que eu só queria abraçar Yasmin.":
            $ aa_audio_event('d03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd03', 0)
            $ aa_audio_event('d03', 'response', 0, 0)
            f "Eu só fui dar um abraço. Ele veio pra cima de mim."
            $ aa_audio_event('d03', 'response', 1, 0)
            y "Eu falei pra não encostar. Depois pedi pra soltar."
            $ aa_audio_event('d03', 'response', 2, 0)
            "Ninguém respondeu à palavra abraço. O funcionário pediu que eu continuasse sentado."
            jump d04
        "Dizer que segurei o braço dela e pedir ajuda para levantar.":
            $ aa_audio_event('d03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd03', 1)
            $ aa_audio_event('d03', 'response', 0, 1)
            f "Eu segurei o braço dela. Me ajuda a levantar."
            $ aa_audio_event('d03', 'response', 1, 1)
            "O funcionário pediu que eu esperasse e trouxe um guardanapo. Yasmin não veio até mim."
            jump d04

label d04:
    $ aa_node = 'd04'
    $ aa_location = '22h24 · Entrada do restaurante'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(1344)
    $ aa_present = ()
    $ aa_audio_enter('d04')
    $ aa_stage_action = 'Cada um de um lado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_policia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_policia'
    show screen aa_location_display
    $ aa_audio_event('d04', 'line', 0, phase=0)
    $ aa_stage_action = 'Cada um de um lado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_policia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_policia'
    show screen aa_location_display
    "A recepcionista tinha chamado ajuda e me mantido sentado. Quando os policiais chegaram, o funcionário mostrou onde cada um estava."
    $ aa_audio_event('d04', 'line', 1, phase=0)
    "Um deles ficou comigo. O outro ouviu Yasmin perto da porta. Joãozão esperou junto ao balcão, longe dela e de mim."
    $ aa_audio_event('d04', 'line', 2, phase=0)
    $ aa_stage_action = 'Cada um de um lado'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_policia at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_policia'
    show screen aa_location_display
    "Perguntaram se eu estava passando mal. Mostrei a boca e disse que o rosto doía. Providenciaram uma avaliação antes de continuarmos."
    $ aa_audio_event('d04', 'line', 3, phase=0)
    f "Eu faço Direito."
    $ aa_audio_event('d04', 'line', 4, phase=0)
    "O policial esperou. Depois perguntou meu nome completo. Eu dei o nome da faculdade antes de perceber que não era isso."
    $ aa_audio_event('d04', 'line', 5, phase=0)
    y "Eu quero que conste que ele me segurou. Eu pedi pra me soltar."
    $ aa_audio_event('d04', 'line', 6, phase=0)
    j "Eu dei o soco. Não vou dizer que não dei."
    $ aa_audio_event('d04', 'line', 7, phase=0)
    "Joãozão falou com o outro policial. Não parecia satisfeito. Yasmin continuou olhando para quem anotava."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 8, phase=0)
        v "Eu vou contar o que eu vi. Não vou falar que foi só um abraço."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 9, phase=0)
        f "Você vai ficar comigo?"
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 10, phase=0)
        v "Vou esperar terminar isso aqui. Depois minha mãe vem me buscar. Eu não consigo ficar com você."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d04', 'line', 11, phase=0)
        "Ela chorava enquanto falava. Quando tentei chamar de novo, foi para perto da recepcionista."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d04', 'line', 12, phase=0)
        "Pensei em ligar para Vanessa. Ela já tinha ido embora antes daquilo. Eu teria que começar contando por que ainda estava ali."
    $ aa_audio_event('d04', 'line', 13, phase=0)
    "Depois da avaliação, explicaram que iríamos à delegacia para registrar os relatos. Joãozão também teria que contar sobre o golpe. Não houve uma decisão ali no restaurante sobre quem tinha razão."
    jump d05

label d05:
    $ aa_node = 'd05'
    $ aa_location = 'Mais tarde · A caminho da delegacia'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(None)
    $ aa_present = ()
    $ aa_audio_enter('d05')
    $ aa_stage_action = 'O banco de trás'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_viatura at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_viatura'
    show screen aa_location_display
    $ aa_audio_event('d05', 'line', 0, phase=0)
    $ aa_stage_action = 'O banco de trás'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_viatura at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_viatura'
    show screen aa_location_display
    "Saí com um policial. Yasmin ficou com o outro, terminando de explicar. Joãozão não veio no mesmo carro que eu."
    $ aa_audio_event('d05', 'line', 1, phase=0)
    "Entrei no banco de trás e coloquei o cinto. A porta fechou. No vidro, meu rosto aparecia por cima das luzes da rua."
    $ aa_audio_event('d05', 'line', 2, phase=0)
    $ aa_stage_action = 'O banco de trás'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_viatura at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_viatura'
    show screen aa_location_display
    "O guardanapo estava amassado na minha mão. Eu tinha vergonha de perguntar onde jogar."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('d05', 'line', 3, phase=0)
        "Vanessa tinha chamado a mãe. Não me pediu para mandar mensagem quando chegasse."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('d05', 'line', 4, phase=0)
        "O celular de Vanessa continuava longe de mim, como já estava antes do golpe. Ela não sabia que eu ia parar ali."
    $ aa_audio_event('d05', 'line', 5, phase=0)
    "Pensei em dizer que ele tinha me batido do nada. Eu conseguia montar a frase. O difícil era tirar minha mão do braço de Yasmin da lembrança."
    jump d06

label d06:
    $ aa_node = 'd06'
    $ aa_location = 'Depois da meia-noite · Delegacia'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(None)
    $ aa_present = ()
    $ aa_audio_enter('d06')
    $ aa_stage_action = 'Feka aguarda na recepção, separado do outro casal.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    $ aa_audio_event('d06', 'line', 0, phase=0)
    $ aa_stage_action = 'Feka aguarda na recepção, separado do outro casal.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    "Na recepção, pediram meu documento. Sentei numa cadeira de plástico até chamarem meu nome. O funcionário do restaurante tinha deixado um contato."
    $ aa_audio_event('d06', 'line', 1, phase=0)
    "Yasmin e Joãozão chegaram depois. Foram orientados a esperar em outro lugar. Eu não fui falar com eles."
    $ aa_audio_event('d06', 'line', 2, phase=0)
    $ aa_stage_action = 'Relato individual à mesa, sem Yasmin ou Joãozão presentes.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_depoimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_depoimento'
    show screen aa_location_display
    "Quando me chamaram, sentei diante de uma mesa com um computador. A pessoa que me atendia pediu que eu contasse desde o começo."
    $ aa_audio_event('d06', 'line', 3, phase=0)
    f "Ele me deu um soco."
    $ aa_audio_event('d06', 'line', 4, phase=0)
    "Anotou. Depois perguntou o que tinha acontecido antes do soco."
    if aa_matches(aa_state, {'incident_account': 'negou'}):
        $ aa_audio_event('d06', 'line', 5, phase=0)
        "Eu já tinha dito que era só um abraço. A frase estava pronta para ser usada outra vez."
    if aa_matches(aa_state, {'incident_account': 'admitiu'}):
        $ aa_audio_event('d06', 'line', 6, phase=0)
        "No restaurante eu tinha admitido que segurei o braço dela. Agora precisava repetir sem diminuir o que fiz."
    menu:
        "Contar que impedi a passagem e continuei segurando depois do pedido para soltar.":
            $ aa_audio_event('d06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'd06', 0)
            $ aa_audio_event('d06', 'response', 0, 0)
            f "Eu parei na frente dela. Ela mandou eu sair. Depois eu peguei no braço. Ela pediu pra soltar e eu não soltei."
            $ aa_audio_event('d06', 'response', 1, 0)
            "Eu tinha começado pelo soco. Agora quem anotava voltou algumas linhas."
            jump e12
        "Omitir que ela pediu para eu soltar e dizer que Joãozão me atacou sem motivo.":
            $ aa_audio_event('d06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'd06', 1)
            $ aa_audio_event('d06', 'response', 0, 1)
            f "Eu fui me despedir. Ele me bateu sem motivo."
            $ aa_audio_event('d06', 'response', 1, 1)
            "Perguntaram se eu tinha tocado nela. Disse que sim. Perguntaram o que ela falou. Fiquei olhando para o teclado."
            jump e12

label e12:
    $ aa_node = 'e12'
    $ aa_location = 'Madrugada · Sala de espera da delegacia'
    $ aa_phone_active = True
    $ aa_present = ()
    call aa_advance_clock(None)
    $ aa_present = ()
    $ aa_audio_enter('e12')
    $ aa_stage_action = 'Sem ninguém para confirmar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    $ aa_audio_event('e12', 'line', 0, phase=0)
    $ aa_stage_action = 'Sem ninguém para confirmar'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg15_espera'
    show screen aa_location_display
    "Voltei para a cadeira de plástico. Ainda precisava esperar. Ninguém tinha dito que aquilo estava resolvido."
    if aa_matches(aa_state, {'station_account': 'completo'}):
        $ aa_audio_event('e12', 'line', 1, phase=0)
        "Eu tinha contado o que fiz. Isso não tirou a dor do rosto nem fez Yasmin querer me ouvir."
    if aa_matches(aa_state, {'station_account': 'omitiu'}):
        $ aa_audio_event('e12', 'line', 2, phase=0)
        $ aa_stage_action = 'Sem ninguém para confirmar'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg15_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg15_espera'
        show screen aa_location_display
        "Eu tinha omitido o pedido dela. O relato de Yasmin e o do funcionário não dependiam de eu concordar com eles."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e12', 'line', 3, phase=0)
        "Vanessa mandou uma mensagem: \"Cheguei com minha mãe. Hoje não me procura. Amanhã eu vejo como falar com você.\""
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_audio_event('e12', 'line', 4, phase=0)
        "Li a conversa com Vanessa. A última mensagem ainda era de antes do jantar. Não contei onde estava."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_audio_event('e12', 'line', 5, phase=0)
        "Eu tinha prometido ajudar na mudança. Olhei a hora. Ela teria que resolver aquilo sem poder contar comigo."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_event('e12', 'line', 6, phase=0)
        "Ainda devia sessenta reais a Joãozão. O golpe não tinha feito o dinheiro deixar de ser dele."
    if aa_matches(aa_state, {'bill': 'vanessa'}):
        $ aa_audio_event('e12', 'line', 7, phase=0)
        "Eu também devia o dinheiro que Vanessa tinha tirado da mudança. Não havia conserto numa mensagem de madrugada."
    $ aa_audio_event('e12', 'line', 8, phase=0)
    "Abri uma mensagem nova para dizer que tinham acabado com a minha noite. Apaguei. Depois escrevi só que precisava de alguém para me buscar quando pudesse sair."
    $ aa_audio_event('e12', 'line', 9, phase=0)
    "Fiquei segurando o celular. Do outro lado da sala, chamaram um nome que não era o meu."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_phone_active = True
    $ aa_audio_ending()
    centered "E12 · Sem ninguém para confirmar"
    return
