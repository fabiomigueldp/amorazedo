# Gerado por tools/build_story.py. Edite a fonte editorial, não este arquivo.
label start:
    $ aa_state = aa_new_state()
    $ aa_last_art = ""
    $ aa_audio_reset()
    jump a00

label a00:
    $ aa_node = 'a00'
    $ aa_location = '18h42 · Quarto de Feka'
    $ aa_audio_enter('a00')
    $ aa_stage_action = 'Vanessa larga a bolsa; Feka sentado, ainda sem celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_bolsa'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 0, phase=0)
    "Vanessa deixou a bolsa na minha cama e abriu o zíper."
    $ aa_stage_action = 'Vanessa entrou no banheiro; Feka responde da cama.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_banheiro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_banheiro'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 1, phase=0)
    "Ela entrou no banheiro. A torneira fez barulho antes de sair água."
    $ aa_audio_event('a00', 'line', 2, phase=0)
    v "Onde você deixa a toalha de rosto?"
    $ aa_audio_event('a00', 'line', 3, phase=0)
    f "Atrás da porta."
    $ aa_stage_action = 'Ela seca as mãos na toalha de banho; o gancho fica vazio.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.08, 0.83, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 4, phase=0)
    "Era a de banho. A de rosto estava no cesto havia três dias. Ela não reclamou."
    $ aa_audio_event('a00', 'line', 5, phase=0)
    "Meu quarto tinha banheiro. A cozinha e a sala eram divididas com gente que sempre sabia quando eu tinha visita."
    $ aa_stage_action = 'Atenção nos cadernos e na escrivaninha, ainda no mesmo espaço.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.2, 0.54, 0.44)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 6, phase=0)
    "Na escrivaninha, dois cadernos de Direito. Vanessa tinha corrigido minhas anotações. Antes da última prova, eu tinha esperado com ela no corredor até a mão parar de tremer. Ela ainda falava daquele dia."
    $ aa_stage_action = 'A escolha ocorre antes de Feka pegar o celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_toalha_corrigida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_toalha_corrigida'
    show screen aa_location_display
    $ aa_audio_event('a00', 'line', 7, phase=0)
    "O celular estava no carregador. Yasmin não tinha me mandado mensagem. Não era preciso uma mensagem para eu pegar o celular."
    menu:
        "Abrir o perfil de Yasmin.":
            $ aa_audio_event('a00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a00', 0)
            jump a01
        "Conferir a conversa antiga com Yasmin.":
            $ aa_audio_event('a00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a00', 1)
            jump a02
        "Deixar o celular e separar a roupa.":
            $ aa_audio_event('a00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a00', 2)
            $ aa_stage_action = 'Ele deixa o telefone e presta atenção no quarto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_brincos'
            $ aa_audio_event('a00', 'response', 0, 2)
            "Afastei o celular com a jaqueta. Não apaguei nada. Só deixei para depois."
            jump a03

label a01:
    $ aa_node = 'a01'
    $ aa_location = '18h46 · Quarto de Feka'
    $ aa_audio_enter('a01')
    $ aa_stage_action = 'Feka pega o celular; Vanessa continua no banheiro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    window hide
    hide screen aa_location_display
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    if aa_last_art != 'cg2_celular':
        show screen aa_cg_continue
        pause
        hide screen aa_cg_continue
    window auto
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    $ aa_stage_action = 'Foto vertical do casal na tela, vista das mãos de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'publicacao'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    show screen aa_phone_view('publicacao')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    $ aa_audio_event('a01', 'line', 0, phase=0)
    "Os dois de jaleco. Eu já sabia que estudavam juntos. Abri a foto mesmo assim."
    $ aa_stage_action = 'Passa à foto do copo, cardápio e mão de Joãozão; localização legível.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'restaurante'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    $ aa_audio_event('a01', 'line', 1, phase=0)
    "A publicação seguinte era de poucos minutos antes."
    $ aa_audio_event('a01', 'line', 2, phase=0)
    "Casa do Pátio. Era o lugar da minha reserva. Eu podia cancelar. Ainda nem tínhamos saído."
    $ aa_audio_event('a01', 'line', 3, phase=0)
    "A ideia de cancelar me deu uma raiva pequena e imediata. Eu tinha passado a semana dizendo que aquele jantar era para Vanessa."
    $ aa_stage_action = 'Vanessa chama fora do quadro; ele ainda olha a publicação.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'restaurante'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    show screen aa_phone_view('restaurante')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    $ aa_audio_event('a01', 'line', 4, phase=0)
    v "Você viu meu brinco? O pequeno."
    $ aa_stage_action = 'Retorno ao quarto após a interrupção; telefone ainda nas mãos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    $ aa_audio_event('a01', 'line', 5, phase=0)
    "Eu respondi que não sem levantar os olhos."
    menu:
        "Fechar a publicação. Agora eu sei que ela está lá.":
            $ aa_audio_event('a01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a01', 0)
            jump a03
        "Ficar olhando mais um pouco.":
            $ aa_audio_event('a01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a01', 1)
            jump a02

label a02:
    $ aa_node = 'a02'
    $ aa_location = '18h51 · Quarto de Feka'
    $ aa_audio_enter('a02')
    $ aa_stage_action = 'Conversa antiga na tela física; nenhum pensamento atribuído a Yasmin.'
    $ aa_table_party = 0
    $ aa_phone_pov = True
    $ aa_phone_kind = 'conversa'
    $ aa_dialogue_side = True
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg3_celular_pov at aa_phone_camera
    with Dissolve(0.25)
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg3_celular_pov'
    show screen aa_location_display
    $ aa_audio_event('a02', 'line', 0, phase=0)
    "A conversa era antiga. Não o suficiente para eu ter esquecido o que ela dizia."
    $ aa_audio_event('a02', 'line', 1, phase=0)
    y "Feka, não me espera na saída de novo. Eu não combinei nada com você."
    $ aa_audio_event('a02', 'line', 2, phase=0)
    "Embaixo, eu tinha escrito que estava só passando. Eu lembrava de ter chegado cedo."
    $ aa_audio_event('a02', 'line', 3, phase=0)
    "Conheci Yasmin no ensino médio. Durante anos, qualquer coisa serviu: uma resposta curta, uma foto nova, o lugar onde ela dizia que ia estar."
    $ aa_audio_event('a02', 'line', 4, phase=0)
    "Eu chamava aquilo de gostar de alguém. A palavra não dizia quanto trabalho eu dava a ela."
    $ aa_stage_action = 'A voz de Vanessa devolve o quarto ao primeiro plano.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_celular'
    show screen aa_location_display
    $ aa_audio_event('a02', 'line', 5, phase=0)
    v "Feka?"
    menu:
        "Guardar o celular e responder.":
            $ aa_audio_event('a02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a02', 0)
            jump a03
        "Reler minha resposta, procurando alguma defesa.":
            $ aa_audio_event('a02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a02', 1)
            jump a03

label a03:
    $ aa_node = 'a03'
    $ aa_location = '19h02 · Quarto e banheiro'
    $ aa_audio_enter('a03')
    $ aa_stage_action = 'Celular abaixado; toalha devolvida; Vanessa termina o brinco.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    $ aa_audio_event('a03', 'line', 0, phase=0)
    "Vanessa pendurou a toalha úmida no banheiro. Ainda mexia no fecho do brinco, perto da porta. O casaco e a bolsa estavam na cama."
    $ aa_audio_event('a03', 'line', 1, phase=0)
    v "Achei o brinco. Tava na minha bolsa."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a03', 'line', 2, phase=0)
        v "Você nem olhou quando eu perguntei. Ficou no celular."
    if aa_matches(aa_state, {'late': True}):
        $ aa_audio_event('a03', 'line', 3, phase=0)
        v "Você ficou quieto. Achei que tinha desistido de sair."
    $ aa_stage_action = 'Último ajuste do brinco antes de atravessar o quarto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_brincos at aa_camera(1.13, 0.83, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_brincos'
    show screen aa_location_display
    $ aa_audio_event('a03', 'line', 4, phase=0)
    "Ela terminou de colocar o brinco, atravessou o quarto e pegou o casaco."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a03', 'line', 5, phase=0)
        "Eu sabia onde Yasmin estava. Vanessa só sabia onde íamos jantar."
    $ aa_stage_action = 'Feka levanta, veste a jaqueta e acerta a gola; cadeira livre.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    $ aa_audio_event('a03', 'line', 6, phase=0)
    "Levantei e vesti a jaqueta escura. Vanessa me olhou enquanto eu acertava a gola."
    $ aa_stage_action = 'O olhar de Vanessa acompanha a escolha da roupa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quarto_jaqueta at aa_camera(1.1, 0.27, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quarto_jaqueta'
    show screen aa_location_display
    $ aa_audio_event('a03', 'line', 7, phase=0)
    v "Essa? Você não vai sentir calor?"
    $ aa_audio_event('a03', 'line', 8, phase=0)
    v "Eu demorei muito?"
    $ aa_audio_event('a03', 'line', 9, phase=0)
    f "Não."
    $ aa_audio_event('a03', 'line', 10, phase=0)
    "Ela olhou para o meu rosto para conferir. Eu estava terminando de arrumar a gola."
    menu:
        "Perguntar se ela prefere a camiseta.":
            $ aa_audio_event('a03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a03', 0)
            $ aa_stage_action = 'Ela espera que a escolha da roupa encerre a distração.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_quarto_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_quarto_espera'
            $ aa_audio_event('a03', 'response', 0, 0)
            v "Eu gosto da camiseta. Mas essa também fica boa."
            $ aa_audio_event('a03', 'response', 1, 0)
            "Ela esperou eu escolher. Eu tinha perguntado por costume."
            jump a04
        "Dizer que já está bom e elogiar o cabelo dela.":
            $ aa_audio_event('a03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a03', 1)
            $ aa_stage_action = 'Feka finalmente olha para ela; sorriso breve, casaco no braço.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_quarto_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_quarto_espera'
            $ aa_audio_event('a03', 'response', 0, 1)
            f "Seu cabelo ficou bonito."
            $ aa_audio_event('a03', 'response', 1, 1)
            v "É? Eu achei que você nem tinha visto."
            $ aa_audio_event('a03', 'response', 2, 1)
            "Ela sorriu. Eu devia ter olhado antes de falar."
            jump a04
        "Conferir pelo celular uma foto minha que Yasmin já curtiu.":
            $ aa_audio_event('a03', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a03', 2)
            $ aa_stage_action = 'Foto antiga ampliável; ele bloqueia antes de Vanessa se aproximar.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = 'comparacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            show screen aa_phone_view('comparacao')
            $ aa_last_art = 'cg2_quarto_jaqueta'
            $ aa_audio_event('a03', 'response', 0, 2)
            "Ampliei a foto para ver a roupa."
            $ aa_stage_action = 'Tela bloqueada; Vanessa volta a ocupar a cena.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quarto_jaqueta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quarto_jaqueta'
            $ aa_audio_event('a03', 'response', 1, 2)
            "Vanessa passou atrás de mim para buscar a bolsa. Bloqueei a tela antes de ela chegar perto."
            jump a04

label a04:
    $ aa_node = 'a04'
    $ aa_location = '19h13 · Cozinha compartilhada'
    $ aa_audio_enter('a04')
    $ aa_stage_action = 'Feka junto à panela; Vanessa diante da geladeira.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    $ aa_audio_event('a04', 'line', 0, phase=0)
    "Na cozinha, alguém tinha deixado uma panela dentro da pia. Passei duas vezes por ela como se não fosse minha."
    $ aa_stage_action = 'Vanessa começa a falar; a panela fica no campo periférico.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha at aa_camera(1.06, 0.78, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha'
    show screen aa_location_display
    $ aa_audio_event('a04', 'line', 1, phase=0)
    v "Amanhã eu pego a chave."
    $ aa_audio_event('a04', 'line', 2, phase=0)
    f "Do apartamento?"
    $ aa_audio_event('a04', 'line', 3, phase=0)
    v "Não. Da prefeitura."
    $ aa_audio_event('a04', 'line', 4, phase=0)
    "Eu ri atrasado. Ela abriu a geladeira, viu uma garrafa com o nome de outro morador e fechou."
    $ aa_stage_action = 'A geladeira é fechada; conversa continua entre os dois.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    $ aa_audio_event('a04', 'line', 5, phase=0)
    v "Vou poder comprar uma coisa e encontrar a mesma coisa quando voltar."
    $ aa_audio_event('a04', 'line', 6, phase=0)
    "Estudávamos Direito na mesma turma. Eu sabia as matérias em que Vanessa ia bem. Não sabia quem tinha ido ver o apartamento com ela."
    menu:
        "Perguntar como foi a visita e deixar ela contar.":
            $ aa_audio_event('a04', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a04', 0)
            jump a05
        "Brincar que agora vou ter onde dormir.":
            $ aa_audio_event('a04', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a04', 1)
            jump a05
        "Avisar que precisamos sair, olhando o celular.":
            $ aa_audio_event('a04', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a04', 2)
            $ aa_stage_action = 'Uma olhada no relógio encerra a escuta.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = 'relogio'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            show screen aa_phone_view('relogio')
            $ aa_last_art = 'cg2_cozinha_fechada'
            $ aa_audio_event('a04', 'response', 0, 2)
            v "Eu já estou pronta. Você também? Então vamos."
            jump a05

label a05:
    $ aa_node = 'a05'
    $ aa_location = '19h22 · Cozinha compartilhada'
    $ aa_audio_enter('a05')
    $ aa_stage_action = 'Geladeira fechada; Vanessa mostra o orçamento no celular.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    if aa_matches(aa_state, {'heard': True}):
        $ aa_audio_event('a05', 'line', 0, phase=0)
        v "Fui com a minha mãe. É pequeno. Não tem onde pôr uma mesa grande. Mas a porta fecha."
    if aa_matches(aa_state, {'claimed_space': True}):
        $ aa_audio_event('a05', 'line', 1, phase=0)
        v "Vai querer ir mesmo ou tá só falando?"
    $ aa_stage_action = 'Orçamento na mão dela, não na tela de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'orcamento'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.1, 0.74, 0.48)
    with Dissolve(0.25)
    show screen aa_phone_view('orcamento')
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    $ aa_audio_event('a05', 'line', 2, phase=0)
    "Ela virou o celular para mim. Tinha separado o dinheiro da caução e do frete. Para o jantar, sobravam noventa reais."
    $ aa_stage_action = 'Voltar a Vanessa: ela explica o limite do orçamento.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cozinha_fechada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cozinha_fechada'
    show screen aa_location_display
    $ aa_audio_event('a05', 'line', 3, phase=0)
    v "Cada um paga o seu, tá? Posso gastar até noventa hoje. O dinheiro da mudança eu não quero mexer."
    $ aa_audio_event('a05', 'line', 4, phase=0)
    "Yasmin tinha recomendado o restaurante no grupo três semanas antes. Guardei o nome. Para Vanessa, disse que tinha pensado nela."
    $ aa_audio_event('a05', 'line', 5, phase=0)
    "Meu saldo aguentava meu prato. Não aguentava a pessoa que eu queria parecer."
    $ aa_audio_event('a05', 'line', 6, phase=0)
    v "Minha mãe vai ajudar de manhã. Você podia ir depois."
    $ aa_audio_event('a05', 'line', 7, phase=0)
    "Ela disse isso enquanto guardava o celular, sem olhar para mim."
    menu:
        "Combinar que cada um paga o seu.":
            $ aa_audio_event('a05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a05', 0)
            $ aa_audio_event('a05', 'response', 0, 0)
            f "Combinado. Cada um o seu."
            $ aa_audio_event('a05', 'response', 1, 0)
            v "Obrigada. Prefiro saber antes."
            jump a06
        "Insistir que hoje eu pago tudo.":
            $ aa_audio_event('a05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a05', 1)
            $ aa_audio_event('a05', 'response', 0, 1)
            f "Hoje deixa comigo."
            $ aa_audio_event('a05', 'response', 1, 1)
            v "Tem certeza?"
            $ aa_audio_event('a05', 'response', 2, 1)
            f "Tenho."
            $ aa_audio_event('a05', 'response', 3, 1)
            "Consegui dizer sem conferir o saldo outra vez."
            jump a06
        "Admitir que estou apertado e pedir um jantar mais simples lá.":
            $ aa_audio_event('a05', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a05', 2)
            $ aa_audio_event('a05', 'response', 0, 2)
            v "Tudo bem. Eu falei de jantar, não de te quebrar."
            jump a06

label a06:
    $ aa_node = 'a06'
    $ aa_location = '19h30 · Hall do apartamento'
    $ aa_audio_enter('a06')
    $ aa_stage_action = 'Casaco vestido, caderno entrando na bolsa, chave com Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall'
    show screen aa_location_display
    $ aa_audio_event('a06', 'line', 0, phase=0)
    "Vanessa vestiu o casaco, guardou o caderno na bolsa e conferiu a chave, o celular e a carteira. Fiquei esperando que terminasse sem me perguntar mais nada."
    $ aa_stage_action = 'A bolsa se fecha; Vanessa levanta os olhos para perguntar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    $ aa_audio_event('a06', 'line', 1, phase=0)
    v "Foi você mesmo que descobriu esse lugar?"
    $ aa_audio_event('a06', 'line', 2, phase=0)
    "A pergunta podia acabar ali. Isso era o que eu queria: que uma pergunta acabasse antes de chegar onde doía."
    menu:
        "Contar que Yasmin indicou o lugar e que eu vi que ela está lá." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a06', 0)
            jump a07
        "Contar que quem indicou foi uma menina de quem eu gostei." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a06', 1)
            jump a07
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('a06', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'a06', 2)
            jump a08
        "Dizer que achei por acaso." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('a06', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'a06', 3)
            jump a08

label a07:
    $ aa_node = 'a07'
    $ aa_location = '19h34 · Hall do apartamento'
    $ aa_audio_enter('a07')
    $ aa_stage_action = 'Vanessa interrompe a saída e olha para Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.08, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    $ aa_audio_event('a07', 'line', 0, phase=0)
    v "De quem você gostou?"
    $ aa_stage_action = 'Contracampo de Feka antes de dizer o nome.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.14, 0.74, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    $ aa_audio_event('a07', 'line', 1, phase=0)
    f "Yasmin. A gente estudou junto no ensino médio."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('a07', 'line', 2, phase=0)
        v "E você ia me levar sabendo que ela está lá?"
    if aa_matches(aa_state, {'knew': False}):
        $ aa_stage_action = 'A pergunta pede uma resposta suportável.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_hall_duvida'
        show screen aa_location_display
        $ aa_audio_event('a07', 'line', 3, phase=0)
        v "Mas você não gosta mais dela, né?"
    $ aa_stage_action = 'A distância entre ambos reaparece no plano aberto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_hall_conversa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_hall_conversa'
    show screen aa_location_display
    $ aa_audio_event('a07', 'line', 4, phase=0)
    "Eu quase disse que não havia motivo para ciúme. Ela ainda não tinha falado de ciúme."
    menu:
        "Admitir que ainda penso nela e deixar Vanessa decidir.":
            $ aa_audio_event('a07', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a07', 0)
            jump a09
        "Dizer que é passado e manter a reserva.":
            $ aa_audio_event('a07', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a07', 1)
            jump a08

label a09:
    $ aa_node = 'a09'
    $ aa_location = '19h38 · Hall do apartamento'
    $ aa_audio_enter('a09')
    $ aa_stage_action = 'Vanessa busca uma garantia antes de sair; bolsa nas mãos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('a09', 'line', 0, phase=0)
    v "Ainda pensa como?"
    $ aa_audio_event('a09', 'line', 1, phase=0)
    "Não respondi. O silêncio fez o serviço que eu estava adiando."
    $ aa_stage_action = 'Ela ainda deseja ir ao jantar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.08, 0.3, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('a09', 'line', 2, phase=0)
    v "Eu quero ir com você. Só não quero chegar lá e ficar sobrando."
    $ aa_audio_event('a09', 'line', 3, phase=0)
    v "E não pede foto se a gente estiver brigado. Eu vou acabar aceitando e depois vou odiar a foto."
    menu:
        "Ir, aceitando esse limite.":
            $ aa_audio_event('a09', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'a09', 0)
            $ aa_audio_event('a09', 'response', 0, 0)
            f "Tá. Sem foto."
            $ aa_audio_event('a09', 'response', 1, 0)
            v "Mas você ainda quer ir comigo?"
            $ aa_audio_event('a09', 'response', 2, 0)
            f "Quero."
            $ aa_audio_event('a09', 'response', 3, 0)
            "Era verdade que eu queria ir. Deixei a resposta inteira por conta dela."
            jump a08
        "Cancelar e encerrar o encontro sem pedir que ela me console.":
            $ aa_audio_event('a09', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'a09', 1)
            jump e00

label a08:
    $ aa_node = 'a08'
    $ aa_location = '19h48 · A caminho do restaurante'
    $ aa_audio_enter('a08')
    $ aa_stage_action = 'Ambos caminham; Vanessa puxa a manga do casaco.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    $ aa_audio_event('a08', 'line', 0, phase=0)
    "Na rua, Vanessa puxou a própria manga sobre a mão. Perguntei se estava com frio. Ela disse que não era nada."
    if aa_matches(aa_state, {'ambush': True}):
        $ aa_audio_event('a08', 'line', 1, phase=0)
        "A tela do meu celular continuava escura. Eu sabia tudo que precisava saber para fingir uma surpresa."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('a08', 'line', 2, phase=0)
        "Eu não sabia que Yasmin estaria lá. Isso me daria, mais tarde, uma frase verdadeira para colocar na frente de várias mentiras."
    $ aa_stage_action = 'A promessa sobre a aula acontece enquanto caminham.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_rua at aa_camera(1.06, 0.65, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_rua'
    show screen aa_location_display
    $ aa_audio_event('a08', 'line', 3, phase=0)
    v "Amanhã, se eu faltar na primeira aula, você pega a matéria?"
    $ aa_audio_event('a08', 'line', 4, phase=0)
    f "Pego."
    $ aa_audio_event('a08', 'line', 5, phase=0)
    "Ela perguntou se eu mandaria a matéria mesmo se não desse para ir à mudança. Falei que sim. Ela disse obrigada duas vezes."
    jump b00

label b00:
    $ aa_node = 'b00'
    $ aa_location = '20h10 · Entrada do restaurante'
    $ aa_audio_enter('b00')
    $ aa_stage_action = 'Reconhecimento: olhar de Feka, casal sentado, Vanessa ao lado.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    $ aa_audio_event('b00', 'line', 0, phase=0)
    "A primeira coisa que vi foi Joãozão. Depois a mão de Yasmin no braço dele. Achei essa ordem injusta."
    $ aa_stage_action = 'Feka volta a ouvir Vanessa e a recepção.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.08, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    $ aa_audio_event('b00', 'line', 1, phase=0)
    "Vanessa tirou o casaco e parou ao meu lado, com ele no braço. A recepcionista perguntou o nome da reserva. Eu disse meu nome baixo demais e precisei repetir."
    if aa_matches(aa_state, {'v_knows': True}):
        $ aa_audio_event('b00', 'line', 2, phase=0)
        v "É ela?"
    if aa_matches(aa_state, {'v_knows': False}):
        $ aa_audio_event('b00', 'line', 3, phase=0)
        v "Você conhece alguém?"
    menu:
        "Apresentar Vanessa como minha namorada.":
            $ aa_audio_event('b00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b00', 0)
            $ aa_audio_event('b00', 'response', 0, 0)
            f "Essa é a Vanessa, minha namorada."
            $ aa_audio_event('b00', 'response', 1, 0)
            "Ela se aproximou um pouco. Eu vi o sorriso chegar antes de ela cumprimentar Yasmin."
            jump b01
        "Dizer que são pessoas da época da escola.":
            $ aa_audio_event('b00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b00', 1)
            $ aa_audio_event('b00', 'response', 0, 1)
            f "É gente da escola. Conhecidos."
            $ aa_audio_event('b00', 'response', 1, 1)
            "Falei baixo. Vanessa ainda não tinha perguntado por que eu estava falando baixo."
            jump b01
        "Puxar Vanessa para perto antes que Yasmin olhe.":
            $ aa_audio_event('b00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b00', 2)
            $ aa_audio_event('b00', 'response', 0, 2)
            "Passei o braço pela cintura de Vanessa. Ela se acomodou perto de mim. Só depois acompanhou meu olhar até Yasmin."
            jump b01

label b01:
    $ aa_node = 'b01'
    $ aa_location = '20h14 · Salão'
    $ aa_audio_enter('b01')
    $ aa_stage_action = 'Joãozão continua sentado; Feka e Vanessa estão de pé.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.08, 0.73, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    $ aa_audio_event('b01', 'line', 0, phase=0)
    y "Feka. Você veio mesmo."
    $ aa_audio_event('b01', 'line', 1, phase=0)
    "Vanessa virou o rosto para mim. Eu senti um alívio absurdo: Yasmin tinha lembrado meu nome."
    $ aa_audio_event('b01', 'line', 2, phase=0)
    y "O restaurante. Eu mandei no grupo. Faz um tempo."
    $ aa_audio_event('b01', 'line', 3, phase=0)
    j "Boa noite."
    $ aa_stage_action = 'Joãozão não oferece a mão; mostrar o gesto interrompido.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_cumprimento at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_cumprimento'
    show screen aa_location_display
    $ aa_audio_event('b01', 'line', 4, phase=0)
    "Joãozão não levantou. Fui apertar uma mão que ele não tinha oferecido. Consertei o movimento mexendo na cadeira."
    $ aa_stage_action = 'Vanessa faz a própria apresentação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg_chegada at aa_camera(1.14, 0.38, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg_chegada'
    show screen aa_location_display
    $ aa_audio_event('b01', 'line', 5, phase=0)
    v "Vanessa."
    $ aa_audio_event('b01', 'line', 6, phase=0)
    y "Yasmin. Vocês se conhecem de onde?"
    $ aa_audio_event('b01', 'line', 7, phase=0)
    v "Da faculdade. Direito."
    $ aa_audio_event('b01', 'line', 8, phase=0)
    "Ela respondeu antes de eu descobrir uma forma de dizer aquilo que parecesse importante."
    menu:
        "Dizer que vamos deixar os dois jantarem.":
            $ aa_audio_event('b01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'b01', 0)
            jump p00
        "Sugerir que juntemos as mesas.":
            $ aa_audio_event('b01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'b01', 1)
            jump c00
        "Pedir um minuto com Yasmin antes de sentar.":
            $ aa_audio_event('b01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'b01', 2)
            jump t00

label p00:
    $ aa_node = 'p00'
    $ aa_location = '20h25 · Mesa junto ao vidro'
    $ aa_audio_enter('p00')
    $ aa_stage_action = 'Dois sentados. Feka vê o salão por trás de Vanessa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_menu_antes at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    $ aa_audio_event('p00', 'line', 0, phase=0)
    "Pedi uma mesa de onde dava para ver o salão. Vanessa sentou de costas para Yasmin. Eu podia ter escolhido o outro lado."
    if aa_matches(aa_state, {'source_truth': False}):
        $ aa_audio_event('p00', 'line', 1, phase=0)
        v "Então foi ela que indicou."
    if aa_matches(aa_state, {'source_truth': True}):
        $ aa_audio_event('p00', 'line', 2, phase=0)
        v "Você prefere sentar do outro lado? Eu troco."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio aberto entre os dois. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu'
    else:
        $ aa_stage_action = 'Cardápio aberto entre os dois.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_menu_antes at aa_camera(1.1, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_menu_antes'
    show screen aa_location_display
    $ aa_audio_event('p00', 'line', 3, phase=0)
    "Ela abriu o cardápio sem olhar os pratos. Eu conhecia o gesto: na aula, fazia isso quando queria que alguém terminasse logo."
    menu:
        "Pedir para trocar de cadeira e contar a origem da reserva.":
            $ aa_audio_event('p00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p00', 0)
            $ aa_stage_action = 'Troca efetiva dos lugares; manter até o fim desse diálogo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_menu at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_menu'
            $ aa_audio_event('p00', 'response', 0, 0)
            "Trocamos de cadeira. O vidro ficou atrás de mim."
            $ aa_audio_event('p00', 'response', 1, 0)
            f "Foi indicação dela. Eu peguei o nome no grupo e fiz a reserva."
            jump p01
        "Dizer que muita gente indica restaurante.":
            $ aa_audio_event('p00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p00', 1)
            $ aa_audio_event('p00', 'response', 0, 1)
            f "Muita gente indica restaurante. Não tem nada demais."
            $ aa_audio_event('p00', 'response', 1, 1)
            v "Eu tô falando de você. Por que escolheu justo esse?"
            jump p01
        "Fazer um elogio alto o suficiente para a outra mesa ouvir.":
            $ aa_audio_event('p00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p00', 2)
            $ aa_audio_event('p00', 'response', 0, 2)
            f "Você tá linda hoje."
            $ aa_audio_event('p00', 'response', 1, 2)
            v "Por que você tá falando alto?"
            jump p01

label p01:
    $ aa_node = 'p01'
    $ aa_location = '20h34 · Mesa junto ao vidro'
    $ aa_audio_enter('p01')
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    $ aa_audio_event('p01', 'line', 0, phase=0)
    "Vanessa fechou o cardápio e deixou as mãos em cima dele. Esperou que eu olhasse para ela."
    if aa_matches(aa_state, {'claimed_space': True}):
        $ aa_audio_event('p01', 'line', 1, phase=0)
        v "Você falou de dormir lá. Eu fiquei pensando se era sério."
    $ aa_audio_event('p01', 'line', 2, phase=0)
    v "Eu queria falar do apartamento. Eu quero morar lá. Só não queria que você parasse de ir me ver."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    $ aa_audio_event('p01', 'line', 3, phase=0)
    f "Você tá com medo de ficar sozinha lá?"
    $ aa_audio_event('p01', 'line', 4, phase=0)
    v "Tô. De chegar, fechar a porta e não ter ninguém pra contar como foi o dia."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_desvio_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_desvio_troca'
    else:
        $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_desvio_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_desvio_antes'
    show screen aa_location_display
    $ aa_audio_event('p01', 'line', 5, phase=0)
    "Eu podia perguntar da mudança. Fiquei esperando que ela me dissesse quanto espaço pretendia me dar."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    $ aa_audio_event('p01', 'line', 6, phase=0)
    v "Eu queria falar disso hoje."
    menu:
        "Pedir que conte o que mais a preocupa.":
            $ aa_audio_event('p01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p01', 0)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p01', 'response', 0, 0)
            f "O que mais te preocupa nessa mudança?"
            $ aa_audio_event('p01', 'response', 1, 0)
            v "Eu sei resolver as coisas. Tenho medo é de não fazer falta."
            $ aa_audio_event('p01', 'response', 2, 0)
            "Ela riu depois da frase. Eu não ri junto."
            jump p02
        "Prometer que ela nunca vai ficar sozinha.":
            $ aa_audio_event('p01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p01', 1)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p01', 'response', 0, 1)
            f "Você não vai ficar sozinha. Amanhã eu vou lá. Depois a gente combina os outros dias."
            $ aa_audio_event('p01', 'response', 1, 1)
            v "Você fala sério?"
            $ aa_audio_event('p01', 'response', 2, 1)
            "Assenti. Ela começou a falar dos horários em que eu poderia ir. Eu ainda não tinha pensado em nenhum."
            jump p02
        "Olhar o movimento no vidro enquanto ela fala.":
            $ aa_audio_event('p01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p01', 2)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_desvio_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_desvio_troca'
            else:
                $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_desvio_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_desvio_antes'
            $ aa_audio_event('p01', 'response', 0, 2)
            "Ela parou no meio de uma frase. Eu só percebi quando o silêncio durou."
            jump p02

label p02:
    $ aa_node = 'p02'
    $ aa_location = '20h45 · Mesa junto ao vidro'
    $ aa_audio_enter('p02')
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_desvio_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_desvio_troca'
    else:
        $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_desvio_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_desvio_antes'
    show screen aa_location_display
    $ aa_audio_event('p02', 'line', 0, phase=0)
    "Um movimento no salão me fez desviar os olhos outra vez. Vanessa tirou a mão do cardápio."
    $ aa_audio_event('p02', 'line', 1, phase=0)
    v "Você fica diferente quando olha pra lá."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_troca'
    else:
        $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_escuta_antes'
    show screen aa_location_display
    $ aa_audio_event('p02', 'line', 2, phase=0)
    f "Diferente como?"
    $ aa_audio_event('p02', 'line', 3, phase=0)
    v "Você fica esperando ela olhar. Eu tô bem aqui."
    if aa_matches(aa_state, {'seat_swapped': True}):
        $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção. · lugares trocados'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_desvio_troca at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_desvio_troca'
    else:
        $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg7_mesa_desvio_antes at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg7_mesa_desvio_antes'
    show screen aa_location_display
    $ aa_audio_event('p02', 'line', 4, phase=0)
    "Quis rir para tornar a frase pequena. Ela não estava brincando."
    menu:
        "Contar que insisti por anos, mesmo depois de ela dizer não.":
            $ aa_audio_event('p02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'p02', 0)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 0)
            f "Eu insisti. Não foi uma semana. Foram anos. Ela pediu que eu parasse."
            $ aa_audio_event('p02', 'response', 1, 0)
            v "E parou?"
            $ aa_audio_event('p02', 'response', 2, 0)
            "Fiquei olhando o copo. Ela esperou. Eu não respondi."
            jump i00
        "Chamar de uma paixão boba de escola.":
            $ aa_audio_event('p02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'p02', 1)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_troca'
            else:
                $ aa_stage_action = 'Cardápio fechado; Vanessa procura o olhar de Feka.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_escuta_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_escuta_antes'
            $ aa_audio_event('p02', 'response', 0, 1)
            v "Então me fala olhando pra mim."
            $ aa_audio_event('p02', 'response', 1, 1)
            "Olhei. Ela assentiu antes de eu repetir a explicação."
            jump i00
        "Dizer que Vanessa está procurando problema.":
            $ aa_audio_event('p02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'p02', 2)
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_desvio_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_desvio_troca'
            else:
                $ aa_stage_action = 'Ele volta a olhar o salão; ela percebe a interrupção.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_desvio_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_desvio_antes'
            $ aa_audio_event('p02', 'response', 0, 2)
            v "Eu não quero brigar."
            $ aa_audio_event('p02', 'response', 1, 2)
            "Ela abaixou a voz. A pergunta continuou sem resposta."
            jump i00

label c00:
    $ aa_node = 'c00'
    $ aa_location = '20h25 · Mesas aproximadas'
    $ aa_audio_enter('c00')
    $ aa_stage_action = 'Quatro sentados; mesas aproximadas, ainda sem pratos servidos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    $ aa_audio_event('c00', 'line', 0, phase=0)
    "Joãozão disse que os pratos deles já estavam chegando. Eu respondi que tudo bem, como se a objeção fosse logística."
    $ aa_audio_event('c00', 'line', 1, phase=0)
    y "Se a Vanessa quiser."
    $ aa_stage_action = 'Concordância com um sorriso tenso; quatro lugares preservados.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_quatro_sorriso at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_quatro_sorriso'
    show screen aa_location_display
    $ aa_audio_event('c00', 'line', 2, phase=0)
    v "Por mim tudo bem. Se vocês quiserem."
    $ aa_audio_event('c00', 'line', 3, phase=0)
    "Ela concordou. Eu me agarrei a isso antes que tivesse alguma coisa para justificar."
    $ aa_audio_event('c00', 'line', 4, phase=0)
    y "Vocês dois em Direito. Deve ser bom discutir e já vir com referência."
    $ aa_stage_action = 'Feka tenta parecer um bom namorado.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.1, 0.18, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    $ aa_audio_event('c00', 'line', 5, phase=0)
    f "Com ela eu nem discuto."
    $ aa_audio_event('c00', 'line', 6, phase=0)
    v "É porque você para de responder."
    $ aa_stage_action = 'O esforço para rir termina quando ele ri também.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    $ aa_audio_event('c00', 'line', 7, phase=0)
    "Yasmin riu. Vanessa tentou acompanhar. Quando eu ri também, ela olhou para o próprio copo."
    menu:
        "Admitir que a crítica de Vanessa é justa.":
            $ aa_audio_event('c00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c00', 0)
            $ aa_audio_event('c00', 'response', 0, 0)
            f "Eu faço isso mesmo. Desculpa."
            $ aa_audio_event('c00', 'response', 1, 0)
            v "Faz."
            jump c01
        "Explicar que ela está brincando.":
            $ aa_audio_event('c00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c00', 1)
            $ aa_audio_event('c00', 'response', 0, 1)
            v "Eu tava falando sério."
            $ aa_audio_event('c00', 'response', 1, 1)
            "Ela mexeu no guardanapo."
            $ aa_audio_event('c00', 'response', 2, 1)
            v "Mas a gente conversa depois."
            jump c01
        "Puxar uma lembrança minha com Yasmin.":
            $ aa_audio_event('c00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c00', 2)
            $ aa_audio_event('c00', 'response', 0, 2)
            f "Lembra daquela festa depois da prova?"
            $ aa_audio_event('c00', 'response', 1, 2)
            y "Você lembra mais dessas coisas do que eu."
            jump c01

label c01:
    $ aa_node = 'c01'
    $ aa_location = '20h38 · Mesa dos quatro'
    $ aa_audio_enter('c01')
    $ aa_stage_action = 'Yasmin dirige a lembrança a Vanessa, não à câmera.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.08, 0.48, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    $ aa_audio_event('c01', 'line', 0, phase=0)
    y "Ele era assim na escola. Você chegava num lugar e ele já tava lá."
    $ aa_audio_event('c01', 'line', 1, phase=0)
    "Ela falou para Vanessa. Tinha um sorriso. Eu não consegui saber se era maldade ou só facilidade. O efeito era o mesmo."
    $ aa_stage_action = 'Vanessa recebe a informação em público.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.1, 0.77, 0.37)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    $ aa_audio_event('c01', 'line', 2, phase=0)
    v "Ele devia ter os amigos dele lá também... não?"
    $ aa_stage_action = 'Joãozão oferece uma saída para o assunto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.1, 0.7, 0.23)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    $ aa_audio_event('c01', 'line', 3, phase=0)
    j "Melhor mudar de assunto."
    $ aa_audio_event('c01', 'line', 4, phase=0)
    "Joãozão me ofereceu uma saída. Tive vontade de odiá-lo ainda mais."
    menu:
        "Dizer que não era uma coincidência e assumir a insistência.":
            $ aa_audio_event('c01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c01', 0)
            $ aa_audio_event('c01', 'response', 0, 0)
            f "Eu ia porque ela ia. Não era por acaso."
            $ aa_audio_event('c01', 'response', 1, 0)
            v "Ah."
            $ aa_audio_event('c01', 'response', 2, 0)
            "Vanessa parou de tentar me ajudar."
            jump c02
        "Pedir a Yasmin que pare de fazer disso uma piada.":
            $ aa_audio_event('c01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c01', 1)
            $ aa_audio_event('c01', 'response', 0, 1)
            f "Não faz piada disso com ela."
            $ aa_audio_event('c01', 'response', 1, 1)
            "Eu também queria que Yasmin parasse de falar. As duas vontades cabiam na mesma frase."
            jump c02
        "Dizer que Yasmin gostava da atenção.":
            $ aa_audio_event('c01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c01', 2)
            $ aa_stage_action = 'Ele acusa; o enquadramento fecha sobre a reação de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_quatro at aa_camera(1.15, 0.77, 0.35)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_quatro'
            $ aa_audio_event('c01', 'response', 0, 2)
            f "Você também gostava. Nunca foi só comigo."
            $ aa_audio_event('c01', 'response', 1, 2)
            "Minha voz saiu mais alta no fim. Vanessa tirou a mão da mesa."
            $ aa_audio_event('c01', 'response', 2, 2)
            y "Eu gostava de poder sair da aula sem explicar para onde ia."
            jump c02

label c02:
    $ aa_node = 'c02'
    $ aa_location = '20h49 · Mesa dos quatro'
    $ aa_audio_enter('c02')
    $ aa_stage_action = 'A piada termina antes da chegada da comida.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_quatro at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_quatro'
    show screen aa_location_display
    if aa_matches(aa_state, {'stopped_joke': True}):
        $ aa_audio_event('c02', 'line', 0, phase=0)
        y "Tá. Não foi uma boa piada."
    $ aa_stage_action = 'Pratos servidos ocupam o espaço dos cotovelos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pratos'
    show screen aa_location_display
    $ aa_audio_event('c02', 'line', 1, phase=0)
    "O garçom colocou os pratos. Ninguém tinha espaço para os cotovelos. Eu disse que a mesa estava ótima."
    $ aa_audio_event('c02', 'line', 2, phase=0)
    v "A gente pode só comer um pouco?"
    $ aa_stage_action = 'O celular fica junto ao prato; ainda não há fotografia.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_pratos at aa_camera(1.06, 0.35, 0.55)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pratos'
    show screen aa_location_display
    $ aa_audio_event('c02', 'line', 3, phase=0)
    "Meu celular estava ao lado do prato. Uma foto poderia registrar quatro pessoas jantando. Não registraria o que cada uma estava aguentando."
    menu:
        "Pedir uma foto, se todos quiserem.":
            $ aa_audio_event('c02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c02', 0)
            jump c03
        "Guardar o celular e voltar a comer.":
            $ aa_audio_event('c02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c02', 1)
            $ aa_audio_event('c02', 'response', 0, 1)
            "Deixei o celular no bolso. A comida tinha esfriado enquanto eu tentava parecer à vontade."
            jump i00
        "Oferecer pagar a mesa inteira para mudar o clima.":
            $ aa_audio_event('c02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'c02', 2)
            $ aa_audio_event('c02', 'response', 0, 2)
            j "Não precisa. A nossa conta a gente paga."
            $ aa_audio_event('c02', 'response', 1, 2)
            "Ficou só a promessa que eu tinha feito para Vanessa. Ainda era mais do que eu podia."
            jump i00

label c03:
    $ aa_node = 'c03'
    $ aa_location = '20h52 · Mesa dos quatro'
    $ aa_audio_enter('c03')
    $ aa_stage_action = 'Celular ainda guardado; a fotografia depende da resposta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_pratos'
    show screen aa_location_display
    if aa_matches(aa_state, {'no_photo': True}):
        $ aa_audio_event('c03', 'line', 0, phase=0)
        v "Eu já disse que não."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        $ aa_audio_event('c03', 'line', 1, phase=0)
        v "Uma só. Me mostra antes de postar."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'gte': 2}}):
        $ aa_stage_action = 'Só exibir a fotografia no ramo em que Vanessa aceita.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'foto'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('foto')
        $ aa_last_art = 'cg2_pratos'
        show screen aa_location_display
        $ aa_audio_event('c03', 'line', 2, phase=0)
        "Vanessa aceitou. Joãozão fez a foto. Yasmin olhou para a lente durante menos de um segundo. Eu quis que aquilo provasse alguma coisa."
    if aa_matches(aa_state, {'no_photo': False, 'trust': {'lte': 1}}):
        $ aa_stage_action = 'A foto aceita com pouca confiança também acontece.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'foto_hesita'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('foto_hesita')
        $ aa_last_art = 'cg2_pratos'
        show screen aa_location_display
        $ aa_audio_event('c03', 'line', 3, phase=0)
        "Joãozão segurou meu celular. Vanessa se inclinou para caber na foto. Sorriu até ele baixar o aparelho."
    menu:
        "Aceitar a resposta sem insistir.":
            $ aa_audio_event('c03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'c03', 0)
            $ aa_stage_action = 'Telefone guardado, independentemente de terem feito a foto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_pratos'
            $ aa_audio_event('c03', 'response', 0, 0)
            "Guardei o celular. Deixei a resposta como estava."
            jump i00
        "Cobrar de todos um esforço para melhorar a noite.":
            $ aa_audio_event('c03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'c03', 1)
            $ aa_audio_event('c03', 'response', 0, 1)
            v "Esforço pra quê, Feka? A gente tá comendo."
            jump i00

label t00:
    $ aa_node = 't00'
    $ aa_location = '20h24 · Porta da varanda'
    $ aa_audio_enter('t00')
    $ aa_stage_action = 'Yasmin segura a bolsa dentro da porta; distância física explícita.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    $ aa_audio_event('t00', 'line', 0, phase=0)
    y "Eu só vim pegar minha bolsa. Fala daqui."
    $ aa_audio_event('t00', 'line', 1, phase=0)
    "Yasmin ficou do lado de dentro. Vanessa tinha sentado à mesa, com o casaco no colo."
    $ aa_audio_event('t00', 'line', 2, phase=0)
    f "Você tá bem?"
    $ aa_audio_event('t00', 'line', 3, phase=0)
    y "Tava jantando."
    $ aa_audio_event('t00', 'line', 4, phase=0)
    "Eu esperei que ela perguntasse de mim. Ela segurou a bolsa com as duas mãos."
    $ aa_stage_action = 'A recusa pertence a Yasmin.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.13, 0.28, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    $ aa_audio_event('t00', 'line', 5, phase=0)
    y "Feka, eu não quero ficar com você. Isso não mudou. E você tá aqui com uma pessoa."
    menu:
        "Dizer que entendi e voltar para Vanessa.":
            $ aa_audio_event('t00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't00', 0)
            jump t01
        "Perguntar se ela falaria isso se Joãozão não estivesse ali.":
            $ aa_audio_event('t00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't00', 1)
            jump t01
        "Dizer que ela não precisava me humilhar.":
            $ aa_audio_event('t00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't00', 2)
            jump t01

label t01:
    $ aa_node = 't01'
    $ aa_location = '20h28 · Porta da varanda'
    $ aa_audio_enter('t01')
    $ aa_stage_action = 'Yasmin conclui a resposta antes de Joãozão entrar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    if aa_matches(aa_state, {'insisted': True}):
        $ aa_audio_event('t01', 'line', 0, phase=0)
        y "Eu falei antes de namorar ele. Você lembra."
    if aa_matches(aa_state, {'stopped_joke': True}):
        $ aa_audio_event('t01', 'line', 1, phase=0)
        y "Eu posso ter sido escrota. Isso não muda a resposta."
    $ aa_stage_action = 'Joãozão entra só agora; Yasmin continua no próprio lugar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite_joao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite_joao'
    show screen aa_location_display
    $ aa_audio_event('t01', 'line', 2, phase=0)
    j "Tá acontecendo alguma coisa?"
    $ aa_audio_event('t01', 'line', 3, phase=0)
    "O corpo de Joãozão ocupou o espaço que eu estava usando para imaginar uma conversa diferente."
    $ aa_stage_action = 'Yasmin interrompe a tentativa de falar por ela.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite_joao at aa_camera(1.1, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite_joao'
    show screen aa_location_display
    $ aa_audio_event('t01', 'line', 4, phase=0)
    y "Já respondi. Eu mesma."
    menu:
        "Sair do caminho e voltar à mesa.":
            $ aa_audio_event('t01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't01', 0)
            jump t02
        "Dizer a Joãozão que ele não manda em mim.":
            $ aa_audio_event('t01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't01', 1)
            $ aa_audio_event('t01', 'response', 0, 1)
            j "Eu perguntei se estava acontecendo alguma coisa."
            $ aa_audio_event('t01', 'response', 1, 1)
            "Ele não tinha precisado levantar a voz para eu perceber a minha."
            jump t02
        "Pedir que ele deixe Yasmin terminar de falar.":
            $ aa_audio_event('t01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't01', 2)
            $ aa_audio_event('t01', 'response', 0, 2)
            y "Eu já terminei. Agora quero voltar."
            jump t02

label t02:
    $ aa_node = 't02'
    $ aa_location = '20h33 · Mesa de Vanessa'
    $ aa_audio_enter('t02')
    $ aa_stage_action = 'Vanessa sentada; meio copo e casaco na cadeira de Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    $ aa_audio_event('t02', 'line', 0, phase=0)
    "O copo de Vanessa estava pela metade. Ela tinha dobrado o casaco sobre a cadeira que eu devia estar usando."
    $ aa_stage_action = 'Reprovação sentada; não substituir por retrato de pé.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_espera at aa_camera(1.1, 0.62, 0.33)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_espera'
    show screen aa_location_display
    $ aa_audio_event('t02', 'line', 1, phase=0)
    v "Achei que você não ia voltar. Vamos pedir? Eu esperei você."
    $ aa_audio_event('t02', 'line', 2, phase=0)
    "Eu procurei uma resposta engraçada. Todas pioravam a pergunta."
    $ aa_stage_action = 'Feka senta; casaco devolvido à cadeira dela, cardápio fechado.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_mesa_escuta_troca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_mesa_escuta_troca'
    show screen aa_location_display
    $ aa_audio_event('t02', 'line', 3, phase=0)
    "Devolvi o casaco à cadeira dela e sentei. Vanessa sorriu, depois perguntou o que tinha demorado tanto."
    menu:
        "Pedir desculpa pelo tempo e contar o que fui fazer.":
            $ aa_audio_event('t02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 't02', 0)
            jump i00
        "Dizer que foi só uma conversa de escola.":
            $ aa_audio_event('t02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 't02', 1)
            jump i00
        "Reclamar que Joãozão é agressivo.":
            $ aa_audio_event('t02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 't02', 2)
            jump i00

label i00:
    $ aa_node = 'i00'
    $ aa_location = '21h02 · Entre os pratos'
    $ aa_audio_enter('i00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '20h56 · Mesa'
        $ aa_stage_action = 'Os quatro comem antes do intervalo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_pratos'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h56 · Mesa'
            $ aa_stage_action = 'Feka sentou na cadeira que Vanessa guardou.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg7_mesa_pratos_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h56 · Mesa'
                $ aa_stage_action = 'Comem antes do intervalo. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_troca'
            else:
                $ aa_location = '20h56 · Mesa'
                $ aa_stage_action = 'Comem antes do intervalo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_antes'
    show screen aa_location_display
    $ aa_audio_event('i00', 'line', 0, phase=0)
    "Terminamos de comer quase sem conversar. Eu ainda procurava uma forma de encerrar o assunto."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '20h56 · Mesa'
        $ aa_stage_action = 'Os quatro comem antes do intervalo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_pratos at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_pratos'
    else:
        if aa_matches(aa_state, {'route': 'varanda'}):
            $ aa_location = '20h56 · Mesa'
            $ aa_stage_action = 'Feka sentou na cadeira que Vanessa guardou.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg7_mesa_pratos_troca'
        else:
            if aa_matches(aa_state, {'seat_swapped': True}):
                $ aa_location = '20h56 · Mesa'
                $ aa_stage_action = 'Comem antes do intervalo. · lugares trocados'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_troca at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_troca'
            else:
                $ aa_location = '20h56 · Mesa'
                $ aa_stage_action = 'Comem antes do intervalo.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg7_mesa_pratos_antes at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg7_mesa_pratos_antes'
    show screen aa_location_display
    $ aa_audio_event('i00', 'line', 1, phase=0)
    "Vanessa cortava pedaços pequenos. Eu esperava ela pegar o copo para olhar o salão."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_location = '21h02 · Entre os pratos'
        $ aa_stage_action = 'Pratos recolhidos; dois lugares vazios mostram a ausência temporária do casal.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_intervalo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_intervalo'
    else:
        $ aa_location = '21h02 · Entre os pratos'
        $ aa_stage_action = 'Vanessa procura na bolsa; o intervalo começa na mesa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_papel at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_papel'
    show screen aa_location_display
    $ aa_audio_event('i00', 'line', 2, phase=0)
    "Quando recolheram os pratos, apareceu um intervalo pequeno. Vanessa procurou alguma coisa na bolsa. Yasmin foi até a porta da varanda. Joãozão ficou perto do balcão."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_intervalo at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_intervalo'
    else:
        $ aa_stage_action = 'Feka precisa escolher quem acompanhar; Vanessa permanece à mesa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_papel at aa_camera(1.07, 0.5, 0.43)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_papel'
    show screen aa_location_display
    $ aa_audio_event('i00', 'line', 3, phase=0)
    "Eu podia escolher para onde ir. Não podia estar nos três lugares. Pela primeira vez naquela noite, isso pareceu um problema meu."
    $ aa_audio_event('i00', 'line', 4, phase=0)
    v "Você vai levantar agora?"
    $ aa_audio_event('i00', 'line', 5, phase=0)
    "Ela abriu a bolsa. Disse que eu podia ir, se precisasse."
    menu:
        "Ficar com Vanessa.":
            $ aa_audio_event('i00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'i00', 0)
            jump iv
        "Conversar com Joãozão, sem plateia.":
            $ aa_audio_event('i00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'i00', 1)
            jump ij
        "Procurar Yasmin no corredor.":
            $ aa_audio_event('i00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'i00', 2)
            jump iy

label iv:
    $ aa_node = 'iv'
    $ aa_location = '21h06 · Mesa'
    $ aa_audio_enter('iv')
    $ aa_stage_action = 'Vanessa levanta os olhos do papel e pergunta sobre amanhã.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_papel_espera'
    show screen aa_location_display
    $ aa_audio_event('iv', 'line', 0, phase=0)
    "Era um papel dobrado com medidas de móveis. Eu estava esperando que fosse alguma prova contra mim. Vanessa estava tentando ver se a cama cabia."
    $ aa_stage_action = 'Ela busca a confirmação da visita.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg5_papel_espera at aa_camera(1.07, 0.52, 0.38)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_papel_espera'
    show screen aa_location_display
    $ aa_audio_event('iv', 'line', 1, phase=0)
    v "Você vai lá amanhã?"
    $ aa_audio_event('iv', 'line', 2, phase=0)
    f "Na mudança?"
    $ aa_audio_event('iv', 'line', 3, phase=0)
    v "É. Minha mãe vai cedo. Depois ela vai embora."
    $ aa_stage_action = 'Ela dobra e guarda o papel antes da escolha.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_papel_guardado at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_papel_guardado'
    show screen aa_location_display
    $ aa_audio_event('iv', 'line', 4, phase=0)
    "Ela guardou o papel antes de eu responder. Disse que, se não desse, tudo bem. Eu ainda não tinha dito que não dava."
    menu:
        "Perguntar o que ela queria desta noite e ouvir.":
            $ aa_audio_event('iv', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'iv', 0)
            $ aa_audio_event('iv', 'response', 0, 0)
            v "Eu queria comer com você. Contar do apartamento. Hoje parece que eu preciso acertar tudo que falo pra você ficar."
            jump r00
        "Dizer que eu também estou tendo uma noite difícil.":
            $ aa_audio_event('iv', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'iv', 1)
            $ aa_audio_event('iv', 'response', 0, 1)
            v "Eu sei."
            $ aa_audio_event('iv', 'response', 1, 1)
            "Ela começou a perguntar o que tinha acontecido com Yasmin. Parou."
            $ aa_audio_event('iv', 'response', 2, 1)
            v "Mas eu também tô aqui."
            jump r00
        "Prometer levar as coisas dela na mudança.":
            $ aa_audio_event('iv', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'iv', 2)
            $ aa_stage_action = 'O papel volta às mãos quando ele promete ir.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_papel_espera at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_papel_espera'
            $ aa_audio_event('iv', 'response', 0, 2)
            v "Vai mesmo? Posso esperar você depois da aula?"
            $ aa_audio_event('iv', 'response', 1, 2)
            f "Pode."
            $ aa_audio_event('iv', 'response', 2, 2)
            "Ela tirou o papel da bolsa outra vez. Eu tinha encontrado um jeito de mudar o assunto."
            jump r00

label ij:
    $ aa_node = 'ij'
    $ aa_location = '21h06 · Balcão'
    $ aa_audio_enter('ij')
    $ aa_stage_action = 'Dois homens de pé, mãos abertas; sem plateia.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    $ aa_audio_event('ij', 'line', 0, phase=0)
    j "Eu não quero ficar vigiando vocês. É um negócio ridículo."
    $ aa_audio_event('ij', 'line', 1, phase=0)
    f "Então não fica."
    $ aa_stage_action = 'Joãozão responde à provocação sem avançar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.12, 0.74, 0.31)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    $ aa_audio_event('ij', 'line', 2, phase=0)
    j "Ela já pediu pra você parar. E você vem falar comigo. Quer que eu faça o quê?"
    $ aa_audio_event('ij', 'line', 3, phase=0)
    "Eu tinha preparado uma fala sobre ciúme. Ela não servia para responder àquilo."
    $ aa_stage_action = 'A referência a Vanessa faz o plano voltar aos dois.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    $ aa_audio_event('ij', 'line', 4, phase=0)
    j "E a Vanessa tá sentada lá, cara."
    menu:
        "Admitir minha insistência e pedir que não faça uma cena.":
            $ aa_audio_event('ij', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'ij', 0)
            $ aa_audio_event('ij', 'response', 0, 0)
            j "Então escuta quando ela pede. Não precisa vir explicar pra mim."
            jump r00
        "Dizer que Yasmin sabe responder por ela.":
            $ aa_audio_event('ij', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'ij', 1)
            $ aa_audio_event('ij', 'response', 0, 1)
            j "Sabe. E já respondeu. Você sabe disso melhor do que eu."
            jump r00
        "Chamar Joãozão de inseguro alto o suficiente para ela ouvir.":
            $ aa_audio_event('ij', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'ij', 2)
            $ aa_audio_event('ij', 'response', 0, 2)
            "Yasmin olhou. Era o que eu queria. Dei um passo para trás antes de Joãozão se mexer."
            jump r00

label iy:
    $ aa_node = 'iy'
    $ aa_location = '21h06 · Corredor'
    $ aa_audio_enter('iy')
    $ aa_stage_action = 'Feka procura a mesma pessoa no mesmo corredor outra vez.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.07, 0.3, 0.32)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    $ aa_audio_event('iy', 'line', 0, phase=0)
    y "Você deixou sua namorada na mesa."
    $ aa_audio_event('iy', 'line', 1, phase=0)
    "Não consegui dizer que era só um minuto. Yasmin já conhecia a duração dos meus minutos."
    $ aa_audio_event('iy', 'line', 2, phase=0)
    f "Você me acha uma pessoa tão ruim assim?"
    $ aa_stage_action = 'A segunda recusa tem menos espaço para negociação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_limite at aa_camera(1.17, 0.28, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_limite'
    show screen aa_location_display
    $ aa_audio_event('iy', 'line', 3, phase=0)
    y "Eu não quero ter que te avaliar para poder jantar."
    $ aa_audio_event('iy', 'line', 4, phase=0)
    "Essa resposta eu não podia transformar em quase. Ela nem estava falando de amor."
    menu:
        "Parar de pedir uma resposta diferente.":
            $ aa_audio_event('iy', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'iy', 0)
            $ aa_audio_event('iy', 'response', 0, 0)
            f "Tá. Eu vou voltar."
            $ aa_audio_event('iy', 'response', 1, 0)
            y "Volta."
            jump r00
        "Pedir só que ela admita que já me deu esperança.":
            $ aa_audio_event('iy', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'iy', 1)
            $ aa_audio_event('iy', 'response', 0, 1)
            y "Eu preciso pedir desculpa por você ter entendido o que quis?"
            jump r00
        "Dizer que estou com Vanessa e não preciso dela.":
            $ aa_audio_event('iy', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'iy', 2)
            $ aa_audio_event('iy', 'response', 0, 2)
            y "Então por que você tá aqui falando comigo?"
            $ aa_audio_event('iy', 'response', 1, 2)
            "Eu não tinha uma resposta que não incluísse a cadeira vazia de Vanessa."
            jump r00

label r00:
    $ aa_node = 'r00'
    $ aa_location = '21h18 · A mesa de Vanessa'
    $ aa_audio_enter('r00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pudim chega perto de Vanessa; as cadeiras centrais ainda estão vazias.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_privado at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_privado'
    else:
        $ aa_stage_action = 'Pudim e duas colheres chegam sem Vanessa ter pedido.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa'
    show screen aa_location_display
    $ aa_audio_event('r00', 'line', 0, phase=0)
    "O garçom levou meu copo vazio e deixou o pudim com duas colheres. Vanessa não tinha dito que queria sobremesa. Eu queria conseguir chegar à sobremesa."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pudim afastado, dois lugares ainda vazios.'
        $ aa_table_party = 2
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_dois'
    else:
        $ aa_stage_action = 'Vanessa afasta o pudim: o gesto antecede a pergunta.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    $ aa_audio_event('r00', 'line', 1, phase=0)
    "Vanessa afastou o prato. Não levantou a voz. Eu precisei me inclinar para ouvir."
    if aa_matches(aa_state, {'presence_told': False}):
        $ aa_audio_event('r00', 'line', 2, phase=0)
        v "Você sabia que ela estaria aqui?"
    if aa_matches(aa_state, {'presence_told': True}):
        $ aa_audio_event('r00', 'line', 3, phase=0)
        v "Você me disse que ela estaria aqui. Eu quero entender por que quis vir mesmo assim."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r00', 'line', 4, phase=0)
        "Eu sabia. Vi no quarto, enquanto ela procurava o brinco."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r00', 'line', 5, phase=0)
        "Não sabia. Percebi o quanto queria usar essa resposta para encerrar todo o resto."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Yasmin e Joãozão retornam aos próprios lugares, antes da resposta.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_quatro'
        show screen aa_location_display
        $ aa_audio_event('r00', 'line', 6, phase=0)
        "Yasmin e Joãozão voltaram aos lugares que tinham deixado. Comecei a responder por cima do barulho das cadeiras. Vanessa esperou que os dois sentassem."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r00', 'line', 7, phase=0)
        v "Fala baixo. Eu tô ouvindo."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_stage_action = 'Na rota separada, o casal volta à própria mesa fora do close.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa_afastada'
        show screen aa_location_display
        $ aa_audio_event('r00', 'line', 8, phase=0)
        "Yasmin e Joãozão voltaram para a outra mesa. Vanessa esperou que eu parasse de acompanhar os dois com os olhos."
    menu:
        "Admitir que vi a publicação e quis encontrá-la." if aa_matches(aa_state, {'knew': True}):
            $ aa_audio_event('r00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r00', 0)
            jump r01
        "Dizer que não sabia, mas escolhi o lugar por causa dela." if aa_matches(aa_state, {'knew': False}):
            $ aa_audio_event('r00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r00', 1)
            jump r01
        "Falar só da indicação e esconder o que vi no celular." if aa_matches(aa_state, {'knew': True, 'presence_told': False}):
            $ aa_audio_event('r00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r00', 2)
            jump r02
        "Repetir que foi coincidência e que Vanessa está exagerando.":
            $ aa_audio_event('r00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'r00', 3)
            jump r02

label r01:
    $ aa_node = 'r01'
    $ aa_location = '21h22 · Mesa'
    $ aa_audio_enter('r01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r01', 'line', 0, phase=0)
        v "Você me viu passando maquiagem e sabia?"
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r01', 'line', 1, phase=0)
        v "E eu agradecendo por você ter pensado em mim."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r01', 'line', 2, phase=0)
    "Ela olhou para as mãos. Eu achei que fosse chorar e senti uma vontade horrível de que chorasse. Uma pessoa chorando ainda pode aceitar um abraço."
    $ aa_audio_event('r01', 'line', 3, phase=0)
    v "Mas você queria sair comigo também?"
    menu:
        "Admitir que fiquei com ela para não me sentir sozinho.":
            $ aa_audio_event('r01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r01', 0)
            jump r03
        "Dizer que gosto dela, mas estou confuso.":
            $ aa_audio_event('r01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r01', 1)
            jump r02
        "Pedir que ela veja quanto Yasmin me machucou.":
            $ aa_audio_event('r01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r01', 2)
            jump r04

label r02:
    $ aa_node = 'r02'
    $ aa_location = '21h25 · Mesa'
    $ aa_audio_enter('r02')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r02', 'line', 0, phase=0)
    v "Eu tento acreditar. Aí você olha pra lá de novo."
    $ aa_audio_event('r02', 'line', 1, phase=0)
    v "Se eu parar de perguntar, você fica aqui comigo até a gente ir embora?"
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r02', 'line', 2, phase=0)
    "Ela continuava sentada. Parecia esperar um sim. Eu ainda estava escolhendo a parte da pergunta que podia responder."
    menu:
        "Parar de reduzir o problema e contar tudo.":
            $ aa_audio_event('r02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r02', 0)
            jump r03
        "Pedir para terminar o jantar sem falar nisso.":
            $ aa_audio_event('r02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r02', 1)
            $ aa_audio_event('r02', 'response', 0, 1)
            v "Tá. Mas não levanta de novo sem falar comigo."
            $ aa_audio_event('r02', 'response', 1, 1)
            "Ela não disse que acreditava em mim. Eu aceitei como se tivesse dito."
            jump v00
        "Dizer que ela aceitou vir e também fez suas escolhas.":
            $ aa_audio_event('r02', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r02', 2)
            jump r05

label r04:
    $ aa_node = 'r04'
    $ aa_location = '21h26 · Mesa'
    $ aa_audio_enter('r04')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r04', 'line', 0, phase=0)
    f "Você não entende o que foram esses anos."
    if aa_matches(aa_state, {'past_told': False}):
        $ aa_audio_event('r04', 'line', 1, phase=0)
        v "Você não me contou o que aconteceu nesses anos. Eu tô tentando entender."
    if aa_matches(aa_state, {'past_told': True}):
        $ aa_audio_event('r04', 'line', 2, phase=0)
        v "Eu lembro do que você contou. Eu tentei te ajudar."
    $ aa_audio_event('r04', 'line', 3, phase=0)
    f "Eu sofri muito."
    $ aa_audio_event('r04', 'line', 4, phase=0)
    v "Eu posso ouvir. Só... você quer ficar comigo ou quer que eu te ajude com ela?"
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r04', 'line', 5, phase=0)
    "Ela tinha baixado a voz para me acalmar. Percebi que eu podia continuar falando dos meus anos ruins e adiar a resposta."
    menu:
        "Admitir o que fiz sem pedir pena.":
            $ aa_audio_event('r04', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r04', 0)
            jump r03
        "Dizer que estou sozinho até quando estou com ela.":
            $ aa_audio_event('r04', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r04', 1)
            jump r05
        "Ficar calado, esperando que ela pare de perguntar.":
            $ aa_audio_event('r04', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r04', 2)
            $ aa_audio_event('r04', 'response', 0, 2)
            "Ela virou o rosto para a janela. Não insisti. Esperei que o silêncio fizesse por mim o que minhas frases não conseguiam."
            jump v00

label r03:
    $ aa_node = 'r03'
    $ aa_location = '21h29 · Mesa'
    $ aa_audio_enter('r03')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r03', 'line', 0, phase=0)
    f "Eu não queria ficar sozinho. Você gostava de estar comigo e eu deixei você achar que era igual."
    if aa_matches(aa_state, {'knew': True}):
        $ aa_audio_event('r03', 'line', 1, phase=0)
        f "Eu vi que ela estava aqui antes de a gente sair."
    if aa_matches(aa_state, {'knew': False}):
        $ aa_audio_event('r03', 'line', 2, phase=0)
        f "Eu não sabia que ia encontrar ela. Mas o lugar tinha a ver com ela desde o começo."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'A pergunta continua sem resposta; mesa e elenco preservados.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r03', 'line', 3, phase=0)
    v "Mas você gostou de ficar comigo depois?"
    $ aa_audio_event('r03', 'line', 4, phase=0)
    "Olhei para o prato. Ela disse que não precisava ter sido desde o começo. Eu podia dizer que gostava. Ela tinha deixado a resposta pronta para mim."
    menu:
        "Pedir uma chance e prometer esquecer Yasmin.":
            $ aa_audio_event('r03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r03', 0)
            jump r06
        "Ouvir o que Vanessa quer fazer, sem negociar a resposta.":
            $ aa_audio_event('r03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r03', 1)
            jump r06
        "Dizer que contei a verdade e mereço algum crédito.":
            $ aa_audio_event('r03', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r03', 2)
            jump r05

label r06:
    $ aa_node = 'r06'
    $ aa_location = '21h33 · Mesa'
    $ aa_audio_enter('r06')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_quatro'
    else:
        $ aa_stage_action = 'Ela responde antes da tentativa de toque.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    if aa_matches(aa_state, {'bargain': True}):
        $ aa_audio_event('r06', 'line', 0, phase=0)
        v "Se você quer continuar, por que fala como se eu tivesse que te convencer?"
    $ aa_audio_event('r06', 'line', 1, phase=0)
    v "Eu gosto de você. Tô tentando entender o que eu faço com isso agora."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_mao_corrigida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_mao_corrigida'
    else:
        $ aa_stage_action = 'A mão de Feka avança; Vanessa estabelece o limite.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_mao at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_mao'
    show screen aa_location_display
    $ aa_audio_event('r06', 'line', 2, phase=0)
    v "Não encosta em mim agora."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_quatro at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_quatro'
    else:
        $ aa_stage_action = 'A mão recua. Não permanecer no gesto proibido.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    $ aa_audio_event('r06', 'line', 3, phase=0)
    "Minha mão já estava indo. Recolhi antes de chegar à dela."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('r06', 'line', 4, phase=0)
        "Yasmin baixou os olhos. Joãozão continuou olhando para a recepção. Eu não sabia quanto tinham ouvido."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('r06', 'line', 5, phase=0)
        "Ninguém na outra mesa teria percebido a diferença."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Depois de recusar o toque, Vanessa explica que o limite é de agora.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r06', 'line', 6, phase=0)
    v "Não tô dizendo que nunca mais. Eu só não consigo agora."
    $ aa_audio_event('r06', 'line', 7, phase=0)
    "Ela se apressou em explicar o limite. Eu podia respeitar sem fazê-la pedir desculpa por ele."
    menu:
        "Respeitar e chamar a conta.":
            $ aa_audio_event('r06', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r06', 0)
            jump v00
        "Dizer que ela não pode me deixar assim depois de eu me abrir.":
            $ aa_audio_event('r06', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r06', 1)
            jump r05
        "Pedir desculpa diante dos outros para mostrar que é sério.":
            $ aa_audio_event('r06', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r06', 2)
            jump r07

label r07:
    $ aa_node = 'r07'
    $ aa_location = '21h37 · Salão'
    $ aa_audio_enter('r07')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_publico'
    else:
        $ aa_stage_action = 'Feka se levanta; Vanessa permanece sentada e exposta.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_publico_dois at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    $ aa_audio_event('r07', 'line', 0, phase=0)
    "Levantei a voz antes de levantar da cadeira. Contei que estava errado. Eu disse o nome de Vanessa duas vezes."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_publico at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_publico'
    else:
        $ aa_stage_action = 'Vanessa pede que pare; ela não se levanta com ele.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_publico_dois at aa_camera(1.12, 0.74, 0.35)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_publico_dois'
    show screen aa_location_display
    $ aa_audio_event('r07', 'line', 1, phase=0)
    v "Não faz isso comigo."
    $ aa_audio_event('r07', 'line', 2, phase=0)
    "Yasmin parou de mexer no copo. Joãozão olhou para a recepção. Todo mundo estava prestando atenção em mim. Era uma sensação boa demais para ser uma desculpa limpa."
    $ aa_audio_event('r07', 'line', 3, phase=0)
    v "Senta, por favor. Fala comigo."
    $ aa_audio_event('r07', 'line', 4, phase=0)
    "Ouvir meu pedido em voz alta parecia ter importado. Ela ainda queria que eu parasse."
    menu:
        "Parar quando Vanessa pede e voltar a sentar.":
            $ aa_audio_event('r07', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r07', 0)
            jump v00
        "Continuar até todos entenderem meu lado.":
            $ aa_audio_event('r07', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r07', 1)
            jump r05

label r05:
    $ aa_node = 'r05'
    $ aa_location = '21h40 · Salão'
    $ aa_audio_enter('r05')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Vanessa ainda sentada; decisão de sair não foi tomada.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('r05', 'line', 0, phase=0)
    v "Eu não aguento você falando comigo desse jeito."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_hesita'
    else:
        $ aa_stage_action = 'Ela puxa a bolsa para o colo, casaco permanece na cadeira.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_hesita'
    show screen aa_location_display
    $ aa_audio_event('r05', 'line', 1, phase=0)
    "Ela puxou a bolsa para o colo. O casaco continuou na cadeira."
    $ aa_audio_event('r05', 'line', 2, phase=0)
    v "Eu devia ir embora."
    $ aa_audio_event('r05', 'line', 3, phase=0)
    "Esperei que levantasse. Ela ficou olhando para mim."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Espera a resposta sem se levantar.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_hesita'
    else:
        $ aa_stage_action = 'Espera a resposta sem se levantar.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_hesita'
    show screen aa_location_display
    $ aa_audio_event('r05', 'line', 4, phase=0)
    v "Você quer que eu vá?"
    menu:
        "Parar de argumentar e dar espaço para ela decidir.":
            $ aa_audio_event('r05', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'r05', 0)
            jump v01
        "Prometer que vou ficar com ela e ir à mudança.":
            $ aa_audio_event('r05', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'r05', 1)
            jump v02
        "Dizer que ela está fazendo uma cena para me prender.":
            $ aa_audio_event('r05', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'r05', 2)
            jump v01

label k00:
    $ aa_node = 'k00'
    $ aa_location = '21h48 · Mesa'
    $ aa_audio_enter('k00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_tres'
        else:
            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_quatro'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Conta e lugar vazio: Vanessa já pagou e saiu.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg_conta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg_conta'
        else:
            $ aa_stage_action = 'Conta em primeiro plano, Vanessa ainda sentada.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_conta_presente'
    show screen aa_location_display
    $ aa_audio_event('k00', 'line', 0, phase=0)
    "A conta chegou dobrada. Eu abri devagar, como se pudesse negociar os números antes que alguém visse."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 1, phase=0)
        "O valor era maior do que eu tinha. A promessa de pagar tudo continuava existindo, embora o dinheiro não."
    if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
        $ aa_audio_event('k00', 'line', 2, phase=0)
        "Sem a parte de Vanessa, eu conseguia pagar. Ela tinha resolvido até a promessa que eu não podia cumprir."
    if aa_matches(aa_state, {'debt': False}):
        $ aa_audio_event('k00', 'line', 3, phase=0)
        "Cabia no que tínhamos combinado. Pela primeira vez, uma parte da noite tinha o tamanho certo."
    if aa_matches(aa_state, {'v_gone': True}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_tres'
        else:
            $ aa_stage_action = 'Comprovante de Vanessa no ramo em que ela já saiu.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg_conta at aa_camera(1.1, 0.51, 0.45)
            with Dissolve(0.25)
            $ aa_last_art = 'cg_conta'
        show screen aa_location_display
        $ aa_audio_event('k00', 'line', 4, phase=0)
        "A parte de Vanessa já estava paga. A assinatura dela no comprovante parecia normal."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 5, phase=0)
        v "Se faltar, eu consigo completar. Depois você me devolve."
    if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
        $ aa_audio_event('k00', 'line', 6, phase=0)
        "Ela tinha me mostrado o dinheiro separado para a mudança antes de sairmos. Agora esperava eu dizer de quanto precisava."
    menu:
        "Pagar minha parte como combinado." if aa_matches(aa_state, {'debt': False}):
            $ aa_audio_event('k00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'k00', 0)
            jump k01
        "Admitir que prometi mais do que podia e pedir divisão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'k00', 1)
            jump k01
        "Pagar minha parte agora que Vanessa acertou a dela." if aa_matches(aa_state, {'debt': True, 'v_gone': True}):
            $ aa_audio_event('k00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'k00', 2)
            jump k01
        "Pedir dinheiro emprestado a Joãozão." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'k00', 3)
            jump k01
        "Reclamar alto do preço para desviar a atenção.":
            $ aa_audio_event('k00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'k00', 4)
            jump k01
        "Aceitar que Vanessa complete o dinheiro e combinar a devolução." if aa_matches(aa_state, {'debt': True, 'v_gone': False}):
            $ aa_audio_event('k00', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'k00', 5)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Ela completa a conta antes da saída do casal.'
                $ aa_table_party = 4
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_pagamento at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_pagamento'
            else:
                $ aa_stage_action = 'Ela completa o pagamento no cartão.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = True
                hide screen aa_phone_view
                scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_pagamento'
            $ aa_audio_event('k00', 'response', 0, 5)
            "Vanessa completou o pagamento no cartão. Eu disse que devolveria na sexta."
            $ aa_audio_event('k00', 'response', 1, 5)
            v "Tá. Sexta."
            $ aa_audio_event('k00', 'response', 2, 5)
            "Ela repetiu a data. Eu fiz que sim. Já estava arrependido de ter escolhido uma."
            jump k01

label k01:
    $ aa_node = 'k01'
    $ aa_location = '21h55 · Salão'
    $ aa_audio_enter('k01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Vanessa já saiu; Yasmin e Joãozão continuam sentados.'
            $ aa_table_party = 3
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_tres at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_tres'
        else:
            $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_quatro'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka sozinho após Vanessa sair.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sozinho'
        else:
            $ aa_stage_action = 'Depois do pagamento, Vanessa ainda espera pela saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_sobremesa at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sobremesa'
    show screen aa_location_display
    if aa_matches(aa_state, {'heat': {'gte': 2}}):
        $ aa_audio_event('k01', 'line', 0, phase=0)
        "A recepção já estava olhando para nossa mesa. O garçom perguntou, pela segunda vez, se precisávamos de alguma coisa."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_quatro'
        else:
            $ aa_stage_action = 'Joãozão responde ao pedido da outra mesa, fora do close de Vanessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_conta_presente'
        show screen aa_location_display
        $ aa_audio_event('k01', 'line', 1, phase=0)
        j "Eu transfiro. Você me devolve amanhã."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_audio_event('k01', 'line', 2, phase=0)
        "Joãozão disse isso sem sorrir. Eu teria suportado melhor uma piada."
    if aa_matches(aa_state, {'bill': 'cena'}):
        $ aa_audio_event('k01', 'line', 3, phase=0)
        "O garçom apontou os itens. Eu sabia que estavam certos. Continuei olhando até ele perceber que eu não tinha uma dúvida."
    if aa_matches(aa_state, {'bill': 'cena', 'debt': True, 'v_gone': False}):
        $ aa_audio_event('k01', 'line', 4, phase=0)
        "Vanessa pediu que separassem o que ela tinha consumido. Com a parte dela paga, meu saldo foi suficiente. Eu ainda resmunguei enquanto aproximava o cartão."
    if aa_matches(aa_state, {'bill': 'admitida', 'v_gone': False}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_conta_quatro at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_conta_quatro'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente quando aceita a divisão.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_conta_presente at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_conta_presente'
        show screen aa_location_display
        $ aa_audio_event('k01', 'line', 5, phase=0)
        v "Eu pago o meu. Foi por isso que eu separei o dinheiro antes de sair. Mas por que você insistiu que dava pra pagar tudo?"
    $ aa_audio_event('k01', 'line', 6, phase=0)
    "O salão começava a esvaziar. Restava pouco tempo para transformar aquela noite em uma história que eu conseguiria contar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Os três outros lugares estão vazios.'
            $ aa_table_party = 1
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_sozinho'
        else:
            $ aa_stage_action = 'Yasmin e Joãozão foram ao balcão; Vanessa ainda sentada.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
        show screen aa_location_display
        $ aa_audio_event('k01', 'line', 7, phase=0)
        "Yasmin recolheu a bolsa. Ela e Joãozão deixaram as cadeiras e foram acertar o que faltava no balcão."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('k01', 'line', 8, phase=0)
        "Na outra mesa, Yasmin recolheu a bolsa. Ela e Joãozão foram ao balcão acertar a conta."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False}):
        $ aa_audio_event('k01', 'line', 9, phase=0)
        v "Você ainda vai comigo amanhã?"
    if aa_matches(aa_state, {'promised': True, 'v_gone': False}):
        $ aa_audio_event('k01', 'line', 10, phase=0)
        "Ela perguntou antes que eu escolhesse para onde olhar. A promessa que eu tinha feito ainda precisava de uma resposta."
    menu:
        "Perguntar a Vanessa como ela quer ir embora." if aa_matches(aa_state, {'v_gone': False}):
            $ aa_audio_event('k01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'k01', 0)
            jump s00
        "Aceitar que ela foi embora e sair sozinho." if aa_matches(aa_state, {'v_gone': True}):
            $ aa_audio_event('k01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'k01', 1)
            jump e04
        "Tentar uma última conversa com Yasmin.":
            $ aa_audio_event('k01', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'k01', 2)
            jump s01
        "Acertar o limite com Joãozão, sem levantar a voz." if aa_matches(aa_state, {'j_limit': True, 'truth': True}):
            $ aa_audio_event('k01', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 'k01', 3)
            jump s02
        "Provocar Joãozão na frente de Yasmin.":
            $ aa_audio_event('k01', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 'k01', 4)
            jump s03
        "Usar uma foto ou mensagem para fazer a noite parecer boa." if aa_matches(aa_state, {'public': True}):
            $ aa_audio_event('k01', 'choice', 5, 5)
            $ aa_state = aa_choose(aa_state, 'k01', 5)
            jump e08

label s00:
    $ aa_node = 's00'
    $ aa_location = '22h02 · Entrada'
    $ aa_audio_enter('s00')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('s00', 'line', 0, phase=0)
    "Na entrada, Vanessa vestiu o casaco e abriu o aplicativo. Depois baixou o telefone e me olhou."
    if aa_matches(aa_state, {'bond': 'mantido'}):
        $ aa_audio_event('s00', 'line', 1, phase=0)
        v "Você espera comigo?"
    if aa_matches(aa_state, {'bond': {'ne': 'mantido'}}):
        $ aa_audio_event('s00', 'line', 2, phase=0)
        v "Eu vou sozinha. Mas espera o carro chegar?"
    $ aa_stage_action = 'Após pedir companhia, ela volta a conferir a placa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'carro'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('carro')
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('s00', 'line', 3, phase=0)
    "Eu disse que esperava. Ela virou a tela para mim: o carro ainda estava a quatro minutos."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_stage_action = 'Telefone baixo; a resposta é dada a Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_saida_espera'
        show screen aa_location_display
        $ aa_audio_event('s00', 'line', 4, phase=0)
        v "Se você mudar de ideia sobre amanhã, fala. Não some."
    if aa_matches(aa_state, {'promised': False}):
        $ aa_stage_action = 'Telefone baixo; a resposta é dada a Vanessa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_saida_espera'
        show screen aa_location_display
        $ aa_audio_event('s00', 'line', 5, phase=0)
        v "Amanhã a gente vai se ver na aula. Eu não sei como vai ser."
    menu:
        "Dizer que quero encerrar o namoro.":
            $ aa_audio_event('s00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's00', 0)
            $ aa_audio_event('s00', 'response', 0, 0)
            f "Eu quero terminar."
            $ aa_audio_event('s00', 'response', 1, 0)
            v "Você esperou eu chamar o carro pra falar?"
            $ aa_audio_event('s00', 'response', 2, 0)
            "Eu tinha esperado. Não tentei dar outro nome."
            $ aa_audio_event('s00', 'response', 3, 0)
            v "Tá. Então deixa eu ir."
            jump e01
        "Perguntar se ela aceita conversar outro dia, sem exigir namoro." if aa_matches(aa_state, {'truth': True, 'listened': True, 'respect': True, 'heard': True, 'bond': 'indefinido'}):
            $ aa_audio_event('s00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's00', 1)
            jump e02
        "Dizer que continuo com ela e combinar a visita de amanhã." if aa_matches(aa_state, {'bond': {'ne': 'terminado'}}):
            $ aa_audio_event('s00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 's00', 2)
            jump e03
        "Pedir a Yasmin que reconheça a humilhação que causou." if aa_matches(aa_state, {'stopped_joke': True, 'truth': True, 'respect': True, 'route': 'juntas'}):
            $ aa_audio_event('s00', 'choice', 3, 3)
            $ aa_state = aa_choose(aa_state, 's00', 3)
            jump e09
        "Ficar calado, esperando Vanessa resolver por mim.":
            $ aa_audio_event('s00', 'choice', 4, 4)
            $ aa_state = aa_choose(aa_state, 's00', 4)
            jump e10

label s01:
    $ aa_node = 's01'
    $ aa_location = '22h02 · Perto do balcão'
    $ aa_audio_enter('s01')
    $ aa_stage_action = 'Yasmin fecha a bolsa e recusa outra conversa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    $ aa_audio_event('s01', 'line', 0, phase=0)
    f "Yasmin, espera."
    $ aa_audio_event('s01', 'line', 1, phase=0)
    "Ela fechou a bolsa. Não precisou olhar para Joãozão."
    $ aa_stage_action = 'Recusa sem sorriso.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_yasmin_bolsa at aa_camera(1.1, 0.73, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_yasmin_bolsa'
    show screen aa_location_display
    $ aa_audio_event('s01', 'line', 2, phase=0)
    y "Não."
    $ aa_audio_event('s01', 'line', 3, phase=0)
    "Eu ainda nem tinha feito a pergunta. Percebi que era sempre a mesma."
    menu:
        "Parar ali.":
            $ aa_audio_event('s01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's01', 0)
            jump e05
        "Insistir, falando por cima dela.":
            $ aa_audio_event('s01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's01', 1)
            jump s03

label s02:
    $ aa_node = 's02'
    $ aa_location = '22h03 · Balcão'
    $ aa_audio_enter('s02')
    $ aa_stage_action = 'Feka admite o limite; Joãozão não oferece amizade.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    $ aa_audio_event('s02', 'line', 0, phase=0)
    f "Eu não vou procurar ela. Não quero que você fale por mim nem por ela."
    $ aa_audio_event('s02', 'line', 1, phase=0)
    j "Você não vai procurar porque eu mandei?"
    $ aa_stage_action = 'O medo não desaparece depois da frase correta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.13, 0.24, 0.3)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    $ aa_audio_event('s02', 'line', 2, phase=0)
    "Ele estava perto. Eu continuava com medo. Não precisava fingir que tinha parado de ter para responder."
    menu:
        "Dizer que a resposta dela já basta.":
            $ aa_audio_event('s02', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's02', 0)
            jump e06
        "Dizer que Yasmin não merece tudo isso.":
            $ aa_audio_event('s02', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's02', 1)
            jump e05

label s03:
    $ aa_node = 's03'
    $ aa_location = '22h04 · Salão'
    $ aa_audio_enter('s03')
    $ aa_stage_action = 'Yasmin detém o passo de Joãozão; funcionário se aproxima.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    $ aa_audio_event('s03', 'line', 0, phase=0)
    j "Para de chamar ela. Ela acabou de falar."
    $ aa_stage_action = 'Mostrar a mão de Yasmin no braço, não uma briga.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.08, 0.67, 0.4)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    $ aa_audio_event('s03', 'line', 1, phase=0)
    "Algumas pessoas olharam. Joãozão deu um passo. Yasmin tocou o braço dele e disse para ele não fazer aquilo."
    if aa_matches(aa_state, {'heat': {'gte': 3}}):
        $ aa_audio_event('s03', 'line', 2, phase=0)
        j "Você passou a noite inteira fazendo isso."
    $ aa_stage_action = 'Abrir o plano para incluir o funcionário.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_confronto at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_confronto'
    show screen aa_location_display
    $ aa_audio_event('s03', 'line', 3, phase=0)
    "Um funcionário veio até nós. Não perguntou quem tinha razão. Perguntou se havia algum problema."
    menu:
        "Baixar a voz e sair.":
            $ aa_audio_event('s03', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 's03', 0)
            jump e05
        "Continuar provocando, mesmo depois do aviso.":
            $ aa_audio_event('s03', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 's03', 1)
            jump e07

label e00:
    $ aa_node = 'e00'
    $ aa_location = '19h45 · Hall do apartamento'
    $ aa_audio_enter('e00')
    $ aa_stage_action = 'Ela tenta adiar a separação antes de chamar o carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_hall_duvida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_hall_duvida'
    show screen aa_location_display
    $ aa_audio_event('e00', 'line', 0, phase=0)
    "Cancelei a reserva. Vanessa perguntou se eu estava cancelando só o jantar. Eu disse que não sabia continuar o namoro daquele jeito."
    $ aa_audio_event('e00', 'line', 1, phase=0)
    v "Eu podia ficar um pouco. A gente não precisa sair."
    $ aa_location = '19h50 · Cozinha compartilhada'
    $ aa_stage_action = 'Vanessa já foi; a panela permanece. Vazio agora tem causa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha'
    show screen aa_location_display
    $ aa_audio_event('e00', 'line', 2, phase=0)
    "Eu repeti que precisava encerrar. Ela chamou a mãe antes de pedir o carro."
    $ aa_audio_event('e00', 'line', 2, phase=1)
    "Depois que saiu, tirei a jaqueta. A panela continuava na pia."
    $ aa_audio_event('e00', 'line', 3, phase=0)
    "Peguei o celular. A vontade de ver Yasmin não tinha acabado porque eu tinha feito uma coisa certa."
    $ aa_location = '19h55 · Cozinha compartilhada'
    $ aa_stage_action = 'Feka lava a própria panela; encerramento concreto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_lavar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_lavar'
    show screen aa_location_display
    $ aa_audio_event('e00', 'line', 4, phase=0)
    "Deixei o celular na mesa e lavei a panela."
    $ aa_audio_event('e00', 'line', 4, phase=1)
    "Na manhã seguinte, Vanessa perguntou se eu tinha certeza. Respondi que sim. Ela pediu que eu não fosse à mudança."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E00 · A noite que não aconteceu"
    return

label e01:
    $ aa_node = 'e01'
    $ aa_location = '22h10 · Calçada'
    $ aa_audio_enter('e01')
    $ aa_stage_action = 'Duas pessoas diante da mesma porta escolhem rumos diferentes.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('e01', 'line', 0, phase=0)
    f "Tá. Eu vou por outro caminho."
    $ aa_audio_event('e01', 'line', 1, phase=0)
    v "Eu vou querer te mandar mensagem. Não responde como se hoje não tivesse acontecido."
    $ aa_audio_event('e01', 'line', 2, phase=0)
    "Esperei uma frase maior. Ela não tinha obrigação de encerrar aquilo de um jeito que me ajudasse."
    $ aa_location = 'Mais tarde · Caminho de volta'
    $ aa_stage_action = 'Sozinho, Feka apaga a cobrança disfarçada de desculpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'rascunho'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('rascunho')
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    $ aa_audio_event('e01', 'line', 3, phase=0)
    "No caminho de volta, escrevi que sentia muito."
    $ aa_location = 'Mais tarde · Caminho de volta'
    $ aa_stage_action = 'Campo vazio; a desculpa não foi enviada.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'rascunho_apagado'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('rascunho_apagado')
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    $ aa_audio_event('e01', 'line', 4, phase=0)
    "Apaguei quando percebi que estava esperando uma resposta antes de enviar."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Dia seguinte: distância entre os colegas.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'grupo_materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('grupo_materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_audio_event('e01', 'line', 5, phase=0)
    "No dia seguinte, Vanessa sentou com uma colega. Olhou para meu lugar quando cheguei, mas não me chamou. Mandei a matéria pelo grupo."
    $ aa_audio_event('e01', 'line', 6, phase=0)
    "Eu soube que ela tinha recebido as chaves por outra pessoa."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e01', 'line', 7, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E01 · Duas contas"
    return

label e02:
    $ aa_node = 'e02'
    $ aa_location = '22h10 · Calçada'
    $ aa_audio_enter('e02')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('e02', 'line', 0, phase=0)
    f "Você aceita conversar outro dia? Se não quiser, eu não vou ficar perguntando."
    $ aa_audio_event('e02', 'line', 1, phase=0)
    v "Eu quero. Mas eu vou acabar perguntando se você volta. Preciso pensar antes."
    $ aa_audio_event('e02', 'line', 2, phase=0)
    "Quase chamei aquilo de uma chance. Era uma conversa que ainda não tinha sido aceita."
    $ aa_audio_event('e02', 'line', 3, phase=0)
    v "Na mudança vai minha mãe. Não aparece sem combinar. Eu posso querer te chamar e ainda assim precisar que você não vá."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A matéria é enviada sem usar a mensagem como reconciliação.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_audio_event('e02', 'line', 4, phase=0)
    "No dia seguinte, mandei a matéria. Ela respondeu que tinha recebido a chave e perguntou se podíamos conversar na quinta, depois da aula."
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'quinta'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('quinta')
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('e02', 'line', 5, phase=0)
    "Respondi que sim. Não tratei a quinta-feira como a data em que ela seria minha namorada de novo."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e02', 'line', 6, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E02 · Sem promessa"
    return

label e03:
    $ aa_node = 'e03'
    $ aa_location = '22h10 · Calçada'
    $ aa_audio_enter('e03')
    $ aa_stage_action = 'Telefone baixo; Vanessa procura uma resposta antes do carro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_saida_espera at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_saida_espera'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 0, phase=0)
    f "Eu continuo com você. Amanhã a gente se encontra depois da aula."
    $ aa_audio_event('e03', 'line', 1, phase=0)
    v "Me manda quando acordar. Pra eu saber que você não mudou de ideia."
    $ aa_location = '22h12 · No carro'
    $ aa_stage_action = 'Ela procura o olhar dele; ambos de cinto, bolsa no colo.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg5_carro_proxima at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg5_carro_proxima'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 2, phase=0)
    "No carro, ela virou o rosto para mim. Eu olhava a rua. A bolsa ficou apertada no colo dela."
    $ aa_audio_event('e03', 'line', 3, phase=0)
    v "Você ainda tá pensando nela?"
    $ aa_audio_event('e03', 'line', 4, phase=0)
    "Demorei. Vanessa disse que não precisava responder naquele momento."
    if aa_matches(aa_state, {'truth': True}):
        $ aa_audio_event('e03', 'line', 5, phase=0)
        "Eu tinha contado por que começara a namorar. Mesmo assim ela tinha aberto espaço no carro."
    if aa_matches(aa_state, {'truth': False}):
        $ aa_audio_event('e03', 'line', 6, phase=0)
        "Uma parte da história continuava escondida. Eu podia me convencer de que era por isso que ela ficava."
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 7, phase=0)
    "Na manhã seguinte, acordei no meu quarto. Tinha deixado Vanessa em casa e voltado para a moradia. A jaqueta continuava na cadeira."
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Feka sozinho na própria moradia; manhã seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_acordar at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_acordar'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 8, phase=0)
    "O celular estava ao lado da minha perna. Eu tinha prometido mandar mensagem quando acordasse. Passei alguns segundos sentado antes de pegar."
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Só agora pega o celular e confirma a visita.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'visita'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('visita')
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 9, phase=0)
    "Mandei bom dia e confirmei que iria depois da aula. Vanessa respondeu que ia me esperar."
    $ aa_location = 'Dia seguinte · Quarto de Feka'
    $ aa_stage_action = 'Conversa fecha; ele precisa se preparar para a aula.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_manha_celular at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_manha_celular'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 10, phase=0)
    "Ainda precisava me arrumar e ir para a aula. A visita agora tinha uma hora na minha cabeça. Eu podia passar a manhã inteira procurando uma desculpa."
    $ aa_location = 'Depois da aula · Porta do apartamento de Vanessa'
    $ aa_stage_action = 'Chega com uma caixa do corredor; Vanessa abre a porta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_chegada_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_chegada_mudanca'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 11, phase=0)
    "Depois da aula, fui ao endereço que ela tinha mandado. Quando Vanessa abriu a porta, eu já segurava uma das caixas que o frete deixara no corredor."
    $ aa_audio_event('e03', 'line', 12, phase=0)
    v "Você veio. Pode entrar. Minha mãe acabou de sair."
    $ aa_audio_event('e03', 'line', 13, phase=0)
    f "Onde ponho essa?"
    $ aa_audio_event('e03', 'line', 14, phase=0)
    v "Perto da janela. É pesada? Espera, eu tiro a cadeira."
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Caixas abertas; os dois trabalham na cozinha.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_trabalho_mudanca'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 15, phase=0)
    "Levei a caixa para dentro. Vanessa afastou a cadeira antes que eu pedisse. A sala era menor do que eu tinha imaginado."
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Ela indica a posição da mesa; diálogo durante o trabalho.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_trabalho_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_trabalho_mudanca'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 16, phase=0)
    "Abrimos as caixas da cozinha. Eu tirava os copos do papel; ela separava o que ia para o armário. Pela primeira vez desde o jantar, havia uma coisa simples para fazer."
    $ aa_audio_event('e03', 'line', 17, phase=0)
    v "A mesa fica aqui. Você acha que dá pra passar?"
    $ aa_audio_event('e03', 'line', 18, phase=0)
    f "Se puxar um pouco pra janela, dá."
    $ aa_location = 'Apartamento de Vanessa · Mudança'
    $ aa_stage_action = 'Os dois deslocam a mesa; caixas e louça continuam por guardar.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_mesa_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_mesa_mudanca'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 19, phase=0)
    "Tiramos os copos de cima e empurramos a mesa alguns centímetros. Ela ficou segurando a outra ponta até eu dizer que estava bom."
    $ aa_audio_event('e03', 'line', 20, phase=0)
    v "Você fica pra comer? Minha mãe deixou comida."
    $ aa_audio_event('e03', 'line', 21, phase=0)
    f "Fico."
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Vanessa chega com os dois pratos; antes de sentarem.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_comida_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_comida_mudanca'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 22, phase=0)
    "Ela foi buscar os pratos. Antes de servir, perguntou de novo se eu não precisava ir embora."
    $ aa_audio_event('e03', 'line', 23, phase=0)
    f "Eu falei que fico."
    $ aa_audio_event('e03', 'line', 24, phase=0)
    v "Tá. Eu só queria saber."
    $ aa_location = 'Mais tarde · Apartamento de Vanessa'
    $ aa_stage_action = 'Os dois finalmente sentados para comer; caixas ainda abertas.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg7_refeicao_mudanca at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg7_refeicao_mudanca'
    show screen aa_location_display
    $ aa_audio_event('e03', 'line', 25, phase=0)
    "Sentamos. Ela esperou minha primeira garfada antes de começar. As caixas continuavam abertas junto da parede."
    $ aa_audio_event('e03', 'line', 26, phase=0)
    "Eu tinha ajudado na mudança. Isso não respondia ao que ela tinha me perguntado na noite anterior. Mesmo assim, quando agradeceu por eu ter ido, senti alívio."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'A devolução continua na sexta, se houve empréstimo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e03', 'line', 27, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E03 · Continuar"
    return

label e04:
    $ aa_node = 'e04'
    $ aa_location = '22h10 · Mesa'
    $ aa_audio_enter('e04')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
        $ aa_table_party = 1
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_sozinho'
    else:
        $ aa_stage_action = 'A cadeira vazia é consequência da saída, não cenário de abertura.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    $ aa_audio_event('e04', 'line', 0, phase=0)
    "A cadeira ainda estava um pouco afastada. Tive vontade de pôr no lugar, como se isso diminuísse o que tinha acontecido."
    $ aa_audio_event('e04', 'line', 1, phase=0)
    "O garçom perguntou se podia tirar o segundo copo. Respondi que podia. Foi a única decisão que alguém ainda precisava de mim."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Um caderno na mesa; o de Vanessa foi embora com ela.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    $ aa_audio_event('e04', 'line', 2, phase=0)
    "Em casa, só o meu caderno estava na escrivaninha. Vanessa tinha guardado o dela na bolsa antes de sairmos."
    $ aa_location = 'Segunda-feira · Campus de Direito'
    $ aa_stage_action = 'Cumprimento distante no dia seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'so_materia'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('so_materia')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_audio_event('e04', 'line', 3, phase=0)
    "Na segunda-feira, Vanessa sentou com uma colega. Me cumprimentou de longe. Depois recebi uma mensagem: queria só a matéria, pelo grupo."
    if aa_matches(aa_state, {'bond': 'indefinido'}):
        $ aa_location = 'Segunda-feira à noite · Quarto de Feka'
        $ aa_stage_action = 'Contato posterior não desfaz a saída da noite anterior.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'espaco'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('espaco')
        $ aa_last_art = 'cg2_retorno'
        show screen aa_location_display
        $ aa_audio_event('e04', 'line', 4, phase=0)
        "À noite ela escreveu que ainda não sabia terminar, mas não queria me ver fora da aula por enquanto. Respondi que tinha entendido."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'O término continua explícito.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        $ aa_audio_event('e04', 'line', 5, phase=0)
        "A vontade de chamá-la de volta não era um motivo para fingir que o término tinha ficado em dúvida."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E04 · Cadeira vazia"
    return

label e05:
    $ aa_node = 'e05'
    $ aa_location = '22h10 · Entrada'
    $ aa_audio_enter('e05')
    $ aa_stage_action = 'Yasmin e Joãozão saem juntos.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    show aa_y firm at aa_left
    show aa_j neutral at aa_right
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    $ aa_audio_event('e05', 'line', 0, phase=0)
    "Yasmin foi embora com Joãozão. Não houve uma última olhada. Esperei até a porta fechar mesmo assim."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_stage_action = 'Exibir Vanessa somente se ainda não tiver saído.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        $ aa_audio_event('e05', 'line', 1, phase=0)
        "Quando voltei, Vanessa ainda esperava perto da porta. Perguntou se agora podíamos ir. Eu disse que ela devia ir sem mim. Ela chamou o carro e perguntou outra vez se eu tinha certeza."
    $ aa_stage_action = 'Feka permanece sem conseguir reter ninguém.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_calcada'
    show screen aa_location_display
    $ aa_audio_event('e05', 'line', 2, phase=0)
    "Eu tinha perdido o jantar de Vanessa e ainda queria que alguém reconhecesse meu sofrimento como a parte principal."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A toalha úmida retoma o início da noite.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    $ aa_audio_event('e05', 'line', 3, phase=0)
    "No quarto, a toalha continuava úmida. Eu lembrava de Vanessa perguntando onde estava. Não lembrava do que respondi."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'A mesma mensagem antiga, agora sem desculpa.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'conversa'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('conversa')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    $ aa_audio_event('e05', 'line', 4, phase=0)
    "Abri a conversa de Yasmin. A mensagem antiga continuava lá, dizendo para eu não esperar na saída. Era uma resposta que eu tinha passado anos fingindo não saber ler."
    if aa_matches(aa_state, {'promised': True}):
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'A promessa quebrada recebe uma resposta no dia seguinte.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'promessa'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('promessa')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        $ aa_audio_event('e05', 'line', 5, phase=0)
        "Eu tinha prometido ir à mudança."
        $ aa_audio_event('e05', 'line', 5, phase=1)
        "No dia seguinte escrevi que não iria e que não podia pedir que ela me esperasse. Ela respondeu horas depois: “Você falou que ia.”"
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e05', 'line', 6, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E05 · A mesma resposta"
    return

label e06:
    $ aa_node = 'e06'
    $ aa_location = '22h10 · Balcão e calçada'
    $ aa_audio_enter('e06')
    $ aa_stage_action = 'A conversa termina sem aperto de mão.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_balcao at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_balcao'
    show screen aa_location_display
    $ aa_audio_event('e06', 'line', 0, phase=0)
    f "Não. Porque ela não quer."
    $ aa_audio_event('e06', 'line', 1, phase=0)
    j "Então faz isso."
    $ aa_audio_event('e06', 'line', 2, phase=0)
    "Ele não me deu a mão. Eu não ofereci a minha. Não havia amizade escondida esperando a frase certa."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_stage_action = 'Vanessa tem seu transporte; acordo com Joãozão não a retém.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_saida'
        show screen aa_location_display
        $ aa_audio_event('e06', 'line', 3, phase=0)
        "Vanessa tinha chamado o carro. Perguntou se a conversa tinha acabado."
        $ aa_audio_event('e06', 'line', 3, phase=1)
        "Eu disse que sim e esperei até a placa aparecer. Ela foi sozinha."
    if aa_matches(aa_state, {'v_gone': True}):
        $ aa_stage_action = 'O ramo em que ela já saiu permanece vazio.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene bg_calcada at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'bg_calcada'
        show screen aa_location_display
        $ aa_audio_event('e06', 'line', 4, phase=0)
        "Vanessa já tinha ido. Acertar uma coisa não trouxe de volta a outra."
    if aa_matches(aa_state, {'bill': 'emprestimo'}):
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Empréstimo devolvido no dia seguinte.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        $ aa_audio_event('e06', 'line', 5, phase=0)
        "No dia seguinte, devolvi o dinheiro de Joãozão com uma mensagem curta."
    $ aa_audio_event('e06', 'line', 6, phase=0)
    "Eu ia continuar estudando com Vanessa. Yasmin, com ele. Pela primeira vez pensei nisso como a vida deles, não como uma provocação."
    if aa_matches(aa_state, {'promised': True, 'v_gone': False}):
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'A relação continua indefinida; a promessa é cobrada.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'indefinido'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('indefinido')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        $ aa_audio_event('e06', 'line', 7, phase=0)
        "Mandei que não iria à mudança e pedi desculpa por ter prometido. Ela perguntou se eu ainda queria o namoro. Respondi que não sabia e que entendia se ela não quisesse esperar."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e06', 'line', 8, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E06 · Sem plateia"
    return

label e07:
    $ aa_node = 'e07'
    $ aa_location = '22h12 · Entrada de serviço'
    $ aa_audio_enter('e07')
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    $ aa_audio_event('e07', 'line', 0, phase=0)
    "O funcionário pediu que eu saísse. Eu tentei contar a história. Ele repetiu o pedido, agora mais devagar."
    $ aa_audio_event('e07', 'line', 1, phase=0)
    y "João, para. Não precisa ir atrás."
    $ aa_audio_event('e07', 'line', 2, phase=0)
    "Joãozão parou. Nem a briga que eu estava tentando fabricar aconteceu do jeito que eu precisava."
    if aa_matches(aa_state, {'v_gone': False}):
        $ aa_audio_event('e07', 'line', 3, phase=0)
        "Vanessa veio até a porta e perguntou se eu tinha me machucado. Eu disse que tinham me desrespeitado. Ela ficou em silêncio, depois chamou a mãe e foi esperar o carro."
    $ aa_stage_action = 'Feka grava o áudio na calçada, já fora do restaurante.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'audio'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.14, 0.74, 0.33)
    with Dissolve(0.25)
    show screen aa_phone_view('audio')
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    $ aa_audio_event('e07', 'line', 4, phase=0)
    "Na calçada, o frio veio depois da vergonha."
    $ aa_audio_event('e07', 'line', 4, phase=1)
    "Enviei um áudio dizendo que tinham me desrespeitado. Ouvi antes de enviar o segundo. Minha voz parecia satisfeita por finalmente ter um culpado."
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'audio_resposta'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_servico at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('audio_resposta')
    $ aa_last_art = 'cg2_servico'
    show screen aa_location_display
    $ aa_audio_event('e07', 'line', 5, phase=0)
    "No grupo, alguém respondeu ‘complicado’. Eu guardei aquela palavra como apoio."
    $ aa_location = 'Mais tarde · Quarto de Feka'
    $ aa_stage_action = 'Funcionário na porta, Feka do lado de fora; sem luta.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'chegou'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_retorno at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('chegou')
    $ aa_last_art = 'cg2_retorno'
    show screen aa_location_display
    $ aa_audio_event('e07', 'line', 6, phase=0)
    "Mais tarde Vanessa perguntou por mensagem se eu tinha chegado. Eu quase usei a preocupação dela para contar minha versão inteira. Ela acrescentou que precisava ficar sem conversar naquela noite."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e07', 'line', 7, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E07 · Fora do salão"
    return

label e08:
    $ aa_node = 'e08'
    $ aa_location = '22h16 · Celular'
    $ aa_audio_enter('e08')
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 1
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_sozinho'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sozinho'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg2_sobremesa_afastada at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_sobremesa_afastada'
    show screen aa_location_display
    if aa_matches(aa_state, {'v_gone': False}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
            $ aa_table_party = 2
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg4_pudim_dois at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg4_pudim_dois'
        else:
            $ aa_stage_action = 'Ela anuncia a saída enquanto Feka procura o celular.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg2_levantar'
        show screen aa_location_display
        $ aa_audio_event('e08', 'line', 0, phase=0)
        "Vanessa perguntou se eu ia continuar no celular. Eu disse que já ia. Quando ela anunciou que iria embora, respondi sem levantar os olhos."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
        $ aa_table_party = 0
        $ aa_phone_pov = True
        $ aa_phone_kind = 'enquadramento'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg6_phone_table at aa_phone_camera
        with Dissolve(0.25)
        show screen aa_phone_view('enquadramento')
        $ aa_last_art = 'cg6_phone_table'
    else:
        $ aa_stage_action = 'Só então a cadeira fica vazia.'
        $ aa_table_party = 0
        $ aa_phone_pov = True
        $ aa_phone_kind = 'enquadramento'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg6_phone_table at aa_phone_camera
        with Dissolve(0.25)
        show screen aa_phone_view('enquadramento')
        $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    $ aa_audio_event('e08', 'line', 1, phase=0)
    "Fotografei os copos que ainda estavam na mesa. Deixei as cadeiras fora do enquadramento."
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado')
            $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    $ aa_audio_event('e08', 'line', 2, phase=0)
    "Escrevi que a noite tinha sido boa. Fiquei olhando as visualizações."
    if aa_matches(aa_state, {'bond': {'ne': 'mantido'}}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'marcacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('marcacao')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'A mensagem desmonta a publicação feliz.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'marcacao'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('marcacao')
            $ aa_last_art = 'cg6_phone_table'
        show screen aa_location_display
        $ aa_audio_event('e08', 'line', 3, phase=0)
        "Vanessa mandou uma mensagem pedindo que eu não a marcasse. Não tinha palavrão. Apaguei a marcação e deixei a publicação."
    if aa_matches(aa_state, {'route': 'juntas'}):
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Só Feka permanece.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Casal no balcão; Vanessa ainda à mesa.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
    else:
        if aa_matches(aa_state, {'v_gone': True}):
            $ aa_stage_action = 'Feka escolhe o enquadramento que esconde a cadeira vazia.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
        else:
            $ aa_stage_action = 'Vanessa ainda está presente antes de anunciar sua saída.'
            $ aa_table_party = 0
            $ aa_phone_pov = True
            $ aa_phone_kind = 'publicado_depois'
            $ aa_dialogue_side = False
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg6_phone_table at aa_phone_camera
            with Dissolve(0.25)
            show screen aa_phone_view('publicado_depois')
            $ aa_last_art = 'cg6_phone_table'
    show screen aa_location_display
    $ aa_audio_event('e08', 'line', 4, phase=0)
    "Yasmin não respondeu. Eu disse a mim mesmo que ela devia ter visto."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'Outro público para a versão menor da história.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_audio_event('e08', 'line', 5, phase=0)
    "Na manhã seguinte, contei a um colega que Vanessa estava estranha. Ele não conhecia o começo da história. Era por isso que eu tinha escolhido contar a ele."
    if aa_matches(aa_state, {'bond': 'mantido'}):
        $ aa_location = 'Dia seguinte · Campus de Direito'
        $ aa_stage_action = 'Ela procura confirmação pela mensagem, apesar da publicação falsa.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'visita_post'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('visita_post')
        $ aa_last_art = 'cg2_campus'
        show screen aa_location_display
        $ aa_audio_event('e08', 'line', 6, phase=0)
        "Vanessa respondeu à publicação perguntando se a visita à mudança ainda estava combinada. Eu mandei que sim. Ela não comentou as cadeiras que eu tinha escondido."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e08', 'line', 7, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E08 · Uma noite ótima"
    return

label e09:
    $ aa_node = 'e09'
    $ aa_location = '22h10 · Entrada'
    $ aa_audio_enter('e09')
    $ aa_stage_action = 'Yasmin se dirige a Vanessa; Joãozão aguarda.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    $ aa_audio_event('e09', 'line', 0, phase=0)
    "Chamei Yasmin quando ela e Joãozão chegaram à porta."
    $ aa_audio_event('e09', 'line', 1, phase=0)
    f "Você podia pelo menos pedir desculpa pelo que falou."
    $ aa_audio_event('e09', 'line', 2, phase=0)
    "Yasmin olhou para Vanessa. Eu fiquei esperando que olhasse para mim."
    $ aa_stage_action = 'Yasmin olha para Vanessa, Feka fora do centro.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_desculpa at aa_camera(1.12, 0.52, 0.35)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_desculpa'
    show screen aa_location_display
    $ aa_audio_event('e09', 'line', 3, phase=0)
    y "Eu fiz uma piada e te coloquei no meio. Foi escroto. Desculpa."
    $ aa_audio_event('e09', 'line', 4, phase=0)
    v "Eu... tá. Foi ruim. Mas eu preciso falar com ele também."
    $ aa_stage_action = 'Cada uma segue seu caminho; ninguém posa para Feka.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_entrada at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_entrada'
    show screen aa_location_display
    $ aa_audio_event('e09', 'line', 5, phase=0)
    "Vanessa esperou eu perguntar se queria companhia até o carro. Disse que sim."
    $ aa_audio_event('e09', 'line', 5, phase=1)
    "Depois pediu que eu não fosse junto. Yasmin e Joãozão seguiram para a rua."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A interpretação continua difícil no dia seguinte.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_audio_event('e09', 'line', 6, phase=0)
    "No dia seguinte, tentei lembrar a noite sem dividir as pessoas entre quem me humilhou e quem devia ter me salvado. Não consegui o tempo todo."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e09', 'line', 7, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E09 · Não foi por mim"
    return

label e10:
    $ aa_node = 'e10'
    $ aa_location = '22h14 · Mesa'
    $ aa_audio_enter('e10')
    $ aa_stage_action = 'Vanessa anuncia o carro antes de sair.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene cg2_saida at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'cg2_saida'
    show screen aa_location_display
    $ aa_audio_event('e10', 'line', 0, phase=0)
    v "Meu carro chegou. Você vai falar alguma coisa antes de eu ir?"
    $ aa_audio_event('e10', 'line', 1, phase=0)
    "Eu disse que não sabia. Vanessa ficou mais um instante. Depois foi embora, olhando o celular enquanto caminhava."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A cadeira de Vanessa continua vazia; o casal já está no balcão.'
        $ aa_table_party = 1
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_sozinho'
    else:
        $ aa_stage_action = 'Feka volta à sobremesa com duas colheres e uma cadeira vazia.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_sozinho'
    show screen aa_location_display
    $ aa_audio_event('e10', 'line', 2, phase=0)
    "Voltei à mesa. O pudim continuava lá, com as duas colheres. O garçom perguntou se podia tirar. Eu disse que ainda estava comendo."
    $ aa_audio_event('e10', 'line', 3, phase=0)
    "Não fiz uma cena. Não disse uma última mentira. Também não disse o que devia. Consegui passar pela noite deixando o trabalho para os outros."
    $ aa_location = 'Mais tarde · Cozinha compartilhada'
    $ aa_stage_action = 'Panela limpa por outra pessoa: repetir o espaço, mudar o objeto.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = ''
    $ aa_dialogue_side = False
    hide screen aa_phone_view
    scene bg_cozinha_noite at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    $ aa_last_art = 'bg_cozinha_noite'
    show screen aa_location_display
    $ aa_audio_event('e10', 'line', 4, phase=0)
    "Em casa, a cozinha estava limpa. Um dos moradores tinha lavado minha panela. Senti alívio antes de sentir vergonha."
    $ aa_location = 'Dia seguinte · Campus de Direito'
    $ aa_stage_action = 'A pergunta chega depois da saída, quando Feka já voltou.'
    $ aa_table_party = 0
    $ aa_phone_pov = False
    $ aa_phone_kind = 'terminou'
    $ aa_dialogue_side = False
    $ aa_dialogue_side = True
    hide screen aa_phone_view
    scene cg2_campus at aa_camera(1.0, 0.5, 0.5)
    with Dissolve(0.25)
    show screen aa_phone_view('terminou')
    $ aa_last_art = 'cg2_campus'
    show screen aa_location_display
    $ aa_audio_event('e10', 'line', 5, phase=0)
    "Ela mandou “cheguei” naquela noite. Respondi “que bom”."
    $ aa_audio_event('e10', 'line', 5, phase=1)
    "No dia seguinte perguntou se a gente tinha terminado. Eu tinha conseguido adiar até a obrigação de responder isso."
    if aa_matches(aa_state, {'v_loan': True}):
        $ aa_location = 'Sexta-feira · Campus de Direito'
        $ aa_stage_action = 'Na sexta-feira, a devolução tem consequência própria.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = 'devolucao_v'
        $ aa_dialogue_side = False
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene bg_campus at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        show screen aa_phone_view('devolucao_v')
        $ aa_last_art = 'bg_campus'
        show screen aa_location_display
        $ aa_audio_event('e10', 'line', 6, phase=0)
        "Na sexta, devolvi o dinheiro de Vanessa. Ela confirmou o valor. Eu quase escrevi que tinha cumprido o combinado, como se devolver o que devia fosse um favor."
    hide screen aa_location_display
    hide screen aa_phone_view
    $ aa_audio_ending()
    centered "E10 · Sobremesa fria"
    return

label v00:
    $ aa_node = 'v00'
    $ aa_location = '21h39 · Mesa'
    $ aa_audio_enter('v00')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_pergunta'
    else:
        $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('v00', 'line', 0, phase=0)
    v "Você ainda quer estar comigo?"
    $ aa_audio_event('v00', 'line', 1, phase=0)
    "Ela perguntou sem olhar para Yasmin. Não havia outra pessoa que pudesse responder por mim."
    if aa_matches(aa_state, {'promised': True}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            $ aa_stage_action = 'A promessa anterior reaparece na pergunta sobre a mudança.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_pergunta'
        show screen aa_location_display
        $ aa_audio_event('v00', 'line', 2, phase=0)
        v "Você disse que ia lá amanhã. Ainda vai?"
    if aa_matches(aa_state, {'promised': False}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            $ aa_stage_action = 'A expectativa de amanhã ainda existe.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_pergunta'
        show screen aa_location_display
        $ aa_audio_event('v00', 'line', 3, phase=0)
        v "Amanhã eu pego a chave. Eu tinha pensado em você lá."
    $ aa_audio_event('v00', 'line', 4, phase=0)
    "Eu imaginei voltar para o meu quarto sem ter com quem conversar. Era mais fácil pensar nisso do que no que ela tinha acabado de ouvir."
    menu:
        "Prometer que continuo com ela e que vou à mudança.":
            $ aa_audio_event('v00', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'v00', 0)
            jump v02
        "Pedir um tempo e oferecer uma conversa, sem prometer namoro.":
            $ aa_audio_event('v00', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'v00', 1)
            $ aa_audio_event('v00', 'response', 0, 1)
            v "Tempo até quando?"
            $ aa_audio_event('v00', 'response', 1, 1)
            f "Não tenho uma data. Não quero inventar uma pra você esperar."
            $ aa_audio_event('v00', 'response', 2, 1)
            "Ela ficou em silêncio."
            $ aa_audio_event('v00', 'response', 3, 1)
            v "Tá. Hoje eu vou sozinha. Amanhã eu penso se quero conversar."
            jump k00
        "Dizer que quero terminar, sem pedir que ela me console.":
            $ aa_audio_event('v00', 'choice', 2, 2)
            $ aa_state = aa_choose(aa_state, 'v00', 2)
            $ aa_audio_event('v00', 'response', 0, 2)
            f "Eu quero terminar. Não quero pedir que você espere eu virar outra pessoa."
            $ aa_audio_event('v00', 'response', 1, 2)
            v "Então fala que terminou. Não fica dizendo que é por mim."
            jump v01

label v02:
    $ aa_node = 'v02'
    $ aa_location = '21h43 · Mesa'
    $ aa_audio_enter('v02')
    if aa_matches(aa_state, {'hesitated': True}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            $ aa_stage_action = 'Ela ainda segura a bolsa no colo enquanto ouve a promessa.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_hesita'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            $ aa_stage_action = 'Vanessa procura uma resposta que permita conservar o vínculo.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('v02', 'line', 0, phase=0)
    f "Eu continuo com você. Amanhã eu vou lá."
    $ aa_audio_event('v02', 'line', 1, phase=0)
    v "Mesmo depois de tudo que você falou?"
    if aa_matches(aa_state, {'hesitated': True}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_hesita'
        else:
            $ aa_stage_action = 'O alívio chega antes de ela devolver a bolsa ao lugar.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_hesita'
    else:
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A confirmação traz alívio incompleto.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            $ aa_stage_action = 'A confirmação traz alívio incompleto.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_pergunta'
    show screen aa_location_display
    $ aa_audio_event('v02', 'line', 2, phase=0)
    "Assenti. Vanessa soltou um pouco os ombros. A pergunta não tinha desaparecido do rosto dela."
    $ aa_audio_event('v02', 'line', 3, phase=0)
    v "Eu não acredito direito em você agora."
    $ aa_audio_event('v02', 'line', 4, phase=0)
    f "Eu sei."
    $ aa_audio_event('v02', 'line', 5, phase=0)
    v "Mas eu não quero ir pra casa achando que nunca mais vou te ver assim."
    if aa_matches(aa_state, {'hesitated': True}):
        if aa_matches(aa_state, {'route': 'juntas'}):
            $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
            $ aa_table_party = 4
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = False
            hide screen aa_phone_view
            scene cg5_pudim_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_pudim_pergunta'
        else:
            $ aa_stage_action = 'A bolsa volta ao lado da cadeira; ela decide esperar.'
            $ aa_table_party = 0
            $ aa_phone_pov = False
            $ aa_phone_kind = ''
            $ aa_dialogue_side = True
            hide screen aa_phone_view
            scene cg5_dois_pergunta at aa_camera(1.0, 0.5, 0.5)
            with Dissolve(0.25)
            $ aa_last_art = 'cg5_dois_pergunta'
        show screen aa_location_display
        $ aa_audio_event('v02', 'line', 6, phase=0)
        "Ela deixou a bolsa ao lado da cadeira. Eu devia ter sentido o peso da promessa. Primeiro senti alívio."
    $ aa_audio_event('v02', 'line', 7, phase=0)
    v "Fica aqui até a conta. Por favor."
    jump k00

label v01:
    $ aa_node = 'v01'
    $ aa_location = '21h43 · Salão'
    $ aa_audio_enter('v01')
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg5_pudim_hesita at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_pudim_hesita'
    else:
        $ aa_stage_action = 'A saída se prepara com hesitação; ninguém desaparece antes de levantar.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg5_dois_hesita at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg5_dois_hesita'
    show screen aa_location_display
    if aa_matches(aa_state, {'bond': 'indefinido'}):
        $ aa_audio_event('v01', 'line', 0, phase=0)
        v "Eu vou embora hoje. Não consigo decidir o resto sentada aqui."
    if aa_matches(aa_state, {'bond': 'terminado'}):
        $ aa_audio_event('v01', 'line', 1, phase=0)
        v "Então terminou. Eu ouvi. Só não fica voltando atrás para eu te acalmar."
    $ aa_audio_event('v01', 'line', 2, phase=0)
    "Ela mandou uma mensagem para a mãe. Pediu que ficasse acordada até ela chegar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Pagamento com os quatro à mesa.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_pagamento at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_pagamento'
    else:
        $ aa_stage_action = 'Vanessa paga ainda sentada.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = True
        hide screen aa_phone_view
        scene cg2_pagamento at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_pagamento'
    show screen aa_location_display
    $ aa_audio_event('v01', 'line', 3, phase=0)
    "Chamou o garçom e pagou o que tinha pedido. Eu ofereci pagar. Ela disse que já estava passando o cartão."
    $ aa_audio_event('v01', 'line', 4, phase=0)
    v "Eu vou pedir a matéria pra outra pessoa amanhã. Se eu falar com você cedo, vou acabar fingindo que não aconteceu."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_stage_action = 'Levanta com uma bolsa e seu casaco.'
        $ aa_table_party = 4
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg4_pudim_levantar_corrigida at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg4_pudim_levantar_corrigida'
    else:
        $ aa_stage_action = 'Ela leva bolsa e casaco.'
        $ aa_table_party = 0
        $ aa_phone_pov = False
        $ aa_phone_kind = ''
        $ aa_dialogue_side = False
        hide screen aa_phone_view
        scene cg2_levantar at aa_camera(1.0, 0.5, 0.5)
        with Dissolve(0.25)
        $ aa_last_art = 'cg2_levantar'
    show screen aa_location_display
    $ aa_audio_event('v01', 'line', 5, phase=0)
    "Vanessa pegou o casaco e a bolsa. Ficou um instante segurando o encosto antes de se afastar."
    if aa_matches(aa_state, {'route': 'juntas'}):
        $ aa_audio_event('v01', 'line', 6, phase=0)
        "Yasmin e Joãozão continuaram sentados. Vanessa manteve os olhos na saída."
    if aa_matches(aa_state, {'route': {'ne': 'juntas'}}):
        $ aa_audio_event('v01', 'line', 7, phase=0)
        "Ela passou pela outra mesa sem parar."
    menu:
        "Deixar ela sair.":
            $ aa_audio_event('v01', 'choice', 0, 0)
            $ aa_state = aa_choose(aa_state, 'v01', 0)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa ausente; Yasmin e Joãozão permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_tres'
            else:
                $ aa_stage_action = 'Vanessa saiu fisicamente.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sozinho'
            jump k00
        "Chamar por ela alto, obrigando o salão a olhar.":
            $ aa_audio_event('v01', 'choice', 1, 1)
            $ aa_state = aa_choose(aa_state, 'v01', 1)
            if aa_matches(aa_state, {'route': 'juntas'}):
                $ aa_stage_action = 'Vanessa ausente; Yasmin e Joãozão permanecem.'
                $ aa_table_party = 3
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg4_pudim_tres at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg4_pudim_tres'
            else:
                $ aa_stage_action = 'Vanessa saiu fisicamente.'
                $ aa_table_party = 0
                $ aa_phone_pov = False
                $ aa_phone_kind = ''
                $ aa_dialogue_side = False
                hide screen aa_phone_view
                scene cg2_sozinho at aa_camera(1.0, 0.5, 0.5)
                with Dissolve(0.25)
                $ aa_last_art = 'cg2_sozinho'
            jump k00
