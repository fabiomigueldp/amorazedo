# Personagens e estado de uma partida. Atribuições por cópia preservam rollback.
init python:
    import json
    from story_model import new_state as aa_new_state
    from story_model import matches as aa_matches
    from story_model import choose as aa_apply_choice
    with renpy.file("story.json") as aa_data_file:
        aa_nodes = json.load(aa_data_file)

    def aa_choose(state, node_id, index):
        result = aa_apply_choice(state, aa_nodes[node_id], index)
        aa_history_choice.add_history("adv", "Escolha", aa_nodes[node_id]['choices'][index]['text'])
        return result

define f = Character("Feka", color="#cad77e")
define v = Character("Vanessa", color="#edb3bf")
define y = Character("Yasmin", color="#e8c593")
define j = Character("Joãozão", color="#aabed4")

default aa_state = aa_new_state()
default aa_node = "a00"
default aa_location = ""
default aa_last_art = ""

screen aa_cg_continue():
    frame:
        xalign 0.97
        yalign 0.92
        padding (14, 8)
        background Solid("#171118d9")
        text "Clique para continuar":
            size 17
            color "#eee7df"

style choice_vbox:
    ypos 330

style choice_button:
    background Solid("#211721ed")
    hover_background Solid("#4b3c49")
    padding (20, 12)
    yminimum 50

style choice_button_text:
    idle_color "#f3e8df"
    hover_color "#e0ecab"

# A interface de leitura e os controles são os nativos do Ren'Py.
screen aa_location_display():
    frame:
        xpos (418 if aa_phone_kind and not aa_phone_pov and aa_phone_kind not in ("foto", "foto_hesita", "visita") else 24)
        ypos 20
        padding (14, 8)
        background Solid("#171118d9")
        text (aa_fm.stamp(aa_world["now"]) + " · " + aa_location.split(" · ", 1)[-1]):
            size 17
            color "#e6d8df"

# Arte conceitual existente, sem recorte ou processamento do arquivo.
image aa_menu = Composite((1280, 720), (0, 0), Solid("#231920"), (670, 0), Transform("images/capa.png", size=(480, 720)))
