# Small runtime regression for menus whose bank predicates change in place.
init python:
    class AAArcDraw:
        def __init__(self, value):
            self.value = value
        def randrange(self, start, stop):
            return self.value

    def aa_qa_arc_win():
        global aa_world
        aa_world = aa_cm.start(aa_world, "crash", 12000, None, AAArcDraw(486000), 0)
        aa_world = aa_cm.crash_advance(aa_world, 1, aa_cm.crash_time(150), True)
        renpy.restart_interaction()

label qa_financial_arc_fixture:
    $ aa_world_start()
    $ aa_state = dict(aa_new_state(), debt=True, route="separadas", trust=3, tender_lie=True, chosen_vanessa=True, bond="mantido", contact="juntos", promised=True)
    $ aa_phone_memory = ()
    $ aa_trace = []
    $ aa_audio_reset()
    jump k00

testsuite aa_financial_arcs_test:
    setup:
        $ _test.timeout = 12.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/financial-arcs"
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        exit
    testcase paid_dinner_and_shared_ride:
        run Start("qa_financial_arc_fixture")
        advance until screen "choice"
        assert eval not aa_choice_visible("Pagar a conta dos dois com meu saldo.")
        run Function(aa_qa_arc_win)
        assert eval aa_choice_visible("Pagar a conta dos dois com meu saldo.")
        assert eval not aa_choice_visible("Pedir dinheiro emprestado a Joãozão.")
        click "Pagar a conta dos dois com meu saldo."
        advance until eval aa_node == "k01" and renpy.get_screen("choice")
        assert eval aa_world["balance"] == 0
        assert eval aa_state["dinner_agreement_kept"]
        click "Perguntar se Vanessa quer voltar comigo para a moradia."
        advance until eval aa_node == "h02" and renpy.get_screen("choice")
        assert eval not aa_choice_visible("Confirmar o convite e chamar o carro para os dois.")
        screenshot "ride-choice.png"
        click "Confirmar o convite e perguntar se Vanessa pode chamar o carro."
        advance until eval aa_node == "h03" and renpy.get_screen("choice")
        click "Oferecer o ombro e deixar a mão junto da dela."
        advance until eval aa_node == "h04"
        assert eval aa_state["sleepover"] and aa_state["ride_payer"] == "vanessa"
        assert eval "ride_vanessa" in aa_world["events"] and "ride_home" not in aa_world["events"]
        assert eval not aa_world["debts"] and aa_world["balance"] == 0

    testcase zero_balance_has_an_honest_exit:
        run Start("qa_financial_arc_fixture")
        advance until screen "choice"
        $ aa_world = aa_cm.start(aa_world, "crash", 12000, None, AAArcDraw(1000000), 0)
        run Function(renpy.restart_interaction)
        assert eval not aa_choice_visible("Aceitar que Vanessa complete o dinheiro e combinar a devolução.")
        click "Dizer que falta dinheiro até para minha parte e falar com o gerente."
        advance until eval aa_node == "k01" and renpy.get_screen("choice")
        assert eval aa_state["money_breach"] and aa_state["trust"] == 2
        assert eval aa_world["debts"]["restaurant"]["amount"] == 9000
        assert eval not aa_choice_visible("Perguntar se Vanessa quer voltar comigo para a moradia.")
