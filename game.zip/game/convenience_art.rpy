# Conveniência C1.0. Gerado por tools/build_convenience.py.
# Cenário disponível para novas cenas; não altera rotas existentes.
image bg_conveniencia_fachada_entardecer = Transform("images/conveniencia-v1/bg_conveniencia_fachada_entardecer.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_salao_entardecer = Transform("images/conveniencia-v1/bg_conveniencia_salao_entardecer.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_corredor = Transform("images/conveniencia-v1/bg_conveniencia_corredor.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_geladeiras = Transform("images/conveniencia-v1/bg_conveniencia_geladeiras.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_cafe = Transform("images/conveniencia-v1/bg_conveniencia_cafe.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_caixa = Transform("images/conveniencia-v1/bg_conveniencia_caixa.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_vitrine = Transform("images/conveniencia-v1/bg_conveniencia_vitrine.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_vestibulo = Transform("images/conveniencia-v1/bg_conveniencia_vestibulo.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_banheiro = Transform("images/conveniencia-v1/bg_conveniencia_banheiro.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_estoque = Transform("images/conveniencia-v1/bg_conveniencia_estoque.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_fachada_noite = Transform("images/conveniencia-v1/bg_conveniencia_fachada_noite.png", xysize=(1280, 720), fit="cover")
image bg_conveniencia_salao_noite = Transform("images/conveniencia-v1/bg_conveniencia_salao_noite.png", xysize=(1280, 720), fit="cover")
