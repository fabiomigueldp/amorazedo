# Sound direction: persistent beds, finite Foley, no dialogue generation.
default aa_audio_room = None
default aa_audio_deck = 0
default aa_audio_family = None
default aa_audio_previous_node = None
default aa_audio_current_node = None
default aa_audio_pending = None
default aa_audio_last_event = None
default aa_audio_mix_mode = None
default aa_audio_gallery_active = False
default persistent.aa_reduced_music = False

init -5 python:
    for _aa_channel, _aa_mixer, _aa_loop in [
        ('aa_room0', 'ambience', True), ('aa_room1', 'ambience', True),
        ('aa_details', 'ambience', True), ('aa_foley', 'sfx', False),
        ('aa_water', 'sfx', False), ('aa_ui', 'sfx', False),
        ('aa_audition', 'sfx', False)]:
        renpy.music.register_channel(_aa_channel, mixer=_aa_mixer, loop=_aa_loop)

init python:
    import json as aa_audio_json
    with renpy.file('audio_manifest.json') as aa_audio_source:
        aa_sound_data = aa_audio_json.load(aa_audio_source)
    aa_sound_assets = aa_sound_data['assets']
    aa_sound_events = {}
    for _aa_event in aa_sound_data['events']:
        _aa_key = (_aa_event['node'], _aa_event['scope'], _aa_event['index'],
                   _aa_event['choice_index'], _aa_event['phase'])
        aa_sound_events.setdefault(_aa_key, []).append(_aa_event)
    aa_sound_channels = ('music', 'aa_room0', 'aa_room1', 'aa_details', 'aa_foley', 'aa_water')

    def aa_audio_path(ident):
        return aa_sound_assets[ident]['path']

    def aa_audio_display_name(ident):
        if not ident.startswith('M'):
            return aa_sound_assets[ident]['name']
        titles = {'M01': 'Expectativa doméstica', 'M02': 'Atenção presa',
                  'M03': 'Entre casa e jantar', 'M04': 'Casa do Pátio',
                  'M05': 'A conta e o tempo restante', 'M06': 'O que continua depois',
                  'M07': 'Trabalho da mudança', 'M08': 'A imagem publicada',
                  'M09': 'Menu principal', 'M10': 'Encerramento', 'M11': 'Aconchego · perto, por enquanto'}
        version = ident[4:].replace('_', ' ').replace('peca', 'peça').replace('saida', 'saída')
        return titles[ident[:3]] + ' · ' + version

    def aa_audio_transients():
        for channel in ('aa_foley', 'aa_water'):
            renpy.music.stop(channel=channel, fadeout=.08)

    def aa_audio_reset():
        global aa_audio_room, aa_audio_family, aa_audio_pending, aa_audio_current_node
        global aa_audio_previous_node, aa_audio_last_event, aa_audio_mix_mode
        for channel in aa_sound_channels + ('aa_audition',):
            renpy.music.set_pause(False, channel=channel)
            renpy.music.stop(channel=channel, fadeout=.25)
        aa_audio_room = aa_audio_family = aa_audio_pending = None
        aa_audio_current_node = aa_audio_previous_node = aa_audio_last_event = None
        aa_audio_mix_mode = None

    def aa_audio_music(family, force=False):
        global aa_audio_family
        if family == 'SEM': family = None
        if family == aa_audio_family and not force:
            return
        aa_audio_family = family
        if not family:
            renpy.music.stop(channel='music', fadeout=1.2)
            return
        reduced = persistent.aa_reduced_music
        variants = {
            'M01': ['M01_reduzida' if reduced else 'M01_base'],
            'M02': ['M02_reduzida' if reduced else 'M02_base'],
            'M03': ['M03_base'],
            'M04': ['M04_peca_a', 'M04_peca_b', 'M04_peca_c'],
            'M05': ['M05_muito_reduzida' if reduced else 'M05_esparsa'],
            'M06': ['M06_vazia' if aa_audio_current_node in ('e00', 'e05', 'e06') else
                    'M06_suspensa' if aa_audio_current_node in ('e01', 'e04') else 'M06_neutra'],
            'M07': ['M07_reduzida' if reduced else 'M07_base'],
            'M08': ['M08_reduzida' if reduced else 'M08_base'],
            'M09': ['M09_reduzida' if reduced else 'M09_base'],
            'M10': ['M10_base'],
            'M11': ['M11_reduzida' if reduced else 'M11_base'],
        }
        files = []
        for ident in variants[family]:
            files.extend([aa_audio_path(ident), '<silence 1.5>'])
        renpy.music.play(files, channel='music', loop=True, fadeout=1.0, fadein=1.5,
                         relative_volume=.55 if family == 'M04' else 1.0)

    def aa_audio_refresh_music():
        aa_audio_music(aa_audio_family, force=True)

    def aa_audio_ambient(ident):
        global aa_audio_room, aa_audio_deck
        if ident == 'AMB06' and aa_state.get('route') == 'juntas':
            ident = 'AMB07'
        if ident == aa_audio_room:
            return
        aa_audio_transients()
        old = 'aa_room%d' % aa_audio_deck
        aa_audio_deck = 1 - aa_audio_deck
        channel = 'aa_room%d' % aa_audio_deck
        renpy.music.stop(channel=old, fadeout=.8)
        renpy.music.play(aa_audio_path(ident), channel=channel, loop=True, fadein=.8)
        aa_audio_room = ident
        detail = ('FX51' if ident in ('AMB01', 'AMB02', 'AMB03') else
                  'FX52' if ident in ('AMB05', 'AMB06', 'AMB07', 'AMB09', 'AMB10') else
                  'FX19' if ident in ('AMB04', 'AMB11') else None)
        if detail:
            renpy.music.play(['<silence 27>', aa_audio_path(detail), '<silence 18>'],
                             channel='aa_details', loop=True, fadeout=.4, relative_volume=.3)
        else:
            renpy.music.stop(channel='aa_details', fadeout=.6)

    def aa_audio_play_event(event):
        global aa_audio_last_event
        aa_audio_last_event = event['id']
        if event.get('ambient'):
            aa_audio_ambient(event['ambient'])
        if event.get('music'):
            aa_audio_music(event['music'])
        if event.get('file') and not renpy.is_skipping():
            channel = 'aa_water' if event['id'] in ('Q002', 'Q082') else 'aa_foley'
            renpy.music.play(event['file'], channel=channel, loop=False, fadeout=.04,
                             relative_volume=event.get('gain', 1.0))

    def aa_audio_enter(node):
        global aa_audio_current_node, aa_audio_previous_node, aa_audio_pending
        aa_audio_previous_node = aa_audio_current_node
        aa_audio_current_node = node
        aa_audio_transients()
        renpy.music.set_volume(1.0, delay=.3, channel='music')
        scene = aa_sound_data['scenes'][node]
        aa_audio_ambient(scene['ambient'])
        music = scene['music']
        if node in ('a01', 'k00', 'e00', 'e08'):
            music = 'SEM'
        aa_audio_music(music)
        if aa_audio_pending:
            aa_audio_play_event(aa_audio_pending)
            aa_audio_pending = None

    def aa_audio_event(node, scope, index, choice=None, phase=0):
        global aa_audio_pending
        if scope == 'response' and aa_audio_pending:
            aa_audio_play_event(aa_audio_pending)
            aa_audio_pending = None
        if phase:
            aa_audio_transients()
        if (node, scope, index, phase) == ('a00', 'line', 4, 0):
            # The finite tap may already have closed; never duplicate that closure.
            position = renpy.music.get_pos(channel='aa_water')
            active = renpy.music.is_playing(channel='aa_water') and (position is None or position < 5.55)
            renpy.music.stop(channel='aa_water', fadeout=.08)
            if active and not renpy.is_skipping():
                renpy.music.play([aa_audio_path('FX08'), aa_audio_path('FX09')],
                                 channel='aa_foley', loop=False)
                return
        if (node, scope, index) == ('a02', 'line', 5):
            renpy.music.set_volume(.6, delay=.8, channel='music')
        if (node, scope, index) == ('k00', 'line', 1):
            aa_audio_music('M05')
        if (node, scope, index, phase) == ('e00', 'line', 2, 1):
            aa_audio_music('M06')
        for event in aa_sound_events.get((node, scope, index, choice, phase), []):
            if not aa_matches(aa_state, event['when']):
                continue
            if event['id'] == 'Q008' and aa_audio_previous_node != 'a00':
                continue
            if scope == 'choice':
                aa_audio_pending = event
            else:
                aa_audio_play_event(event)

    def aa_audio_ending():
        aa_audio_transients()
        aa_audio_music('M10')

    def aa_audio_main_menu():
        # Reopening the menu from preferences must not restart its current track.
        if aa_audio_family == 'M09' and renpy.music.is_playing(channel='music'):
            return
        aa_audio_reset()
        aa_audio_music('M09')

    def aa_audio_interact():
        global aa_audio_mix_mode
        if aa_audio_gallery_active and not renpy.get_screen('aa_sound_library'):
            aa_audio_gallery_close()
        mode = (bool(renpy.context()._menu and not main_menu), bool(renpy.is_skipping()))
        if mode != aa_audio_mix_mode:
            aa_audio_mix_mode = mode
            renpy.music.set_volume(.5 if mode[0] else 1.0, delay=.15, channel='music')
            for channel in ('aa_room0', 'aa_room1', 'aa_details'):
                renpy.music.set_volume(.65 if mode[0] else 1.0, delay=.15, channel=channel)
        if any(mode):
            aa_audio_transients()

    def aa_audio_after_load():
        global aa_audio_pending, aa_audio_mix_mode
        aa_audio_pending = None
        aa_audio_mix_mode = None
        aa_audio_transients()
        renpy.music.stop(channel='aa_audition')
        # Old saves have no sound state. Initialize their current scene once.
        if aa_audio_room is None:
            aa_audio_enter(aa_node)

    def aa_audio_gallery_open():
        global aa_audio_gallery_active
        aa_audio_gallery_active = True
        for channel in aa_sound_channels:
            renpy.music.set_pause(True, channel=channel)

    def aa_audio_gallery_close():
        global aa_audio_gallery_active
        aa_audio_gallery_active = False
        renpy.music.stop(channel='aa_audition', fadeout=.15)
        for channel in aa_sound_channels:
            renpy.music.set_pause(False, channel=channel)

    config.interact_callbacks.append(aa_audio_interact)
    config.after_load_callbacks.append(aa_audio_after_load)

define config.sample_sound = 'audio/effects/FX27.ogg'
style button:
    activate_sound 'audio/effects/UI01.ogg'
style return_button:
    activate_sound 'audio/effects/UI02.ogg'

screen aa_sound_library():
    tag menu
    on 'show' action Function(aa_audio_gallery_open)
    on 'hide' action Function(aa_audio_gallery_close)
    on 'replaced' action Function(aa_audio_gallery_close)
    default category = 'M'
    use game_menu(_('Biblioteca sonora'), scroll='viewport', audio_panel=True):
        vbox:
            spacing 12
            text _('As faixas e efeitos podem antecipar locais e ações da história.') size 19
            hbox:
                spacing 18
                for prefix, title in [('M', 'Músicas'), ('AMB', 'Ambientes'), ('FX', 'Efeitos'), ('UI', 'Interface')]:
                    textbutton title action [Stop('aa_audition'), SetScreenVariable('category', prefix)]
                textbutton _('Parar') action Stop('aa_audition')
            for ident in sorted(aa_sound_assets):
                if ident.startswith(category):
                    $ item = aa_sound_assets[ident]
                    textbutton aa_audio_display_name(ident):
                        action Play('aa_audition', item['path'], loop=False)
                        text_size 20
