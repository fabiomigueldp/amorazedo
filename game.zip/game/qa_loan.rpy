# Regressão focal do empréstimo: 3 rotas x 3 decisões.
label qa_loan_setup:
    $ aa_state = aa_new_state()
    $ aa_state.update(route=qa_loan_route, debt=True, v_gone=False, heat=qa_loan_heat)
    jump k00

testsuite aa_loan:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/loan"
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu"
    teardown:
        exit

    testcase juntas_0:
        $ qa_loan_route = 'juntas'
        $ qa_loan_heat = 0
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Assumir os sessenta reais e combinar amanhã até meio-dia."
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "emprestimo_pix"
        assert eval aa_state["bill"] == "emprestimo"
        pause 0.3
        screenshot "juntas_0_pix.png"
        advance
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'emprestimo'
        assert not screen "aa_phone_view"

    testcase juntas_1:
        $ qa_loan_route = 'juntas'
        $ qa_loan_heat = 2
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Aceitar, mas pedir que ele não fique cobrando na frente dos outros."
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "emprestimo_pix"
        assert eval aa_state["bill"] == "emprestimo"
        pause 0.3
        screenshot "juntas_1_pix.png"
        advance
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'emprestimo'
        assert not screen "aa_phone_view"

    testcase juntas_2:
        $ qa_loan_route = 'juntas'
        $ qa_loan_heat = 0
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Desistir do empréstimo e dividir a conta com Vanessa."
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'admitida'
        assert not screen "aa_phone_view"

    testcase separadas_0:
        $ qa_loan_route = 'separadas'
        $ qa_loan_heat = 0
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Assumir os sessenta reais e combinar amanhã até meio-dia."
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "emprestimo_pix"
        assert eval aa_state["bill"] == "emprestimo"
        pause 0.3
        screenshot "separadas_0_pix.png"
        advance
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'emprestimo'
        assert not screen "aa_phone_view"

    testcase separadas_1:
        $ qa_loan_route = 'separadas'
        $ qa_loan_heat = 2
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Aceitar, mas pedir que ele não fique cobrando na frente dos outros."
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "emprestimo_pix"
        assert eval aa_state["bill"] == "emprestimo"
        pause 0.3
        screenshot "separadas_1_pix.png"
        advance
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'emprestimo'
        assert not screen "aa_phone_view"

    testcase separadas_2:
        $ qa_loan_route = 'separadas'
        $ qa_loan_heat = 0
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Desistir do empréstimo e dividir a conta com Vanessa."
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'admitida'
        assert not screen "aa_phone_view"

    testcase varanda_0:
        $ qa_loan_route = 'varanda'
        $ qa_loan_heat = 0
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Assumir os sessenta reais e combinar amanhã até meio-dia."
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "emprestimo_pix"
        assert eval aa_state["bill"] == "emprestimo"
        pause 0.3
        screenshot "varanda_0_pix.png"
        advance
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'emprestimo'
        assert not screen "aa_phone_view"

    testcase varanda_1:
        $ qa_loan_route = 'varanda'
        $ qa_loan_heat = 2
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Aceitar, mas pedir que ele não fique cobrando na frente dos outros."
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "emprestimo_pix"
        assert eval aa_state["bill"] == "emprestimo"
        pause 0.3
        screenshot "varanda_1_pix.png"
        advance
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'emprestimo'
        assert not screen "aa_phone_view"

    testcase varanda_2:
        $ qa_loan_route = 'varanda'
        $ qa_loan_heat = 0
        run Start("qa_loan_setup")
        advance until screen "choice"
        click "Pedir dinheiro emprestado a Joãozão."
        assert eval aa_node == "jl00" timeout 5.0
        assert eval aa_state["bill"] == "pedido_joaozao"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_node == "jl00"
        click "Desistir do empréstimo e dividir a conta com Vanessa."
        advance until screen "choice"
        assert eval aa_node == "k01"
        assert eval aa_state["bill"] == 'admitida'
        assert not screen "aa_phone_view"
