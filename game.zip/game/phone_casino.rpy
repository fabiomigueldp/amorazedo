# Mesa shares the campaign wallet. No balance or outcome lives in UI preferences.
init -4 python:
    renpy.music.register_channel("aa_casino_fx", mixer="sfx", loop=False)

init python:
    import casino_model as aa_cm

    AA_CASINO_COPY = {
        "blackjack": ("Chegue mais perto de 21.", "blackjack-art"),
        "roulette": ("Uma bola. 37 possibilidades.", "wheel"),
        "slots": ("Três rolos, cinco símbolos.", "seven"),
        "dice": ("Escolha a soma dos dados.", "die-5"),
        "mines": ("Revele. Decida quando parar.", "gem"),
    }
    AA_CASINO_RULES = {
        "blackjack": (
            ("O objetivo", "Some mais que a mesa sem passar de 21. Ás vale 1 ou 11; figuras valem 10. Um baralho de 52 cartas é embaralhado a cada rodada."),
            ("Suas decisões", "Pedir recebe uma carta. Parar encerra sua mão. Dobrar exige mais uma aposta igual, dá uma única carta e encerra a mão. Disponível só nas duas primeiras cartas."),
            ("A mesa", "Compra até 16 e para em qualquer 17, inclusive com ás valendo 11. Esta mesa não oferece divisão de pares nem seguro."),
            ("Retornos", "Vitória: 2× a aposta. Blackjack natural: 2,5×. Empate: 1×, devolvendo a aposta. Derrota: zero. Blackjack natural vence um 21 com mais cartas.")),
        "roulette": (
            ("Roleta europeia", "Uma única casa zero e números de 1 a 36. Cada número tem chance de 1 em 37. Cada rodada é independente."),
            ("Apostas simples", "Vermelho, preto, par, ímpar, 1–18 e 19–36 retornam 2×. O zero perde em todas essas apostas. Chance de ganhar: 18 em 37."),
            ("Número exato", "Escolha de 0 a 36. Acertar retorna 36×. Chance de ganhar: 1 em 37. Uma única aposta por giro."),
            ("Retorno teórico", "97,30% em ambas as modalidades, considerando muitas rodadas. Isso não prevê o resultado de uma sessão.")),
        "slots": (
            ("Três rolos independentes", "Cada rolo tem 20 posições: 6 cerejas, 5 limões, 4 barras, 3 sinos e 2 setes. Todas as posições são igualmente prováveis."),
            ("Três símbolos iguais", "Cerejas: 4× · Limões: 8× · Barras: 12× · Sinos: 30× · Setes: 100×."),
            ("Duas cerejas", "Exatamente duas cerejas, em qualquer posição, retornam 2×. As demais combinações não retornam dinheiro."),
            ("Retorno teórico", "90,825% ao longo de muitas rodadas. Os rolos não mudam suas chances conforme o saldo ou resultados anteriores.")),
        "dice": (
            ("Dois dados", "Dois dados independentes de seis faces. Existem 36 pares igualmente prováveis."),
            ("Escolha uma faixa", "Soma menor que 7 ou maior que 7: retorno de 2,3×, com 15 chances em 36. Soma igual a 7: retorno de 5,7×, com 6 chances em 36."),
            ("Retorno teórico", "95,83% nas faixas e 95% no sete, antes de arredondar os centavos. Os valores são arredondados para baixo ao centavo.")),
        "mines": (
            ("25 casas", "Escolha 1, 3 ou 5 minas. As posições são sorteadas ao apostar e permanecem iguais durante a rodada. Fechar o app não troca o campo."),
            ("Revelar ou recolher", "Cada casa segura aumenta o retorno. Encontrar uma mina perde a aposta inteira. Recolha a qualquer momento; antes da primeira casa, a aposta é devolvida."),
            ("Como é calculado", "Depois de k casas seguras, o multiplicador é 0,97 × C(25,k) ÷ C(25−m,k), sendo m o número de minas. O retorno é arredondado para baixo ao centavo."),
            ("Última casa segura", "Ao abrir todas as casas seguras, o retorno é recolhido automaticamente. A próxima chance e o próximo retorno aparecem antes de cada decisão.")),
    }

    def aa_casino_art(name):
        return AA_PHONE_ASSETS + "casino/" + name + ".svg"

    def aa_casino_set(**values):
        if not renpy.get_screen("aa_phone_hub"):
            return
        if "scroll" in values:
            screen = renpy.get_screen("aa_phone_hub")
            if screen:
                # Viewport replacement copies the old offset into a new
                # adjustment. Reset the displayed one before replacing it.
                screen.scope["casino_scroll"].change(0)
        for key, value in values.items():
            renpy.set_screen_variable("casino_" + key, value, "aa_phone_hub")
        renpy.restart_interaction()

    def aa_casino_nav(view):
        renpy.set_editable_input_value(None, False)
        aa_casino_set(view=view, panel=None, record=None, error="", busy=None, scroll=ui.adjustment())

    def aa_casino_panel(panel):
        aa_casino_set(panel=panel, scroll=ui.adjustment())

    def aa_casino_bet_text(cents):
        return "%d,%02d" % (cents // 100, cents % 100)

    def aa_casino_parse(text):
        return aa_cm.parse_stake(text)

    def aa_casino_scope():
        screen = renpy.get_screen("aa_phone_hub")
        return screen.scope if screen else {}

    def aa_casino_audio(name):
        if aa_phone_pref("casino_sound", True):
            renpy.music.play("audio/casino/" + name + ".wav", channel="aa_casino_fx", relative_volume=.7)

    def aa_casino_silence():
        renpy.music.stop(channel="aa_casino_fx", fadeout=.06)

    def aa_casino_toggle_audio():
        aa_casino_silence()
        aa_phone_set_pref("casino_sound", not aa_phone_pref("casino_sound", True))

    def aa_casino_begin_visual(r):
        duration = {"roulette": .95, "slots": 1.0, "dice": .65, "blackjack": .35, "mines": .12}[r["game"]] if persistent.aa_motion else .01
        aa_casino_set(busy=(r["id"], r["revision"]), started=aa_casino_time.monotonic(), duration=duration, error="", scroll=ui.adjustment())
        aa_casino_audio("deal" if r["game"] == "blackjack" else "reveal" if r["game"] == "mines" else "roll")

    def aa_casino_finish_visual(token):
        if aa_casino_scope().get("casino_busy") != token:
            return
        aa_casino_set(busy=None)
        r = aa_cm.state(aa_world)["round"]
        if r and r["status"] == "done":
            aa_casino_audio("finish")

    def aa_casino_visual(game, data, width, height, busy=None):
        scope = aa_casino_scope()
        return AACasinoVisual(game, data or {}, width, height,
            scope.get("casino_started") if busy else None, scope.get("casino_duration", 0) if busy else 0)

    def aa_casino_open_record(ident):
        aa_casino_nav("history")
        aa_casino_set(panel="record", record=ident)

    def aa_casino_choose_number(number):
        aa_casino_set(roulette=number, panel=None, scroll=ui.adjustment())

    def aa_casino_bank(ident=None):
        aa_phone_go("bank")
        if ident:
            aa_bank_nav("history", ("transaction", ident))

    def aa_casino_commit(game, amount, option, sequence):
        global aa_world, aa_state
        if aa_casino_scope().get("casino_busy"):
            return
        renpy.set_editable_input_value(None, False)
        try:
            updated = aa_cm.start(aa_world, game, aa_casino_parse(amount), option, renpy.random, sequence)
        except aa_cm.CasinoError as error:
            aa_casino_set(error=str(error))
            return
        aa_world = updated
        aa_state = aa_financial_state(aa_state, aa_world)
        for key, value in (("casino_amount", amount), ("casino_" + game, option)):
            setattr(aa_phone_preferences, key, value)
        aa_casino_begin_visual(aa_cm.state(aa_world)["round"])
        renpy.retain_after_load()

    def aa_casino_act(ident, revision, action, cell=None):
        global aa_world, aa_state
        if aa_casino_scope().get("casino_busy"):
            return
        try:
            aa_world = aa_cm.act(aa_world, ident, revision, action, cell)
        except aa_cm.CasinoError as error:
            aa_casino_set(error=str(error))
            return
        aa_state = aa_financial_state(aa_state, aa_world)
        aa_casino_begin_visual(aa_cm.state(aa_world)["round"])
        renpy.retain_after_load()

    def aa_casino_bet_label(option):
        return {"red": "Vermelho", "black": "Preto", "even": "Par", "odd": "Ímpar",
                "low": "1–18", "high": "19–36", "under": "Menor que 7", "over": "Maior que 7",
                "seven": "Igual a 7"}.get(option, "Número %s" % option)

    def aa_casino_signed(value):
        return ("+ " if value > 0 else "− " if value < 0 else "") + aa_pm.brl(abs(value))

style aa_casino_text is aa_hub_text:
    size 16
    color "#f3edf5"
    line_spacing 0
style aa_casino_muted is aa_casino_text:
    size 13
    color "#b9adbf"
style aa_casino_button is button:
    background aa_phone_round("casino-surface", 16)
    hover_background aa_phone_round("casino-hover", 16)
    selected_background aa_phone_round("casino-accent", 16)
    insensitive_background aa_phone_round("casino-surface", 16)
    padding (10, 12)
    yminimum 44
style aa_casino_button_text is aa_casino_text:
    size 15
    selected_color "#2c2236"
    insensitive_color "#837989"
    textalign .5
    align (.5, .5)
style aa_casino_primary is aa_casino_button:
    background aa_phone_round("casino-accent", 18)
    hover_background aa_phone_round("casino-card", 18)
style aa_casino_primary_text is aa_casino_button_text:
    font "fonts/Inter-SemiBold.ttf"
    color "#2c2236"
    hover_color "#2c2236"
    insensitive_color "#837989"

transform aa_casino_deal:
    alpha .0
    yoffset (9 if persistent.aa_motion else 0)
    easeout (.22 if persistent.aa_motion else .0) alpha 1.0 yoffset 0

