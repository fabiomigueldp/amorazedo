# Bank presentation only. Campaign events and finance_model own every cent.
init python:
    def aa_bank_art(name, tone="ink"):
        return AA_PHONE_ASSETS + "bank/" + name + "-" + tone + ".svg"

    def aa_bank_set(**values):
        screen = renpy.get_screen("aa_phone_hub")
        if not screen:
            return
        if "scroll" in values:
            screen.scope["bank_scroll"].change(0)
        for key, value in values.items():
            renpy.set_screen_variable("bank_" + key, value, "aa_phone_hub")
        renpy.restart_interaction()

    def aa_bank_nav(tab, detail=None):
        renpy.set_screen_variable("selected_entry", None, "aa_phone_hub")
        aa_bank_set(tab=tab, detail=detail, trail=(), search=False, query="", limit=40, scroll=ui.adjustment())

    def aa_bank_open_detail(kind, ident=None):
        screen = renpy.get_screen("aa_phone_hub")
        current = screen.scope.get("bank_detail") if screen else None
        trail = screen.scope.get("bank_trail", ()) if screen else ()
        aa_bank_set(detail=(kind, ident), trail=trail + ((current,) if current else ()), scroll=ui.adjustment())

    def aa_bank_back():
        screen = renpy.get_screen("aa_phone_hub")
        trail = screen.scope.get("bank_trail", ()) if screen else ()
        renpy.set_screen_variable("selected_entry", None, "aa_phone_hub")
        aa_bank_set(detail=trail[-1] if trail else None, trail=trail[:-1], scroll=ui.adjustment())

    def aa_bank_search(active):
        aa_bank_set(search=active, query="", limit=40, scroll=ui.adjustment())

    class AABankQuery(InputValue):
        def get_text(self):
            screen = renpy.get_screen("aa_phone_hub")
            return screen.scope.get("bank_query", "") if screen else ""

        def set_text(self, value):
            aa_bank_set(query=value, limit=40, scroll=ui.adjustment())

    def aa_bank_tx(ident):
        return next((t for t in aa_world["transactions"] if t["id"] == ident), None)

    def aa_bank_transactions(filter="all", query=""):
        needle = aa_pm.fold(query.strip())
        return tuple(t for t in reversed(aa_world["transactions"])
            if (filter == "all" or (t["amount"] > 0 if filter == "in" else t["amount"] < 0))
            and (not needle or needle in aa_pm.fold(" ".join((t["party"], t["title"], aa_pm.brl(abs(t["amount"])), aa_fm.stamp(t["at"]))))))

    def aa_bank_debts(paid=False):
        return tuple(sorted(((who, d) for who, d in aa_world["debts"].items()
            if (d["paid_at"] is not None) == paid), key=lambda row: -row[1]["paid_at"] if paid else row[1]["due"]))

    def aa_bank_day(at):
        distance = aa_world["now"] // 1440 - at // 1440
        return "Hoje" if distance == 0 else "Ontem" if distance == 1 else aa_fm.stamp(at).split(" · ")[0]

    def aa_bank_due(debt):
        if debt["paid_at"] is not None:
            return "Pago em " + aa_fm.stamp(debt["paid_at"])
        return ("Vencido · " if aa_world["now"] > debt["due"] else "Até ") + aa_fm.stamp(debt["due"])

    def aa_bank_signed(amount):
        return ("+ " if amount > 0 else "− " if amount < 0 else "") + aa_pm.brl(abs(amount))

    @functools.lru_cache(maxsize=256)
    def aa_bank_fit(value, width, size):
        # Money is never shortened or rounded for layout.
        while size > 12:
            measured = renpy.render(Text(value, font="fonts/Inter-Medium.ttf", size=size,
                line_spacing=0, outlines=[]), 4096, 100, 0, 0)
            if measured.width <= width:
                break
            size -= 1
        return size

    def aa_bank_tx_label(item):
        casino = item["id"].startswith("casino_")
        return ("Mesa" if casino else item["party"] or item["title"],
                item["party"] + " · " + item["title"].replace("Mesa · ", "") if casino else item["title"])

    def aa_bank_tx_icon(item):
        return ("mesa" if item["id"].startswith("casino_") else "dinner" if item["id"] == "dinner"
                else "incoming" if item["amount"] > 0 else "outgoing")

    def aa_bank_can_pay(who):
        d = aa_world["debts"].get(who)
        return bool(d and d["paid_at"] is None and aa_world["dinner_paid"] and aa_world["balance"] >= d["amount"])

    def aa_bank_payment(who):
        aa_pay_debt(who)
        # In-person repayment owns the dialogue and closes the phone. Preserve it.
        if renpy.get_screen("aa_phone_hub") and aa_bank_tx("repay_" + who):
            aa_bank_set(payments="paid")
            aa_bank_nav("payments", ("transaction", "repay_" + who))

    def aa_bank_legacy(entry):
        kind = entry["kind"]
        ident = {"emprestimo_pix": "joao_loan", "devolucao": "repay_joaozao", "devolucao_v": "repay_vanessa"}.get(kind)
        if kind == "jantar_pago":
            return ("dinner", None)
        if kind == "ajuda_v" and "vanessa" in aa_world["debts"]:
            return ("debt", "vanessa")
        return ("transaction", ident) if ident and aa_bank_tx(ident) else ("archive", entry)

    def aa_bank_dinner():
        yours = sum(-t["amount"] for t in aa_world["transactions"] if t["id"] in ("dinner", "repay_restaurant"))
        initial = aa_bank_tx("dinner")
        obligation = aa_world.get("dinner_obligation", -initial["amount"] if initial else 0)
        hers = 18000 - obligation if aa_world["dinner_paid"] else 9000 if aa_state.get("v_gone") else 0
        return yours, hers, max(0, 18000 - yours - hers)

    def aa_bank_sheet_geometry():
        height = AA_PHONE_POV_HEIGHT if aa_phone_pov else AA_PHONE_BODY_HEIGHT
        x, width = (AA_PHONE_POV_POSITION[0], aa_phone_body_size(height)[0]) if aa_phone_pov else aa_phone_geometry()
        sx, sy, sw, sh = aa_phone_screen_geometry(width, height)
        return x + sx, (AA_PHONE_POV_POSITION[1] if aa_phone_pov else 18) + sy, sw, sh

style aa_bank_text is aa_hub_text:
    size 16
    color "#eff2f1"
    line_spacing 0
style aa_bank_secondary is aa_bank_text:
    size 13
    color "#a4aaa7"
style aa_bank_title is aa_bank_text:
    font "fonts/Inter-SemiBold.ttf"
    size 31
    kerning -0.8
style aa_bank_row is button:
    background None
    hover_background aa_phone_round("bank-hover", 12)
    padding (0, 0)
    yminimum 44
style aa_bank_row_text is aa_bank_text
style aa_bank_primary is button:
    background aa_phone_round("primary", 24)
    hover_background aa_phone_round("primary-hover", 24)
    insensitive_background aa_phone_round("bank-surface", 24)
    padding (12, 14)
    yminimum 48
style aa_bank_primary_text is aa_bank_text:
    font "fonts/Inter-SemiBold.ttf"
    color "#163a2c"
    insensitive_color "#a4aaa7"
    textalign .5
    xalign .5
style aa_bank_link is aa_bank_row
style aa_bank_link_text is aa_bank_text:
    color "#b4dbc8"
    hover_color "#daf4e7"
    size 14
    yalign .5

screen aa_bank_symbol(name, size=24, tone="ink"):
    add aa_bank_art(name, tone) xysize (size, size)

screen aa_bank_control(icon, action, label):
    button:
        style "aa_bank_row"
        background aa_phone_round("bank-glass-solid" if aa_phone_pref("glass", .55) >= .95 else "bank-glass", 22)
        hover_background aa_phone_round("bank-hover", 22)
        xysize (44, 44)
        padding (11, 11)
        action action
        alt label
        use aa_bank_symbol(icon, 22)

screen aa_bank_rule(width, inset=0):
    add Solid("#303633") xpos inset xysize (width - inset, 1)

screen aa_bank_empty(width, icon, title, body):
    vbox:
        xsize width
        spacing 12
        null height 24
        add aa_bank_art(icon, "muted") xysize (34, 34) xalign .5
        text title style "aa_bank_title" size aa_phone_size(20) xalign .5 textalign .5 xmaximum width
        text body style "aa_bank_secondary" size aa_phone_size(15) xalign .5 textalign .5 xmaximum (width - 12)
        null height 24

screen aa_bank_segments(width, options, selected, field):
    frame:
        background aa_phone_round("bank-surface", 14)
        padding (3, 3)
        xsize width
        hbox:
            for value, label in options:
                textbutton label:
                    style "aa_bank_row"
                    background (aa_phone_round("bank-selected", 11) if value == selected else None)
                    xysize ((width - 6) // len(options), 44)
                    text_style "aa_bank_text"
                    text_size aa_phone_size(13)
                    text_font ("fonts/Inter-SemiBold.ttf" if value == selected else "fonts/Inter-Regular.ttf")
                    text_color ("#eff2f1" if value == selected else "#a4aaa7")
                    text_align (.5, .5)
                    action Function(aa_bank_set, **{field: value, "limit": 40, "scroll": ui.adjustment()})
                    selected value == selected

screen aa_bank_transaction_row(item, width):
    $ name, subtitle = aa_bank_tx_label(item)
    $ row_height = 68 + aa_phone_pref("text_size", 0) * 3
    $ amount_width = min(112, max(88, len(aa_bank_signed(item["amount"])) * 7))
    $ label_width = width - amount_width - 51
    button:
        style "aa_bank_row"
        xysize (width, row_height)
        action Function(aa_bank_open_detail, "transaction", item["id"])
        alt (name + ", " + subtitle + ", " + aa_bank_signed(item["amount"]) + ". Ver comprovante")
        fixed:
            xysize (width, row_height)
            frame:
                background aa_phone_round("bank-surface", 11)
                padding (7, 7)
                xysize (34, 34)
                yalign .5
                use aa_bank_symbol(aa_bank_tx_icon(item), 20, "mint" if item["amount"] > 0 else "muted")
            vbox:
                xpos 44
                yalign .5
                spacing 5
                text aa_messages_elide(name, label_width, aa_phone_size(15), 1) style "aa_bank_text" size aa_phone_size(15) xmaximum label_width
                text aa_messages_elide(subtitle, label_width, aa_phone_size(12), 2) style "aa_bank_secondary" size aa_phone_size(12) xmaximum label_width
            text aa_bank_signed(item["amount"]):
                style "aa_bank_text"
                font "fonts/Inter-Medium.ttf"
                size aa_bank_fit(aa_bank_signed(item["amount"]), amount_width, aa_phone_size(15))
                color ("#b4dbc8" if item["amount"] > 0 else "#eff2f1")
                xalign 1.0
                yalign .5
    use aa_bank_rule(width, 44)

screen aa_bank_debt_row(who, debt, width, paid=False):
    button:
        style "aa_bank_row"
        xsize width
        padding (0, 15)
        action Function(aa_bank_open_detail, "transaction" if paid else "debt", "repay_" + who if paid else who)
        alt (aa_fm.party_name(who) + ", " + aa_pm.brl(debt["amount"]) + ", " + aa_bank_due(debt))
        vbox:
            spacing 8
            fixed:
                xysize (width, 23 + aa_phone_pref("text_size", 0))
                text aa_fm.party_name(who) style "aa_bank_text" font "fonts/Inter-Medium.ttf" size aa_phone_size(17) xmaximum (width - 24)
                add aa_bank_art("chevron", "muted") xysize (14, 14) xalign 1.0 yalign .5
            text aa_pm.brl(debt["amount"]) style "aa_bank_text" size aa_phone_size(23)
            text aa_bank_due(debt) style "aa_bank_secondary" size aa_phone_size(13) color ("#e6b79e" if not paid and aa_world["now"] > debt["due"] else "#a4aaa7")
    use aa_bank_rule(width)

screen aa_bank_key_value(label, value, width, accent=False):
    vbox:
        xsize width
        spacing 4
        null height 6
        text label style "aa_bank_secondary" size aa_phone_size(13)
        text value style "aa_bank_text" size aa_phone_size(16) color ("#b4dbc8" if accent else "#eff2f1") xmaximum width
        null height 6
    use aa_bank_rule(width)

screen aa_bank_account(width):
    $ pending = aa_bank_debts()
    text "Saldo disponível" style "aa_bank_secondary" size aa_phone_size(15)
    null height 7
    $ balance = "••••••" if aa_phone_pref("bank_private", False) else aa_balance_text()
    text balance style "aa_bank_title" font "fonts/Inter-Medium.ttf" size aa_bank_fit(balance, width, aa_phone_size(37))
    null height 25
    button:
        style "aa_bank_row"
        background aa_phone_round("bank-surface", 18)
        padding (14, 15)
        xsize width
        action [Function(aa_bank_set, payments="pending"), Function(aa_bank_nav, "payments")]
        alt "Ver pagamentos pendentes"
        hbox:
            spacing 11
            add aa_bank_art("clock" if pending else "check", "mint") xysize (23, 23) yalign .5
            vbox:
                xsize (width - 77)
                spacing 5
                text ((str(len(pending)) + (" pagamento pendente" if len(pending) == 1 else " pagamentos pendentes")) if pending else "Tudo em dia") style "aa_bank_text" size aa_phone_size(15)
                text ((aa_pm.brl(sum(d["amount"] for _, d in pending)) + " para pagar") if pending else "Nenhum valor pendente") style "aa_bank_secondary" size aa_phone_size(13)
            add aa_bank_art("chevron", "muted") xysize (14, 14) yalign .5
    null height 16
    fixed:
        xysize (width, 46)
        text "Atividade recente" style "aa_bank_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17) yalign .5 xmaximum (width - 70)
        textbutton "Ver tudo" style "aa_bank_link" text_size aa_phone_size(13) xalign 1.0 yalign .5 xminimum 64 action [Function(aa_bank_set, filter="all"), Function(aa_bank_nav, "history")]
    if aa_world["transactions"]:
        for item in aa_bank_transactions()[:2]:
            use aa_bank_transaction_row(item, width)
    else:
        use aa_bank_empty(width, "history", "Sua conta, em ordem", "Pix, pagamentos e a atividade do Mesa aparecem aqui conforme você usa o dinheiro.")

screen aa_bank_payments(width, selected):
    use aa_bank_segments(width, (("pending", "Pendentes"), ("paid", "Pagos")), selected, "payments")
    null height 12
    $ debts = aa_bank_debts(selected == "paid")
    if debts:
        for who, debt in debts:
            use aa_bank_debt_row(who, debt, width, selected == "paid")
    else:
        use aa_bank_empty(width, "check" if selected == "pending" else "payments", "Tudo em dia" if selected == "pending" else "Nenhum pagamento ainda", "Você não tem pagamentos pendentes." if selected == "pending" else "Os valores que você quitar ficam reunidos aqui.")
    if aa_world["dinner_paid"] or aa_node in ("k00", "jl00", "k01"):
        null height 18
        button:
            style "aa_bank_row"
            xsize width
            padding (0, 12)
            action Function(aa_bank_open_detail, "dinner")
            alt "Conta do jantar"
            hbox:
                spacing 12
                use aa_bank_symbol("dinner", 22, "mint")
                text "Conta do jantar" style "aa_bank_text" size aa_phone_size(16) yalign .5

screen aa_bank_history(width, filter, query, search, limit):
    if search:
        frame:
            background aa_phone_round("bank-surface", 16)
            padding (12, 12)
            xsize width
            hbox:
                spacing 8
                use aa_bank_symbol("search", 20, "muted")
                input:
                    value AABankQuery()
                    length 60
                    style "aa_bank_text"
                    size aa_phone_size(16)
                    xmaximum (width - 56)
                    copypaste True
                    default_focus True
            if not query:
                text "Nome, valor ou descrição" style "aa_bank_secondary" size aa_phone_size(13) xpos 28 ypos 2
        null height 12
    use aa_bank_segments(width, (("all", "Tudo"), ("in", "Entradas"), ("out", "Saídas")), filter, "filter")
    $ entries = aa_bank_transactions(filter, query)
    if not entries:
        use aa_bank_empty(width, "search" if query else "history", "Nenhum resultado" if query else "Sem movimentações", "Tente outro nome, valor ou descrição." if query else "As movimentações desta categoria aparecerão aqui.")
    for index, item in enumerate(entries[:limit]):
        if index == 0 or item["at"] // 1440 != entries[index - 1]["at"] // 1440:
            null height 20
            text aa_bank_day(item["at"]) style "aa_bank_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(16)
            null height 4
        use aa_bank_transaction_row(item, width)
    if len(entries) > limit:
        textbutton "Mostrar anteriores" style "aa_bank_link" xfill True action Function(aa_bank_set, limit=limit + 40)

screen aa_bank_debt(who, width, interactive=True):
    $ debt = aa_world["debts"].get(who)
    if debt:
        null height 8
        use aa_phone_avatar(aa_fm.party_name(who), 48)
        null height 15
        text aa_fm.party_name(who) style "aa_bank_title" size aa_phone_size(24)
        null height 8
        text aa_pm.brl(debt["amount"]) style "aa_bank_title" size aa_bank_fit(aa_pm.brl(debt["amount"]), width, aa_phone_size(35))
        null height 8
        text ("Quitado" if debt["paid_at"] is not None else "Pagamento pendente") style "aa_bank_secondary" size aa_phone_size(14)
        null height 15
        use aa_bank_key_value("Prazo combinado", aa_bank_due(debt), width)
        if debt["paid_at"] is None:
            use aa_bank_key_value("Seu saldo disponível", aa_balance_text(), width)
            null height 20
            if interactive:
                textbutton "Continuar" style "aa_bank_primary" text_size aa_phone_size(16) xsize width sensitive aa_bank_can_pay(who) action Show("aa_transfer_confirm", who=who)
            if not aa_world["dinner_paid"]:
                null height 10
                text "O pagamento fica disponível depois de acertar o jantar." style "aa_bank_secondary" size aa_phone_size(14)
            elif aa_world["balance"] < debt["amount"]:
                null height 10
                text ("Faltam " + aa_pm.brl(debt["amount"] - aa_world["balance"]) + " para este pagamento.") style "aa_bank_secondary" size aa_phone_size(14)
        elif interactive:
            null height 16
            textbutton "Ver comprovante" style "aa_bank_link" action Function(aa_bank_open_detail, "transaction", "repay_" + who)
    else:
        use aa_bank_empty(width, "check", "Nenhum valor pendente", "Os pagamentos da sua história aparecem aqui.")

screen aa_bank_transaction(item, width, interactive=True):
    $ name, subtitle = aa_bank_tx_label(item)
    $ shortfall = item["id"] in aa_world.get("shortfalls", {})
    $ zero_expense = item["amount"] == 0 and shortfall
    null height 6
    frame:
        background aa_phone_round("bank-success", 24)
        padding (12, 12)
        xysize (48, 48)
        use aa_bank_symbol("history" if zero_expense else "check", 24, "mint")
    null height 17
    text ("Atividade registrada" if zero_expense else "Pagamento parcial" if shortfall else "Pix recebido" if item["amount"] > 0 and not item["id"].startswith("casino_") else "Pagamento concluído" if item["id"].startswith("repay_") else "Movimentação concluída") style "aa_bank_title" size aa_phone_size(24) xmaximum width
    null height 10
    text aa_pm.brl(abs(item["amount"])) style "aa_bank_title" size aa_bank_fit(aa_pm.brl(abs(item["amount"])), width, aa_phone_size(35))
    null height 12
    use aa_bank_key_value("Referente a" if zero_expense else "De" if item["amount"] > 0 else "Para", name, width)
    use aa_bank_key_value("Descrição", subtitle, width)
    use aa_bank_key_value("Data e hora", aa_fm.stamp(item["at"]), width)
    use aa_bank_key_value("Saldo após a movimentação", "••••••" if aa_phone_pref("bank_private", False) else aa_pm.brl(item["balance"]), width)
    if item["id"] == "joao_loan" and "joaozao" in aa_world["debts"]:
        null height 15
        text ("Combinado com Joãozão: " + aa_bank_due(aa_world["debts"]["joaozao"]).lower() + ".") style "aa_bank_secondary" size aa_phone_size(14)
    if interactive:
        null height 12
        if item["id"].startswith("casino_"):
            $ round_id = int(item["id"].split("_")[1])
            textbutton "Ver no Mesa" style "aa_bank_link" xfill True action [Function(aa_phone_go, "casino"), Function(aa_casino_open_record, round_id)]
        elif item["id"] in ("dinner", "repay_restaurant"):
            textbutton "Conta do jantar" style "aa_bank_link" xfill True action Function(aa_bank_open_detail, "dinner")
        elif any(t["title"] == item["party"] for t in aa_phone_threads()):
            textbutton "Ver conversa" style "aa_bank_link" xfill True action Function(aa_phone_open, contact=item["party"])

screen aa_bank_bill(width):
    $ yours, hers, remaining = aa_bank_dinner()
    null height 6
    add aa_bank_art("dinner", "mint") xysize (36, 36)
    null height 17
    text "Casa do Pátio" style "aa_bank_title" size aa_phone_size(25)
    null height 6
    text "Serviço e sobremesa incluídos" style "aa_bank_secondary" size aa_phone_size(14)
    null height 20
    for label, value in (("Feka", 9000), ("Vanessa", 9000), ("Total do jantar", 18000), ("Pago por você", yours), ("Pago por Vanessa", hers), ("Restante", remaining)):
        fixed:
            xysize (width, 46 + aa_phone_pref("text_size", 0) * 2)
            text label style "aa_bank_secondary" size aa_phone_size(14) yalign .5 xmaximum (width - 110)
            text aa_pm.brl(value) style "aa_bank_text" size aa_phone_size(16) xalign 1.0 yalign .5
        use aa_bank_rule(width)
    null height 14
    text ("Conta quitada" if not remaining else "Há um valor a acertar com o restaurante.") style "aa_bank_secondary" size aa_phone_size(14) color ("#b4dbc8" if not remaining else "#e6b79e")

screen aa_bank_detail(detail, width, interactive=True):
    if detail[0] == "transaction":
        $ item = aa_bank_tx(detail[1])
        if item:
            use aa_bank_transaction(item, width, interactive)
        else:
            use aa_bank_empty(width, "history", "Comprovante indisponível", "Esta movimentação não consta no extrato da partida.")
    elif detail[0] == "debt":
        use aa_bank_debt(detail[1], width, interactive)
    elif detail[0] == "dinner":
        use aa_bank_bill(width)
    elif detail[0] == "archive":
        $ entry = detail[1]
        text entry["title"] style "aa_bank_title" size aa_phone_size(25)
        null height 16
        for paragraph in entry["paragraphs"]:
            text paragraph style "aa_bank_text" size aa_phone_size(17)
            null height 12

screen aa_bank_tabs(width, tab, height):
    frame:
        background aa_phone_round("bank-glass-solid" if aa_phone_pref("glass", .55) >= .95 else "bank-glass", 29)
        padding (4, 4)
        xysize (width, height)
        hbox:
            for value, label, icon in (("account", "Conta", "account"), ("payments", "Pagamentos", "payments"), ("history", "Extrato", "history")):
                button:
                    style "aa_bank_row"
                    background (aa_phone_round("bank-selected", 25) if tab == value else None)
                    xysize ((width - 8) // 3, height - 8)
                    action Function(aa_bank_nav, value)
                    selected tab == value
                    alt label
                    vbox:
                        align (.5, .5)
                        spacing 4
                        add aa_bank_art(icon, "mint" if tab == value else "muted") xysize (22, 22) xalign .5
                        text label style "aa_bank_text" size aa_phone_size(11) color ("#b4dbc8" if tab == value else "#a4aaa7") xalign .5

screen aa_bank_app(width, height, tab, detail, filter, query, search, payments, limit, scroll, selected_entry=None):
    $ current = detail or (aa_bank_legacy(selected_entry) if selected_entry else None)
    $ nav_height = 60 + aa_phone_pref("text_size", 0) * 2
    $ viewport_y = 112
    fixed:
        xysize (width, height)
        fixed:
            xpos 16
            ypos 53
            xysize (width - 32, 48)
            if current:
                use aa_bank_control("back", Function(aa_bank_back), "Voltar ao Banco")
                text ("Pagamento" if current[0] == "debt" else "Conta do jantar" if current[0] == "dinner" else "Comprovante") style "aa_bank_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(18) xpos 56 yalign .5 xmaximum (width - 88)
            else:
                text {"account": "Banco", "payments": "Pagamentos", "history": "Extrato"}[tab] style "aa_bank_title" size aa_phone_size(31 if tab != "payments" else 29) xpos 4 yalign .5
                if tab in ("account", "history"):
                    fixed:
                        xalign 1.0
                        xysize (44, 44)
                        if tab == "account":
                            use aa_bank_control("eye-off" if aa_phone_pref("bank_private", False) else "eye", Function(aa_phone_set_pref, "bank_private", not aa_phone_pref("bank_private", False)), "Mostrar saldo" if aa_phone_pref("bank_private", False) else "Ocultar saldo")
                        else:
                            use aa_bank_control("close" if search else "search", Function(aa_bank_search, not search), "Fechar busca" if search else "Buscar no extrato")
        viewport:
            id "bank_content"
            xpos 20
            ypos viewport_y
            xysize (width - 40, height - viewport_y - nav_height - 38)
            mousewheel True
            draggable True
            arrowkeys True
            pagekeys True
            yadjustment scroll
            vbox:
                xsize (width - 40)
                if current:
                    use aa_bank_detail(current, width - 40)
                elif tab == "account":
                    use aa_bank_account(width - 40)
                elif tab == "payments":
                    use aa_bank_payments(width - 40, payments)
                else:
                    use aa_bank_history(width - 40, filter, query, search, limit)
                null height 22
        fixed:
            xpos 12
            ypos (height - nav_height - 32)
            xysize (width - 24, nav_height)
            use aa_bank_tabs(width - 24, tab, nav_height)

# One sheet follows the actual handset pose, including the phone in Feka's hand.
screen aa_bank_sheet(title, dismiss):
    $ x, y, width, height = aa_bank_sheet_geometry()
    $ sheet_height = min(height - 78, 480 + aa_phone_pref("text_size", 0) * 24)
    button:
        xfill True
        yfill True
        background None
        action dismiss
        alt "Cancelar e voltar ao Banco"
    fixed:
        xpos x
        ypos y
        xysize (width, height)
        add AlphaMask(Solid("#00000088"), aa_phone_screen_mask(width, height)) xysize (width, height)
        frame:
            background aa_phone_round("bank-sheet", 28)
            padding (18, 12)
            xpos 5
            ypos (height - sheet_height - 26)
            xysize (width - 10, sheet_height)
            at aa_phone_content_enter
            vbox:
                xsize (width - 46)
                fixed:
                    xysize (width - 46, 50)
                    text title style "aa_bank_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(18) yalign .5 xmaximum (width - 94)
                    button:
                        style "aa_bank_row"
                        xysize (44, 44)
                        xalign 1.0
                        padding (12, 12)
                        action dismiss
                        alt "Fechar revisão"
                        use aa_bank_symbol("close", 20, "muted")
                viewport:
                    xysize (width - 46, sheet_height - 77)
                    mousewheel True
                    draggable True
                    arrowkeys True
                    vbox:
                        xsize (width - 46)
                        transclude

screen aa_transfer_confirm(who):
    modal True
    zorder 180
    $ debt = aa_world["debts"].get(who)
    $ width = aa_bank_sheet_geometry()[2] - 46
    use aa_bank_sheet("Revisar pagamento", Hide("aa_transfer_confirm")):
        if debt and debt["paid_at"] is None:
            null height 12
            text "Valor do Pix" style "aa_bank_secondary" size aa_phone_size(14)
            null height 8
            text aa_pm.brl(debt["amount"]) style "aa_bank_title" size aa_bank_fit(aa_pm.brl(debt["amount"]), width, aa_phone_size(34))
            null height 15
            use aa_bank_key_value("Para", aa_fm.party_name(who), width)
            use aa_bank_key_value("Saldo após o pagamento", aa_pm.brl(aa_world["balance"] - debt["amount"]) if aa_bank_can_pay(who) else "Saldo insuficiente" if aa_world["dinner_paid"] else "Aguarde o acerto do jantar", width)
            null height 16
            text "Este Pix quita o valor combinado." style "aa_bank_secondary" size aa_phone_size(14)
            null height 20
            textbutton "Confirmar pagamento" style "aa_bank_primary" xsize width text_size aa_phone_size(16) sensitive aa_bank_can_pay(who) action Function(aa_bank_payment, who)
        else:
            use aa_bank_empty(width, "check", "Pagamento concluído", "Este valor já foi quitado.")
            textbutton "Concluído" style "aa_bank_primary" xsize width action Hide("aa_transfer_confirm")
    key "game_menu" action Hide("aa_transfer_confirm")

screen aa_dinner_receipt():
    modal True
    zorder 180
    use aa_bank_sheet("Conta do jantar", Hide("aa_dinner_receipt")):
        use aa_bank_bill(aa_bank_sheet_geometry()[2] - 46)
    key "game_menu" action Hide("aa_dinner_receipt")

screen aa_bank_story(kind, width, height):
    $ entry = aa_pm.make_entry(kind, aa_location, aa_state, aa_phone_chats)
    fixed:
        xysize (width, height)
        text "Banco" style "aa_bank_title" size aa_phone_size(31) xpos 20 ypos 59
        viewport:
            xpos 20
            ypos 114
            xysize (width - 40, height - 150)
            mousewheel True
            draggable True
            vbox:
                xsize (width - 40)
                if entry:
                    use aa_bank_detail(aa_bank_legacy(entry), width - 40, False)
                null height 24
