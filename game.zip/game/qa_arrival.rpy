label qa_arrival_setup:
    $ aa_state = aa_new_state()
    $ aa_state.update(v_knows=qa_arrival_knows, group_source=qa_arrival_group)
    jump b00

testsuite aa_arrival:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/arrival"
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu"
    teardown:
        exit

    testcase sabia_cuidado_separadas:
        $ qa_arrival_knows = True
        $ qa_arrival_group = False
        run Start("qa_arrival_setup")
        advance until screen "choice"
        assert eval aa_last_art == "cg11_recepcao_reconhecimento"
        click "Responder Vanessa e perguntar se ela quer cumprimentar os dois."
        advance until "Vanessa ajeitou o casaco no braço e esperou que eu andasse ao lado dela."
        assert eval aa_last_art == "cg11_entrada_conversa"
        advance until screen "choice"
        assert eval aa_node == "b01"
        click "Dizer que vamos deixar os dois jantarem."
        advance until eval aa_last_art == "cg11_ir_mesa_dois"
        screenshot "sabia_cuidado_separadas.png"
        advance until screen "choice"
        assert eval aa_node == 'p00'
        assert eval aa_state["route"] == 'separadas'

    testcase grupo_cuidado_juntas:
        $ qa_arrival_knows = False
        $ qa_arrival_group = True
        run Start("qa_arrival_setup")
        advance until screen "choice"
        assert eval aa_last_art == "cg11_recepcao_reconhecimento"
        click "Responder Vanessa e perguntar se ela quer cumprimentar os dois."
        advance until "Vanessa ajeitou o casaco no braço e esperou que eu andasse ao lado dela."
        assert eval aa_last_art == "cg11_entrada_conversa"
        advance until screen "choice"
        assert eval aa_node == "b01"
        click "Sugerir que juntemos as mesas."
        advance until eval aa_last_art == "cg11_juntar_mesas"
        screenshot "grupo_cuidado_juntas.png"
        advance until screen "choice"
        assert eval aa_node == 'c00'
        assert eval aa_state["route"] == 'juntas'

    testcase nao_sabia_cuidado_varanda:
        $ qa_arrival_knows = False
        $ qa_arrival_group = False
        run Start("qa_arrival_setup")
        advance until screen "choice"
        assert eval aa_last_art == "cg11_recepcao_reconhecimento"
        click "Responder Vanessa e perguntar se ela quer cumprimentar os dois."
        advance until "Vanessa ajeitou o casaco no braço e esperou que eu andasse ao lado dela."
        assert eval aa_last_art == "cg11_entrada_conversa"
        advance until screen "choice"
        assert eval aa_node == "b01"
        click "Pedir um minuto com Yasmin antes de sentar."
        advance until eval aa_last_art == "cg11_deixar_vanessa"
        screenshot "nao_sabia_cuidado_varanda.png"
        advance until screen "choice"
        assert eval aa_node == 't00'
        assert eval aa_state["route"] == 'varanda'

    testcase sabia_apresenta_separadas:
        $ qa_arrival_knows = True
        $ qa_arrival_group = False
        run Start("qa_arrival_setup")
        advance until screen "choice"
        assert eval aa_last_art == "cg11_recepcao_reconhecimento"
        click "Ir até a mesa e apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == "b01"
        click "Dizer que vamos deixar os dois jantarem."
        advance until eval aa_last_art == "cg11_ir_mesa_dois"
        screenshot "sabia_apresenta_separadas.png"
        advance until screen "choice"
        assert eval aa_node == 'p00'
        assert eval aa_state["route"] == 'separadas'

    testcase grupo_puxa_juntas:
        $ qa_arrival_knows = False
        $ qa_arrival_group = True
        run Start("qa_arrival_setup")
        advance until screen "choice"
        assert eval aa_last_art == "cg11_recepcao_reconhecimento"
        click "Puxar Vanessa para perto antes que Yasmin olhe."
        advance until screen "choice"
        assert eval aa_node == "b01"
        click "Sugerir que juntemos as mesas."
        advance until eval aa_last_art == "cg11_juntar_mesas"
        screenshot "grupo_puxa_juntas.png"
        advance until screen "choice"
        assert eval aa_node == 'c00'
        assert eval aa_state["route"] == 'juntas'

    testcase nao_sabia_apresenta_varanda:
        $ qa_arrival_knows = False
        $ qa_arrival_group = False
        run Start("qa_arrival_setup")
        advance until screen "choice"
        assert eval aa_last_art == "cg11_recepcao_reconhecimento"
        click "Ir até a mesa e apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == "b01"
        click "Pedir um minuto com Yasmin antes de sentar."
        advance until eval aa_last_art == "cg11_deixar_vanessa"
        screenshot "nao_sabia_apresenta_varanda.png"
        advance until screen "choice"
        assert eval aa_node == 't00'
        assert eval aa_state["route"] == 'varanda'
