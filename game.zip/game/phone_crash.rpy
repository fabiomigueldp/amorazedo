# Crash timing is advanced by actions, never by rendering or prediction.
init python:
    import phone_crash_clock as aa_crash_runtime

    def aa_crash_round():
        r = aa_cm.active(aa_world)
        return r if r and r["game"] == "crash" else None

    def aa_crash_running(r):
        return aa_crash_runtime.clock.running(r)

    def aa_crash_update(cashout=False):
        global aa_world, aa_state
        r = aa_crash_round()
        if not aa_crash_running(r):
            return
        aa_world = aa_cm.crash_advance(aa_world, r["id"], aa_crash_runtime.clock.elapsed(r), cashout)
        updated = aa_cm.state(aa_world)["round"]
        if updated["status"] == "done":
            aa_crash_runtime.clock.reset()
            aa_state = aa_financial_state(aa_state, aa_world)
            aa_crash_settled(updated)
        else:
            aa_crash_runtime.clock.follow(updated)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_crash_pause():
        aa_crash_update()
        aa_crash_runtime.clock.reset()

    def aa_crash_resume(ident):
        r = aa_crash_round()
        if r and r["id"] == ident and not aa_crash_running(r):
            aa_crash_runtime.clock.bind(r)
            aa_casino_set(error="")

    def aa_crash_started(r):
        aa_crash_runtime.clock.reset()
        aa_casino_set(busy=None, error="", scroll=ui.adjustment())
        if r["status"] == "active":
            aa_crash_resume(r["id"])
            aa_casino_audio("reveal")
        else:
            aa_crash_settled(r)

    def aa_crash_settled(r):
        # A double tap on Withdraw must not become the next paid bet.
        aa_casino_set(busy=(r["id"], r["revision"]), started=aa_casino_time.monotonic(), duration=.4)
        aa_casino_audio("crash" if r["data"]["crashed"] else "finish")

    def aa_crash_cashout(ident):
        r = aa_crash_round()
        if r and r["id"] == ident:
            aa_crash_update(cashout=True)

    def aa_crash_choose(target):
        aa_casino_set(crash=target, panel=None, scroll=ui.adjustment())

    def aa_crash_context_guard():
        # A game menu or other context must not leave an invisible live clock.
        # The last committed tick is already in the save; never mutate the
        # campaign from a temporary context, where only part of it would persist.
        aa_crash_runtime.clock.reset()

    config.context_callbacks.append(aa_crash_context_guard)

    def aa_crash_visibility_guard():
        if aa_crash_runtime.clock.round is None:
            return
        scope = aa_casino_scope()
        if scope.get("page") != "casino" or scope.get("casino_view") != "crash" or scope.get("casino_panel"):
            aa_crash_runtime.clock.reset()

    config.interact_callbacks.append(aa_crash_visibility_guard)

    class AACrashGraph(renpy.Displayable):
        def __init__(self, elapsed_ms, width, height, crashed=False, moving=True, **properties):
            super(AACrashGraph, self).__init__(**properties)
            self.elapsed_ms, self.width, self.height = elapsed_ms, width, height
            self.crashed, self.moving = crashed, moving

        def render(self, width, height, st, at):
            # Supersample the vector plot, matching the handset's smooth edges.
            scale = 3
            drawing = renpy.Render(self.width * scale, self.height * scale)
            canvas = drawing.canvas()
            left, right, top, bottom = 7 * scale, (self.width - 8) * scale, 6 * scale, (self.height - 8) * scale
            for fraction in (.0, .5, 1.0):
                y = int(bottom - (bottom - top) * fraction)
                canvas.line("#c8b5db1e", (left, y), (right, y), scale)
            for fraction in (.25, .5, .75, 1.0):
                x = int(left + (right - left) * fraction)
                canvas.line("#c8b5db0f", (x, top), (x, bottom), scale)
            elapsed = self.elapsed_ms
            # Axes depend only on elapsed play, never the hidden crash point.
            horizon = max(4000, elapsed * 1.18)
            maximum = max(1.5, aa_cm.crash_multiplier(elapsed) / 100 * 1.2)
            points = []
            for i in range(65):
                t = elapsed * i / 64
                x = left + (right - left) * t / horizon
                y = bottom - (bottom - top) * (aa_casino_math.exp(t / aa_cm.CRASH_RATE_MS) - 1) / (maximum - 1)
                points.append((int(x), int(y)))
            color = "#ed9fac" if self.crashed else "#d8c4ed"
            if elapsed:
                canvas.polygon("#d8c4ed0d" if not self.crashed else "#ed9fac0d", [(left, bottom)] + points + [(points[-1][0], bottom)])
                canvas.lines(color, False, points, 2 * scale)
            x, y = points[-1]
            if self.crashed:
                canvas.line(color, (x - 4 * scale, y - 4 * scale), (x + 4 * scale, y + 4 * scale), 2 * scale)
                canvas.line(color, (x - 4 * scale, y + 4 * scale), (x + 4 * scale, y - 4 * scale), 2 * scale)
            else:
                if self.moving:
                    canvas.circle("#d8c4ed25", (x, y), 8 * scale)
                canvas.circle(color, (x, y), 4 * scale)
            result = renpy.Render(self.width, self.height)
            result.blit(drawing, (0, 0))
            result.zoom(1.0 / scale, 1.0 / scale)
            return result

screen aa_crash_table(width, r, readonly=False):
    $ d = r["data"] if r else None
    $ active = r and r["status"] == "active"
    $ running = active and aa_crash_running(r)
    $ multiplier = (d["end_multiplier"] or aa_cm.crash_multiplier(d["elapsed_ms"])) if d else 100
    $ lost = d and d["crashed"]
    $ done = r and not active
    $ panel_height = (258 if active else 168 if done and not readonly else 184) + aa_phone_pref("text_size", 0) * 2
    $ caption = "Retire antes da queda" if not r else "Em voo" if running else "Rodada pausada" if active else "Caiu" if lost else "Retorno recolhido"
    frame:
        xysize (width, panel_height)
        background aa_phone_round("casino-table", 22)
        padding (12, 10)
        fixed:
            xfill True
            text caption style "aa_casino_muted" size aa_phone_size(13) xalign .5
            text aa_cm.crash_text(multiplier) style "aa_phone_title" size 43 xalign .5 ypos 22 color ("#f1b4bf" if lost else "#f3edf5")
            if persistent.aa_motion or not active:
                add AACrashGraph(d["elapsed_ms"] if d else 0, width - 24, panel_height - 117, bool(lost), bool(running)) ypos 77
            else:
                add aa_casino_art("crash") xysize (68, 68) xalign .5 ypos 112
            text (("%.1f s" % (d["elapsed_ms"] / 1000)).replace(".", ",") if d else "1,00× para começar") style "aa_casino_muted" size 11 ypos (panel_height - 34)
            text "Limite 100×" style "aa_casino_muted" size 11 xalign 1.0 ypos (panel_height - 34)
    if active:
        text ("Automática em " + aa_cm.crash_text(d["auto"]) + ". Você também pode retirar antes." if d["auto"] else "Retirada manual. Se cair antes do toque, a aposta é perdida.") style "aa_casino_muted" size aa_phone_size(13)
    elif not readonly:
        if done:
            button:
                style "aa_casino_button"
                xsize width
                padding (12, 7)
                action Function(aa_casino_open_record, r["id"])
                alt "Ver detalhes da rodada"
                vbox:
                    spacing 2
                    text ("Retorno " + aa_pm.brl(r["gross"]) + "  ›") style "aa_casino_text" size aa_phone_size(15)
                    text ("Líquido " + aa_casino_signed(r["net"])) style "aa_casino_muted" size aa_phone_size(12)
        $ selected = aa_casino_scope().get("casino_crash")
        textbutton ("Retirada · " + (aa_cm.crash_text(selected) + " automática" if selected else "manual") + "  ›"):
            style "aa_casino_button"
            xfill True
            text_size aa_phone_size(13)
            action Function(aa_casino_panel, "crash")
            alt "Escolher retirada do Crash"
        if not r:
            text "Pode cair já em 1,00×. Retire a tempo para receber." style "aa_casino_muted" size aa_phone_size(13)
    if readonly:
        text ("Retirada configurada: " + aa_cm.crash_text(d["auto"]) if d["auto"] else "Retirada manual") style "aa_casino_muted" size aa_phone_size(13)

screen aa_crash_controls(width, r):
    $ running = aa_crash_running(r)
    $ multiplier = aa_cm.crash_multiplier(r["data"]["elapsed_ms"])
    $ gross = r["stake"] * multiplier // 100
    fixed:
        xysize (width, 23 + aa_phone_pref("text_size", 0))
        text "Em jogo" style "aa_casino_muted" size aa_phone_size(13) yalign .5
        text aa_pm.brl(r["stake"]) style "aa_casino_text" size aa_bank_fit(aa_pm.brl(r["stake"]), width - 80, aa_phone_size(15)) xalign 1.0 yalign .5
    textbutton ("Retirar " + aa_pm.brl(gross) if running else "Continuar rodada"):
        style "aa_casino_primary"
        xysize (width, 52)
        text_size aa_bank_fit("Retirar " + aa_pm.brl(gross), width - 20, aa_phone_size(18))
        action (Function(aa_crash_cashout, r["id"]) if running else Function(aa_crash_resume, r["id"]))
        alt ("Retirar agora no Crash" if running else "Continuar rodada de Crash")
    text ("Sair da mesa pausa a rodada." if running else "Retome do mesmo ponto, sem nova aposta.") style "aa_casino_muted" size aa_phone_size(12)

screen aa_crash_picker(width):
    $ selected = aa_casino_scope().get("casino_crash")
    text "Quando retirar" style "aa_phone_title" size aa_phone_size(24)
    text "Escolha antes de apostar. A retirada automática só acontece se o multiplicador chegar ao alvo antes da queda." style "aa_casino_muted" size aa_phone_size(14)
    null height 4
    textbutton "Manual" style "aa_casino_button" xfill True selected selected is None action Function(aa_crash_choose, None)
    grid 2 4:
        spacing 8
        for target in (150, 200, 300, 500, 1000, 2500, 5000, 10000):
            textbutton aa_cm.crash_text(target):
                style "aa_casino_button"
                xysize ((width - 8) // 2, 46)
                selected selected == target
                action Function(aa_crash_choose, target)
                alt ("Retirada automática em " + aa_cm.crash_text(target))
    text "Você pode retirar manualmente antes do alvo. Se a queda e o alvo coincidirem, a aposta é perdida." style "aa_casino_muted" size aa_phone_size(13)
