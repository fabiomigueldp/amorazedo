# Table variants, with decisions outside the scrolling play area.
screen aa_casino_nav_button(caption, action, label=None):
    button:
        style "aa_casino_button"
        background aa_phone_round("message-glass-solid" if aa_phone_pref("glass", .55) >= .95 else "message-glass", 22)
        xysize (44, 44)
        padding (0, 0)
        action action
        alt (label or caption)
        if caption == "‹":
            add aa_phone_asset("icon-back") xysize (22, 22) align (.5, .5)
        else:
            text caption style "aa_casino_text" size 22 align (.5, .5)

screen aa_casino_app(width, height, casino_view, casino_panel, casino_amount, casino_roulette, casino_dice, casino_mines, casino_busy, casino_error, casino_scroll, casino_record=None, casino_history_filter="all"):
    $ cs = aa_cm.state(aa_world)
    $ pending = aa_cm.active(aa_world)
    $ game = casino_view if casino_view in aa_cm.GAMES else None
    $ r = cs["round"] if cs["round"] and cs["round"]["game"] == game else None
    $ playing = r and r["status"] == "active"
    $ blocked = pending and not playing
    $ body_width = width - 28
    $ extra = aa_phone_pref("text_size", 0)
    $ stake_invalid = bool(casino_error) or not 100 <= aa_casino_parse(casino_amount) <= aa_world["balance"]
    $ footer = (132 + extra * 4 if game == "blackjack" else 126 + (aa_phone_size(12) - 12) * 5 if game == "crash" else 118 + extra * 5) if playing else (190 + extra * 7 if stake_invalid else 166 + extra * 2)
    if game == "holdem" and playing:
        $ footer = 136 + (aa_phone_size(12) - 12) * 2
    if game == "plinko" and playing:
        $ footer = 166 + extra * 2
    $ footer = footer if game and not casino_panel and not blocked else 0
    $ top = 128 if game and not casino_panel else 105
    $ nav_height = 52 if not game and not casino_panel else 0
    $ heading = ("Regras" if casino_panel == "rules" else "Retirada" if casino_panel == "crash" else "Escolher aposta" if casino_panel == "roulette" else "Rodada #" + str(casino_record) if casino_panel == "record" else aa_cm.GAMES.get(casino_view, "Atividade" if casino_view == "history" else "Mesa"))
    if casino_panel == "holdem-raise":
        $ heading = "Sua aposta"
    if casino_panel == "plinko":
        $ heading = "Pagamentos"
    if game == "holdem" and r and (playing or casino_busy) and not casino_panel:
        timer .1 repeat True action Function(aa_holdem_pulse)
    if game == "crash" and playing and not casino_panel and aa_crash_running(r):
        timer .05 repeat True action Function(aa_crash_update)
    if game == "plinko" and playing and not casino_panel and aa_plinko_runtime.clock.running(r):
        timer .05 repeat True action Function(aa_plinko_update)
    if casino_busy and game != "holdem":
        $ remaining = max(.01, aa_casino_scope().get("casino_duration", .01) - (aa_casino_time.monotonic() - (aa_casino_scope().get("casino_started") or 0)))
        timer remaining action Function(aa_casino_finish_visual, casino_busy)
    fixed:
        xpos 12
        ypos 48
        xysize (width - 24, 48)
        use aa_casino_nav_button("‹", Function(aa_phone_back), "Voltar no Mesa")
        text heading style "aa_phone_title" size aa_bank_fit(heading, width - 122, aa_phone_size(21 if casino_panel or game else 27)) xpos 54 yalign .5 xmaximum (width - 122)
        if not casino_panel:
            fixed:
                xalign 1.0
                xysize (44, 44)
                use aa_casino_nav_button("i", Function(aa_casino_panel, "rules"), "Regras do Mesa")
    if game and not casino_panel:
        fixed:
            xpos 16
            ypos 96
            xysize (width - 32, 30)
            text "Disponível" style "aa_casino_muted" size aa_phone_size(12) yalign .5
            textbutton aa_balance_text():
                style "aa_casino_button"
                background None
                yminimum 30
                padding (0, 0)
                xalign 1.0
                text_size aa_bank_fit(aa_balance_text(), width - 135, aa_phone_size(16))
                action Function(aa_casino_bank)
                alt "Ver saldo no Banco"
    viewport:
        id "casino_scroll"
        xpos 14
        ypos top
        xysize (body_width, height - top - max(footer, nav_height) - 38)
        mousewheel True
        draggable True
        arrowkeys True
        pagekeys True
        yadjustment casino_scroll
        vbox:
            xsize body_width
            spacing 8
            if casino_panel == "rules":
                use aa_casino_rules(game, body_width)
            elif casino_panel == "roulette":
                use aa_casino_roulette_picker(body_width, casino_roulette)
            elif casino_panel == "crash":
                use aa_crash_picker(body_width)
            elif casino_panel == "holdem-raise":
                use aa_holdem_raise_picker(body_width, r)
            elif casino_panel == "plinko":
                use aa_plinko_paytable(body_width)
            elif casino_panel == "record":
                use aa_casino_record(body_width, casino_record)
            elif casino_view == "lobby":
                use aa_casino_lobby(body_width, pending)
            elif casino_view == "history":
                use aa_casino_history(body_width, cs, casino_history_filter)
            elif blocked:
                text "Sua rodada está em andamento" style "aa_phone_title" size aa_phone_size(23)
                text (aa_cm.GAMES[pending["game"]] + " · " + aa_pm.brl(pending["stake"]) + " em jogo") style "aa_casino_muted" size aa_phone_size(16)
                textbutton ("Continuar " + aa_cm.GAMES[pending["game"]]) style "aa_casino_primary" xfill True action Function(aa_casino_nav, pending["game"])
                text "Você pode guardar o celular e continuar depois. A rodada acompanha o save." style "aa_casino_muted" size aa_phone_size(14)
            elif game:
                if game == "blackjack":
                    use aa_casino_blackjack(body_width, r, casino_busy)
                elif game == "roulette":
                    use aa_casino_roulette(body_width, r, casino_busy)
                    textbutton (aa_casino_bet_label(casino_roulette) + (" · 36×" if type(casino_roulette) is int else " · 2×") + "  ›"):
                        style "aa_casino_button"
                        xfill True
                        text_size aa_phone_size(14)
                        sensitive not casino_busy
                        action Function(aa_casino_panel, "roulette")
                        alt "Escolher aposta da roleta"
                elif game == "slots":
                    use aa_casino_slots(body_width, r, casino_busy)
                elif game == "dice":
                    use aa_casino_dice(body_width, r, casino_busy)
                    hbox:
                        spacing 6
                        for opt, caption in (("under", "< 7 · 2,3×"), ("seven", "7 · 5,7×"), ("over", "> 7 · 2,3×")):
                            textbutton caption style "aa_casino_button" padding (2, 10) xsize ((body_width - 12) // 3) text_size aa_phone_size(12) selected casino_dice == opt sensitive not casino_busy action Function(aa_casino_set, dice=opt)
                elif game == "crash":
                    use aa_crash_table(body_width, r)
                elif game == "holdem":
                    if r and r["status"] == "done":
                        use aa_casino_result(body_width, r)
                    use aa_holdem_table(body_width, r)
                elif game == "plinko":
                    use aa_plinko_table(body_width, r, available_height=height - top - max(footer, nav_height) - 38)
                else:
                    use aa_casino_mines(body_width, r, casino_busy)
                    if not playing:
                        hbox:
                            spacing 6
                            for n in (1, 3, 5):
                                textbutton (str(n) + (" mina" if n == 1 else " minas")) style "aa_casino_button" xsize ((body_width - 12) // 3) padding (2, 10) text_size aa_phone_size(13) selected casino_mines == n sensitive not casino_busy action Function(aa_casino_set, mines=n)
                if r and r["status"] == "done" and not casino_busy and game not in ("crash", "holdem", "plinko"):
                    use aa_casino_result(body_width, r)
            null height 18
    if footer:
        frame:
            xpos 10
            ypos (height - footer - 28)
            xysize (width - 20, footer)
            background aa_phone_round("casino-dock", 24)
            padding (10, 8)
            vbox:
                xsize (width - 40)
                spacing 6
                if playing:
                    use aa_casino_play_controls(width - 40, r, casino_busy)
                else:
                    use aa_casino_stake(width - 40, game, cs["sequence"], casino_amount, casino_roulette, casino_dice, casino_mines, casino_busy, casino_error)
    if nav_height:
        frame:
            xpos 10
            ypos (height - nav_height - 28)
            xysize (width - 20, nav_height)
            background aa_phone_round("message-glass-solid" if aa_phone_pref("glass", .55) >= .95 else "message-glass", 26)
            padding (4, 4)
            hbox:
                for name, caption in (("lobby", "Jogos"), ("history", "Atividade"), ("bank", "Banco")):
                    textbutton caption:
                        style "aa_casino_button"
                        background None
                        selected_background aa_phone_round("casino-hover", 22)
                        text_selected_color "#f3edf5"
                        text_size aa_phone_size(13)
                        xsize ((width - 28) // 3)
                        selected casino_view == name
                        action (Function(aa_casino_bank) if name == "bank" else Function(aa_casino_nav, name))

screen aa_casino_lobby(width, pending):
    text "Saldo disponível" style "aa_casino_muted" size aa_phone_size(14)
    text aa_balance_text() style "aa_phone_title" size aa_bank_fit(aa_balance_text(), width, aa_phone_size(33))
    if pending:
        textbutton ("Continuar " + aa_cm.GAMES[pending["game"]] + "  ›") style "aa_casino_primary" xfill True action Function(aa_casino_nav, pending["game"])
    null height 5
    button:
        background aa_phone_round("casino-table", 22)
        hover_background aa_phone_round("casino-hover", 22)
        padding (0, 0)
        xysize (width, 88 + aa_phone_pref("text_size", 0) * 2)
        action Function(aa_casino_nav, "holdem")
        alt "Jogar Texas Hold’em"
        fixed:
            add aa_casino_art("holdem-art") xysize (86, 75) xpos (width - 91) ypos 7
            vbox:
                xpos 14
                ypos 20
                spacing 6
                text "Texas Hold’em" style "aa_phone_title" size aa_bank_fit("Texas Hold’em", width - 104, aa_phone_size(22))
                text "No Limit · solo" style "aa_casino_muted" size aa_phone_size(12)
    for game in ("plinko", "crash", "blackjack"):
        button:
            style "aa_casino_button"
            padding (10, 8)
            xysize (width, 60 + aa_phone_pref("text_size", 0) * 2)
            action Function(aa_casino_nav, game)
            alt ("Jogar " + aa_cm.GAMES[game])
            hbox:
                spacing 12
                add aa_casino_art(AA_CASINO_COPY[game][1]) xysize (46, 46)
                vbox:
                    spacing 3
                    yalign .5
                    text (aa_cm.GAMES[game] + "  ›") style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17)
    null height 3
    text "Mais jogos" style "aa_phone_title" size aa_phone_size(20)
    grid 2 2:
        spacing 10
        for key in ("roulette", "slots", "dice", "mines"):
            button:
                background aa_phone_round("casino-surface", 20)
                hover_background aa_phone_round("casino-hover", 20)
                padding (12, 8)
                xysize ((width - 10) // 2, 84 + aa_phone_pref("text_size", 0) * 3)
                action Function(aa_casino_nav, key)
                alt ("Jogar " + aa_cm.GAMES[key])
                vbox:
                    spacing 4
                    add aa_casino_art(AA_CASINO_COPY[key][1]) xysize (36, 36)
                    text aa_cm.GAMES[key] style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(14)

screen aa_casino_stake(width, game, sequence, casino_amount, casino_roulette, casino_dice, casino_mines, casino_busy, error=""):
    $ stake = aa_casino_parse(casino_amount)
    $ option = casino_roulette if game == "roulette" else casino_dice if game == "dice" else casino_mines if game == "mines" else aa_casino_scope().get("casino_crash") if game == "crash" else aa_casino_scope().get("casino_plinko", "medium") if game == "plinko" else None
    $ wager_input = ScreenVariableInputValue("casino_amount", default=False)
    button:
        style "aa_casino_button"
        background aa_phone_round("casino-surface", 14)
        selected_background aa_phone_round("casino-hover", 14)
        padding (10, 7)
        xysize (width, 44)
        sensitive not casino_busy
        action wager_input.Enable()
        alt "Editar valor da aposta"
        hbox:
            spacing 10
            text ("Entrada" if game == "holdem" else "Aposta") style "aa_casino_muted" size aa_phone_size(14) yalign .5 xsize 58
            text "R$" style "aa_casino_text" size aa_phone_size(17) yalign .5
            input:
                value wager_input
                action wager_input.Disable()
                allow "0123456789,."
                length 18
                style "aa_casino_text"
                size aa_phone_size(18)
                xmaximum (width - 125)
                copypaste True
    hbox:
        spacing 6
        for amount, caption in ((100, "1"), (500, "5"), (1000, "10"), (aa_world["balance"], "Tudo")):
            textbutton caption:
                style "aa_casino_button"
                xsize ((width - 18) // 4)
                padding (2, 8)
                ysize 44
                text_size aa_phone_size(13)
                selected stake == amount and caption != "Tudo"
                sensitive not casino_busy and 100 <= amount <= aa_world["balance"]
                action [wager_input.Disable(), Function(aa_casino_set, amount=aa_casino_bet_text(amount), error="")]
                alt ("Apostar todo o saldo" if caption == "Tudo" else "Aposta de " + caption + " reais")
    textbutton (("Concluído" if game == "plinko" else "Rodada encerrada" if game == "crash" else "Distribuindo…" if game in ("blackjack", "holdem") else "Sorteando…") if casino_busy else ("Entrar com " if game == "holdem" else "Lançar · " if game == "plinko" else "Apostar ") + aa_pm.brl(stake)):
        style "aa_casino_primary"
        xsize width
        ysize 48
        text_size aa_bank_fit("Apostar " + aa_pm.brl(stake), width - 20, aa_phone_size(16))
        sensitive not casino_busy and 100 <= stake <= aa_world["balance"]
        action Function(aa_casino_commit, game, casino_amount, option, sequence)
        alt "Confirmar aposta"
    $ hint = error or (("Saldo insuficiente." if game == "plinko" else "Saldo insuficiente. Mínimo R$ 1,00.") if aa_world["balance"] < 100 else "Mínimo R$ 1,00." if stake < 100 else "Saldo insuficiente." if stake > aa_world["balance"] else "")
    if hint:
        text hint style "aa_casino_muted" size aa_phone_size(12) xmaximum width color "#f1b4bf"

screen aa_casino_play_controls(width, r, busy):
    $ d = r["data"]
    if r["game"] == "holdem":
        use aa_holdem_controls(width, r, busy)
    elif r["game"] == "plinko":
        use aa_plinko_controls(width, r)
    elif r["game"] == "crash":
        use aa_crash_controls(width, r)
    elif r["game"] == "blackjack":
        hbox:
            spacing 8
            textbutton "Pedir carta" style "aa_casino_primary" text_size aa_phone_size(14) xsize ((width - 8) // 2) sensitive not busy action Function(aa_casino_act, r["id"], r["revision"], "hit")
            textbutton "Parar" style "aa_casino_button" text_size aa_phone_size(14) xsize ((width - 8) // 2) sensitive not busy action Function(aa_casino_act, r["id"], r["revision"], "stand")
        textbutton ("Dobrar · + " + aa_pm.brl(r["initial_stake"])):
            style "aa_casino_button"
            xfill True
            text_size aa_phone_size(14)
            sensitive not busy and len(d["player"]) == 2 and not d["doubled"] and aa_world["balance"] >= r["initial_stake"]
            action Function(aa_casino_act, r["id"], r["revision"], "double")
        text ("Em jogo · " + aa_pm.brl(r["stake"])) style "aa_casino_muted" size aa_phone_size(12) xalign .5
    else:
        $ picks = len(d["revealed"])
        $ gross = aa_cm.mines_return(r["stake"], d["count"], picks)
        textbutton (("Recolher " + aa_pm.brl(gross)) if picks else "Retirar aposta · " + aa_pm.brl(gross)):
            style "aa_casino_primary"
            xfill True
            text_size aa_bank_fit("Recolher " + aa_pm.brl(gross), width - 20, aa_phone_size(16))
            sensitive not busy
            action Function(aa_casino_act, r["id"], r["revision"], "cashout")
        text ("Próxima casa: %d de %d seguras" % (25 - d["count"] - picks, 25 - picks)) style "aa_casino_muted" size aa_phone_size(12) xalign .5
        text ("Próximo retorno: " + aa_pm.brl(aa_cm.mines_return(r["stake"], d["count"], picks + 1))) style "aa_casino_text" size aa_phone_size(13) xalign .5

screen aa_casino_result(width, r, interactive=True):
    button:
        style "aa_casino_button"
        xsize width
        padding (12, 6)
        action (Function(aa_casino_open_record, r["id"]) if interactive else NullAction())
        alt "Ver detalhes da rodada"
        vbox:
            spacing 2
            text r["label"] style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(14)
            text ("Retorno " + aa_pm.brl(r["gross"])) style "aa_casino_text" size aa_phone_size(18)
            text ("Líquido · " + aa_casino_signed(r["net"])) style "aa_casino_muted" size aa_phone_size(12) color ("#c7e1cc" if r["net"] > 0 else "#d6bfcc")

screen aa_casino_card(card=None, back=False, width=44):
    fixed:
        xysize (width, int(width * 1.4))
        at aa_casino_deal
        if back:
            add aa_casino_art("card-back") xysize (width, int(width * 1.4))
        else:
            add aa_phone_round("casino-card", 6) xysize (width, int(width * 1.4))
            $ rank = {1: "A", 11: "J", 12: "Q", 13: "K"}.get(card[0], str(card[0]))
            text rank style "aa_casino_text" color ("#b64355" if card[1] in (1, 2) else "#27232e") size 16 font "fonts/Inter-SemiBold.ttf" xpos 4 ypos 2
            add aa_casino_art("suit-" + str(card[1])) xysize (22, 22) align (.5, .72)

screen aa_casino_hand(cards, width, hide_second=False):
    $ step = min(50, (width - 44) // max(1, len(cards) - 1))
    fixed:
        xysize (width, 62)
        for i, card in enumerate(cards):
            fixed:
                xpos ((width - 44 - step * (len(cards) - 1)) // 2 + step * i)
                xysize (44, 62)
                use aa_casino_card(card, hide_second and i == 1)

screen aa_casino_blackjack(width, r, busy=None):
    $ done = r and r["status"] == "done" and not busy
    $ d = r["data"] if r else None
    frame:
        background aa_phone_round("casino-table", 22)
        padding (12, 10)
        xsize width
        vbox:
            spacing 6
            text ("Mesa · " + str(aa_cm.hand_total(d["dealer"])) if done else "Mesa · para em 17") style "aa_casino_muted" size aa_phone_size(12) xalign .5
            if d:
                use aa_casino_hand(d["dealer"], width - 24, not done)
            else:
                hbox:
                    xalign .5
                    spacing 6
                    use aa_casino_card(back=True)
                    use aa_casino_card(back=True)
            text ("Você · " + str(aa_cm.hand_total(d["player"])) if d else "Blackjack paga 3:2") style "aa_casino_text" size aa_phone_size(12) xalign .5
            if d:
                use aa_casino_hand(d["player"], width - 24)
            else:
                text "Aposte para receber suas cartas." style "aa_casino_muted" size aa_phone_size(14) xalign .5 textalign .5 yminimum 48

screen aa_casino_roulette(width, r, busy=None):
    fixed:
        xysize (width, 150)
        add aa_casino_visual("roulette", r["data"] if r else {}, width, 148, busy)
        if r and not busy:
            $ number = r["data"]["number"]
            frame:
                background aa_phone_round("casino-green" if number == 0 else "casino-red" if number in aa_cm.RED else "casino-surface", 23)
                padding (0, 0)
                xysize (46, 46)
                align (.5, .49)
                text str(number) style "aa_phone_title" size 27 align (.5, .5)

screen aa_casino_roulette_picker(width, selected):
    text "Apostas simples · retorno 2×" style "aa_casino_muted" size aa_phone_size(14)
    grid 3 2:
        spacing 6
        for opt in ("red", "black", "even", "odd", "low", "high"):
            textbutton aa_casino_bet_label(opt):
                style "aa_casino_button"
                padding (2, 10)
                xsize ((width - 12) // 3)
                text_size aa_phone_size(12)
                selected selected == opt
                action Function(aa_casino_choose_number, opt)
    null height 12
    text "Número exato · retorno 36×" style "aa_casino_muted" size aa_phone_size(14)
    textbutton "0":
        style "aa_casino_button"
        background aa_phone_round("casino-green", 12)
        selected_background aa_phone_round("casino-accent", 12)
        selected selected == 0
        xfill True
        action Function(aa_casino_choose_number, 0)
        alt "Apostar no número 0"
    vpgrid:
        cols 5
        spacing 5
        xsize width
        ysize 388
        mousewheel True
        draggable True
        for n in range(1, 37):
            textbutton str(n):
                style "aa_casino_button"
                background aa_phone_round("casino-red" if n in aa_cm.RED else "casino-surface", 12)
                selected_background aa_phone_round("casino-accent", 12)
                xysize ((width - 20) // 5, 44)
                padding (0, 0)
                selected selected == n
                action Function(aa_casino_choose_number, n)
                alt ("Apostar no número " + str(n))

screen aa_casino_slots(width, r, busy=None):
    frame:
        background aa_phone_round("casino-table", 22)
        padding (10, 12)
        xsize width
        vbox:
            spacing 8
            add aa_casino_visual("slots", r["data"] if r else {}, width - 20, 76, busy)
            text ("Girando…" if busy else "3 iguais ou 2 cerejas") style "aa_casino_text" size aa_phone_size(13) xalign .5
    text "Cerejas 4× · limões 8× · barras 12×\nSinos 30× · setes 100× · 2 cerejas 2×" style "aa_casino_muted" size aa_phone_size(11) xalign .5 textalign .5

screen aa_casino_dice(width, r, busy=None):
    frame:
        background aa_phone_round("casino-table", 22)
        padding (12, 8)
        xsize width
        vbox:
            spacing 6
            add aa_casino_visual("dice", r["data"] if r else {}, width - 24, 88, busy)
            text ("Lançando…" if busy else "Soma " + str(sum(r["data"]["values"])) if r else "Escolha a soma dos dois dados") style "aa_casino_text" size aa_phone_size(14) xalign .5

screen aa_casino_mines(width, r, busy=None, readonly=False):
    $ d = r["data"] if r else None
    $ running = r and r["status"] == "active"
    $ tile = (width - 20) // 5 if running or readonly else 40
    if running:
        text (str(len(d["revealed"])) + " casas seguras · " + str(d["count"]) + " minas") style "aa_casino_muted" size aa_phone_size(13)
    grid 5 5:
        spacing 5
        xalign .5
        for cell in range(25):
            $ revealed = d and cell in d["revealed"]
            $ mine = d and cell in d["mines"] and (not running or revealed)
            button:
                xysize (tile, tile)
                padding (7, 7)
                background aa_phone_round("casino-red" if mine else "casino-hover" if revealed else "casino-surface", 11)
                hover_background aa_phone_round("casino-hover", 11)
                sensitive running and not readonly and not busy and not revealed
                action (Function(aa_casino_act, r["id"], r["revision"], "reveal", cell) if running else NullAction())
                alt ("Mina" if mine else "Gema" if revealed else "Abrir casa " + str(cell + 1))
                if mine or revealed:
                    add aa_casino_art("mine" if mine else "gem") xysize (tile - 14, tile - 14) at aa_casino_deal
                else:
                    text "·" style "aa_casino_muted" size 24 align (.5, .5)

screen aa_casino_history(width, cs, filter="all"):
    text "Resultado acumulado" style "aa_casino_muted" size aa_phone_size(14)
    text aa_casino_signed(cs["total_returned"] - cs["total_staked"]) style "aa_phone_title" size aa_bank_fit(aa_casino_signed(cs["total_returned"] - cs["total_staked"]), width, aa_phone_size(29))
    text "Inclui o valor ainda em jogo." style "aa_casino_muted" size aa_phone_size(12)
    if aa_cm.active(aa_world):
        textbutton "Continuar rodada" style "aa_casino_primary" xfill True text_size aa_phone_size(14) action Function(aa_casino_nav, aa_cm.active(aa_world)["game"])
    hbox:
        spacing 6
        for value, label in (("all", "Todas"), ("wins", "Ganhos"), ("losses", "Perdas")):
            textbutton label style "aa_casino_button" text_size aa_phone_size(13) xsize ((width - 12) // 3) selected filter == value action Function(aa_casino_set, history_filter=value, scroll=ui.adjustment())
    $ entries = [e for e in cs["history"] if filter == "all" or (e["net"] > 0 if filter == "wins" else e["net"] < 0)]
    if not entries:
        null height 16
        text "Nenhuma rodada por aqui" style "aa_phone_title" size aa_phone_size(22)
        text "As rodadas concluídas aparecem aqui. Toque em uma delas para conferir o resultado e os lançamentos." style "aa_casino_muted" size aa_phone_size(14)
    for index, entry in enumerate(entries):
        if index == 0 or entry["finished_at"] // 1440 != entries[index - 1]["finished_at"] // 1440:
            null height 8
            text aa_bank_day(entry["finished_at"]) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(16)
        button:
            style "aa_casino_button"
            background None
            padding (0, 8)
            xsize width
            action Function(aa_casino_open_record, entry["id"])
            alt ("Ver rodada " + str(entry["id"]) + " de " + aa_cm.GAMES[entry["game"]])
            vbox:
                spacing 4
                fixed:
                    xysize (width, 24 + aa_phone_pref("text_size", 0))
                    text aa_cm.GAMES[entry["game"]] style "aa_casino_text" size aa_phone_size(16) xmaximum (width - 104)
                    text aa_casino_signed(entry["net"]) style "aa_casino_text" size aa_bank_fit(aa_casino_signed(entry["net"]), 100, aa_phone_size(15)) color ("#c7e1cc" if entry["net"] > 0 else "#e4d4e1") xalign 1.0
                text ("#" + str(entry["id"]) + " · " + aa_fm.stamp(entry["finished_at"])) style "aa_casino_muted" size aa_phone_size(12)
                text entry["label"] style "aa_casino_muted" size aa_phone_size(13)
        use aa_phone_rule(width)
    if entries:
        text "Últimas 100 rodadas. O Banco conserva o extrato completo." style "aa_casino_muted" size aa_phone_size(12)

screen aa_casino_record(width, ident):
    $ entry = aa_cm.record(aa_world, ident)
    $ ledger = aa_cm.transactions(aa_world, ident)
    if entry:
        text aa_cm.GAMES[entry["game"]] style "aa_phone_title" size aa_phone_size(25)
        text aa_fm.stamp(entry["finished_at"]) style "aa_casino_muted" size aa_phone_size(13)
        if entry["data"]:
            if entry["game"] == "blackjack":
                use aa_casino_blackjack(width, entry)
            elif entry["game"] == "roulette":
                use aa_casino_roulette(width, entry)
                text ("Escolha · " + aa_casino_bet_label(entry["data"]["bet"])) style "aa_casino_muted" size aa_phone_size(14)
            elif entry["game"] == "slots":
                use aa_casino_slots(width, entry)
            elif entry["game"] == "dice":
                use aa_casino_dice(width, entry)
                text ("Escolha · " + aa_casino_bet_label(entry["data"]["bet"])) style "aa_casino_muted" size aa_phone_size(14)
            elif entry["game"] == "crash":
                use aa_crash_table(width, entry, readonly=True)
            elif entry["game"] == "holdem":
                use aa_holdem_table(width, entry, readonly=True)
            elif entry["game"] == "plinko":
                use aa_plinko_table(width, entry, readonly=True)
            else:
                use aa_casino_mines(width, entry, readonly=True)
                text (str(entry["data"]["count"]) + " minas · " + str(len(entry["data"]["revealed"])) + " casas abertas") style "aa_casino_muted" size aa_phone_size(14)
        else:
            text "Este registro antigo conserva os valores e o resultado, sem o detalhe da mesa." style "aa_casino_muted" size aa_phone_size(14)
        use aa_casino_result(width, entry, False)
    else:
        text "Rodada anterior ao histórico recente" style "aa_phone_title" size aa_phone_size(23)
        text "Os lançamentos financeiros continuam disponíveis abaixo." style "aa_casino_muted" size aa_phone_size(14)
    null height 8
    text "Banco" style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17)
    for tx in ledger:
        textbutton (tx["title"].replace("Mesa · ", "") + " · " + aa_casino_signed(tx["amount"])):
            style "aa_casino_button"
            text_size aa_phone_size(14)
            xfill True
            action Function(aa_casino_bank, tx["id"])
            alt ("Abrir lançamento " + tx["id"] + " no Banco")
    if not ledger:
        text "Nenhum lançamento encontrado nesta partida." style "aa_casino_muted" size aa_phone_size(14)

screen aa_casino_rules(game, width):
    textbutton ("Sons do Mesa · " + ("ativados" if aa_phone_pref("casino_sound", True) else "desativados")) style "aa_casino_button" xfill True text_size aa_phone_size(14) action Function(aa_casino_toggle_audio)
    text "Seu dinheiro na história" style "aa_phone_title" size aa_phone_size(23)
    text "Mesa usa o mesmo saldo do Banco. Apostar debita na hora; o retorno volta à conta ao concluir a rodada. Você pode apostar tudo, inclusive o dinheiro das suas despesas." style "aa_casino_text" size aa_phone_size(15)
    text "Os multiplicadores incluem a aposta. Retorno de 2× em R$ 5 devolve R$ 10: lucro de R$ 5. Frações são arredondadas para baixo ao centavo." style "aa_casino_muted" size aa_phone_size(14)
    for key in ((game,) if game else tuple(aa_cm.GAMES)):
        null height 6
        text aa_cm.GAMES[key] style "aa_phone_title" size aa_phone_size(24)
        for title, body in AA_CASINO_RULES[key]:
            text title style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(16)
            text body style "aa_casino_muted" size aa_phone_size(14)
    text "Rodadas acompanham o save. Sair do app não cancela uma aposta. O dinheiro pertence à partida, sem depósitos ou saques externos." style "aa_casino_muted" size aa_phone_size(14)
