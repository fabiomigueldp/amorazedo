# Integration tests exercise real Ren'Py channels, not a mocked audio backend.
testsuite aa_audio:
    setup:
        $ _test.timeout = 35.0
        $ _test.transition_timeout = .02
        $ preferences.text_cps = 0
    before testcase:
        if not screen 'main_menu':
            run MainMenu(confirm=False)
        assert screen 'main_menu'
    teardown:
        exit

    testcase menu_and_library:
        assert eval aa_audio_family == 'M09'
        assert eval aa_audio_room is None
        run ShowMenu('preferences')
        assert screen 'preferences' timeout 5.0
        pause 1.0
        screenshot 'audio_preferences.png'
        assert eval preferences.get_volume('ambience') >= 0
        click 'Biblioteca sonora'
        assert screen 'aa_sound_library'
        pause 1.0
        screenshot 'audio_library.png'
        $ renpy.music.play(aa_audio_path('M01_base'), channel='aa_audition', loop=False)
        pause .3
        assert eval renpy.music.is_playing(channel='aa_audition')
        click 'Voltar'
        pause .3
        assert eval not renpy.music.is_playing(channel='aa_audition')

    testcase audio_save_load_rollback:
        run Start()
        advance until screen 'choice'
        click 'Abrir o perfil de Yasmin.'
        advance until screen 'choice'
        assert eval aa_audio_family == 'M02' and aa_audio_room == 'AMB01'
        run QuickSave()
        click 'Fechar a publicação. Agora eu sei que ela está lá.'
        advance until screen 'choice'
        assert eval aa_audio_family == 'M01'
        run QuickLoad(confirm=False)
        assert eval aa_node == 'a01' timeout 10.0
        assert eval aa_audio_family == 'M02' and aa_audio_room == 'AMB01'
        assert eval not renpy.music.is_playing(channel='aa_water')
        click 'Fechar a publicação. Agora eu sei que ela está lá.'
        advance until screen 'choice'
        run Rollback() until eval (aa_node == 'a01' and renpy.get_screen('choice')) timeout 10.0
        assert eval aa_audio_family == 'M02' and aa_audio_room == 'AMB01'

    testcase tap_and_room_continuity:
        run Start()
        advance until 'Ela entrou no banheiro.'
        pause .3
        assert eval aa_audio_room == 'AMB01' and aa_audio_family is None
        assert eval renpy.music.is_playing(channel='aa_water')
        advance until 'Era a de banho.'
        pause .3
        assert eval not renpy.music.is_playing(channel='aa_water')
        advance until screen 'choice'
        click 'Deixar o celular e separar a roupa.'
        advance until screen 'choice'
        assert eval aa_audio_room == 'AMB01' and aa_audio_family == 'M01'

    testcase finite_water_and_skip:
        run Start()
        advance until 'Ela entrou no banheiro.'
        pause 8.0
        assert eval not renpy.music.is_playing(channel='aa_water')
        $ aa_audio_event('a00', 'line', 4)
        assert eval aa_audio_last_event == 'Q003'
        $ config.skipping = 'fast'
        $ aa_audio_event('a00', 'line', 1)
        $ config.skipping = None
        pause .2
        assert eval not renpy.music.is_playing(channel='aa_water')

    testcase branches_and_time_changes:
        run Start()
        advance until screen 'choice'
        $ aa_audio_enter('a01')
        $ aa_audio_enter('a02')
        $ aa_audio_last_event = None
        $ aa_audio_event('a02', 'line', 0)
        assert eval aa_audio_last_event is None
        $ aa_state = dict(aa_state, route='juntas')
        $ aa_audio_enter('r00')
        assert eval aa_audio_room == 'AMB07' and aa_audio_family is None
        $ aa_audio_event('r00', 'line', 6)
        assert eval aa_audio_last_event == 'Q048'
        $ aa_audio_event('r00', 'line', 8)
        assert eval aa_audio_last_event == 'Q048'
        $ aa_audio_enter('e00')
        $ aa_audio_event('e00', 'line', 4)
        pause .2
        assert eval renpy.music.is_playing(channel='aa_water')
        $ aa_audio_event('e00', 'line', 4, phase=1)
        pause .2
        assert eval aa_audio_room == 'AMB14'
        assert eval not renpy.music.is_playing(channel='aa_water')
        $ aa_audio_ending()
        assert eval aa_audio_family == 'M10'
        run MainMenu(confirm=False)
        pause .3
        assert eval aa_audio_room is None and aa_audio_family == 'M09'

    testcase car_close_and_morning:
        run Start()
        advance until screen 'choice'
        run Jump('cr00')
        advance until screen 'choice'
        assert eval aa_audio_room == 'AMB11' and aa_audio_family == 'M11'
        click 'Abraçá-la e ficar ali, sem apressar a despedida.'
        advance until 'Ela passou os braços pela minha cintura.'
        assert eval aa_audio_last_event == 'QCAR_HUG'
        advance until screen 'choice'
        assert eval aa_node == 'cr01' and aa_audio_room == 'AMB19'
        assert eval aa_audio_family is None
        pause .3
        assert eval renpy.music.is_playing(channel='aa_room%d' % aa_audio_deck)
        click 'Dizer que sim e oferecer o ombro.'
        advance until 'Antes de o motorista arrancar'
        assert eval aa_audio_last_event == 'QCAR_REBUCKLE' and aa_audio_room == 'AMB19'
        advance until 'Vanessa apoiou a cabeça no meu ombro.'
        assert eval aa_audio_room == 'AMB18' and aa_audio_family == 'M11'
        run QuickSave()
        advance until 'Quando ela apertou minha mão'
        assert eval aa_audio_last_event == 'QCOZY_HAND'
        advance until 'Esperei ela entrar em casa.'
        assert eval aa_audio_room == 'AMB19' and aa_audio_family is None
        advance until 'Depois pedi ao motorista'
        assert eval aa_audio_room == 'AMB18'
        run QuickLoad(confirm=False)
        assert eval aa_audio_room == 'AMB18' timeout 10.0
        advance until 'Na manhã seguinte, acordei no meu quarto.'
        assert eval aa_node == 'e03' and aa_audio_room == 'AMB14'
        assert eval aa_audio_last_event == 'Q089'

    testcase car_without_contact:
        run Start()
        advance until screen 'choice'
        run Jump('cr00')
        advance until screen 'choice'
        click 'Dizer que prefiro esperar ao lado dela, sem abraçar.'
        advance until 'Ela recolheu as mãos'
        assert eval aa_audio_last_event == 'QCAR_NO_HUG'
        advance until screen 'choice'
        assert eval aa_audio_room == 'AMB19'
        click 'Pedir que fiquem cada um no seu lugar por enquanto.'
        advance until 'O motorista arrancou.'
        assert eval aa_audio_room == 'AMB18' and aa_audio_last_event == 'QCAR_DRIVE_APART'
        assert eval aa_audio_family == 'M11'
        advance until 'Na manhã seguinte, acordei no meu quarto.'
        assert eval aa_audio_room == 'AMB14'

    testcase cozy_reduced_music:
        run Start()
        advance until screen 'choice'
        $ persistent.aa_reduced_music = True
        run Jump('cr00')
        advance until screen 'choice'
        pause .3
        assert eval aa_audio_family == 'M11'
        assert eval renpy.music.get_playing(channel='music') == aa_audio_path('M11_reduzida') timeout 3.0
        $ persistent.aa_reduced_music = False
        $ aa_audio_refresh_music()
        pause 1.5
        assert eval renpy.music.get_playing(channel='music') == aa_audio_path('M11_base') timeout 3.0

    testcase meal_and_loan_cues:
        run Start()
        advance until screen 'choice'
        $ aa_state = dict(aa_state, route='juntas')
        $ aa_audio_enter('i00')
        $ aa_audio_event('i00', 'line', 20)
        assert eval aa_audio_last_event == 'QEAT_FOUR_LATER'
        $ aa_state = dict(aa_state, route='separadas')
        $ aa_audio_event('i00', 'line', 23)
        assert eval aa_audio_last_event == 'Q040'
        run Jump('jl00')
        advance until screen 'choice'
        assert eval aa_audio_family is None
        assert eval aa_audio_room == 'AMB07' and aa_audio_last_event == 'QLOAN_UNLOCK'
        click 'Assumir os sessenta reais e combinar amanhã até meio-dia.'
        advance until 'Entraram sessenta reais.'
        assert eval aa_audio_last_event == 'Q068'
        advance until 'Voltei para Vanessa.'
        assert eval aa_audio_last_event == 'QLOAN_RETURN_PAY_0' and aa_audio_room == 'AMB06'

    testcase loan_refused:
        run Start()
        advance until screen 'choice'
        $ aa_state = dict(aa_state, route='juntas')
        run Jump('jl00')
        advance until screen 'choice'
        click 'Desistir do empréstimo e dividir a conta com Vanessa.'
        advance until 'Afastei a conta para o garçom conseguir pegar.'
        assert eval aa_audio_last_event == 'QLOAN_REFUSE_PAPER'
        assert eval aa_audio_room == 'AMB07' and aa_state['bill'] == 'admitida'
