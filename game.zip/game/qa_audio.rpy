# Integration tests exercise real Ren'Py channels, not a mocked audio backend.
testsuite aa_audio:
    setup:
        $ _test.timeout = 35.0
        $ _test.transition_timeout = .02
        $ preferences.text_cps = 0
    before testcase:
        if not screen 'main_menu':
            run MainMenu(confirm=False)
        assert screen 'main_menu'
    teardown:
        exit

    testcase menu_and_library:
        assert eval aa_audio_family == 'M09'
        assert eval aa_audio_room is None
        run ShowMenu('preferences')
        assert screen 'preferences' timeout 5.0
        pause 1.0
        screenshot 'audio_preferences.png'
        assert eval preferences.get_volume('ambience') >= 0
        click 'Biblioteca sonora'
        assert screen 'aa_sound_library'
        pause 1.0
        screenshot 'audio_library.png'
        $ renpy.music.play(aa_audio_path('M01_base'), channel='aa_audition', loop=False)
        pause .3
        assert eval renpy.music.is_playing(channel='aa_audition')
        click 'Voltar'
        pause .3
        assert eval not renpy.music.is_playing(channel='aa_audition')

    testcase audio_save_load_rollback:
        run Start()
        advance until screen 'choice'
        click 'Abrir o perfil de Yasmin.'
        advance until screen 'choice'
        assert eval aa_audio_family == 'M02' and aa_audio_room == 'AMB01'
        run QuickSave()
        click 'Fechar a publicação. Agora eu sei que ela está lá.'
        advance until screen 'choice'
        assert eval aa_audio_family == 'M01'
        run QuickLoad(confirm=False)
        assert eval aa_node == 'a01' timeout 10.0
        assert eval aa_audio_family == 'M02' and aa_audio_room == 'AMB01'
        assert eval not renpy.music.is_playing(channel='aa_water')
        click 'Fechar a publicação. Agora eu sei que ela está lá.'
        advance until screen 'choice'
        run Rollback() until eval (aa_node == 'a01' and renpy.get_screen('choice')) timeout 10.0
        assert eval aa_audio_family == 'M02' and aa_audio_room == 'AMB01'

    testcase tap_and_room_continuity:
        run Start()
        advance until 'Ela entrou no banheiro.'
        pause .3
        assert eval aa_audio_room == 'AMB01' and aa_audio_family is None
        assert eval renpy.music.is_playing(channel='aa_water')
        advance until 'Era a de banho.'
        pause .3
        assert eval not renpy.music.is_playing(channel='aa_water')
        advance until screen 'choice'
        click 'Deixar o celular e separar a roupa.'
        advance until screen 'choice'
        assert eval aa_audio_room == 'AMB01' and aa_audio_family == 'M01'

    testcase finite_water_and_skip:
        run Start()
        advance until 'Ela entrou no banheiro.'
        pause 8.0
        assert eval not renpy.music.is_playing(channel='aa_water')
        $ aa_audio_event('a00', 'line', 4)
        assert eval aa_audio_last_event == 'Q003'
        $ config.skipping = 'fast'
        $ aa_audio_event('a00', 'line', 1)
        $ config.skipping = None
        pause .2
        assert eval not renpy.music.is_playing(channel='aa_water')

    testcase branches_and_time_changes:
        run Start()
        advance until screen 'choice'
        $ aa_audio_enter('a01')
        $ aa_audio_enter('a02')
        $ aa_audio_last_event = None
        $ aa_audio_event('a02', 'line', 0)
        assert eval aa_audio_last_event is None
        $ aa_state = dict(aa_state, route='juntas')
        $ aa_audio_enter('r00')
        assert eval aa_audio_room == 'AMB07' and aa_audio_family is None
        $ aa_audio_event('r00', 'line', 6)
        assert eval aa_audio_last_event == 'Q048'
        $ aa_audio_event('r00', 'line', 8)
        assert eval aa_audio_last_event == 'Q048'
        $ aa_audio_enter('e00')
        $ aa_audio_event('e00', 'line', 4)
        pause .2
        assert eval renpy.music.is_playing(channel='aa_water')
        $ aa_audio_event('e00', 'line', 4, phase=1)
        pause .2
        assert eval aa_audio_room == 'AMB14'
        assert eval not renpy.music.is_playing(channel='aa_water')
        $ aa_audio_ending()
        assert eval aa_audio_family == 'M10'
        run MainMenu(confirm=False)
        pause .3
        assert eval aa_audio_room is None and aa_audio_family == 'M09'
