# Imagegen supplies the corrected object. Native composition preserves every
# original pixel outside its local region, including faces, costumes and sets.
init -4 python:
    renpy.register_shader("aa.scene_patch", variables="""
        uniform vec2 u_scene_patch_size;
        attribute vec4 a_position;
        varying vec2 v_scene_patch_position;
    """, vertex_300="""
        v_scene_patch_position = a_position.xy;
    """, fragment_400="""
        vec2 edge = min(v_scene_patch_position, u_scene_patch_size - v_scene_patch_position);
        gl_FragColor *= smoothstep(0.0, 6.0, min(edge.x, edge.y));
    """)

    def aa_phone_scene_patch(original, replacement, regions):
        layers = [(0, 0), original]
        for x, y, width, height in regions:
            patch = Transform(Crop((x, y, width, height), replacement),
                              mesh=True, shader="aa.scene_patch",
                              u_scene_patch_size=(float(width), float(height)))
            layers.extend([(x, y), patch])
        return Transform(Composite((1672, 941), *layers), xysize=(1280, 720), fit="cover")
