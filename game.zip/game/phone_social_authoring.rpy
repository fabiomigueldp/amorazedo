# Presentation state is separate from the campaign. Only the final native
# control runs the same choice action as the narration's menu.
default aa_phone_banner = None

init python:
    def aa_social_choice(caption):
        menu = renpy.get_screen('choice')
        return next((item.action for item in menu.scope.get('items', ())
                     if item.caption == caption and item.action is not None), None) if menu else None

    def aa_social_commit(caption):
        action = aa_social_choice(caption)
        if action is not None:
            aa_phone_close()
            return renpy.run(action)

    def aa_social_edit_value(name, fallback=None):
        screen = renpy.get_screen('aa_phone_hub') or renpy.get_screen('aa_phone_view')
        return screen.scope.get(name, fallback) if screen else fallback

    def aa_social_edit_set(name, value):
        target = 'aa_phone_hub' if renpy.get_screen('aa_phone_hub') else 'aa_phone_view'
        renpy.set_screen_variable(name, value, target)
        renpy.restart_interaction()

    def aa_social_own_options():
        aa_phone_open()
        aa_social_panel_open('more', 'publicacao_feka')

    def aa_social_banner_close(open_chat=False):
        global aa_phone_banner
        aa_phone_banner = None
        if open_chat:
            aa_phone_open(contact='Vanessa')
        renpy.restart_interaction()

transform aa_message_banner_enter:
    alpha 0.0
    yoffset (-24 if persistent.aa_motion else 0)
    easeout (0.3 if persistent.aa_motion else 0.0) alpha 1.0 yoffset 0

screen aa_phone_incoming_banner(width):
    if aa_phone_banner and aa_node == 'post_request':
        timer 7.0 action Function(aa_social_banner_close)
        button:
            id 'incoming_vanessa'
            xpos 7 ypos 43 xsize (width - 14) yminimum 92
            padding (11, 12)
            background aa_phone_round('message-glass-solid', 22)
            action Function(aa_social_banner_close, True)
            alt 'Ler mensagem de Vanessa'
            at aa_message_banner_enter
            hbox:
                spacing 10
                fixed:
                    xysize (42, 45)
                    use aa_social_avatar('Vanessa', 40)
                    add aa_phone_app_art('messages', 16) xysize (16, 16) xpos 28 ypos 27
                vbox:
                    xsize (width - 88) spacing 3
                    fixed:
                        xysize (width - 88, 19)
                        text 'Vanessa' style 'aa_social_text' font 'fonts/Inter-SemiBold.ttf' size aa_phone_size(14)
                        text 'agora' style 'aa_social_muted' size 10 xalign 1.0 ypos 3
                    text 'Não me marca, por favor.' style 'aa_social_text' size aa_phone_size(14) xmaximum (width - 88)

screen aa_social_composer(width, height):
    $ editor = aa_social_edit_value('social_editor')
    $ tagged = aa_social_edit_value('social_draft_tagged', False)
    $ share_caption = 'Publicar e marcar Vanessa.' if tagged else 'Publicar sem marcar ninguém.'
    fixed:
        xysize (width, height)
        fixed:
            xpos 6 ypos 45 xysize (width - 12, 49)
            use aa_social_icon_button('back', Function(aa_social_edit_set, 'social_editor', None if editor else 'discard'), 'Voltar', 22)
            text ('Marcar pessoas' if editor == 'tags' else 'Nova publicação') style 'aa_social_text' font 'fonts/Inter-SemiBold.ttf' size aa_phone_size(17) xalign .5 yalign .5
        if editor == 'tags':
            add aa_phone_cover('post6_copos', width, 260) ypos 100
            text 'Pessoas marcadas' style 'aa_social_muted' size aa_phone_size(12) xpos 14 ypos 377
            button:
                style 'aa_social_button' xpos 12 ypos 403 xysize (width - 24, 64)
                action Function(aa_social_edit_set, 'social_draft_tagged', not tagged)
                alt 'Marcar Vanessa'
                fixed:
                    xysize (width - 24, 64)
                    fixed:
                        ypos 11 xysize (42, 42)
                        use aa_social_avatar('Vanessa', 42)
                    text 'Vanessa' style 'aa_social_text' size aa_phone_size(15) xpos 54 yalign .5
                    text ('✓' if tagged else '○') style 'aa_social_text' color '#63adff' size 23 xalign 1.0 yalign .5
            textbutton 'Concluir':
                style 'aa_social_button' text_style 'aa_social_text'
                text_xalign .5 text_yalign .5
                background aa_phone_round('social-blue', 12)
                xpos 14 ypos (height - 88) xysize (width - 28, 46)
                action Function(aa_social_edit_set, 'social_editor', None)
        else:
            viewport:
                xpos 0 ypos 100 xysize (width, height - 200)
                mousewheel True draggable True
                vbox:
                    xsize width spacing 0
                    add aa_phone_cover('post6_copos', width, 270)
                    hbox:
                        spacing 10 xpos 14 ysize 78
                        fixed:
                            xysize (34, 78)
                            fixed:
                                ypos 20 xysize (34, 34)
                                use aa_social_avatar('Feka', 34)
                        text 'Uma noite ótima.' style 'aa_social_text' size aa_phone_size(15) yalign .5 xmaximum (width - 78)
                    add Solid('#28282d') xysize (width, 1)
                    button:
                        style 'aa_social_button' xsize width yminimum 59 padding (14, 12)
                        action Function(aa_social_edit_set, 'social_editor', 'tags')
                        alt 'Marcar pessoas'
                        fixed:
                            xysize (width - 28, 32)
                            text 'Marcar pessoas' style 'aa_social_text' size aa_phone_size(14) yalign .5
                            text ('Vanessa  ›' if tagged else '›') style 'aa_social_muted' size aa_phone_size(13) xalign 1.0 yalign .5
                    add Solid('#28282d') xysize (width, 1)
            textbutton 'Compartilhar':
                id 'share_publication'
                style 'aa_social_button' text_style 'aa_social_text' text_font 'fonts/Inter-SemiBold.ttf'
                text_xalign .5 text_yalign .5
                background aa_phone_round('social-blue', 12)
                xpos 14 ypos (height - 88) xysize (width - 28, 46)
                sensitive aa_social_choice(share_caption) is not None
                action Function(aa_social_commit, share_caption)
        if editor == 'discard':
            use aa_social_confirmation(width, height, 'Descartar publicação?', 'A foto continuará em Fotos.', 'Descartar', Function(aa_social_commit, 'Desistir da publicação.'), Function(aa_social_edit_set, 'social_editor', None))

screen aa_social_confirmation(width, height, title, body, confirm, action, cancel):
    button:
        xysize (width, height - 30) ypos 38 background Solid('#00000088')
        action cancel alt 'Cancelar'
    frame:
        xpos 8 ypos (height - 267) xsize (width - 16)
        padding (16, 18) background aa_phone_round('message-sheet', 24)
        vbox:
            xsize (width - 48) spacing 12
            text title style 'aa_social_text' font 'fonts/Inter-SemiBold.ttf' size aa_phone_size(17) xalign .5
            text body style 'aa_social_muted' size aa_phone_size(13) xalign .5 textalign .5
            textbutton confirm style 'aa_social_button' text_color '#ff686d' text_size aa_phone_size(16) xfill True action action
            textbutton 'Cancelar' style 'aa_social_button' text_size aa_phone_size(15) xfill True action cancel

screen aa_social_post_options(width, height, panel):
    if panel == 'delete':
        use aa_social_confirmation(width, height, 'Excluir publicação?', 'A foto continuará em Fotos.', 'Excluir', Function(aa_social_commit, 'Apagar a publicação.'), Function(aa_social_panel_open, 'more', 'publicacao_feka'))
    elif panel == 'edit_tags':
        $ tagged = aa_social_edit_value('social_draft_tagged', True)
        button:
            xysize (width, height - 30) ypos 38 background Solid('#00000088')
            action Function(aa_social_panel_close) alt 'Cancelar edição'
        frame:
            xpos 8 ypos (height - 296) xsize (width - 16)
            padding (16, 17) background aa_phone_round('message-sheet', 24)
            vbox:
                spacing 10 xsize (width - 48)
                text 'Editar marcações' style 'aa_social_text' font 'fonts/Inter-SemiBold.ttf' size aa_phone_size(17) xalign .5
                button:
                    style 'aa_social_button' xfill True ysize 60
                    action Function(aa_social_edit_set, 'social_draft_tagged', not tagged)
                    alt 'Remover marcação de Vanessa'
                    fixed:
                        xysize (width - 48, 60)
                        fixed:
                            ypos 11 xysize (38, 38)
                            use aa_social_avatar('Vanessa', 38)
                        text 'Vanessa' style 'aa_social_text' size aa_phone_size(15) xpos 48 yalign .5
                        text ('✓' if tagged else '○') style 'aa_social_text' color '#63adff' size 23 xalign 1.0 yalign .5
                textbutton 'Concluir':
                    style 'aa_social_button' text_color '#63adff' xfill True
                    action (Function(aa_social_panel_close) if tagged else Function(aa_social_commit, 'Tirar a marcação e manter a publicação.'))
                textbutton 'Cancelar' style 'aa_social_button' xfill True action Function(aa_social_panel_close)
    else:
        button:
            xysize (width, height - 30) ypos 38 background Solid('#00000088')
            action Function(aa_social_panel_close) alt 'Fechar opções'
        frame:
            xpos 8 ypos (height - 270) xsize (width - 16)
            padding (15, 12) background aa_phone_round('message-sheet', 24)
            vbox:
                spacing 4 xsize (width - 46)
                add aa_phone_round('received', 2) xysize (32, 4) xalign .5
                $ own_post = next((p for p in aa_pm.social_posts(aa_phone_memory) if p['id'] == 'publicacao_feka'), None)
                if own_post:
                    textbutton ('Remover dos salvos' if aa_social_is_saved(own_post) else 'Salvar publicação'):
                        style 'aa_social_button' text_size aa_phone_size(15) xfill True
                        action Function(aa_social_toggle_save, own_post)
                if aa_social_choice('Tirar a marcação e manter a publicação.'):
                    textbutton 'Editar marcações':
                        style 'aa_social_button' text_size aa_phone_size(15) xfill True
                        action [Function(aa_social_edit_set, 'social_draft_tagged', True), Function(aa_social_panel_open, 'edit_tags', 'publicacao_feka')]
                if aa_social_choice('Apagar a publicação.'):
                    textbutton 'Excluir':
                        style 'aa_social_button' text_color '#ff686d' text_size aa_phone_size(15) xfill True
                        action Function(aa_social_panel_open, 'delete', 'publicacao_feka')
                textbutton 'Cancelar' style 'aa_social_button' text_size aa_phone_size(15) xfill True action Function(aa_social_panel_close)

screen aa_social_empty_profile(width, height):
    $ remaining = aa_pm.social_profile_posts(aa_phone_memory, 'Feka')
    text 'Feka' style 'aa_social_text' font 'fonts/Inter-SemiBold.ttf' size 19 xpos 14 ypos 55
    fixed:
        xpos 14 ypos 110 xysize (72, 72)
        use aa_social_avatar('Feka', 72)
    text str(len(remaining)) style 'aa_social_text' size 20 xpos 116 ypos 120
    text ('publicação' if len(remaining) == 1 else 'publicações') style 'aa_social_muted' size 13 xpos 116 ypos 148
    text 'Você' style 'aa_social_text' size 14 xpos 14 ypos 205
    add Solid('#28282d') xysize (width, 1) ypos 250
    if remaining:
        viewport:
            ypos 262 xysize (width, height - 300)
            mousewheel True draggable True
            vbox:
                xsize width spacing 2
                for post in remaining:
                    button:
                        background None padding (0, 0) xysize (width // 3, width // 3)
                        action [Function(aa_phone_open), Function(aa_phone_select, post, 'social')]
                        alt 'Abrir publicação anterior'
                        add aa_phone_cover(post['image'], width // 3, width // 3)
    else:
        add aa_social_icon('grid') xysize (28, 28) xalign .5 ypos 290
        text 'Nenhuma publicação' style 'aa_social_text' size aa_phone_size(17) xalign .5 ypos 340
