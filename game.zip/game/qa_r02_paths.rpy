# Gerado por tools/check_r02_paths.py.
testsuite aa_r02_paths:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = 'C:/Users/fabio/Projects/amor_azedo/output/qa/r02'
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu" timeout 5.0
    teardown:
        exit

    testcase separadas_vanessa:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Dizer que vamos deixar os dois jantarem."
        advance until screen "choice"
        assert eval aa_node == 'p00'
        click "Pedir para trocar de cadeira e contar a origem da reserva."
        advance until screen "choice"
        assert eval aa_node == 'p01'
        click "Pedir que conte o que mais a preocupa."
        advance until screen "choice"
        assert eval aa_node == 'p02'
        click "Contar que insisti por anos, mesmo depois de ela dizer não."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Ficar com Vanessa."
        advance until screen "choice"
        assert eval aa_node == 'iv'
        click "Perguntar o que ela queria desta noite e ouvir."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Você ficou aqui comigo. Eu sei. Só queria sentir que você também quer estar aqui." timeout 5.0
        pause 0.3
        screenshot "separadas_vanessa.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase separadas_joaozao:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Dizer que vamos deixar os dois jantarem."
        advance until screen "choice"
        assert eval aa_node == 'p00'
        click "Pedir para trocar de cadeira e contar a origem da reserva."
        advance until screen "choice"
        assert eval aa_node == 'p01'
        click "Pedir que conte o que mais a preocupa."
        advance until screen "choice"
        assert eval aa_node == 'p02'
        click "Contar que insisti por anos, mesmo depois de ela dizer não."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Conversar com Joãozão, sem plateia."
        advance until screen "choice"
        assert eval aa_node == 'ij'
        click "Admitir minha insistência e pedir que não faça uma cena."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Você foi falar com Joãozão e eu fiquei esperando. Se precisar levantar, me avisa antes." timeout 5.0
        pause 0.3
        screenshot "separadas_joaozao.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase separadas_yasmin:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Dizer que vamos deixar os dois jantarem."
        advance until screen "choice"
        assert eval aa_node == 'p00'
        click "Pedir para trocar de cadeira e contar a origem da reserva."
        advance until screen "choice"
        assert eval aa_node == 'p01'
        click "Pedir que conte o que mais a preocupa."
        advance until screen "choice"
        assert eval aa_node == 'p02'
        click "Contar que insisti por anos, mesmo depois de ela dizer não."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Procurar Yasmin no corredor."
        advance until screen "choice"
        assert eval aa_node == 'iy'
        click "Parar de pedir uma resposta diferente."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Mas você foi atrás dela e me deixou esperando. Se quiser sair da mesa, fala comigo antes." timeout 5.0
        pause 0.3
        screenshot "separadas_yasmin.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase juntas_vanessa:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Sugerir que juntemos as mesas."
        advance until screen "choice"
        assert eval aa_node == 'c00'
        click "Admitir que a crítica de Vanessa é justa."
        advance until screen "choice"
        assert eval aa_node == 'c01'
        click "Dizer que não era uma coincidência e assumir a insistência."
        advance until screen "choice"
        assert eval aa_node == 'c02'
        click "Guardar o celular e voltar a comer."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Ficar com Vanessa."
        advance until screen "choice"
        assert eval aa_node == 'iv'
        click "Perguntar o que ela queria desta noite e ouvir."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Você ficou aqui comigo. Eu sei. Só queria sentir que você também quer estar aqui." timeout 5.0
        pause 0.3
        screenshot "juntas_vanessa.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase juntas_joaozao:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Sugerir que juntemos as mesas."
        advance until screen "choice"
        assert eval aa_node == 'c00'
        click "Admitir que a crítica de Vanessa é justa."
        advance until screen "choice"
        assert eval aa_node == 'c01'
        click "Dizer que não era uma coincidência e assumir a insistência."
        advance until screen "choice"
        assert eval aa_node == 'c02'
        click "Guardar o celular e voltar a comer."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Conversar com Joãozão, sem plateia."
        advance until screen "choice"
        assert eval aa_node == 'ij'
        click "Admitir minha insistência e pedir que não faça uma cena."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Você foi falar com Joãozão e eu fiquei esperando. Se precisar levantar, me avisa antes." timeout 5.0
        pause 0.3
        screenshot "juntas_joaozao.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase juntas_yasmin:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Sugerir que juntemos as mesas."
        advance until screen "choice"
        assert eval aa_node == 'c00'
        click "Admitir que a crítica de Vanessa é justa."
        advance until screen "choice"
        assert eval aa_node == 'c01'
        click "Dizer que não era uma coincidência e assumir a insistência."
        advance until screen "choice"
        assert eval aa_node == 'c02'
        click "Guardar o celular e voltar a comer."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Procurar Yasmin no corredor."
        advance until screen "choice"
        assert eval aa_node == 'iy'
        click "Parar de pedir uma resposta diferente."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Mas você foi atrás dela e me deixou esperando. Se quiser sair da mesa, fala comigo antes." timeout 5.0
        pause 0.3
        screenshot "juntas_yasmin.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase varanda_vanessa:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Pedir um minuto com Yasmin antes de sentar."
        advance until screen "choice"
        assert eval aa_node == 't00'
        click "Dizer que entendi e voltar para Vanessa."
        advance until screen "choice"
        assert eval aa_node == 't01'
        click "Sair do caminho e voltar à mesa."
        advance until screen "choice"
        assert eval aa_node == 't02'
        click "Pedir desculpa pelo tempo e contar o que fui fazer."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Ficar com Vanessa."
        advance until screen "choice"
        assert eval aa_node == 'iv'
        click "Perguntar o que ela queria desta noite e ouvir."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Quando a gente chegou, você me deixou esperando pra falar com ela. Agora eu queria ficar com você." timeout 5.0
        pause 0.3
        screenshot "varanda_vanessa.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase varanda_joaozao:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Pedir um minuto com Yasmin antes de sentar."
        advance until screen "choice"
        assert eval aa_node == 't00'
        click "Dizer que entendi e voltar para Vanessa."
        advance until screen "choice"
        assert eval aa_node == 't01'
        click "Sair do caminho e voltar à mesa."
        advance until screen "choice"
        assert eval aa_node == 't02'
        click "Pedir desculpa pelo tempo e contar o que fui fazer."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Conversar com Joãozão, sem plateia."
        advance until screen "choice"
        assert eval aa_node == 'ij'
        click "Admitir minha insistência e pedir que não faça uma cena."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Você foi falar com Joãozão e eu fiquei esperando. Se precisar levantar, me avisa antes." timeout 5.0
        pause 0.3
        screenshot "varanda_joaozao.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"

    testcase varanda_yasmin:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Perguntar se ela prefere a camiseta."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que achei por acaso."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Apresentar Vanessa como minha namorada."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Pedir um minuto com Yasmin antes de sentar."
        advance until screen "choice"
        assert eval aa_node == 't00'
        click "Dizer que entendi e voltar para Vanessa."
        advance until screen "choice"
        assert eval aa_node == 't01'
        click "Sair do caminho e voltar à mesa."
        advance until screen "choice"
        assert eval aa_node == 't02'
        click "Pedir desculpa pelo tempo e contar o que fui fazer."
        advance until screen "choice"
        assert eval aa_node == 'i00'
        click "Procurar Yasmin no corredor."
        advance until screen "choice"
        assert eval aa_node == 'iy'
        click "Parar de pedir uma resposta diferente."
        advance until screen "choice"
        assert eval aa_node == 'r00'
        click "Repetir que foi coincidência e que Vanessa está exagerando."
        advance until screen "choice"
        assert eval aa_node == "r02"
        click "Pedir para terminar o jantar sem falar nisso."
        assert "Tá. Mas você foi atrás dela e me deixou esperando. Se quiser sair da mesa, fala comigo antes." timeout 5.0
        pause 0.3
        screenshot "varanda_yasmin.png"
        advance until "Ela não disse que acreditava em mim."
        assert "Ela não disse que acreditava em mim." timeout 5.0
        advance until screen "choice"
        assert eval aa_node == "v00"
