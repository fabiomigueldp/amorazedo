# Calculator's own full-screen layout follows Apple's iOS 27 reference.
init python:
    import phone_calculator as aa_calc

    def aa_calc_panel(value):
        renpy.set_screen_variable("calc_panel", value, "aa_phone_hub")
        renpy.set_screen_variable("calc_edit", False, "aa_phone_hub")
        renpy.restart_interaction()

    def aa_calc_mode(value):
        aa_phone_preferences.calculator_mode = value
        aa_calc_panel(None)
        renpy.retain_after_load()

    def aa_calc_restore(item):
        aa_phone_set_pref("calculator", item[1])
        aa_calc_panel(None)

    def aa_calc_delete(index):
        rows = tuple(aa_phone_pref("calculator_history", ()))
        aa_phone_set_pref("calculator_history", rows[:index] + rows[index+1:])

    def aa_calc_copy(text):
        try:
            CopyToClipboard(text)()
        except Exception:
            renpy.notify("Não foi possível copiar neste dispositivo.")
        else:
            aa_calc_panel(None)
            renpy.notify("Copiado")

    def aa_calc_category(value):
        for name, item in (("calc_category", value), ("calc_source", aa_calc.UNITS[value][0][0]), ("calc_target", aa_calc.UNITS[value][1][0])):
            renpy.set_screen_variable(name, item, "aa_phone_hub")
            setattr(aa_phone_preferences, name, item)
        renpy.retain_after_load()
        aa_calc_panel(None)

    def aa_calc_unit(name, value):
        renpy.set_screen_variable(name, value, "aa_phone_hub")
        aa_phone_set_pref(name, value)
        aa_calc_panel(None)

    def aa_calc_note_save(text):
        result = aa_calc.math_note(text)
        if result == "Erro":
            renpy.notify("Revise a expressão e os parênteses.")
            return
        rows = tuple(aa_phone_pref("calculator_notes", ()))
        aa_phone_set_pref("calculator_notes", (rows + ((text, result),))[-50:])
        renpy.set_screen_variable("calc_note", "", "aa_phone_hub")

    @functools.lru_cache(maxsize=256)
    def aa_calc_font(value, width, maximum=48, minimum=20):
        for size in range(maximum, minimum-1, -1):
            rendered = renpy.render(Text(value, font="fonts/Inter-Regular.ttf", size=size, outlines=[]), 4096, 200, 0, 0)
            if rendered.width <= width:
                return size
        return minimum

    @functools.lru_cache(maxsize=256)
    def aa_calc_text_width(value, size):
        return renpy.render(Text(value, font="fonts/Inter-Regular.ttf", size=size, outlines=[]), 8192, 200, 0, 0).width

screen aa_calc_control(icon, action, label):
    button:
        style "aa_calc_key"
        xysize (38, 38)
        background aa_phone_round("calc-toolbar", 19)
        hover_background aa_phone_round("calc-number-hover", 19)
        action action
        alt label
        add ("gui/phone/modern/calc-" + icon + ".svg") xysize (21, 21) align (.5, .5)

screen aa_calc_keycap(caption, key, width, height, role="number", active=False):
    button:
        style "aa_calc_key"
        xysize (width, height)
        background aa_phone_round("calc-selected" if active else "calc-" + role, height // 2)
        hover_background aa_phone_round("calc-" + role + "-hover", height // 2)
        action Function(aa_phone_calc, key)
        alternate (Function(aa_phone_calc, "AC") if key in ("C", "AC", "⌫") else None)
        alt caption
        if key in ("⌫", "±"):
            add ("gui/phone/modern/calc-delete.svg" if key == "⌫" else "gui/phone/modern/calc-sign.svg") xysize (26, 26) align (.5, .5)
        else:
            text caption:
                style "aa_calc_text"
                size (int(height * .52) if len(key) <= 2 else min(16, int(height * .45)))
                font ("DejaVuSans.ttf" if key in ("√", "∛", "ʸ√") else "fonts/Inter-Regular.ttf")
                color ("#ff9500" if active else "#ffffff")
                align (.5, .5)

screen aa_calculator_app(width, height, panel, editing, note, category, source, target):
    $ state = aa_phone_pref("calculator", aa_calc.EMPTY)
    $ meta = aa_calc.metadata(state)
    $ mode = aa_phone_pref("calculator_mode", "basic")
    $ scientific = mode == "scientific"
    $ converting = mode == "convert"
    $ gap = 6
    $ margin = 18
    $ key_width = (width - margin * 2 - gap * 3) // 4
    $ key_height = 34 if scientific else key_width
    $ grid_width = key_width * 4 + gap * 3
    $ grid_x = (width - grid_width) // 2
    $ grid_y = height - 52 - (key_height * 5 + gap * 4)
    $ equation = aa_calc.expression(state)
    $ display = aa_calc.localized(state[0]) if meta.get("done") or converting else equation
    $ clear = "AC" if meta.get("done") or state[0] in ("0", "Erro") else "C"

    # A fixed viewport preserves the handset's layout contract without scrolling keys.
    viewport:
        id "phone_scroll"
        xysize (width, height - 30)
        draggable False
        mousewheel False
        fixed:
            xysize (width, height - 30)
            fixed:
                xpos grid_x
                ypos 44
                use aa_calc_control("history", Function(aa_calc_panel, "history"), "Histórico de cálculos")
            fixed:
                xpos (width - grid_x - 38)
                ypos 44
                use aa_calc_control("mode", Function(aa_calc_panel, "modes"), "Modo da calculadora")

            if converting:
                $ converted = aa_calc.localized(aa_calc.convert(state[0], category, source, target))
                textbutton category style "aa_calc_link" xpos grid_x ypos (grid_y - 152) action Function(aa_calc_panel, "units")
                text display style "aa_calc_text" size aa_calc_font(display, grid_width - 65, 36) xpos (width - grid_x - 65) xanchor 1.0 ypos (grid_y - 113)
                textbutton (source + " ›") style "aa_calc_link" xpos (width - grid_x - 62) ypos (grid_y - 109) action Function(aa_calc_panel, "source")
                add Solid("#303030") xpos grid_x ypos (grid_y - 66) xysize (grid_width, 1)
                text converted style "aa_calc_text" size aa_calc_font(converted, grid_width - 65, 36) xpos (width - grid_x - 65) xanchor 1.0 ypos (grid_y - 55)
                textbutton (target + " ›") style "aa_calc_link" xpos (width - grid_x - 62) ypos (grid_y - 51) action Function(aa_calc_panel, "target")
            else:
                $ display_bottom = grid_y - (195 if scientific else 12)
                if meta.get("done") and equation:
                    text aa_messages_elide(equation, grid_width, 20, 1) style "aa_calc_text" size 20 color "#8e8e93" xpos (width - grid_x) xanchor 1.0 ypos (display_bottom - 87)
                button:
                    style "aa_calc_key"
                    xpos grid_x
                    ypos (display_bottom - 62)
                    xysize (grid_width, 62)
                    action Function(aa_calc_panel, "copy")
                    alternate Function(aa_calc_panel, "copy")
                    alt ("Resultado " + display + ". Copiar")
                    viewport:
                        xysize (grid_width, 62)
                        xinitial 1.0
                        draggable True
                        mousewheel "horizontal"
                        $ display_size = aa_calc_font(display, grid_width, 48)
                        fixed:
                            xysize (max(grid_width, aa_calc_text_width(display, display_size)), 62)
                            text display style "aa_calc_text" size display_size align (1.0, .5) layout "nobreak"
            if scientific:
                $ second = meta.get("second", False)
                grid 6 5:
                    xpos grid_x
                    ypos (grid_y - 190)
                    spacing 5
                    for key in ("(", ")", "mc", "m+", "m−", "mr", "2nd", "x²", "x³", "xʸ", "eˣ", "2ˣ" if second else "10ˣ", "1/x", "√", "∛", "ʸ√", "ln", "log₂" if second else "log", "x!", "asin" if second else "sin", "acos" if second else "cos", "atan" if second else "tan", "e", "EE", "Rand", "asinh" if second else "sinh", "acosh" if second else "cosh", "atanh" if second else "tanh", "π", "Deg" if meta.get("radians") else "Rad"):
                        use aa_calc_keycap(key, key, (grid_width - 25) // 6, 33, active=(key == "2nd" and second))
            grid 4 5:
                xpos grid_x
                ypos grid_y
                spacing gap
                for key in ("⌫", clear, "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "±", "0", ",", "="):
                    use aa_calc_keycap(key, key, key_width, key_height, "orange" if key in ("÷", "×", "−", "+", "=") else "function" if key in ("⌫", "AC", "C", "%") else "number", state[2] == key and state[3])

    if panel is None:
        for digit in "0123456789":
            key digit action Function(aa_phone_calc, digit)
            key ("K_KP" + digit) action Function(aa_phone_calc, digit)
        for keysym, value in (("K_BACKSPACE", "⌫"), ("K_DELETE", "AC"), ("K_RETURN", "="), ("K_KP_ENTER", "="), ("K_KP_PLUS", "+"), ("K_KP_MINUS", "−"), ("K_KP_MULTIPLY", "×"), ("K_KP_DIVIDE", "÷"), ("K_KP_PERIOD", ","), ("+", "+"), ("-", "−"), ("*", "×"), ("/", "÷"), ("=", "="), (",", ","), (".", ","), ("%", "%"), ("(", "("), (")", ")")):
            key keysym action Function(aa_phone_calc, value)

    if panel:
        button:
            xpos 0
            ypos 40
            xysize (width, height - 70)
            background Solid("#00000088")
            action Function(aa_calc_panel, None)
            alt "Fechar painel da calculadora"
        if panel in ("modes", "copy"):
            frame:
                xpos (width - 234)
                ypos 89
                xsize 216
                padding (8, 8)
                background aa_phone_round("calc-sheet", 22)
                vbox:
                    spacing 1
                    if panel == "modes":
                        for label, value in (("Básica", "basic"), ("Científica", "scientific"), ("Converter", "convert")):
                            textbutton (("✓  " if mode == value else "    ") + label) style "aa_calc_menu" action Function(aa_calc_mode, value)
                        add Solid("#ffffff20") xysize (200, 1)
                        textbutton "    Notas Matemáticas" style "aa_calc_menu" action Function(aa_calc_panel, "notes")
                    else:
                        textbutton "Copiar resultado" style "aa_calc_menu" action Function(aa_calc_copy, aa_calc.localized(state[0]))
                        textbutton "Copiar expressão" style "aa_calc_menu" action Function(aa_calc_copy, equation)
        else:
            frame:
                xpos 8
                ypos 94
                xysize (width - 16, height - 130)
                padding (14, 14)
                background aa_phone_round("calc-sheet", 24)
                fixed:
                    text ("Histórico" if panel in ("history", "clear") else "Notas Matemáticas" if panel == "notes" else "Converter" if panel == "units" else "Unidade") style "aa_calc_text" size 21 ypos 6
                    textbutton "OK" style "aa_calc_link" xalign 1.0 action Function(aa_calc_panel, None)
                    if panel == "history":
                        $ history = tuple(aa_phone_pref("calculator_history", ()))
                        textbutton ("Concluir" if editing else "Editar") style "aa_calc_link" ypos 42 action SetScreenVariable("calc_edit", not editing)
                        if editing and history:
                            textbutton "Limpar" style "aa_calc_link" ypos 42 xalign 1.0 action Function(aa_calc_panel, "clear")
                        viewport:
                            ypos 88
                            xysize (width - 44, height - 252)
                            mousewheel True
                            draggable True
                            vbox:
                                xsize (width - 44)
                                spacing 6
                                if not history:
                                    null height 76
                                    text "Nenhum cálculo" style "aa_calc_text" size 21 xalign .5
                                    text "Os resultados aparecem aqui." style "aa_calc_text" color "#a0a0a5" size 14 xalign .5
                                for index in range(len(history)-1, -1, -1):
                                    $ item = history[index]
                                    button:
                                        style "aa_calc_menu"
                                        xfill True
                                        action Function(aa_calc_restore, item)
                                        alternate Function(aa_calc_copy, aa_calc.localized(item[1][0]))
                                        alt ("Recuperar " + item[0])
                                        vbox:
                                            xfill True
                                            text aa_messages_elide(item[0], width - 66, 16, 2) style "aa_calc_text" size 16 color "#a0a0a5" xalign 1.0
                                            text aa_calc.localized(item[1][0]) style "aa_calc_text" size aa_calc_font(aa_calc.localized(item[1][0]), width - 66, 28) xalign 1.0
                                    if editing:
                                        textbutton "Apagar cálculo" style "aa_calc_link" text_size 14 xalign 1.0 action Function(aa_calc_delete, index)
                                    add Solid("#ffffff18") xysize (width - 44, 1)
                    elif panel == "clear":
                        vbox:
                            ypos 90
                            spacing 20
                            text "Apagar todos os cálculos?" style "aa_calc_text" size 20
                            textbutton "Limpar histórico" style "aa_calc_menu" text_color "#ff6961" action [Function(aa_phone_set_pref, "calculator_history", ()), Function(aa_calc_panel, "history")]
                            textbutton "Cancelar" style "aa_calc_menu" action Function(aa_calc_panel, "history")
                    elif panel == "notes":
                        vbox:
                            ypos 58
                            spacing 12
                            xsize (width - 44)
                            text "Digite uma expressão" style "aa_calc_text" size 15 color "#a0a0a5"
                            frame:
                                background aa_phone_round("calc-toolbar", 12)
                                padding (10, 12)
                                xfill True
                                input:
                                    value ScreenVariableInputValue("calc_note")
                                    style "aa_calc_text"
                                    size 20
                                    length 80
                                    allow "0123456789+-*/×÷−^()., ="
                                    xmaximum (width - 64)
                                    copypaste True
                            textbutton "Calcular e guardar" style "aa_calc_link" action Function(aa_calc_note_save, note)
                            viewport:
                                xysize (width - 44, height - 340)
                                mousewheel True
                                draggable True
                                vbox:
                                    spacing 16
                                    for text_value, answer in reversed(aa_phone_pref("calculator_notes", ())):
                                        text (text_value + " = " + aa_calc.localized(answer)) style "aa_calc_text" size 18 xmaximum (width - 44)
                    else:
                        viewport:
                            ypos 60
                            xysize (width - 44, height - 224)
                            mousewheel True
                            draggable True
                            vbox:
                                xfill True
                                if panel == "units":
                                    for name in aa_calc.UNITS:
                                        textbutton name style "aa_calc_menu" action Function(aa_calc_category, name)
                                else:
                                    for name, factor, offset in aa_calc.UNITS[category]:
                                        textbutton name style "aa_calc_menu" action Function(aa_calc_unit, "calc_source" if panel == "source" else "calc_target", name)

style aa_calc_text is default:
    font "fonts/Inter-Regular.ttf"
    color "#ffffff"
    outlines []
    line_spacing 0
style aa_calc_key is button:
    padding (0, 0)
    background None
    focus_mask True
style aa_calc_link is button:
    padding (4, 8)
    background None
    hover_background aa_phone_round("calc-number-hover", 12)
style aa_calc_link_text is aa_calc_text:
    size 16
    color "#ff9f0a"
style aa_calc_menu is button:
    xfill True
    padding (8, 12)
    background None
    hover_background aa_phone_round("calc-number-hover", 12)
style aa_calc_menu_text is aa_calc_text:
    size 17
