# The view follows a saved path. Drawing never rolls, advances or pays a round.
init python:
    import plinko_model as aa_plm
    import phone_plinko_runtime as aa_plinko_runtime

    def aa_plinko_round():
        r = aa_cm.active(aa_world)
        return r if r and r["game"] == "plinko" else None

    def aa_plinko_update(finish=False):
        global aa_world, aa_state
        r = aa_plinko_round()
        if not r or (not finish and not aa_plinko_runtime.clock.running(r)):
            return
        before = r["data"]["elapsed_ms"]
        elapsed = aa_plm.DURATION_MS if finish else aa_plinko_runtime.clock.elapsed(r)
        aa_world = aa_cm.plinko_advance(aa_world, r["id"], elapsed)
        updated = aa_cm.state(aa_world)["round"]
        if updated["status"] == "done":
            aa_plinko_runtime.clock.reset()
            aa_state = aa_financial_state(aa_state, aa_world)
            aa_casino_set(busy=(updated["id"], updated["revision"]), started=aa_casino_time.monotonic(), duration=.3)
            aa_casino_audio("plinko-land")
        else:
            aa_plinko_runtime.clock.follow(updated)
            if aa_plm.contacts(elapsed) > aa_plm.contacts(before):
                aa_casino_audio("plinko-tap")
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_plinko_pause():
        aa_plinko_update()
        aa_plinko_runtime.clock.reset()

    def aa_plinko_resume(ident):
        r = aa_plinko_round()
        if r and r["id"] == ident and not aa_plinko_runtime.clock.running(r):
            aa_plinko_runtime.clock.bind(r)
            aa_casino_set(error="")
            if not persistent.aa_motion:
                aa_plinko_update(finish=True)

    def aa_plinko_finish(ident):
        r = aa_plinko_round()
        if r and r["id"] == ident:
            aa_plinko_update(finish=True)

    def aa_plinko_started(r):
        aa_plinko_runtime.clock.reset()
        aa_casino_set(busy=None, error="", scroll=ui.adjustment())
        aa_plinko_resume(r["id"])

    def aa_plinko_choose(risk):
        if not aa_plinko_round() and risk in aa_plm.RISKS:
            aa_casino_set(plinko=risk, error="")
            aa_phone_preferences.casino_plinko = risk

    def aa_plinko_guard():
        scope = aa_casino_scope()
        if scope.get("page") != "casino" or scope.get("casino_view") != "plinko" or scope.get("casino_panel"):
            aa_plinko_runtime.clock.reset()

    def aa_plinko_context_guard():
        aa_plinko_runtime.clock.reset()

    @functools.lru_cache(maxsize=128)
    def aa_plinko_bucket_size(label, width, size):
        while size > 9:
            measured = renpy.render(Text(label, font="fonts/Inter-SemiBold.ttf", size=size, outlines=[]), 512, 50, 0, 0)
            if measured.width <= width:
                break
            size -= 1
        return size

    config.interact_callbacks.append(aa_plinko_guard)
    config.context_callbacks.append(aa_plinko_context_guard)

    class AAPlinkoBoard(renpy.Displayable):
        def __init__(self, width, height, risk, r=None, **properties):
            super(AAPlinkoBoard, self).__init__(**properties)
            self.width, self.height, self.risk, self.round = width, height, risk, r
            self.board = Image(aa_casino_art("plinko-" + risk))

        def render(self, width, height, st, at):
            result = renpy.Render(self.width, self.height)
            result.blit(renpy.render(Transform(self.board, xysize=(self.width, self.height)), self.width, self.height, st, at), (0, 0))
            scale = 3
            drawing = renpy.Render(self.width * scale, self.height * scale)
            canvas = drawing.canvas()
            sx, sy = self.width * scale / 270.0, self.height * scale / 240.0
            def xy(x, y):
                return (int(x * sx), int(y * sy))
            def circle(color, x, y, radius):
                canvas.circle(color, xy(x, y), max(1, int(radius * sx)))
            def locate(point):
                return (135 + point[0] * 28, 29 + point[1] * 21)
            r = self.round
            moving = r and aa_plinko_runtime.clock.running(r) and persistent.aa_motion
            elapsed = aa_plinko_runtime.clock.elapsed(r) if r else 0
            if r:
                path = r["data"]["path"]
                done = r["status"] == "done"
                if done:
                    points = [xy(*locate(p)) for p in aa_plm.trace(path, elapsed)]
                    canvas.lines("#e7c5a455", False, points, max(1, int(sx)))
                elif persistent.aa_motion:
                    for i in range(18):
                        tail = max(0, elapsed - (18 - i) * 12)
                        x, y = locate(aa_plm.point(path, tail))
                        circle("#f0cfaa%02x" % (8 + i * 4), x, y, 1.2 + i * .08)
                for row in range(aa_plm.contacts(elapsed)):
                    x = 135 + (sum(path[:row]) - row / 2) * 28
                    y = 35 + row * 21
                    age = elapsed - (aa_plm.FIRST_HIT_MS + row * aa_plm.HOP_MS)
                    if 0 <= age < 240 and moving:
                        fade = 1 - age / 240.0
                        circle("#e9c3a4%02x" % int(fade * 56), x, y, 4 + (1 - fade) * 7)
                    circle("#efd2b5" if not done else "#a68d81", x, y, 2.1)
                x, y = locate(aa_plm.point(path, elapsed))
            else:
                x, y = 135, 4
            for radius, alpha in ((12, "08"), (9, "10"), (6, "23")):
                circle("#e9caaa" + alpha, x, y, radius)
            circle("#0f0d1480", x + .8, y + 1.5, 4.5)
            circle("#cba77f", x, y, 4.2)
            circle("#f2e6d4", x - .2, y - .4, 3.4)
            circle("#fbf4e8", x - 1.1, y - 1.4, 1.2)
            overlay = renpy.Render(self.width, self.height)
            overlay.blit(drawing, (0, 0))
            overlay.zoom(1.0 / scale, 1.0 / scale)
            result.blit(overlay, (0, 0))
            if moving:
                renpy.redraw(self, 1.0 / 60)
            return result

        def visit(self):
            return [self.board]

screen aa_plinko_risks(width, risk, locked=False):
    hbox:
        xsize width
        spacing 3
        text "Risco" style "aa_casino_muted" size aa_phone_size(12) xsize 40 yalign .5
        for key, caption in aa_plm.RISKS.items():
            textbutton caption:
                style "aa_casino_button"
                background None
                selected_background aa_phone_round("casino-hover", 12)
                text_selected_color "#f3edf5"
                xysize ((width - 49) // 3, 44)
                padding (0, 4)
                text_size aa_phone_size(13)
                selected risk == key
                sensitive not locked
                action Function(aa_plinko_choose, key)
                alt ("Risco " + caption.lower())

screen aa_plinko_table(width, r, readonly=False, available_height=None):
    $ active = r and r["status"] == "active"
    $ risk = r["data"]["risk"] if r and (active or readonly) else aa_casino_scope().get("casino_plinko", "medium")
    if r and not readonly and not active and r["data"]["risk"] != risk:
        $ r = None
    $ done = r and r["status"] == "done"
    $ board_height = min(int(width * 240 / 270), max(168, available_height - 56)) if available_height and not readonly else int(width * 240 / 270)
    if not readonly:
        use aa_plinko_risks(width, risk, bool(active))
    else:
        text ("Risco " + aa_plm.RISKS[risk].lower()) style "aa_casino_muted" size aa_phone_size(14)
    fixed:
        xysize (width, board_height)
        add AAPlinkoBoard(width, board_height, risk, r)
        for index, multiplier in enumerate(aa_plm.payouts(r["data"] if r else None, risk)):
            $ bucket_label = aa_plm.text(multiplier)[:-1]
            fixed:
                xpos int((9 + index * 28) * width / 270)
                ypos int(204 * board_height / 240)
                xysize (int(28 * width / 270), int(29 * board_height / 240))
                if done and r["data"]["slot"] == index:
                    add aa_phone_round("casino-accent", 6) xysize (int(26 * width / 270), int(29 * board_height / 240)) xalign .5
                text bucket_label style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_plinko_bucket_size(bucket_label, int(24 * width / 270), aa_phone_size(11)) color ("#302239" if done and r["data"]["slot"] == index else "#f1d7c4" if multiplier >= 400 else "#eee2f3") align (.5, .5)
        if not readonly:
            textbutton "Tabela ›" style "aa_casino_button" background None hover_background None padding (0, 0) xysize (68, 44) xalign 1.0 text_size aa_phone_size(12) action Function(aa_casino_panel, "plinko") alt "Tabela de pagamentos do Plinko"
            if done:
                button:
                    background None
                    padding (0, 0)
                    xysize (int(width * .31), 62)
                    action Function(aa_casino_open_record, r["id"])
                    alt "Ver detalhes da rodada"
                    vbox:
                        spacing 3
                        text "Retorno ›" style "aa_casino_muted" size aa_phone_size(11)
                        text aa_pm.brl(r["gross"]) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_bank_fit(aa_pm.brl(r["gross"]), int(width * .31), aa_phone_size(15))
                        text aa_casino_signed(r["net"]) style "aa_casino_muted" size aa_bank_fit(aa_casino_signed(r["net"]), int(width * .31), aa_phone_size(11)) color ("#c7e1cc" if r["net"] > 0 else "#b9adbf")

screen aa_plinko_controls(width, r):
    $ running = aa_plinko_runtime.clock.running(r)
    null height 6
    text ("Aposta " + aa_pm.brl(r["stake"])) style "aa_casino_text" size aa_phone_size(16) xalign .5
    null height 4
    bar:
        value r["data"]["elapsed_ms"]
        range aa_plm.DURATION_MS
        xysize (width, 4)
        left_bar aa_phone_round("casino-accent", 2)
        right_bar aa_phone_round("casino-surface", 2)
        thumb None
        thumb_shadow None
    null height 5
    textbutton ("Ver resultado" if running else "Continuar"):
        style "aa_casino_primary"
        xysize (width, 48)
        text_size aa_phone_size(16)
        action Function(aa_plinko_finish if running else aa_plinko_resume, r["id"])
        alt ("Concluir queda do Plinko" if running else "Continuar Plinko")

screen aa_plinko_paytable(width):
    $ pending = aa_plinko_round()
    $ risk = pending["data"]["risk"] if pending else aa_casino_scope().get("casino_plinko", "medium")
    use aa_plinko_risks(width, risk, bool(pending))
    fixed:
        xysize (width, 24)
        text "Saída" style "aa_casino_muted" size aa_phone_size(12)
        text "Retorno" style "aa_casino_muted" size aa_phone_size(12) xalign .52
        text "Chance" style "aa_casino_muted" size aa_phone_size(12) xalign 1.0
    for index, multiplier in enumerate(aa_plm.payouts(pending["data"] if pending else None, risk)):
        fixed:
            xysize (width, 32 + aa_phone_pref("text_size", 0))
            text str(index + 1) style "aa_casino_muted" size aa_phone_size(15) yalign .5
            text aa_plm.text(multiplier) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(16) xalign .52 yalign .5
            text (("%.3f%%" % (aa_plm.WAYS[index] * 100 / 256)).replace(".", ",")) style "aa_casino_text" size aa_phone_size(14) xalign 1.0 yalign .5
        use aa_phone_rule(width)
    text "Retornos incluem a aposta." style "aa_casino_muted" size aa_phone_size(13) xmaximum width

