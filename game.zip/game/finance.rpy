# Financial state belongs to the campaign save, including its narrative calendar.
default aa_world = aa_fm.new_world()
default aa_world_schema = 0
default aa_transfer_target = None
default aa_return_used_car = False
default aa_present = ()

init python:
    import finance_model as aa_fm

    def aa_world_start():
        global aa_world, aa_world_schema
        aa_world = aa_fm.new_world()
        aa_world_schema = 1

    def aa_world_scene(at=None):
        global aa_world, aa_world_schema
        aa_world_schema = 1
        if at is not None:
            aa_world = aa_fm.advance(aa_world, at)

    def aa_finance_event(event):
        global aa_world, aa_return_used_car
        if event == "settle_dinner":
            bill = aa_state.get("bill")
            if bill == "cena" and aa_state.get("debt") and not aa_state.get("v_gone"):
                return
            event = "dinner_full" if bill == "emprestimo" else "dinner_vanessa" if bill == "vanessa" else "dinner_split"
        if event == "return_home":
            aa_return_used_car = aa_world["balance"] >= 1800
            if not aa_return_used_car: return
            event = "ride_return"
        aa_world = aa_fm.transact(aa_world, event)

    def aa_financial_line(kind):
        if kind == "return_home":
            return ("Esperei ela entrar em casa. Paguei dezoito reais pelo trecho até a moradia."
                    if aa_return_used_car else "Esperei ela entrar em casa. Sem dinheiro para outra corrida, voltei a pé para a moradia.")
        who = "joaozao" if kind == "joao_epilogue" else "vanessa"
        name = "Joãozão" if who == "joaozao" else "Vanessa"
        status = aa_fm.status(aa_world, who)
        if status == "paid":
            return "Eu tinha devolvido os sessenta reais a " + name + " dentro do prazo."
        if status == "paid_late":
            return "Eu tinha devolvido os sessenta reais a " + name + ", mas depois do prazo combinado."
        if status == "overdue":
            return "O prazo tinha passado. Eu ainda devia sessenta reais a " + name + "."
        return "Eu ainda devia sessenta reais a " + name + ". O prazo não tinha vencido."

    def aa_pay_debt(who):
        global aa_world, aa_state
        present = who in aa_present
        updated = aa_fm.repay(aa_world, who, in_person=present)
        if updated is aa_world:
            return
        aa_world = updated
        aa_state = aa_financial_state(aa_state, aa_world)
        renpy.hide_screen("aa_transfer_confirm")
        renpy.retain_after_load()
        if present:
            renpy.hide_screen("aa_phone_hub")
            renpy.call_in_new_context("aa_repayment_dialogue", who,
                                      aa_fm.status(aa_world, who) == "paid_late",
                                      _clear_layers=False)
        renpy.restart_interaction()

    def aa_message_read(ident):
        global aa_world
        aa_world = aa_fm.read(aa_world, ident)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_notification_close(ident):
        global aa_world
        aa_world = aa_fm.dismiss(aa_world, ident)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_notification_open(ident):
        notice = next((m for m in aa_world["messages"] if m["id"] == ident), None)
        aa_phone_open(contact=notice["sender"] if notice else None)
        aa_phone_preferences.page = "messages"
        aa_notification_close(ident)

    def aa_world_load():
        global aa_world, aa_world_schema
        if aa_world_schema:
            return
        # Import only completed legacy facts, never credit a mere loan request.
        aa_world = aa_fm.new_world()
        kinds = {entry["kind"] for entry in aa_phone_memory}
        if "emprestimo_pix" in kinds:
            aa_world = aa_fm.transact(aa_world, "joao_loan")
        if "ajuda_v" in kinds:
            aa_world = aa_fm.transact(aa_world, "dinner_vanessa")
        if "jantar_pago" in kinds:
            bill = aa_state.get("bill")
            aa_world = aa_fm.transact(aa_world, "dinner_full" if bill == "emprestimo" else "dinner_vanessa" if bill == "vanessa" else "dinner_split")
        for kind, who in (("devolucao", "joaozao"), ("devolucao_v", "vanessa")):
            if kind in kinds:
                aa_world = aa_fm.advance(aa_world, 1440 + 9 * 60 if who == "joaozao" else 5 * 1440 + 12 * 60)
                aa_world = aa_fm.repay(aa_world, who)
        aa_world_schema = 1
        renpy.block_rollback()

    config.after_load_callbacks.append(aa_world_load)

screen aa_phone_notification():
    zorder 106
    $ pending = aa_fm.notices(aa_world, aa_present)
    if pending and aa_phone_active and quick_menu and not main_menu and not renpy.get_screen("aa_phone_hub"):
        $ notice = pending[-1]
        timer 7.0 repeat True action Function(aa_notification_close, notice["id"])
        frame:
            xpos 1256
            xanchor 1.0
            ypos 82
            xsize 344
            padding (14, 12)
            background Solid("#22271ff2")
            hbox:
                button:
                    xsize 272
                    padding (0, 0)
                    action Function(aa_notification_open, notice["id"])
                    alt ("Mensagem de " + notice["sender"])
                    vbox:
                        spacing 5
                        text notice["sender"] style "aa_hub_text" size 19
                        text notice["body"] style "aa_hub_muted" size 16 xmaximum 268
                textbutton "×":
                    style "aa_hub_button"
                    padding (4, 0)
                    action Function(aa_notification_close, notice["id"])
                    alt "Dispensar notificação"

screen aa_transfer_confirm(who):
    modal True
    zorder 180
    $ d = aa_world["debts"].get(who)
    if d and d["paid_at"] is None:
        add Solid("#11150dcc")
        frame:
            xalign 0.5
            yalign 0.5
            xsize 420
            padding (28, 24)
            background Solid("#22271f")
            vbox:
                spacing 18
                text "Enviar Pix" style "aa_hub_text" size 28
                text ("Joãozão" if who == "joaozao" else "Vanessa") style "aa_hub_text"
                text aa_pm.brl(d["amount"]) style "aa_hub_text" size 36
                hbox:
                    spacing 16
                    textbutton "Cancelar" style "aa_hub_button" action Hide("aa_transfer_confirm")
                    textbutton "Enviar" style "aa_hub_button" sensitive aa_world["dinner_paid"] and aa_world["balance"] >= d["amount"] action Function(aa_pay_debt, who)
    key "game_menu" action Hide("aa_transfer_confirm")

init python:
    config.overlay_screens.append("aa_phone_notification")


screen aa_dinner_receipt():
    modal True
    zorder 180
    $ yours = next((-t["amount"] for t in aa_world["transactions"] if t["id"] == "dinner"), 0)
    $ hers = (18000 - yours if aa_world["dinner_paid"] else 9000 if aa_state.get("v_gone") else 0)
    add Solid("#11150dcc")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 430
        padding (28, 24)
        background Solid("#22271f")
        vbox:
            spacing 16
            text "Casa do Pátio" style "aa_hub_text" size 28
            text "Feka · R$ 90,00" style "aa_hub_text"
            text "Vanessa · R$ 90,00" style "aa_hub_text"
            text "Serviço e sobremesa incluídos" style "aa_hub_muted" size 16
            text "Total · R$ 180,00" style "aa_hub_text" size 26
            text ("Pago por você · " + aa_pm.brl(yours)) style "aa_hub_muted"
            text ("Pago por Vanessa · " + aa_pm.brl(hers)) style "aa_hub_muted"
            text ("Restante · " + aa_pm.brl(18000 - yours - hers)) style "aa_hub_text"
            textbutton "Fechar" style "aa_hub_button" action Hide("aa_dinner_receipt")
    key "game_menu" action Hide("aa_dinner_receipt")


# A jump in the script must not remove the player's only chance to pay on time.
label aa_repayment_dialogue(who, late=False):
    hide screen aa_phone_view
    $ aa_repayment_phone_active = aa_phone_active
    $ aa_phone_active = False
    f "Te mandei os sessenta agora."
    if who == "vanessa":
        v "Recebi. Obrigada."
    elif late:
        j "Recebi. Da próxima vez, cumpre o prazo."
    else:
        j "Recebi. Valeu."
    $ aa_phone_active = aa_repayment_phone_active
    return

label aa_advance_clock(at=None):
    if at is not None:
        if aa_world["now"] < aa_fm.FATHER_AT and at > aa_fm.JOAO_DUE and aa_fm.status(aa_world, "joaozao") == "pending":
            $ aa_world_scene(aa_fm.FATHER_AT)
            $ aa_clock_return_location = aa_location
            $ aa_location = "Campus de Direito"
            hide screen aa_phone_view
            scene bg_campus
            "Às nove, chegou o Pix que meu pai tinha prometido. Eu tinha até meio-dia para devolver os sessenta reais de Joãozão."
            $ aa_location = aa_clock_return_location
            if aa_last_art:
                scene expression aa_last_art at aa_camera(1.0, 0.5, 0.5)
        $ aa_world_scene(at)
    return
