# Financial state belongs to the campaign save, including its narrative calendar.
default aa_world = aa_fm.new_world()
default aa_world_schema = 0
default aa_transfer_target = None
default aa_return_used_car = False
default aa_present = ()

init python:
    import finance_model as aa_fm

    def aa_world_start():
        global aa_world, aa_world_schema
        aa_world = aa_fm.new_world()
        aa_world_schema = 1

    def aa_world_scene(at=None):
        global aa_world, aa_world_schema
        aa_world_schema = 1
        if at is not None:
            aa_world = aa_fm.advance(aa_world, at)

    def aa_finance_event(event):
        global aa_world, aa_return_used_car, aa_state
        if event == "settle_dinner":
            bill = aa_state.get("bill")
            if bill == "cena" and aa_state.get("debt") and not aa_state.get("v_gone"):
                return
            event = "dinner_full" if bill in ("emprestimo", "proprio") else "dinner_vanessa" if bill == "vanessa" else "dinner_split"
        if event == "return_home":
            aa_return_used_car = aa_world["balance"] >= 1800
            if not aa_return_used_car: return
            event = "ride_return"
        previous = set(aa_world.get("shortfalls", {}))
        aa_world = aa_fm.transact(aa_world, event, allow_shortfall=True)
        new_shortfalls = set(aa_world.get("shortfalls", {})) - previous
        for ident in sorted(new_shortfalls):
            if ident == "dinner" and not aa_state.get("v_gone", False):
                aa_state = dict(aa_state, trust=aa_state.get("trust", 1) - 1)
            renpy.call_in_new_context("aa_expense_consequence", ident, _clear_layers=False)
        aa_state = aa_financial_state(aa_state, aa_world)

    def aa_financial_line(kind):
        if kind == "dinner_funds":
            available = aa_pm.brl(aa_world["balance"])
            return ("Eu tinha " + available + ". Dava para cumprir o que eu tinha prometido."
                    if aa_world["balance"] >= 18000 else "Eu tinha " + available + ". Para pagar pelos dois, faltavam " + aa_pm.brl(18000 - aa_world["balance"]) + ".")
        if kind == "dinner_loan":
            return "O Pix de Joãozão tinha entrado. Eu precisava devolver os sessenta até meio-dia de amanhã."
        if kind == "dinner_split":
            return ("Vanessa pagou a parte dela. A minha ficou parcialmente pendente no restaurante."
                    if "dinner" in aa_world.get("shortfalls", {}) else "Vanessa pediu que separassem o que ela tinha consumido. Paguei minha parte, ainda resmungando.")
        if kind == "dinner_full":
            return ("Acertamos com o gerente o que eu pagaria agora e o que ficava para amanhã. Guardei o comprovante."
                    if "dinner" in aa_world.get("shortfalls", {}) else "Pedi a máquina e paguei a conta. Guardei o comprovante.")
        if kind == "dinner_vanessa":
            return ("Vanessa completou sessenta no cartão. Ainda ficou uma pendência minha com o restaurante. Eu disse que devolveria a parte dela na sexta."
                    if "dinner" in aa_world.get("shortfalls", {}) else "Paguei cento e vinte. Vanessa completou os sessenta no cartão. Eu disse que devolveria na sexta.")
        if kind == "bus_campus":
            return (("Depois da aula, fomos a pé até o prédio. Sem o dinheiro da passagem, o caminho demorou mais. "
                     if "bus_campus" in aa_world.get("shortfalls", {}) else "Depois da aula, pegamos o ônibus e caminhamos da parada até o prédio. ")
                    + "A mãe de Vanessa já tinha ido embora. Buscamos a chave na portaria e subimos.")
        if kind == "return_home":
            return ("Esperei ela entrar em casa. Paguei dezoito reais pelo trecho até a moradia."
                    if aa_return_used_car else "Esperei ela entrar em casa. Sem dinheiro para outra corrida, voltei a pé para a moradia.")
        who = "joaozao" if kind == "joao_epilogue" else "vanessa"
        name = "Joãozão" if who == "joaozao" else "Vanessa"
        status = aa_fm.status(aa_world, who)
        if status == "paid":
            return "Eu tinha devolvido os sessenta reais a " + name + " dentro do prazo."
        if status == "paid_late":
            return "Eu tinha devolvido os sessenta reais a " + name + ", mas depois do prazo combinado."
        if status == "overdue":
            return "O prazo tinha passado. Eu ainda devia sessenta reais a " + name + "."
        return "Eu ainda devia sessenta reais a " + name + ". O prazo não tinha vencido."

    def aa_pay_debt(who):
        global aa_world, aa_state
        present = who in aa_present
        updated = aa_fm.repay(aa_world, who, in_person=present)
        if updated is aa_world:
            return
        aa_world = updated
        aa_state = aa_financial_state(aa_state, aa_world)
        renpy.hide_screen("aa_transfer_confirm")
        renpy.retain_after_load()
        if present:
            renpy.hide_screen("aa_phone_hub")
            renpy.call_in_new_context("aa_repayment_dialogue", who,
                                      aa_fm.status(aa_world, who) == "paid_late",
                                      _clear_layers=False)
        renpy.restart_interaction()

    def aa_message_read(ident):
        global aa_world
        aa_world = aa_fm.read(aa_world, ident)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_notification_close(ident):
        global aa_world
        aa_world = aa_fm.dismiss(aa_world, ident)
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_notification_open(ident):
        notice = next((m for m in aa_world["messages"] if m["id"] == ident), None)
        aa_phone_open(contact=notice["sender"] if notice else None)
        aa_phone_preferences.page = "messages"
        aa_notification_close(ident)

    def aa_world_load():
        global aa_world, aa_world_schema
        if aa_world_schema:
            return
        # Import only completed legacy facts, never credit a mere loan request.
        aa_world = aa_fm.new_world()
        kinds = {entry["kind"] for entry in aa_phone_memory}
        if "emprestimo_pix" in kinds:
            aa_world = aa_fm.transact(aa_world, "joao_loan")
        if "ajuda_v" in kinds:
            aa_world = aa_fm.transact(aa_world, "dinner_vanessa")
        if "jantar_pago" in kinds:
            bill = aa_state.get("bill")
            aa_world = aa_fm.transact(aa_world, "dinner_full" if bill == "emprestimo" else "dinner_vanessa" if bill == "vanessa" else "dinner_split")
        for kind, who in (("devolucao", "joaozao"), ("devolucao_v", "vanessa")):
            if kind in kinds:
                aa_world = aa_fm.advance(aa_world, 1440 + 9 * 60 if who == "joaozao" else 5 * 1440 + 12 * 60)
                aa_world = aa_fm.repay(aa_world, who)
        aa_world_schema = 1
        renpy.block_rollback()

    config.after_load_callbacks.append(aa_world_load)

screen aa_phone_notification():
    zorder 106
    $ pending = aa_fm.notices(aa_world, aa_present)
    if renpy.get_screen("aa_phone_view"):
        $ pending = [notice for notice in pending if notice["id"] != "story_" + aa_phone_kind]
    if pending and aa_phone_active and quick_menu and not main_menu and not renpy.get_screen("aa_phone_hub") and not renpy.get_screen("aa_phone_image"):
        $ notice = pending[-1]
        timer 7.0 repeat True action Function(aa_notification_close, notice["id"])
        frame:
            xpos 1256
            xanchor 1.0
            ypos 82
            xsize 360
            padding (16, 14)
            background aa_phone_round("message-glass-solid", 28)
            at aa_hub_enter
            hbox:
                spacing 10
                button:
                    xsize 258
                    padding (0, 0)
                    action Function(aa_notification_open, notice["id"])
                    alt ("Mensagem de " + notice["sender"])
                    vbox:
                        spacing 5
                        hbox:
                            spacing 8
                            add aa_phone_app_art("messages", 22) xysize (22, 22)
                            text "Mensagens" style "aa_messages_secondary" size 13 yalign .5
                        text notice["sender"] style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size 17
                        text (notice["body"][:110] + ("…" if len(notice["body"]) > 110 else "")) style "aa_hub_muted" size 16 xmaximum 258
                button:
                    style "aa_messages_row"
                    padding (10, 10)
                    xysize (44, 44)
                    action Function(aa_notification_close, notice["id"])
                    alt "Dispensar notificação"
                    use aa_hub_icon("close", 20)

init python:
    config.overlay_screens.append("aa_phone_notification")


# A jump in the script must not remove the player's only chance to pay on time.
label aa_repayment_dialogue(who, late=False):
    hide screen aa_phone_view
    $ aa_repayment_phone_active = aa_phone_active
    $ aa_phone_active = False
    f "Te mandei os sessenta agora."
    if who == "vanessa":
        v "Recebi. Obrigada."
    elif late:
        j "Recebi. Da próxima vez, cumpre o prazo."
    else:
        j "Recebi. Valeu."
    $ aa_phone_active = aa_repayment_phone_active
    return

label aa_expense_consequence(ident):
    $ aa_expense_phone_active = aa_phone_active
    $ aa_phone_active = False
    hide screen aa_phone_view
    if ident == "dinner":
        "Na hora de pagar, o saldo não cobriu a conta. Eu tinha colocado nas apostas o dinheiro daquela noite."
        if not aa_state.get("v_gone", False):
            v "Você apostou o dinheiro do jantar? Eu avisei quanto podia gastar."
            "Eu não consegui responder sem olhar para o celular. Ela afastou a cadeira enquanto eu falava com o gerente."
        if aa_world["shortfalls"]["dinner"]["amount"] < aa_world["dinner_obligation"]:
            "Paguei o que restava na conta. O gerente anotou meus dados e combinamos o restante para amanhã, até meio-dia. A pendência ficou no Banco."
        else:
            "Eu estava sem nada na conta. O gerente anotou meus dados e combinamos o pagamento para amanhã, até meio-dia. A pendência ficou no Banco."
    elif ident.startswith("ride_"):
        "A corrida já tinha terminado quando o pagamento falhou. Mostrei o saldo ao motorista e combinei de acertar o restante até amanhã ao meio-dia."
        "Anotei o valor no Banco. Não era uma corrida gratuita. Era outra conta para pagar."
    elif ident == "bus_campus":
        "Faltavam os cinco reais da passagem. Guardei o celular e falei que teria de ir a pé."
        v "Podia ter me falado antes. Vamos andando."
    $ aa_phone_active = aa_expense_phone_active
    return

label aa_advance_clock(at=None):
    if at is not None:
        if aa_world["now"] < aa_fm.FATHER_AT and at > aa_fm.JOAO_DUE and aa_fm.status(aa_world, "joaozao") == "pending":
            $ aa_world_scene(aa_fm.FATHER_AT)
            $ aa_clock_return_location = aa_location
            $ aa_clock_return_pov = aa_phone_pov
            $ aa_phone_pov = False
            $ aa_location = "Campus de Direito"
            hide screen aa_phone_view
            scene bg_campus
            "Às nove, chegou o Pix que meu pai tinha prometido. Eu tinha até meio-dia para devolver os sessenta reais de Joãozão."
            $ aa_location = aa_clock_return_location
            $ aa_phone_pov = aa_clock_return_pov
            if aa_last_art:
                if aa_phone_pov:
                    scene expression aa_last_art at aa_phone_camera
                else:
                    scene expression aa_last_art at aa_camera(1.0, 0.5, 0.5)
        $ aa_world_scene(at)
    return
