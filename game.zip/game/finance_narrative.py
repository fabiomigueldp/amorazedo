"""Prose based on current, observable campaign money rather than starting funds."""
import finance_model as finance


def brl(cents):
    return "R$ %d,%02d" % (cents // 100, cents % 100)


def line(kind, state, world, return_used_car=False):
    balance = world["balance"]
    short = "dinner" in world.get("shortfalls", {})
    if kind == "dinner_funds":
        return ("Eu tinha " + brl(balance) + ". Dava para cumprir o que eu tinha prometido."
                if balance >= 18000 else "Eu tinha " + brl(balance) + ". Para pagar pelos dois, faltavam " + brl(18000 - balance) + ".")
    if kind == "dinner_share_funds":
        return ("Minha parte era noventa reais. Conferi o saldo: " + brl(balance) + ". Dava para pagar."
                if balance >= 9000 else "Minha parte era noventa reais. Eu tinha " + brl(balance) + ". Faltavam " + brl(9000 - balance) + ".")
    if kind == "offer_sixty":
        return "Posso colocar sessenta no cartão e você me devolve na sexta. Com o que você tem, fecha?"
    if kind == "promise_funds":
        return ("Conferi o saldo antes de guardar o celular. O dinheiro estava ali; eu precisava separar o do jantar."
                if balance >= 18000 else "Disse que tinha certeza. Ainda estava contando com um dinheiro que não tinha.")
    if kind == "dinner_loan":
        status = finance.status(world, "joaozao")
        if status in ("paid", "paid_late"):
            return "O empréstimo de Joãozão já estava devolvido. Ter pedido na frente de Yasmin ainda me incomodava."
        return "O Pix de Joãozão tinha entrado. Eu precisava devolver os sessenta até meio-dia de amanhã."
    if kind == "dinner_split":
        return ("Vanessa pagou a parte dela. A minha ficou pendente no restaurante."
                if short else "Vanessa pediu que separassem o que ela tinha consumido. Paguei minha parte, ainda resmungando.")
    if kind in ("dinner_full", "dinner_full_return"):
        prefix = "Voltei para Vanessa e sentei. " if kind.endswith("_return") else ""
        return prefix + ("Acertamos com o gerente o que eu pagaria agora e o que ficava para amanhã. Guardei o comprovante."
                         if short else "Pedi a máquina e paguei os cento e oitenta reais. Guardei o comprovante.")
    if kind == "dinner_vanessa":
        return ("Vanessa completou sessenta no cartão. Ainda ficou uma pendência minha com o restaurante. Eu disse que devolveria a parte dela na sexta."
                if short else "Paguei cento e vinte. Vanessa completou sessenta no cartão. Eu disse que devolveria na sexta.")
    if kind == "loan_paid_thought":
        return ("Mesmo depois de pedir dinheiro a ele, eu tinha deixado uma parte da conta para amanhã."
                if short else "Eu tinha pago com dinheiro emprestado. Não consegui olhar para Vanessa quando ela agradeceu ao garçom.")
    if kind == "bus_campus":
        return (("Depois da aula, fomos a pé até o prédio. Sem o dinheiro da passagem, o caminho demorou mais. "
                 if "bus_campus" in world.get("shortfalls", {}) else "Depois da aula, pegamos o ônibus e caminhamos da parada até o prédio. ")
                + "A mãe de Vanessa já tinha ido embora. Buscamos a chave na portaria e subimos.")
    if kind == "return_home":
        return ("Esperei ela entrar em casa. Paguei dezoito reais pelo trecho até a moradia."
                if return_used_car else "Esperei ela entrar em casa. Sem dinheiro para outra corrida, voltei a pé para a moradia.")
    if kind == "vanessa_not_repaid":
        return ("Eu tenho o dinheiro, mas não vou transferir agora." if state.get("can_repay_v")
                else "Eu ainda não tenho os sessenta pra te devolver.")
    if kind == "other_debts":
        pending = [finance.party_name(who) + ": " + brl(world["debts"][who]["amount"])
                   for who in ("restaurant", "ride") if finance.status(world, who) in ("pending", "overdue")]
        return "Ainda havia pagamentos pendentes: " + "; ".join(pending) + ". Eu precisava acertar isso." if pending else "Conferi os pagamentos. Não havia pendência com o restaurante nem com o transporte."
    if kind in ("joao_epilogue", "vanessa_epilogue"):
        who = "joaozao" if kind == "joao_epilogue" else "vanessa"
        name, status = finance.party_name(who), finance.status(world, who)
        if status == "paid":
            return "Eu tinha devolvido os sessenta reais a " + name + " dentro do prazo."
        if status == "paid_late":
            return "Eu tinha devolvido os sessenta reais a " + name + ", mas depois do prazo combinado."
        if status == "overdue":
            return "O prazo tinha passado. Eu ainda devia sessenta reais a " + name + "."
        if status == "none":
            return "Eu não tinha empréstimo de " + name + " para devolver."
        return "Eu ainda devia sessenta reais a " + name + ". O prazo não tinha vencido."
    raise ValueError("Texto financeiro desconhecido: " + kind)
