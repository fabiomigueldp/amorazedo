# Gerado por tools/build_table_tests.py.
label qa_photo_choice_setup:
    $ aa_state = aa_new_state()
    $ aa_trace = []
    $ aa_phone_memory = ()
    $ aa_state.update(route="juntas", trust=qa_photo_trust, no_photo=qa_photo_refused)
    jump c02

testsuite aa_photo_choice:
    setup:
        $ _test.timeout = 15.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 1.0
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/foto-escolhas"
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu"
    teardown:
        exit

    testcase aceita:
        $ qa_photo_trust = 3
        $ qa_photo_refused = False
        run Start("qa_photo_choice_setup")
        advance until screen "choice"
        assert eval aa_node == "c02"
        click "Sugerir uma foto."
        advance until "Eu tiro."
        assert not screen "aa_phone_view"
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == 'foto'
        assert eval aa_audio_last_event == 'Q032'
        assert not screen "choice"
        run QuickSave()
        pause 0.3
        screenshot "aceita_foto.png"
        advance until "Guardei o celular."
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side and aa_table_party == 4
        run QuickLoad(confirm=False)
        assert screen "aa_phone_view" timeout 5.0
        advance until "Guardei o celular."
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side
        assert eval "A conversa sobre a foto acabou" not in aa_history_export()
        assert eval "Cobrar de todos" not in aa_history_export()

    testcase hesita:
        $ qa_photo_trust = 0
        $ qa_photo_refused = False
        run Start("qa_photo_choice_setup")
        advance until screen "choice"
        assert eval aa_node == "c02"
        click "Sugerir uma foto."
        advance until "Eu tiro."
        assert not screen "aa_phone_view"
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == 'foto_hesita'
        assert eval aa_audio_last_event == 'Q033'
        assert not screen "choice"
        run QuickSave()
        pause 0.3
        screenshot "hesita_foto.png"
        advance until "Guardei o celular."
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side and aa_table_party == 4
        run QuickLoad(confirm=False)
        assert screen "aa_phone_view" timeout 5.0
        advance until "Guardei o celular."
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side
        assert eval "A conversa sobre a foto acabou" not in aa_history_export()
        assert eval "Cobrar de todos" not in aa_history_export()

    testcase recusa:
        $ qa_photo_trust = 3
        $ qa_photo_refused = True
        run Start("qa_photo_choice_setup")
        advance until screen "choice"
        assert eval aa_node == "c02"
        click "Pedir uma foto, mesmo tendo combinado que não pediria."
        advance until "Feka, a gente combinou que não."
        assert not screen "aa_phone_view"
        assert eval aa_state["photo_boundary_broken"] and aa_state["trust"] == 2
        assert eval aa_state["used"] and not aa_phone_memory
        screenshot "recusa.png"
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side
        assert eval "A conversa sobre a foto acabou" not in aa_history_export()
        assert eval "Cobrar de todos" not in aa_history_export()
        assert eval "Tá. Quer provar?" not in aa_history_export()

    testcase respeita:
        $ qa_photo_trust = 3
        $ qa_photo_refused = True
        run Start("qa_photo_choice_setup")
        advance until screen "choice"
        assert eval aa_node == "c02"
        click "Guardar o celular."
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side
        assert eval "A conversa sobre a foto acabou" not in aa_history_export()
        assert eval "Cobrar de todos" not in aa_history_export()
        assert eval not aa_state["photo_asked"] and not aa_state["photo_boundary_broken"]
        assert eval not aa_phone_memory

    testcase sem_foto:
        $ qa_photo_trust = 1
        $ qa_photo_refused = False
        run Start("qa_photo_choice_setup")
        advance until screen "choice"
        assert eval aa_node == "c02"
        click "Guardar o celular."
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side
        assert eval "A conversa sobre a foto acabou" not in aa_history_export()
        assert eval "Cobrar de todos" not in aa_history_export()
        assert eval not aa_state["photo_asked"] and not aa_state["photo_boundary_broken"]
        assert eval not aa_phone_memory

    testcase oferece_pagar:
        $ qa_photo_trust = 2
        $ qa_photo_refused = False
        run Start("qa_photo_choice_setup")
        advance until screen "choice"
        assert eval aa_node == "c02"
        click "Oferecer pagar a mesa inteira para mudar o clima."
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert not screen "aa_phone_view"
        assert eval not aa_dialogue_side
        assert eval "A conversa sobre a foto acabou" not in aa_history_export()
        assert eval "Cobrar de todos" not in aa_history_export()
        assert eval aa_state["debt"]
        assert eval "Hoje eu pago. De vocês também." in aa_history_export()

    testcase percurso_do_jogador:
        run Start()
        advance until screen "choice"
        assert eval aa_node == 'a00'
        click "Deixar o celular e separar a roupa."
        advance until screen "choice"
        assert eval aa_node == 'a03'
        click "Dizer que já está bom e elogiar o cabelo dela."
        advance until screen "choice"
        assert eval aa_node == 'a04'
        click "Perguntar como foi a visita e deixar ela contar."
        advance until screen "choice"
        assert eval aa_node == 'a05'
        click "Combinar que cada um paga o seu."
        advance until screen "choice"
        assert eval aa_node == 'a06'
        click "Dizer que uma amiga da escola compartilhou o restaurante num grupo."
        advance until screen "choice"
        assert eval aa_node == 'b00'
        click "Responder Vanessa e perguntar se ela quer cumprimentar os dois."
        advance until screen "choice"
        assert eval aa_node == 'b01'
        click "Sugerir que juntemos as mesas."
        advance until screen "choice"
        assert eval aa_node == 'c00'
        click "Puxar uma lembrança minha com Yasmin."
        advance until screen "choice"
        assert eval aa_node == 'c01'
        click "Dizer que não era uma coincidência e assumir a insistência."
        advance until screen "choice"
        assert eval aa_node == 'c02'
        click "Sugerir uma foto."
        advance until screen "aa_phone_view"
        assert eval aa_state["trust"] == 3
        assert eval "Fiquei com vergonha." in aa_history_export()
        assert eval "Eu preferia saber por você." in aa_history_export()
        advance until screen "choice"
        assert eval aa_node == "i00"
        assert eval "Tá. Quer provar?" in aa_history_export()
        click "Ficar com Vanessa."
        advance until screen "choice"
        assert eval aa_node == "iv"
        assert eval "A gente pode só comer um pouco?" not in aa_history_export()
