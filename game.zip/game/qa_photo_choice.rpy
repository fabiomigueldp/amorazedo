# Regressão localizada: revisão da foto -> escolhas -> resposta.
label qa_photo_choice_setup:
    $ aa_state = aa_new_state()
    $ aa_state.update(route="juntas", photo_asked=True, trust=qa_photo_trust, no_photo=qa_photo_refused)
    jump c03

testsuite aa_photo_choice:
    setup:
        $ _test.timeout = 12.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/foto-escolhas"
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
        assert screen "main_menu"
    teardown:
        exit

    testcase aceita:
        $ qa_photo_trust = 3
        $ qa_photo_refused = False
        run Start("qa_photo_choice_setup")
        assert screen "aa_phone_view" timeout 5.0
        pause 0.3
        screenshot "foto_dialogo.png"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_phone_kind == "" and not aa_dialogue_side and aa_table_party == 4
        screenshot "foto_escolhas.png"
        click "Aceitar a resposta sem insistir."
        assert not screen "aa_phone_view"
        assert screen "say" timeout 5.0

    testcase hesita:
        $ qa_photo_trust = 0
        $ qa_photo_refused = False
        run Start("qa_photo_choice_setup")
        advance until screen "aa_phone_view"
        assert eval aa_phone_kind == "foto_hesita"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        assert eval aa_phone_kind == "" and not aa_dialogue_side
        screenshot "hesita_escolhas.png"
        click "Cobrar de todos um esforço para melhorar a noite."
        assert not screen "aa_phone_view"

    testcase recusada:
        $ qa_photo_trust = 1
        $ qa_photo_refused = True
        run Start("qa_photo_choice_setup")
        assert "Eu já disse que não." timeout 5.0
        assert not screen "aa_phone_view"
        advance until screen "choice"
        assert not screen "aa_phone_view"
        screenshot "recusa_escolhas.png"
        click "Aceitar a resposta sem insistir."
        assert not screen "aa_phone_view"
