# System apps use only disclosed campaign data and bundled local media.
# Their presence in the home grid never creates calls, email or future events.
init python:
    import phone_utilities as aa_pu

    def aa_phone_calc(key):
        state = aa_phone_pref("calculator", ("0", None, None, True))
        aa_phone_set_pref("calculator", aa_pu.calculator(state, key))

    def aa_phone_calendar():
        import calendar
        from datetime import timedelta
        today = aa_fm.EPOCH + timedelta(minutes=aa_world["now"])
        weeks = calendar.Calendar(firstweekday=6).monthdayscalendar(today.year, today.month)
        return today, weeks

    def aa_phone_app_matches(query):
        import unicodedata
        fold = lambda s: ''.join(c for c in unicodedata.normalize('NFD', s.casefold()) if unicodedata.category(c) != 'Mn')
        return tuple(app for app in AA_PHONE_APPS if app not in ("home", "search") and fold(query) in fold(AA_PHONE_APPS[app][0]))

    def aa_phone_play_pause():
        renpy.music.set_pause(not renpy.music.get_pause(channel="music"), channel="music")
        renpy.restart_interaction()

screen aa_phone_launch_row(app, subtitle=""):
    button:
        style "aa_hub_row"
        action Function(aa_phone_go, app)
        alt ("Abrir " + AA_PHONE_APPS[app][0])
        hbox:
            spacing 12
            add aa_phone_app_art(app, 40) xysize (40, 40)
            vbox:
                yalign 0.5
                spacing 4
                text AA_PHONE_APPS[app][0] style "aa_hub_text" size aa_phone_size(18)
                if subtitle:
                    text subtitle style "aa_hub_muted" size 13

screen aa_phone_system_empty(app, title, body):
    vbox:
        spacing 14
        null height 30
        add aa_phone_app_art(app, 64) xysize (64, 64)
        text title style "aa_phone_title" size aa_phone_size(24)
        text body style "aa_hub_muted" size aa_phone_size(17)

screen aa_phone_system_app(page, width, query):
    if page == "calendar":
        $ today, weeks = aa_phone_calendar()
        text aa_phone_date() style "aa_hub_text" font "fonts/Inter-Medium.ttf" size aa_phone_size(19)
        grid 7 1:
            for day in ("D", "S", "T", "Q", "Q", "S", "S"):
                fixed:
                    xysize (width // 7, 24)
                    text day style "aa_hub_muted" size 14 align (0.5, 0.5)
        for week in weeks:
            hbox:
                for day in week:
                    frame:
                        xysize (width // 7, 38)
                        padding (0, 0)
                        background (aa_phone_round("sent") if day == today.day else None)
                        text (str(day) if day else "") style "aa_hub_text" size 18 align (0.5, 0.5)
        null height 10
        text "Combinados" style "aa_phone_title" size aa_phone_size(23)
        use aa_phone_reminders(width)
    elif page == "reminders":
        use aa_phone_reminders(width)
    elif page == "clock":
        null height 35
        text aa_phone_time() style "aa_hub_text" font "fonts/Inter-Light.ttf" size 70 xalign 0.5
        text aa_phone_date() style "aa_hub_muted" size aa_phone_size(17) xalign 0.5 textalign 0.5
        null height 30
        use aa_phone_rule(width)
        text "Alarmes" style "aa_phone_title" size aa_phone_size(24)
        text "Nenhum alarme definido." style "aa_hub_muted" size aa_phone_size(17)
    elif page in ("contacts", "phone", "facetime"):
        $ contacts = aa_phone_threads()
        if not contacts:
            use aa_phone_system_empty(page, "Nenhum contato recente", "Os contatos das suas conversas aparecem aqui.")
        else:
            text ("Contatos" if page != "contacts" else "Nas suas conversas") style "aa_hub_muted" size aa_phone_size(16)
            for entry in contacts:
                button:
                    style "aa_hub_row"
                    action Function(aa_phone_select, entry)
                    alt ("Abrir conversa com " + entry["title"])
                    hbox:
                        spacing 12
                        use aa_phone_avatar(entry["title"], 40)
                        vbox:
                            text entry["title"] style "aa_hub_text" size aa_phone_size(19)
                            text "Mensagem" style "aa_hub_muted" size 14
                use aa_phone_rule(width)
            if page != "contacts":
                text "Nenhuma chamada recente." style "aa_hub_muted" size aa_phone_size(16)
    elif page == "camera":
        $ actions = aa_phone_context_actions("photos")
        if actions:
            use aa_phone_system_empty("camera", "Fotografar", "")
            use aa_phone_context_choices("photos", width)
        else:
            use aa_phone_system_empty("camera", "Câmera", "Não é o momento de tirar uma foto.")
        use aa_phone_launch_row("photos", "Ver fotografias salvas")
    elif page == "wallet":
        text "Comprovantes" style "aa_phone_title" size aa_phone_size(25)
        if aa_world["dinner_paid"]:
            textbutton "Conta do jantar" style "aa_hub_button" xfill True action Show("aa_dinner_receipt")
        if not aa_world["transactions"]:
            text "Você ainda não tem comprovantes." style "aa_hub_muted" size aa_phone_size(17)
        for item in reversed(aa_world["transactions"]):
            text item["title"] style "aa_hub_text" size aa_phone_size(19)
            text (aa_pm.brl(item["amount"]) + " · " + aa_fm.stamp(item["at"])) style "aa_hub_muted" size aa_phone_size(15)
            use aa_phone_rule(width)
        use aa_phone_launch_row("bank", "Saldo e devoluções")
    elif page == "calculator":
        $ calculator_state = aa_phone_pref("calculator", ("0", None, None, True))
        text calculator_state[0].replace(".", ",") style "aa_hub_text" font "fonts/Inter-Light.ttf" size (35 if len(calculator_state[0]) > 10 else 52) xalign 1.0
        grid 4 5:
            spacing 7
            for key in ("AC", "±", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ",", "=", "⌫"):
                textbutton key:
                    style "aa_hub_button"
                    xysize ((width - 21) // 4, 57)
                    padding (0, 0)
                    text_xalign 0.5
                    text_yalign 0.5
                    text_size 24
                    background aa_phone_round("sent" if key in ("÷", "×", "−", "+", "=") else "received")
                    action Function(aa_phone_calc, key)
    elif page == "maps":
        $ locations = tuple(item for item in aa_phone_memory if item["kind"] in ("endereco", "carro", "restaurante"))
        if not locations:
            use aa_phone_system_empty("maps", "Lugares compartilhados", "Endereços e viagens compartilhados com você aparecem aqui.")
        for entry in locations:
            textbutton entry["title"] style "aa_hub_button" xfill True action Function(aa_phone_select, entry)
    elif page == "files":
        text "No aparelho" style "aa_phone_title" size aa_phone_size(24)
        use aa_phone_launch_row("photos", "Imagens salvas")
        use aa_phone_launch_row("notes", "Informações compartilhadas")
        $ documents = tuple(item for item in aa_phone_memory if item["kind"] in ("grupo_materia", "materia", "so_materia"))
        for entry in documents:
            textbutton entry["title"] style "aa_hub_button" xfill True action Function(aa_phone_open, entry["title"])
    elif page == "safari":
        text "Favoritos" style "aa_phone_title" size aa_phone_size(25)
        use aa_phone_launch_row("social", "Publicações e perfis")
        use aa_phone_launch_row("maps", "Lugares compartilhados")
        text "Visto recentemente" style "aa_hub_muted" size aa_phone_size(16)
        for entry in aa_pm.app_entries(aa_phone_memory, "social"):
            textbutton entry["title"] style "aa_hub_button" xfill True action Function(aa_phone_select, entry)
    elif page == "recorder":
        $ recordings = tuple(item for item in aa_phone_memory if item["kind"] in ("audio", "audio_resposta"))
        if not recordings:
            use aa_phone_system_empty("recorder", "Nenhuma gravação", "Seus áudios ficam aqui.")
        for entry in recordings:
            text "Áudio enviado ao grupo" style "aa_phone_title" size aa_phone_size(23)
            for sent, body in entry["messages"]:
                if sent:
                    text body style "aa_hub_text" size aa_phone_size(20)
            text "Transcrição" style "aa_hub_muted" size 14
    elif page == "music":
        $ playing = renpy.music.get_playing(channel="music")
        $ track = next((key for key, data in aa_sound_assets.items() if data["path"] == playing), None)
        null height 16
        add aa_phone_app_art("music", 110) xysize (110, 110) xalign 0.5
        text (aa_audio_display_name(track) if track else "Nada em reprodução") style "aa_phone_title" size aa_phone_size(25) textalign 0.5 xalign 0.5
        if playing:
            text "Trilha do momento" style "aa_hub_muted" size aa_phone_size(16) xalign 0.5
            textbutton ("Reproduzir" if renpy.music.get_pause(channel="music") else "Pausar") style "aa_hub_button" xfill True action Function(aa_phone_play_pause)
            text "Volume" style "aa_hub_muted" size 16
            bar value Preference("music volume") xsize width ysize 28
    elif page == "shortcuts":
        use aa_phone_launch_row("bank", "Conferir saldo e devolver dinheiro")
        use aa_phone_launch_row("messages", "Continuar uma conversa")
        use aa_phone_launch_row("social", "Ver publicações")
        use aa_phone_launch_row("camera", "Fotografar")
    elif page in ("appstore", "search"):
        if page == "appstore":
            text "No seu aparelho" style "aa_phone_title" size aa_phone_size(24)
        $ matches = aa_phone_app_matches(query)
        for app in matches:
            use aa_phone_launch_row(app)
        if not matches:
            use aa_hub_empty("search", "Nenhum aplicativo", "Tente outro nome.")
    else:
        $ empty = {"mail": ("Sua caixa está vazia", "Você não tem e-mails recebidos."), "tv": ("Sua biblioteca", "Você não tem vídeos salvos."), "podcasts": ("Seus podcasts", "Você ainda não segue nenhum podcast."), "books": ("Sua biblioteca", "Você não tem livros adicionados."), "health": ("Seus dados de saúde", "Nenhum dado registrado."), "house": ("Sua casa", "Nenhum acessório conectado.")}
        $ heading, body = empty.get(page, ("Nada por aqui", ""))
        use aa_phone_system_empty(page, heading, body)

screen aa_phone_reminders(width):
    $ debts = tuple((who, d) for who, d in aa_world["debts"].items() if d["paid_at"] is None)
    if not debts:
        text "Nenhuma devolução pendente." style "aa_hub_muted" size aa_phone_size(17)
    for who, debt in debts:
        text ("Pagar · " + aa_fm.party_name(who)) style "aa_hub_text" size aa_phone_size(20)
        text (aa_pm.brl(debt["amount"]) + " · " + aa_fm.stamp(debt["due"])) style "aa_hub_muted" size aa_phone_size(15)
        textbutton "Abrir Banco" style "aa_hub_button" action Function(aa_phone_go, "bank")
        use aa_phone_rule(width)
