# Media surfaces keep content opaque and reserve glass for transport/navigation.
style aa_media_control is button:
    background None
    hover_background aa_phone_round("media-hover", 24)
    selected_background aa_phone_round("media-hover", 24)
    padding (0, 0)
    xminimum 44
    yminimum 44
    activate_sound None
style aa_media_control_text is aa_hub_text:
    size 16
    text_align .5
    align (.5, .5)
    insensitive_color "#78717e"
style aa_media_link is aa_hub_button:
    background aa_phone_round("media-glass", 22)
    hover_background aa_phone_round("media-hover", 22)
    padding (14, 10)
    yminimum 44
    activate_sound None
style aa_media_link_text is aa_hub_text:
    size 16
    text_align .5
    align (.5, .5)
style aa_media_slider is slider:
    left_bar Transform(aa_phone_round("mask", 2), ysize=4, yalign=.5)
    right_bar Transform(aa_phone_round("media-hover", 2), ysize=4, yalign=.5)
    thumb Transform(aa_phone_round("mask", 6), xysize=(12, 12))
    thumb_shadow None
    thumb_offset 0
    ysize 44

screen aa_media_button(icon, action, label, size=48, enabled=True, number=None):
    button:
        style "aa_media_control"
        xysize (size, size)
        sensitive enabled
        action action
        alt label
        fixed:
            xysize (size, size)
            add ("gui/phone/media/" + icon + ".svg") xysize (32 if size < 60 else 38, 32 if size < 60 else 38) align (.5, .5) alpha (1.0 if enabled else .3)
            if number:
                text number style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size 12 align (.5, .53) color ("#f4eef5" if enabled else "#78717e")

screen aa_media_art(item, size):
    add AlphaMask(aa_phone_cover(item["art"], size, size), aa_phone_round("mask", max(8, size // 18))) xysize (size, size)

screen aa_media_row(item, width, queued=False):
    hbox:
        xsize width
        button:
            style "aa_hub_row"
            padding (0, 12)
            xsize (width - 44)
            action Function(aa_media_open, item["id"])
            alt ("Abrir " + item["title"])
            hbox:
                spacing 12
                use aa_media_art(item, 48)
                vbox:
                    xsize (width - 108)
                    spacing 5
                    text item["title"] style "aa_hub_text" font "fonts/Inter-Medium.ttf" size aa_phone_size(16)
                    text (aa_media_model.timestamp(item["duration"]) + " · " + ("Concluído" if item["id"] in aa_media_state.completed else item["subtitle"])) style "aa_hub_muted" size aa_phone_size(12)
        textbutton ("−" if item["id"] in aa_media_state.queue else "+"):
            style "aa_media_control"
            text_size 26
            xysize (44, 58)
            yalign .5
            sensitive item["id"] != aa_media_state.current
            action Function(aa_media_queue, item["id"])
            alt (("Remover da fila: " if item["id"] in aa_media_state.queue else "Ouvir depois: ") + item["title"])

screen aa_media_mini(width):
    $ mini_item = aa_media_item()
    if aa_media_available(mini_item):
        frame:
            background aa_phone_round("media-glass-solid" if aa_phone_pref("glass", .55) >= .95 else "media-glass", 22)
            padding (6, 4)
            xysize (width, 64)
            hbox:
                button:
                    style "aa_media_control"
                    xysize (width - 104, 56)
                    action Function(aa_media_open)
                    alt ("Abrir áudio: " + mini_item["title"])
                    hbox:
                        yalign .5
                        spacing 9
                        use aa_media_art(mini_item, 42)
                        vbox:
                            yalign .5
                            spacing 3
                            xsize (width - 155)
                            text aa_media_caption(mini_item, width - 155) style "aa_hub_text" size 13 font "fonts/Inter-Medium.ttf" xsize (width - 155)
                            text ("Reproduzindo" if aa_media_has_focus() else "Pausado") style "aa_hub_muted" size 12
                use aa_media_button("pause" if aa_media_state.playing else "play", Function(aa_media_toggle), "Pausar" if aa_media_state.playing else "Reproduzir", 48)
                use aa_media_button("stop", Function(aa_media_stop), "Encerrar reprodução", 44)

screen aa_media_app(page, width, height, detail, panel, query, searching, scroll):
    $ item = aa_media_item(detail) if detail else None
    $ accent = "#d5b3f5" if page == "podcasts" else "#ffadb9"
    fixed:
        xpos 14
        ypos 50
        xysize (width - 28, 46)
        use aa_phone_control("back", Function(aa_phone_back), "Voltar")
        text ("Áudio" if panel == "audio" else "A seguir" if panel == "queue" else "Em reprodução" if item and item["id"] == aa_media_state.current else "Episódio" if item and page == "podcasts" else "Faixa" if item else AA_PHONE_APPS[page][0]):
            style "aa_phone_title"
            size (19 if item or panel else 25)
            xpos 54
            yalign .5
            xsize (width - 128 if not item and not panel else width - 85)
        if not item and not panel:
            fixed:
                xpos (width - 74)
                use aa_phone_control("search", [SetScreenVariable("search_active", not searching), SetScreenVariable("query", ""), Function(scroll.change, 0)], "Buscar na biblioteca")
    if panel:
        viewport:
            id "phone_scroll"
            xpos 20
            ypos 118
            xysize (width - 40, height - 158)
            mousewheel True
            draggable True
            arrowkeys True
            vbox:
                xsize (width - 40)
                spacing 14
                if panel == "audio":
                    text "Volume do celular" style "aa_phone_title" size aa_phone_size(22)
                    bar:
                        style "aa_media_slider"
                        value Preference("mixer phone_media volume")
                        xsize (width - 40)
                        ysize 44
                        alt "Volume do áudio do celular"
                    textbutton ("Som: desligado" if preferences.get_mute("phone_media") else "Som: ligado"):
                        style "aa_media_link"
                        xfill True
                        action Preference("mixer phone_media mute", "toggle")
                    null height 10
                    text "Ao guardar o celular" style "aa_phone_title" size aa_phone_size(22)
                    textbutton ("Continuar ouvindo" if aa_media_state.background else "Pausar reprodução"):
                        style "aa_media_link"
                        xfill True
                        action [ToggleField(aa_media_state, "background"), Function(aa_media_changed)]
                    text "Menus e falas com voz pausam o áudio. Ele retoma quando a interrupção termina." style "aa_hub_muted" size aa_phone_size(15)
                    if item and item["kind"] == "music":
                        textbutton ("Repetir faixa: ligado" if aa_media_state.repeat else "Repetir faixa: desligado"):
                            style "aa_media_link"
                            xfill True
                            action ToggleField(aa_media_state, "repeat")
                    if item and item["kind"] == "podcast":
                        null height 10
                        text "Transcrição" style "aa_phone_title" size aa_phone_size(22)
                        text "Ainda não disponível para este episódio." style "aa_hub_muted" size aa_phone_size(15)
                else:
                    $ queue_items = tuple(aa_media_item(i) for i in aa_media_state.queue if aa_media_available(aa_media_item(i)))
                    if queue_items:
                        for queued_item in queue_items:
                            use aa_media_row(queued_item, width - 40, True)
                            use aa_phone_rule(width - 40)
                    else:
                        use aa_hub_empty("note", "Sua fila está vazia", "Toque em + na biblioteca para ouvir um episódio ou uma faixa depois.")
    elif item and aa_media_available(item):
        $ current = item["id"] == aa_media_state.current
        $ position = aa_media_position(item)
        $ transport_y = height - 228
        $ art_size = 116 if aa_phone_size(0) >= 6 else 134 if aa_phone_size(0) >= 3 else 152
        viewport:
            id "phone_scroll"
            xpos 24
            ypos 110
            xysize (width - 48, transport_y - 114)
            mousewheel True
            draggable True
            arrowkeys True
            vbox:
                xsize (width - 50)
                spacing 12
                fixed:
                    xysize (width - 50, art_size + 4)
                    fixed:
                        xalign .5
                        xysize (art_size, art_size)
                        use aa_media_art(item, art_size)
                text item["title"] style "aa_phone_title" size aa_phone_size(21) xsize (width - 50)
                text item["subtitle"] style "aa_hub_muted" size aa_phone_size(14)
                text aa_media_status(item) style "aa_hub_muted" size aa_phone_size(13) color accent
                null height 6
        fixed:
            xpos 24
            ypos transport_y
            xysize (width - 48, 62)
            if current:
                bar:
                    id "media_seek"
                    style "aa_media_slider"
                    value AAMediaSeek()
                    xsize (width - 48)
                    ysize 44
                    alt "Posição da reprodução"
            else:
                add aa_phone_round("media-hover", 2) xysize (width - 48, 4) ypos 20
            text aa_media_model.timestamp(position) style "aa_hub_muted" size 12 ypos 39
            text ("−" + aa_media_model.timestamp(item["duration"] - position)) style "aa_hub_muted" size 12 xpos (width - 48) xanchor 1.0 ypos 39
        hbox:
            xpos 24
            ypos (transport_y + 66)
            xsize (width - 48)
            box_justify True
            if item["kind"] == "podcast":
                use aa_media_button("back15", Function(aa_media_skip, -15), "Voltar 15 segundos", 60, current, "15")
            else:
                use aa_media_button("restart", Function(aa_media_seek, 0), "Recomeçar faixa", 60, current)
            use aa_media_button("pause" if current and aa_media_state.playing else "play", Function(aa_media_toggle) if current and aa_media_state.playing else Function(aa_media_play, item["id"]), "Pausar" if current and aa_media_state.playing else "Reproduzir", 64)
            if item["kind"] == "podcast":
                use aa_media_button("forward30", Function(aa_media_skip, 30), "Avançar 30 segundos", 60, current, "30")
            else:
                use aa_media_button("next", Function(aa_media_next), "Próxima faixa", 60, current and bool(aa_media_state.queue))
        hbox:
            xpos 24
            ypos (height - 82)
            xsize (width - 48)
            box_justify True
            if item["kind"] == "podcast":
                textbutton ("%g×" % aa_media_rate(item)):
                    style "aa_media_control"
                    text_color accent
                    xysize (56, 44)
                    sensitive current
                    action Function(aa_media_cycle_rate)
                    alt "Alterar velocidade"
            else:
                textbutton ("↻" if aa_media_state.repeat else "1×"):
                    style "aa_media_control"
                    xysize (56, 44)
                    selected aa_media_state.repeat
                    action ToggleField(aa_media_state, "repeat")
                    alt "Repetir faixa"
            use aa_media_button("volume", Function(aa_media_panel, "audio"), "Ajustes do áudio", 48)
            use aa_media_button("queue", Function(aa_media_panel, "queue"), "A seguir", 48)
            if current:
                textbutton "Parar":
                    style "aa_media_control"
                    background aa_phone_round("media-glass", 24)
                    text_color accent
                    text_font "fonts/Inter-SemiBold.ttf"
                    text_size aa_phone_size(13)
                    xysize (64, 48)
                    action Function(aa_media_stop)
                    alt "Encerrar reprodução"
    else:
        $ items = aa_media_items(page, query if searching else "")
        viewport:
            id "phone_scroll"
            xpos 20
            ypos 113
            xysize (width - 40, height - 240 if aa_media_available(aa_media_item()) else height - 185)
            mousewheel True
            draggable True
            arrowkeys True
            yadjustment scroll
            vbox:
                xsize (width - 40)
                spacing 10
                if searching:
                    frame:
                        background aa_phone_round("received", 16)
                        padding (12, 12)
                        xfill True
                        input:
                            value ScreenVariableInputValue("query")
                            style "aa_hub_text"
                            size aa_phone_size(17)
                            xmaximum (width - 64)
                            length 80
                            default_focus True
                    text "Buscar por título" style "aa_hub_muted" size 13
                elif items:
                    fixed:
                        xysize (width - 40, 156)
                        fixed:
                            xalign .5
                            xysize (148, 148)
                            use aa_media_art(items[0], 148)
                    text ("No seu aparelho" if page == "podcasts" else "Trilhas do jogo") style "aa_phone_title" size aa_phone_size(25)
                    text ("1 episódio" if page == "podcasts" and len(items) == 1 else str(len(items)) + (" episódios" if page == "podcasts" else " faixas")) style "aa_hub_muted" size aa_phone_size(14)
                    if page == "music":
                        textbutton "Reproduzir todas" style "aa_media_link" xfill True action Function(aa_media_play_all, page)
                    null height 8
                if not items:
                    use aa_hub_empty("search" if searching else "note", "Nenhum resultado" if searching else "Sua biblioteca", "Tente outro título." if searching else "As trilhas aparecem aqui conforme você as ouve na história.")
                for listed_item in items:
                    use aa_media_row(listed_item, width - 40)
                    use aa_phone_rule(width - 40)
                null height 10
        if aa_media_available(aa_media_item()):
            fixed:
                xpos 12
                ypos (height - 126)
                use aa_media_mini(width - 24)
        textbutton "A seguir":
            style "aa_media_control"
            text_color accent
            xpos 20
            ypos (height - 67)
            xysize (width - 40, 44)
            action Function(aa_media_panel, "queue")

screen aa_media_access():
    zorder 104
    if aa_phone_active and quick_menu and not main_menu and not renpy.get_screen("aa_phone_hub") and not renpy.get_screen("aa_phone_view") and not aa_phone_pov and not renpy.get_screen("aa_phone_image") and aa_media_available(aa_media_item()):
        fixed:
            xpos 770
            ypos 20
            xysize (286, 64)
            use aa_media_mini(286)

init 5 python:
    config.overlay_screens.append("aa_media_access")
