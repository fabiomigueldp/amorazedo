# Reply time is presentation time. The narrative calendar never advances here.
init python:
    import message_timing as aa_reply_runtime

    def aa_messages_pending(contact):
        return next(iter(aa_family.pending(aa_world, contact)), None)

    def aa_messages_typing(contact):
        pending = aa_messages_pending(contact)
        return pending is not None and aa_reply_runtime.phase(pending) == "typing"

    def aa_messages_delivery_guard():
        if main_menu or renpy.context_nesting_level() != 0:
            aa_reply_runtime.clock.reset()
        else:
            aa_reply_runtime.clock.sync(aa_world.get("family", {}).get("seed"), aa_family.pending(aa_world))

    def aa_messages_delivery_tick():
        global aa_world, aa_state
        if main_menu or renpy.context_nesting_level() != 0:
            return
        pending = aa_family.pending(aa_world)
        if not pending:
            return
        seed = aa_world["family"]["seed"]
        aa_reply_runtime.clock.sync(seed, pending)
        elapsed = {p["id"]: aa_reply_runtime.clock.elapsed(seed, p) for p in pending}
        screen = renpy.get_screen("aa_phone_hub")
        scope = screen.scope if screen else {}
        entry = scope.get("selected_entry")
        scroll = scope.get("scroll")
        viewing = bool(entry and scope.get("page") == "messages" and not scope.get("message_panel")
                       and not renpy.get_screen("aa_phone_image"))
        at_bottom = viewing and scroll is not None and scroll.value >= scroll.range - 16
        reading = entry["title"] if at_bottom else None
        updated = aa_family.progress(aa_world, elapsed, reading)
        if updated is aa_world:
            return
        before = {p["id"]: p for p in pending}
        remaining = aa_family.pending(updated)
        arrived = [p for key, p in before.items() if not any(q["id"] == key for q in remaining)]
        aa_world = updated
        aa_reply_runtime.clock.follow(seed, remaining)
        if arrived:
            aa_state = aa_financial_state(aa_state, aa_world)
            if viewing and any(p["sender"] == entry["title"] for p in arrived):
                fresh = aa_messages_live_entry(entry)
                renpy.set_screen_variable("selected_entry", fresh, "aa_phone_hub")
                if at_bottom:
                    aa_phone_reset_scroll("bottom")
        renpy.retain_after_load()
        renpy.restart_interaction()

    def aa_messages_show_latest(entry):
        aa_phone_select(aa_messages_live_entry(entry))
        aa_phone_reset_scroll("bottom")

    config.context_callbacks.append(aa_reply_runtime.clock.reset)
    config.after_load_callbacks.append(aa_reply_runtime.clock.reset)
    config.interact_callbacks.append(aa_messages_delivery_guard)
    config.overlay_screens.append("aa_message_delivery")

screen aa_message_delivery():
    if not main_menu and renpy.context_nesting_level() == 0 and aa_family.pending(aa_world):
        timer .1 repeat True action Function(aa_messages_delivery_tick)

transform aa_message_typing_dot(delay=0):
    alpha .4
    pause delay
    block:
        ease .3 alpha .95
        ease .3 alpha .4
        pause .3
        repeat

screen aa_messages_typing_indicator(contact):
    fixed:
        xysize (76, 43)
        if aa_messages_typing(contact):
            frame:
                id "message_typing_bubble"
                background aa_phone_round("message-bubble-received", 22)
                padding (15, 8)
                xysize (72, 38)
                alt (contact + " está digitando")
                hbox:
                    align (.5, .5)
                    spacing 5
                    for delay in (0, .15, .3):
                        text "●":
                            font "fonts/Inter-Regular.ttf"
                            size 11
                            color "#b8b8be"
                            at (aa_message_typing_dot(delay) if persistent.aa_motion else Transform(alpha=.8))
