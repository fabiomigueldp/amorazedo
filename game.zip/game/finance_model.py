"""Campaign money and narrative time. Amounts are cents, time is minutes from day 0.
Every operation returns a new snapshot; event IDs prevent duplicate charges.
"""
from copy import deepcopy
from datetime import datetime, timedelta

EPOCH = datetime(2026, 9, 20)  # Fictional campaign calendar; Sunday.
START = 18 * 60 + 42
FATHER_AT = 1440 + 9 * 60
JOAO_DUE = 1440 + 12 * 60
JOAO_REMINDER = 1440 + 16 * 60
VANESSA_DUE = 5 * 1440 + 23 * 60 + 59
SCHEDULE = (
    dict(id="father", at=FATHER_AT, sender="Pai", amount=10000,
         body="Mandei os R$ 100, filho. Usa com cuidado."),
    dict(id="joao_reminder", at=JOAO_REMINDER, sender="Joãozão", debt="joaozao",
         body="Feka, eram sessenta reais até meio-dia. Já são quatro horas. Vai mandar quando?"),
    dict(id="vanessa_reminder", at=5 * 1440 + 16 * 60, sender="Vanessa", debt="vanessa",
         body="Oi. Você consegue devolver os R$ 60 hoje? Foi o que a gente combinou."),
)

def new_world():
    return dict(version=1, now=START, balance=12000, transactions=[], debts={},
                messages=[], events=[], dismissed=[], dinner_paid=False)

def stamp(minutes):
    return (EPOCH + timedelta(minutes=minutes)).strftime("%d/%m · %H:%M")

def post(w, ident, amount, title, party="", at=None):
    if ident in w["events"]: return
    if w["balance"] + amount < 0: raise ValueError("Saldo insuficiente")
    w["balance"] += amount
    w["events"].append(ident)
    w["transactions"].append(dict(id=ident, amount=amount, title=title, party=party,
                                  at=w["now"] if at is None else at, balance=w["balance"]))

def message(w, ident, sender, body, at=None):
    if ident in w["events"]: return
    w["events"].append(ident)
    w["messages"].append(dict(id=ident, sender=sender, body=body,
                              at=w["now"] if at is None else at, read=False))

def debt(w, who, amount, due):
    if who not in w["debts"]:
        w["debts"][who] = dict(amount=amount, due=due, created=w["now"], paid_at=None,
                                reminded_at=None, was_overdue=False)

def advance(world, at):
    w = deepcopy(world)
    w["now"] = max(w["now"], at)
    for event in sorted(SCHEDULE, key=lambda event: event["at"]):
        ident, scheduled = event["id"], event["at"]
        if scheduled > w["now"] or ident in w["events"]: continue
        d = w["debts"].get(event.get("debt"))
        if event.get("debt") and (not d or d["paid_at"] is not None): continue
        if event.get("amount"):
            post(w, ident + "_transfer", event["amount"], "Pix recebido", event["sender"], scheduled)
        message(w, ident, event["sender"], event["body"], scheduled)
        if d: d["reminded_at"] = scheduled
    for d in w["debts"].values():
        if d["paid_at"] is None and w["now"] > d["due"]: d["was_overdue"] = True
    return w

def transact(world, event):
    w = deepcopy(world)
    if event == "joao_loan" and event not in w["events"]:
        post(w, event, 6000, "Pix recebido", "Joãozão")
        debt(w, "joaozao", 6000, JOAO_DUE)
    elif event in ("dinner_split", "dinner_full", "dinner_vanessa") and not w["dinner_paid"]:
        amount = {"dinner_split": 9000, "dinner_full": 18000, "dinner_vanessa": 12000}[event]
        post(w, "dinner", -amount, "Jantar", "Casa do Pátio")
        w["dinner_paid"] = True
        if event == "dinner_vanessa": debt(w, "vanessa", 6000, VANESSA_DUE)
    elif event == "bus_campus":
        post(w, event, -500, "Passagem", "Ônibus")
    elif event.startswith("ride_"):
        post(w, event, -1800, "Corrida", "Moradia")
    return advance(w, w["now"])

def repay(world, who, in_person=False):
    d = world["debts"].get(who)
    if not d or d["paid_at"] is not None: return world
    if not world["dinner_paid"]: return world
    if world["balance"] < d["amount"]: return world
    w = deepcopy(world)
    d = w["debts"][who]
    sender = "Joãozão" if who == "joaozao" else "Vanessa"
    post(w, "repay_" + who, -d["amount"], "Pix enviado", sender)
    d["paid_at"] = w["now"]
    d["was_overdue"] = d["was_overdue"] or w["now"] > d["due"]
    body = "Recebi. Da próxima vez, cumpre o prazo." if d["was_overdue"] else "Recebi. Obrigado."
    if who == "vanessa": body = "Recebi. Obrigada."
    if not in_person:
        message(w, "receipt_" + who, sender, body)
    return w

def dismiss(world, ident):
    w = deepcopy(world)
    if ident not in w["dismissed"]: w["dismissed"].append(ident)
    return w

def read(world, ident):
    w = dismiss(world, ident)
    for m in w["messages"]:
        if m["id"] == ident: m["read"] = True
    return w


def notices(world, present=()):
    """Só banners recentes; o arquivo de mensagens e os não lidos permanecem."""
    names={'vanessa':'Vanessa','joaozao':'Joãozão','yasmin':'Yasmin'}
    together={names.get(person, person) for person in present}
    return [m for m in world['messages'] if not m['read']
            and m['id'] not in world['dismissed'] and m['sender'] not in together
            and 0 <= world['now']-m['at'] <= 20]

def status(world, who):
    d = world["debts"].get(who)
    if not d: return "none"
    if d["paid_at"] is not None: return "paid_late" if d["was_overdue"] else "paid"
    return "overdue" if world["now"] > d["due"] else "pending"
