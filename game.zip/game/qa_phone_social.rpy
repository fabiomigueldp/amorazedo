# Focused native coverage for Momentos and its story-driven archive.
testsuite aa_phone_social_test:
    setup:
        $ _test.timeout = 14.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/phone-social" + ("-small" if renpy.variant("small") else "")
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        exit

    testcase feed_post_saved_and_profile:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        keysym "p"
        click "Momentos"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_tab"] == "home"
        assert eval len(aa_pm.social_posts(aa_phone_memory)) == 1
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").xadjustment.range == 0
        screenshot "feed.png"
        run Function(renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.change, 250)
        click "Curtir"
        assert eval "publicacao" in aa_phone_preferences.social_likes
        click "Salvar publicação"
        assert eval aa_social_is_saved(aa_pm.social_posts(aa_phone_memory)[0])
        click "Abrir publicação de Yasmin"
        assert eval renpy.get_screen("aa_phone_hub").scope["selected_entry"]["kind"] == "publicacao"
        click "Ampliar imagem de Yasmin"
        assert "Voltar à foto"
        keysym "K_ESCAPE"
        keysym "K_ESCAPE"
        click "Perfil"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_profile"] == "Feka"
        assert eval not aa_pm.social_profile_posts(aa_phone_memory, "Feka")
        click "Salvos"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_profile_section"] == "saved"
        screenshot "saved.png"

    testcase separate_posts_and_withdrawal:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        $ aa_phone_remember("restaurante")
        $ aa_phone_remember("publicado")
        keysym "p"
        click "Momentos"
        assert eval len(aa_pm.social_posts(aa_phone_memory)) == 3
        assert eval tuple(p["kind"] for p in aa_pm.social_posts(aa_phone_memory)) == ("publicado", "restaurante", "publicacao")
        run Function(renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.change, 670)
        screenshot "two-posts.png"
        click "Abrir publicação de Yasmin"
        assert eval renpy.get_screen("aa_phone_hub").scope["selected_entry"]["kind"] == "restaurante"
        keysym "K_ESCAPE"
        $ aa_chapter_phone_action("withdraw_post")
        assert eval len(aa_pm.social_posts(aa_phone_memory)) == 2
        assert eval not any(p["id"] == "publicacao_feka" for p in aa_pm.app_entries(aa_phone_memory, "social"))
        assert eval any(p["id"] == "publicacao_feka" for p in aa_pm.app_entries(aa_phone_memory, "photos"))
        click "Perfil"
        screenshot "withdrawn.png"
        assert not "Abrir fotografia guardada"
        run Function(aa_phone_go, 'photos')
        assert eval renpy.get_screen("aa_phone_hub").scope["page"] == "photos"

    testcase search_reels_messages_and_activity:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        keysym "p"
        click "Momentos"
        click "Buscar"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_tab"] == "search"
        screenshot "search.png"
        click "Reels"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_tab"] == "reels"
        screenshot "reels.png"
        click "Conversas"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_tab"] == "dm"
        screenshot "conversations.png"
        click "Abrir conversa com Yasmin em Mensagens"
        assert eval renpy.get_screen("aa_phone_hub").scope["page"] == "messages"
        run Function(aa_phone_go, "social")
        click "Atividade"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_panel"] == "activity"
        screenshot "activity.png"
        click "Abrir atividade de Yasmin"
        assert eval renpy.get_screen("aa_phone_hub").scope["selected_entry"]["kind"] == "publicacao"

    testcase detail_panels_and_save:
        run Start("qa_hub_populated")
        advance until "Ainda estamos no restaurante."
        keysym "p"
        click "Momentos"
        click "Abrir publicação de Yasmin"
        run Function(renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.change, 160)
        click "Ver comentários"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_panel"] == "comments"
        screenshot "comments.png"
        keysym "K_ESCAPE"
        assert eval renpy.get_screen("aa_phone_hub").scope["selected_entry"]["kind"] == "publicacao"
        run Function(renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.change, 160)
        click "Compartilhar"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_panel"] == "share"
        click "Abrir Mensagens do celular"
        assert eval renpy.get_screen("aa_phone_hub").scope["page"] == "messages"
        run Function(aa_phone_go, "social")
        click "Abrir publicação de Yasmin"
        click "Opções"
        assert eval renpy.get_screen("aa_phone_hub").scope["social_panel"] == "more"
        click "Salvar publicação"
        assert eval aa_social_is_saved(aa_pm.social_posts(aa_phone_memory)[0])
        run QuickSave()
        click "Remover dos salvos"
        assert eval not aa_social_is_saved(aa_pm.social_posts(aa_phone_memory)[0])
        run QuickLoad(confirm=False)
        assert eval aa_social_is_saved(aa_pm.social_posts(aa_phone_memory)[0])

    testcase narration_uses_social_surface:
        run Start("qa_phone_publicacao")
        advance until screen "aa_phone_view"
        screenshot "story-first.png"

    testcase narration_second_slide:
        run Start("qa_phone_restaurante")
        advance until screen "aa_phone_view"
        screenshot "story-second.png"

    testcase narration_old_post:
        run Start("qa_phone_comparacao")
        advance until screen "aa_phone_view"
        screenshot "story-old-post.png"

    testcase narration_own_post:
        run Start("qa_phone_publicado")
        advance until screen "aa_phone_view"
        screenshot "story-own-post.png"

    testcase narration_own_post_after_tag_change:
        run Start("qa_phone_publicado_depois")
        advance until screen "aa_phone_view"
        screenshot "story-after-tag.png"

    testcase story_choice_from_social_app:
        run Start()
        advance until screen "choice"
        keysym "p"
        click "Momentos"
        assert "Yasmin"
        screenshot "story-choice.png"
        click "Yasmin"
        assert not screen "aa_phone_hub"
        advance until screen "aa_phone_view"
        assert eval any(item["kind"] == "publicacao" for item in aa_phone_memory)
