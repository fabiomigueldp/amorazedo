# Actual input, save/load and rollback coverage for the family composer.
label qa_family_fixture:
    $ aa_world_start()
    $ aa_world_scene(aa_fm.FATHER_AT)
    $ aa_world = dict(aa_world, family=dict(aa_world["family"], seed="0"))
    $ aa_state = dict(aa_new_state(), chapter=2)
    $ aa_phone_memory = ()
    $ aa_phone_preferences = AAPhonePreferences()
    $ aa_phone_active = True
    $ aa_phone_kind = ""
    $ aa_phone_pov = False
    $ aa_node = "k01"
    $ aa_location = "09h00 · Quarto de Feka"
    $ aa_present = ()
    scene cg14_emprestimo
    "A manhã começou."
    "O celular está na mesa."
    "Hora de continuar."
    return

testsuite aa_family_messages_test:
    setup:
        $ _test.timeout = 20.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = .02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/family-messages" + ("-small" if renpy.variant("small") else "")
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        exit

    testcase greeting_draft_cancel_save_rollback:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Mãe")
        assert "Boa noite, filho."
        click "Escolher resposta"
        pause .3
        screenshot "greeting-options.png"
        click "Bom dia, mãe."
        pause .3
        screenshot "greeting-draft.png"
        assert eval aa_world["family"]["affinity"]["mother"] == 0
        click "Cancelar"
        assert eval aa_world["family"]["sequence"] == 0
        click "Escolher resposta"
        click "Bom dia, mãe."
        click "Enviar mensagem"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["family"]["affinity"]["mother"] == 1
        assert eval aa_state["trust"] == 1
        assert eval aa_phone_badge("messages") == 1
        assert eval aa_world["family"]["sequence"] == 1
        pause .3
        screenshot "greeting-sent.png"
        run QuickSave()
        keysym "p"
        advance until "Hora de continuar."
        run QuickLoad(confirm=False)
        assert eval aa_world["family"]["affinity"]["mother"] == 1
        run Rollback() until eval aa_world["family"]["sequence"] == 0 timeout 10.0
        assert eval aa_world["family"]["affinity"]["mother"] == 0

    testcase greeting_then_thanks_then_money:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Bom dia, pai."
        click "Enviar mensagem"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        click "Escolher resposta"
        click "Obrigado pelo dinheiro, pai."
        screenshot "thanks-after-greeting-draft.png"
        assert "Enviar mensagem"
        assert eval isinstance(renpy.get_widget("aa_phone_hub", "message_draft_field").get_placement()[1], int)
        click "Enviar mensagem"
        assert eval aa_world["messages"][-1]["body"] == "Obrigado pelo dinheiro, pai."
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert "De nada, filho."
        assert eval aa_world["balance"] == 22000
        click "Escolher resposta"
        assert eval "thanks" not in dict(aa_family.options(aa_world, "Pai"))
        click "Pai, consegue me mandar um dinheiro?"
        type "80"
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 30000
        click "Escolher resposta"
        click "Obrigado pelo dinheiro, pai."
        click "Enviar mensagem"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval len([m for m in aa_world["messages"] if m.get("outgoing") and m["body"] == "Obrigado pelo dinheiro, pai."]) == 2
        assert eval aa_world["balance"] == 30000
        screenshot "thanks-after-transfer-received.png"

    testcase multiline_draft_pov_cancel_save_load:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        $ aa_phone_pov = True
        run Function(aa_phone_set_pref, "text_size", 3)
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Obrigado pelo dinheiro, pai."
        assert "Enviar mensagem"
        assert eval isinstance(renpy.get_widget("aa_phone_hub", "message_draft_field").get_placement()[1], int)
        screenshot "thanks-pov-large-draft.png"
        click "Cancelar"
        assert "Escolher resposta"
        assert eval aa_world["family"]["sequence"] == 0
        click "Escolher resposta"
        click "Obrigado pelo dinheiro, pai."
        run QuickSave()
        click "Cancelar"
        run QuickLoad(confirm=False)
        assert not screen "aa_phone_hub"
        assert eval aa_world["family"]["sequence"] == 0
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Obrigado pelo dinheiro, pai."
        assert "Enviar mensagem"
        click "Enviar mensagem"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert "De nada, filho."
        assert eval aa_world["family"]["sequence"] == 1
        screenshot "thanks-pov-large-received.png"

    testcase custom_amount_bank_save_and_rollback:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Pai")
        click "Informações de Pai"
        assert "Jeferson"
        assert "Oficial de registro civil"
        pause .3
        screenshot "father-contact.png"
        keysym "K_ESCAPE"
        click "Escolher resposta"
        pause .3
        screenshot "father-options.png"
        click "Pai, consegue me mandar um dinheiro?"
        type "80,50"
        assert "Pai, consegue me mandar R$ 80,50?"
        pause .3
        screenshot "money-draft.png"
        assert eval aa_world["balance"] == 22000
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 30050
        assert eval aa_world["transactions"][-1]["amount"] == 8050
        assert eval aa_world["family"]["sequence"] == 1
        assert "Mandei, filho."
        pause .3
        screenshot "money-sent.png"
        click "Início"
        click "Banco"
        pause .3
        screenshot "money-bank.png"
        assert eval aa_bank_transactions()[0]["amount"] == 8050
        run QuickSave()
        keysym "p"
        advance until "Hora de continuar."
        run QuickLoad(confirm=False)
        assert eval aa_world["balance"] == 30050
        assert eval aa_world["family"]["sequence"] == 1
        run Rollback() until eval aa_world["balance"] == 22000 timeout 10.0
        assert eval aa_world["family"]["sequence"] == 0
        assert eval not aa_world["family"]["requests"]

    testcase refusal_is_persistent_and_greetings_still_work:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "1200"
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 22000
        assert eval aa_world["family"]["blocked_until"] == 0
        assert eval aa_world["family"]["next_request_at"] == aa_world["now"] + 1440
        assert eval "amanhã" in aa_world["messages"][-1]["body"]
        pause .3
        screenshot "father-refusal.png"
        click "Escolher resposta"
        assert not "Pai, consegue me mandar um dinheiro?"
        click "Bom dia, pai."
        click "Enviar mensagem"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["family"]["affinity"]["father"] == 1
        run QuickSave()
        keysym "p"
        advance until "Hora de continuar."
        run QuickLoad(confirm=False)
        assert eval not any(k == "money" for k, body in aa_family.options(aa_world,"Pai"))

    testcase large_text_amount_validation_and_cancel:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_set_pref, "text_size", 3)
        run Function(aa_phone_set_pref, "glass", 1.0)
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        pause .3
        screenshot "large-options.png"
        click "Pai, consegue me mandar um dinheiro?"
        type "1.250,75"
        pause .3
        screenshot "large-money.png"
        assert "Pai, consegue me mandar R$ 1.250,75?"
        assert eval renpy.get_widget("aa_phone_hub", "message_panel_scroll").xadjustment.range == 0
        keysym "K_ESCAPE"
        assert eval renpy.get_screen("aa_phone_hub").scope["message_draft"] is None
        assert eval aa_world["balance"] == 22000
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "0"
        assert "Confira o valor."
        assert eval not renpy.get_widget("aa_phone_hub", "family_amount").value.get_text() == ""
        pause .3
        screenshot "invalid-amount.png"
        keysym "K_ESCAPE"
        assert eval aa_world["family"]["sequence"] == 0

    testcase recent_help_is_named_and_legacy_save_is_migrated:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        $ aa_world = {k: v for k, v in aa_world.items() if k != "family"}
        run QuickSave()
        run QuickLoad(confirm=False)
        assert eval "family" in aa_world and aa_world["balance"] == 22000
        assert eval not aa_world["family"]["requests"]
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "300"
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 52000
        run Function(aa_world_scene, aa_world["now"] + 60)
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "800"
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 52000
        assert eval aa_world["family"]["blocked_until"] == 0
        assert eval "R$ 300,00" in aa_world["messages"][-1]["body"]
        assert eval aa_world["messages"][-2]["outgoing"]
        pause .3
        screenshot "father-recent-spending.png"

    testcase substantial_recent_help_can_suspend_the_week:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "500"
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 72000
        run Function(aa_world_scene, aa_world["now"] + 60)
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "1000"
        click "Enviar"
        assert eval not aa_family.pending(aa_world) timeout 6.0
        assert eval aa_world["balance"] == 72000
        assert eval aa_world["family"]["blocked_until"] == aa_world["now"] + 10080
        assert eval "R$ 500,00" in aa_world["messages"][-1]["body"]
        assert eval "sete dias" in aa_world["messages"][-1]["body"]
        assert eval renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.value >= renpy.get_widget("aa_phone_hub", "phone_scroll").yadjustment.range - 1 timeout 1.0
        screenshot "father-substantial-help-refusal.png"
