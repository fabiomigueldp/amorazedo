"""Estado narrativo pequeno, explícito, sem I/O e sem dependência de Ren'Py."""

# These predicates must be evaluated again after using the phone over a menu.
FINANCIAL_KEYS = frozenset((
    "can_pay_dinner", "can_pay_share", "can_borrow_sixty", "can_pay_ride",
    "dinner_agreement_kept", "other_debt_open", "can_repay_restaurant", "can_repay_ride",
    "j_debt_status", "v_debt_status", "j_debt_open", "v_debt_open",
    "can_repay_j", "can_repay_v",
))

def new_state():
    return dict(
        trust=1, heat=0, knew=False, phone=False, late=False, past_read=False,
        asked_clothes=False, heard=False, claimed_space=False, debt=False,
        source_truth=False, initial_lie=False, v_knows=False, early_admit=False,
        group_source=False,
        presence_told=False, ambush=False,
        no_photo=False, introduced=False, minimized=False, used=False, arrival_checked=False,
        route="", seat_swapped=False, table_focus="", past_told=False, public=False, stopped_joke=False,
        photo_asked=False, photo_boundary_broken=False, table_topic="", table_history="",
        y_limit=False, insisted=False, j_limit=False,
        interval="", private=False, bargain=False, truth=False,
        silence=False, listened=False, respect=False, v_gone=False, bill="",
        bond="namoro", promised=False, contact="", hesitated=False, v_loan=False,
        comfort_lie=False,
        car_hug=False, car_close=False,
        present_choice=False, tender_lie=False, chosen_vanessa=False,
        sleepover=False, bed_close=False,
        blocked_exit=False, unwanted_contact=False, held_after_no=False,
        punched=False, incident_account="", station_account="",
        chapter=1, chapter_origin="", campaign="open", relationship_phase="",
        move_status="unknown", visit_plan="", contact_accepted=False,
        public_corrected=False, public_story_corrected=False, reservation_explained=False,
        post_arc_version=1, post_status="none", post_tagged=False,
        tag_response="none", tag_breach=False, colleague_account="none",
        reply_style="", daily_promise=False, arrival_notice=False,
        task_plan="", task_done=False, task_repaired=False,
        boundary_kept=False, returned_on_time=False, visit_accepted=False,
        friday_arrangement=False, weekend_plan="", weekend_space=False,
        week_pressure=0, weekend_honest=False, visit_missed=False,
        weekend_close=False, weekend_cancelled_friend=False, weekend_studied=False,
        j_debt_status="none", v_debt_status="none", j_debt_open=False,
        v_debt_open=False, can_repay_j=False, can_repay_v=False,
        money_response="", own_time=False, final_contact="", can_pay_dinner=False,
        can_pay_share=False, can_borrow_sixty=False, can_pay_ride=False,
        dinner_agreement_kept=False, money_breach=False, loan_requested=False,
        ride_payer="", other_debt_open=False, can_repay_restaurant=False, can_repay_ride=False,
    )

def matches(state, requirements):
    for key, expected in requirements.items():
        actual = state[key] if key in state else new_state()[key]
        if isinstance(expected, dict):
            for op, value in expected.items():
                if op == "gte" and not actual >= value:
                    return False
                if op == "lte" and not actual <= value:
                    return False
                if op == "ne" and not actual != value:
                    return False
                if op not in ("gte", "lte", "ne"):
                    raise ValueError("Operador de condição inválido: " + op)
        elif actual != expected:
            return False
    return True

def available(state, node):
    return [(i, choice) for i, choice in enumerate(node["choices"]) if matches(state, choice["when"])]

def enter(state, node):
    """Fatos de entrada explícitos; não inferir namoro a partir da presença."""
    result = dict(new_state(), **state)
    for effect in node.get("entry", []):
        if matches(result, effect.get("when", {})):
            for key, value in effect["set"].items():
                if key not in result:
                    raise KeyError(key)
                result[key] = value
    return result

def next_node(state, node):
    for route in node.get("routes", []):
        if matches(state, route.get("when", {})):
            return route["target"]
    return node["next"]

def financial_state(state, world):
    """Fotografia atual das dívidas para escolhas; a economia continua separada."""
    from finance_model import status
    result = dict(state)
    result["can_pay_dinner"] = world["balance"] >= 18000
    result["can_pay_share"] = world["balance"] >= 9000
    result["can_borrow_sixty"] = 12000 <= world["balance"] < 18000
    result["can_pay_ride"] = world["balance"] >= 1800
    result["dinner_agreement_kept"] = bool(
        world["dinner_paid"] and "dinner" not in world.get("shortfalls", {})
        and state.get("bill") in ("dividida", "proprio")
        and not state.get("money_breach") and not state.get("loan_requested"))
    result["other_debt_open"] = any(status(world, who) in ("pending", "overdue")
                                    for who in ("restaurant", "ride"))
    for who in ("restaurant", "ride"):
        d = world["debts"].get(who)
        result["can_repay_" + who] = bool(d and d["paid_at"] is None
            and world["dinner_paid"] and world["balance"] >= d["amount"])
    for short, who in (("j", "joaozao"), ("v", "vanessa")):
        current = status(world, who)
        debt = world["debts"].get(who)
        opened = current in ("pending", "overdue")
        result[short + "_debt_status"] = current
        result[short + "_debt_open"] = opened
        result["can_repay_" + short] = bool(opened and world["dinner_paid"] and world["balance"] >= debt["amount"])
    return result


def financial_consequences(state, before, after):
    """Only a new failed dinner settlement changes trust, once, in every runner."""
    result = dict(state)
    if "dinner" in after.get("shortfalls", {}) and "dinner" not in before.get("shortfalls", {}):
        result["money_breach"] = True
        if not state.get("v_gone"):
            result["trust"] = max(0, state.get("trust", 1) - 1)
    return financial_state(result, after)

def choose(state, node, index):
    choice = node["choices"][index]
    if not matches(state, choice["when"]):
        raise ValueError("Escolha indisponível neste estado")
    result = new_state()
    result.update(state)
    for key, value in choice["set"].items():
        if key not in result:
            raise KeyError(key)
        result[key] = value
    for key, amount in choice["add"].items():
        result[key] = max(0, min(3, result[key] + amount))
    return result
