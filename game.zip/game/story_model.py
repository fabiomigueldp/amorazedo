"""Estado narrativo pequeno, explícito, sem I/O e sem dependência de Ren'Py."""

def new_state():
    return dict(
        trust=1, heat=0, knew=False, phone=False, late=False, past_read=False,
        asked_clothes=False, heard=False, claimed_space=False, debt=False,
        source_truth=False, initial_lie=False, v_knows=False, early_admit=False,
        group_source=False,
        presence_told=False, ambush=False,
        no_photo=False, introduced=False, minimized=False, used=False, arrival_checked=False,
        route="", seat_swapped=False, table_focus="", past_told=False, public=False, stopped_joke=False,
        photo_asked=False, y_limit=False, insisted=False, j_limit=False,
        interval="", private=False, bargain=False, truth=False,
        silence=False, listened=False, respect=False, v_gone=False, bill="",
        bond="namoro", promised=False, contact="", hesitated=False, v_loan=False,
        comfort_lie=False,
        car_hug=False, car_close=False,
        present_choice=False, tender_lie=False, chosen_vanessa=False,
        sleepover=False, bed_close=False,
    )

def matches(state, requirements):
    for key, expected in requirements.items():
        actual = state[key] if key in state else new_state()[key]
        if isinstance(expected, dict):
            for op, value in expected.items():
                if op == "gte" and not actual >= value:
                    return False
                if op == "lte" and not actual <= value:
                    return False
                if op == "ne" and not actual != value:
                    return False
                if op not in ("gte", "lte", "ne"):
                    raise ValueError("Operador de condição inválido: " + op)
        elif actual != expected:
            return False
    return True

def available(state, node):
    return [(i, choice) for i, choice in enumerate(node["choices"]) if matches(state, choice["when"])]

def choose(state, node, index):
    choice = node["choices"][index]
    if not matches(state, choice["when"]):
        raise ValueError("Escolha indisponível neste estado")
    result = new_state()
    result.update(state)
    for key, value in choice["set"].items():
        if key not in result:
            raise KeyError(key)
        result[key] = value
    for key, amount in choice["add"].items():
        result[key] = max(0, min(3, result[key] + amount))
    return result
