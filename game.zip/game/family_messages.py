"""Family conversations. Campaign snapshots, fictional minutes and integer cents.

No UI timers, network calls or drawing side effects. A saved seed makes a given
request reproducible across loading and rollback; retries have narrative limits.
"""
from copy import deepcopy
from hashlib import sha256
import re
import uuid
import message_timing

DAY = 1440
WEEK = 7 * DAY
CONTACTS = {
    "father": dict(title="Pai", name="Jeferson", detail="Oficial de registro civil"),
    "mother": dict(title="Mãe", name="Heloise", detail=""),
}


def contact_id(name):
    for key, data in CONTACTS.items():
        if name in (key, data["title"], data["name"]):
            return key
    return None


def initial_state(seed=None):
    return dict(version=2, seed=seed or uuid.uuid4().hex, sequence=0, pending=[],
                used=[], rewarded=[], chapter_rewards={}, affinity={"father": 0, "mother": 0},
                requests=[], blocked_until=0, next_request_at=0)


def ensure(world):
    if "family" in world:
        if "pending" in world["family"]:
            return world
        result = deepcopy(world)
        result["family"].update(version=2, pending=[])
        return result
    result = deepcopy(world)
    # Loading the same pre-feature save must not generate a new family roll.
    legacy_facts = (world["now"], tuple((t["id"], t["at"], t["amount"])
                                      for t in world["transactions"]), tuple(world["events"]))
    seed = sha256(repr(legacy_facts).encode("utf-8")).hexdigest()
    result["family"] = initial_state(seed)
    return result


def history():
    return tuple(dict(id="family_history_" + key, kind="chapter_message", section="messages",
                      title=data["title"], contact_id=key, subtitle="", location="",
                      messages=((True, "Bom dia, pai."), (False, "Bom dia, filho.")) if key == "father"
                      else ((False, "Boa noite, filho."), (True, "Boa noite, mãe.")),
                      paragraphs=(), image=None, at=-1)
                 for key, data in CONTACTS.items())


def money(cents):
    return "R$ " + ("{:,.2f}".format(cents / 100).replace(",", "_").replace(".", ",").replace("_", "."))


def parse_amount(value):
    """Accept Brazilian currency, reject ambiguous decimals, signs and overflow."""
    text = value.strip().removeprefix("R$").strip()
    if not re.fullmatch(r"(?:[0-9]{1,6}|[0-9]{1,3}(?:\.[0-9]{3}){1,2})(?:,[0-9]{1,2})?", text):
        return None
    whole, _, fraction = text.replace(".", "").partition(",")
    amount = int(whole) * 100 + int(fraction.ljust(2, "0") or "0")
    return amount if 0 < amount <= 99999900 else None


def period(now):
    minute = now % DAY
    return "morning" if 360 <= minute < 720 else "night" if 1080 <= minute < DAY else None


def action_key(world, contact, kind):
    if kind in ("morning", "night"):
        return "%s:%s:%d" % (contact, kind, world["now"] // DAY)
    if kind == "thanks":
        transfer = next((t for t in reversed(world["transactions"])
                         if t["id"] == "father_transfer" or t["id"].startswith("family_transfer_")), None)
        return "thanks:" + transfer["id"] if transfer else None
    return "request:%d" % world.get("family", {}).get("sequence", 0)


def options(world, contact):
    contact = contact_id(contact)
    if contact is None:
        return ()
    data = world.get("family", {})
    if any(p["contact"] == contact for p in data.get("pending", ())):
        return ()
    used = data.get("used", ())
    result = []
    greeting = period(world["now"])
    if greeting and action_key(world, contact, greeting) not in used:
        result.append((greeting, ("Bom dia, " if greeting == "morning" else "Boa noite, ")
                       + ("pai." if contact == "father" else "mãe.")))
    if contact == "father":
        thanks = action_key(world, contact, "thanks")
        if thanks and thanks not in used:
            result.append(("thanks", "Obrigado pelo dinheiro, pai."))
        # The already-promised transfer anchors the first chapter's economy.
        if "father_transfer" in world["events"] and world["now"] >= max(
                data.get("blocked_until", 0), data.get("next_request_at", 0)):
            result.append(("money", "Pai, consegue me mandar um dinheiro?"))
    return tuple(result)


def request_body(amount):
    return "Pai, consegue me mandar " + money(amount) + "?"


def rolling_total(world):
    return sum(r["amount"] for r in world.get("family", {}).get("requests", ())
               if r["accepted"] and world["now"] - WEEK < r["at"] <= world["now"])


def refusal_probability(projected):
    return 0.0 if projected <= 30000 else .30 if projected <= 50000 else .75 if projected <= 100000 else 1.0


def request_roll(world):
    # Amount is deliberately absent: editing cents cannot reroll the same turn.
    data = world["family"]
    digest = sha256((data["seed"] + ":" + str(len(data["requests"]))).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") / 2**64


def send(world, contact, kind, chapter, token, amount=None):
    """Commit the outgoing action and queue its reply; credit only on delivery."""
    import finance_model as finance
    contact = contact_id(contact)
    if kind not in dict(options(world, contact)) or token != action_key(world, contact, kind):
        return world
    if kind == "money" and (type(amount) is not int or not 0 < amount <= 99999900):
        return world
    w = deepcopy(ensure(world))
    data = w["family"]
    sender = CONTACTS[contact]["title"]
    ident = "family_%s_%d" % (contact, data["sequence"])
    transfer = None
    body = request_body(amount) if kind == "money" else dict(options(w, contact))[kind]
    finance.message(w, ident + "_sent", sender, body)
    w["messages"][-1].update(outgoing=True, read=True, contact_id=contact)
    if kind == "money":
        total = rolling_total(w)
        projected = total + amount
        accepted = request_roll(w) >= refusal_probability(projected)
        if accepted:
            transfer = dict(id="family_transfer_" + str(data["sequence"]), amount=amount)
            response = "Mandei, filho." if projected <= 30000 else "Mandei. Tenta se organizar com esse dinheiro."
            data["next_request_at"] = w["now"] + 60
        elif projected > 50000 and total > 30000:
            # A large request alone is not evidence of repeated dependence.
            # Only money actually granted in the rolling window warrants a freeze.
            response = "Filho, já te mandei " + money(total) + " nesses últimos dias. Você tem me pedido bastante. "
            response += "Não vou mandar mais dinheiro nos próximos sete dias."
            data["blocked_until"] = w["now"] + WEEK
        else:
            response = ("Filho, te mandei " + money(total) + " nesses últimos dias. " if total else "Filho, ")
            response += ("esse valor é alto. Hoje não vou mandar. A gente conversa de novo amanhã."
                         if not total else "Esse pedido é alto. Hoje não vou mandar mais. A gente conversa amanhã.")
            data["next_request_at"] = w["now"] + DAY
        data["requests"].append(dict(at=w["now"], amount=amount, accepted=accepted))
    elif kind == "thanks":
        response = "De nada, filho."
    else:
        response = "Bom dia, filho." if kind == "morning" else "Boa noite, filho. Dorme bem."
        if kind == "morning" and data["affinity"][contact] >= 2:
            response = "Bom dia, filho. Bom falar com você."
        reward = "%s:%d" % (contact, w["now"] // DAY)
        chapter_key = "%s:%s" % (contact, chapter)
        if reward not in data["rewarded"]:
            data["rewarded"].append(reward)
            count = data["chapter_rewards"].get(chapter_key, 0)
            if count < 2:
                data["chapter_rewards"][chapter_key] = count + 1
                data["affinity"][contact] = min(10, data["affinity"][contact] + 1)
    data["used"].append(token)
    data["sequence"] += 1
    data["pending"].append(dict(id=ident + "_reply", sender=sender, contact=contact,
                                body=response, transfer=transfer, at=w["now"], elapsed_ms=0,
                                timing=message_timing.plan(response, data["seed"], ident)))
    return w


def pending(world, contact=None):
    return tuple(p for p in world.get("family", {}).get("pending", ())
                 if contact is None or p["contact"] == contact_id(contact))


def progress(world, elapsed_by_id, reading=None):
    """Deliver message and transfer together, once. Unrelated state is preserved."""
    import finance_model as finance
    current = pending(world)
    if not any(elapsed_by_id.get(p["id"], 0) > p["elapsed_ms"] for p in current):
        return world
    w = deepcopy(world)
    remaining = []
    for p in w["family"]["pending"]:
        p["elapsed_ms"] = min(p["timing"]["total_ms"], max(p["elapsed_ms"], elapsed_by_id.get(p["id"], 0)))
        if message_timing.phase(p) != "done":
            remaining.append(p)
            continue
        transfer = p["transfer"]
        if transfer:
            finance.post(w, transfer["id"], transfer["amount"], "Pix recebido", "Pai")
        finance.message(w, p["id"], p["sender"], p["body"])
        w["messages"][-1]["contact_id"] = p["contact"]
        if contact_id(reading) == p["contact"]:
            w = finance.read(w, p["id"])
    w["family"]["pending"] = remaining
    return w


def finish_all(world):
    return progress(world, {p["id"]: p["timing"]["total_ms"] for p in pending(world)})
