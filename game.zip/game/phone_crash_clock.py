"""Unsaved presentation clock. Saved play time belongs to casino_model only.

Binding to the exact round object prevents a load, rollback, or new campaign
from inheriting a previous process deadline, even when round IDs match.
"""
from time import monotonic


class CrashClock:
    def __init__(self, now=monotonic):
        self.now = now
        self.reset()

    def reset(self):
        self.round = None
        self.anchor = 0.0
        self.base = 0

    def running(self, r):
        return r is not None and self.round is r and r["status"] == "active"

    def bind(self, r):
        self.round = r
        self.base = r["data"]["elapsed_ms"]
        self.anchor = self.now()

    def elapsed(self, r):
        saved = r["data"]["elapsed_ms"]
        return max(saved, self.base + int((self.now() - self.anchor) * 1000)) if self.running(r) else saved

    def follow(self, r):
        # Keep the original anchor, retaining fractional milliseconds per tick.
        self.round = r


clock = CrashClock()
