# Native regression for publication decisions, archive, save/load and rollback.
label qa_post_arc_start:
    $ aa_world_start()
    $ aa_world = aa_fm.transact(aa_world, 'dinner_split')
    $ aa_state = dict(aa_new_state(), bond='indefinido', contact='conversa', route='varanda', trust=0, bill='dividida')
    $ aa_phone_memory = ()
    $ aa_trace = []
    $ aa_audio_reset()
    jump e08

label qa_post_arc_sunday:
    $ aa_world_start()
    $ aa_state = dict(aa_new_state(), bond='mantido', chapter=4, chapter_origin='e08', post_status='published', post_tagged=True, colleague_account='blamed')
    $ aa_phone_memory = ()
    $ aa_trace = []
    $ aa_audio_reset()
    $ aa_phone_remember('publicado')
    jump c4_plan

testsuite aa_post_arc_test:
    setup:
        $ _test.timeout = 18.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = 0.02
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/post-ui" + ('-small' if renpy.variant('small') else '')
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        exit

    testcase publish_from_phone_and_rollback:
        run Start('qa_post_arc_start')
        advance until screen "choice"
        assert eval aa_node == 'e08'
        assert eval not aa_pm.social_profile_posts(aa_phone_memory, 'Feka')
        screenshot "draft.png"
        click "Marcar pessoas"
        click "Vanessa"
        click "Concluir"
        screenshot "composer-tagged.png"
        keysym 'p'
        assert eval renpy.get_screen('aa_phone_hub').scope['social_draft_tagged']
        keysym 'p'
        assert eval renpy.get_screen('aa_phone_view').scope['social_draft_tagged']
        click "Compartilhar"
        assert eval aa_state['post_status'] == 'published' timeout 3.0
        assert eval aa_phone_kind == 'publicado'
        screenshot "published-response.png"
        advance until eval aa_node == 'post_request' and renpy.get_screen('choice')
        assert eval '@Vanessa' in aa_pm.social_profile_posts(aa_phone_memory, 'Feka')[0]['paragraphs']
        click "Apagar a publicação."
        advance until eval aa_node == 'post_campus' and renpy.get_screen('choice')
        run Rollback() until eval aa_node == 'post_request' and renpy.get_screen('choice') timeout 10.0
        assert eval aa_state['tag_response']=='pending' and aa_state['post_tagged']
        assert eval len(aa_pm.social_profile_posts(aa_phone_memory,'Feka'))==1

    testcase remove_tag_and_reload_pending_request:
        run Start('qa_post_arc_start')
        advance until screen "choice"
        click "Publicar e marcar Vanessa."
        advance until eval aa_node == 'post_request' and renpy.get_screen('choice')
        assert eval aa_state['tag_response'] == 'pending'
        screenshot "request.png"
        run QuickSave()
        keysym "p"
        run Function(aa_social_panel_open, 'more', 'publicacao_feka')
        click "Editar marcações"
        click "Remover marcação de Vanessa"
        click "Cancelar"
        assert eval aa_state['post_tagged']
        run Function(aa_social_panel_open, 'more', 'publicacao_feka')
        click "Editar marcações"
        click "Remover marcação de Vanessa"
        screenshot "edit-tags.png"
        click "Concluir"
        assert eval not aa_state['post_tagged'] timeout 3.0
        assert not screen 'aa_phone_hub'
        assert not screen 'aa_phone_image'
        pause 0.3
        assert 'Tirei a marcação. Deixei a legenda.' timeout 3.0
        screenshot 'tag-removed-response.png'
        move pos (400, 180)
        advance until eval aa_node == 'post_campus' and renpy.get_screen('choice')
        assert eval aa_state['post_status'] == 'published' and not aa_state['post_tagged']
        assert eval '@Vanessa' not in aa_pm.social_profile_posts(aa_phone_memory, 'Feka')[0]['paragraphs']
        assert eval aa_state['colleague_account'] == 'none'
        screenshot "campus.png"
        run QuickLoad(confirm=False)
        assert eval aa_state['tag_response'] == 'pending' and aa_state['post_tagged']
        assert eval '@Vanessa' in aa_pm.social_profile_posts(aa_phone_memory, 'Feka')[0]['paragraphs']

    testcase delete_then_keep_private:
        run Start('qa_post_arc_start')
        advance until screen "choice"
        click "Publicar e marcar Vanessa."
        advance until eval aa_node == 'post_request' and renpy.get_screen('choice')
        keysym "p"
        run Function(aa_social_panel_open, 'more', 'publicacao_feka')
        click "Excluir"
        screenshot "delete-confirm.png"
        click "Cancelar"
        assert eval aa_state['post_status']=='published'
        click "Excluir"
        click "Excluir"
        advance until eval aa_node == 'post_campus' and renpy.get_screen('choice')
        assert eval not aa_pm.social_profile_posts(aa_phone_memory, 'Feka')
        assert eval any(p['id']=='publicacao_feka' for p in aa_pm.app_entries(aa_phone_memory,'photos'))
        click "Dizer que prefiro não falar disso."
        advance until eval aa_node == 'b_post_define' and renpy.get_screen('choice')
        assert eval aa_state['colleague_account'] == 'private'
        assert not "Apagar a publicação."
        screenshot "already-deleted.png"

    testcase ignore_then_remove_later:
        run Start('qa_post_arc_start')
        advance until screen "choice"
        click "Publicar e marcar Vanessa."
        advance until eval aa_node == 'post_request' and renpy.get_screen('choice')
        click "Deixar a publicação como está."
        advance until eval aa_node == 'post_campus' and renpy.get_screen('choice')
        assert eval aa_state['tag_breach'] and aa_state['post_tagged']
        click "Dizer que Vanessa ficou estranha."
        advance until eval aa_node == 'b_post_define' and renpy.get_screen('choice')
        click "Tirar a marcação e manter a publicação."
        advance until eval aa_node == 'post_account' and renpy.get_screen('choice')
        assert eval aa_state['tag_breach'] and not aa_state['post_tagged']
        click "Corrigir o que contei ao colega."
        advance until eval aa_node == 'post_contact' and renpy.get_screen('choice')
        assert eval aa_state['public_story_corrected'] and aa_state['post_status']=='published'
        assert eval any(e['title']=='Colega de Direito' for e in aa_phone_memory)

    testcase untagged_and_cancelled:
        run Start('qa_post_arc_start')
        advance until screen "choice"
        click "Publicar sem marcar ninguém."
        advance until eval aa_node == 'post_campus' and renpy.get_screen('choice')
        assert eval aa_state['tag_response'] == 'none'
        assert eval not any(e['kind']=='tag_request' for e in aa_phone_memory)
        run MainMenu(confirm=False)
        run Start('qa_post_arc_start')
        advance until screen "choice"
        click "Desistir da publicação."
        advance until eval aa_node == 'post_campus' and renpy.get_screen('choice')
        assert eval aa_state['post_status']=='draft'
        assert eval not aa_pm.social_profile_posts(aa_phone_memory,'Feka')

    testcase banner_read_is_not_a_tag_decision:
        run Start('qa_post_arc_start')
        advance until screen 'choice'
        click 'Publicar e marcar Vanessa.'
        advance until eval aa_node == 'post_request' and renpy.get_screen('choice')
        assert eval aa_phone_banner is not None
        click 'Ler mensagem de Vanessa'
        assert eval aa_phone_banner is None
        assert eval renpy.get_screen('aa_phone_hub').scope['selected_entry']['title']=='Vanessa'
        assert eval aa_state['tag_response']=='pending' and aa_state['post_tagged']
        $ count = len(aa_phone_memory)
        $ aa_phone_remember('tag_request')
        assert eval len(aa_phone_memory)==count and aa_phone_banner is None
        screenshot 'message-opened.png'
        keysym 'p'
        click 'Deixar a publicação como está.'
        advance until eval aa_node=='post_campus' and renpy.get_screen('choice')
        assert eval aa_state['tag_breach']

    testcase discard_from_composer:
        run Start('qa_post_arc_start')
        advance until screen 'choice'
        keysym 'p'
        assert eval renpy.get_screen('aa_phone_hub').scope['social_panel']=='create'
        click 'Voltar'
        click 'Cancelar'
        assert eval aa_node=='e08' and aa_state['post_status']!='published'
        click 'Voltar'
        click 'Descartar'
        advance until eval aa_node=='post_campus' and renpy.get_screen('choice')
        assert eval aa_state['post_status']=='draft'
        assert eval not aa_pm.social_profile_posts(aa_phone_memory, 'Feka')

    testcase sunday_two_distinct_repairs:
        run Start('qa_post_arc_sunday')
        advance until screen "choice"
        click "Corrigir o que contei ao colega."
        advance until eval aa_node == 'post_sunday' and renpy.get_screen('choice')
        assert eval aa_state['public_story_corrected'] and aa_state['post_status']=='published'
        screenshot "sunday-publication.png"
        keysym "p"
        run Function(aa_phone_go, 'social')
        run Function(aa_social_panel_open, 'more', 'publicacao_feka')
        click "Excluir"
        click "Excluir"
        advance until eval aa_node == 'e16'
        assert eval aa_state['public_story_corrected'] and aa_state['post_status']=='withdrawn'
