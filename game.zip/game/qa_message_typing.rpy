init python:
    def aa_qa_typing_history():
        from copy import deepcopy
        global aa_world
        aa_world = deepcopy(aa_world)
        for i in range(14):
            aa_fm.message(aa_world, "typing_history_" + str(i), "Pai", "Mensagem anterior para conferir a posição de leitura.", aa_world["now"] - 10)

testsuite aa_message_typing_test:
    setup:
        $ _test.timeout = 18.0
        $ preferences.text_cps = 0
        $ _test.transition_timeout = .02
        $ aa_reply_runtime.qa_motion = persistent.aa_motion
        $ persistent.aa_motion = True
        $ _test.screenshot_directory = "C:/Users/fabio/Projects/amor_azedo/output/qa/message-typing" + ("-small" if renpy.variant("small") else "")
    before testcase:
        if not screen "main_menu":
            run MainMenu(confirm=False)
    teardown:
        $ persistent.aa_motion = aa_reply_runtime.qa_motion
        exit

    testcase short_reply_indicator_then_message:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Mãe")
        click "Escolher resposta"
        click "Bom dia, mãe."
        click "Enviar mensagem"
        $ qa_typing_start = aa_reply_runtime.clock.now()
        assert eval aa_family.pending(aa_world,"Mãe")
        assert eval aa_world["messages"][-1]["outgoing"]
        assert eval aa_messages_typing("Mãe") timeout 1.0
        assert "Mãe está digitando"
        screenshot "mother-typing.png"
        pause .2
        screenshot "mother-typing-next-frame.png"
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval aa_reply_runtime.clock.now() - qa_typing_start < 5.0
        assert "Bom dia, filho."
        assert eval aa_world["messages"][-1]["read"]
        assert not "Mãe está digitando"
        screenshot "mother-received.png"

    testcase hesitation_disappears_resumes_and_finishes_under_five_seconds:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        $ aa_world = dict(aa_world,family=dict(aa_world["family"],seed="2"))
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "1200"
        click "Enviar"
        $ qa_typing_start = aa_reply_runtime.clock.now()
        assert eval aa_world["balance"] == 22000
        assert eval aa_messages_typing("Pai") timeout 1.0
        screenshot "father-typing.png"
        assert eval aa_reply_runtime.phase(aa_messages_pending("Pai")) == "paused" timeout 3.0
        assert not "Pai está digitando"
        screenshot "father-pause.png"
        assert eval aa_messages_typing("Pai") timeout 1.0
        screenshot "father-resumed.png"
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval aa_reply_runtime.clock.now() - qa_typing_start < 5.0
        assert eval "amanhã" in aa_world["messages"][-1]["body"]
        assert eval aa_world["balance"] == 22000
        screenshot "father-received.png"

    testcase background_delivery_pending_save_load_and_rollback:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open, "Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "80"
        click "Enviar"
        assert eval aa_world["balance"] == 22000
        pause .3
        $ aa_reply_runtime.qa_saved_progress = aa_family.pending(aa_world)[0]["elapsed_ms"]
        run QuickSave()
        keysym "p"
        assert not screen "aa_phone_hub"
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval aa_world["balance"] == 30000
        assert eval not aa_world["messages"][-1]["read"]
        assert "Mensagem de Pai"
        screenshot "background-notification.png"
        run QuickLoad(confirm=False)
        assert eval aa_world["balance"] == 22000
        assert eval aa_family.pending(aa_world)[0]["elapsed_ms"] >= aa_reply_runtime.qa_saved_progress
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval aa_world["balance"] == 30000
        assert eval len([t for t in aa_world["transactions"] if t["id"].startswith("family_transfer_")]) == 1
        run Rollback() until eval aa_world["family"]["sequence"] == 0 timeout 10.0
        pause 1.0
        assert eval aa_world["balance"] == 22000 and not aa_family.pending(aa_world)

    testcase reading_older_messages_keeps_position_and_unread:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_qa_typing_history)
        run Function(aa_phone_open,"Pai")
        click "Escolher resposta"
        click "Bom dia, pai."
        click "Enviar mensagem"
        run Function(renpy.get_widget("aa_phone_hub","phone_scroll").yadjustment.change,0)
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval renpy.get_widget("aa_phone_hub","phone_scroll").yadjustment.value == 0
        assert eval not aa_world["messages"][-1]["read"]
        assert "Nova mensagem ↓"
        screenshot "older-messages.png"
        click "Nova mensagem ↓"
        assert eval aa_world["messages"][-1]["read"]
        assert not "Nova mensagem ↓"

    testcase simultaneous_contacts_and_reduced_motion:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        $ persistent.aa_motion = False
        run Function(aa_phone_set_pref,"text_size",3)
        run Function(aa_phone_open,"Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "1200"
        click "Enviar"
        run Function(aa_phone_open,"Mãe")
        click "Escolher resposta"
        click "Bom dia, mãe."
        click "Enviar mensagem"
        assert eval len(aa_family.pending(aa_world)) == 2
        assert eval aa_messages_typing("Mãe") timeout 1.0
        screenshot "reduced-motion-large.png"
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval next(t for t in aa_phone_threads() if t["title"] == "Pai")["unread"]
        assert eval not next(t for t in aa_phone_threads() if t["title"] == "Mãe")["unread"]

    testcase game_menu_pauses_and_resumes_remaining_time:
        run Start("qa_family_fixture")
        advance until "O celular está na mesa."
        run Function(aa_phone_open,"Pai")
        click "Escolher resposta"
        click "Pai, consegue me mandar um dinheiro?"
        type "1200"
        click "Enviar"
        pause .3
        run ShowMenu("preferences")
        $ aa_reply_runtime.qa_saved_progress = aa_family.pending(aa_world)[0]["elapsed_ms"]
        pause .7
        assert eval aa_family.pending(aa_world)[0]["elapsed_ms"] == aa_reply_runtime.qa_saved_progress
        click "Voltar"
        assert not screen "preferences"
        assert eval not aa_family.pending(aa_world) timeout 5.0
        assert eval aa_world["balance"] == 22000
