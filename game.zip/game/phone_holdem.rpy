# The phone is a view of the saved hand; no dealing or AI runs during drawing.
init python:
    import holdem_model as aa_hm

    AA_HOLDEM_ACTIONS = {"small": "Small blind", "big": "Big blind", "fold": "Desistiu",
        "check": "Passou", "call": "Pagou", "raise": "Aumentou para", "bet": "Apostou",
        "allin": "All-in", "allin_to": "All-in para", "refund": "Recebeu de volta", "deal": "Cartas abertas"}

    def aa_holdem_pulse():
        r = aa_cm.active(aa_world)
        scope = aa_casino_scope()
        if scope.get("casino_panel"):
            return
        if scope.get("casino_busy"):
            if aa_casino_time.monotonic() - scope.get("casino_started", 0) >= scope.get("casino_duration", 0):
                aa_casino_finish_visual(scope["casino_busy"])
            return
        if not r or r["game"] != "holdem":
            return
        if r["data"]["phase"] == "deal" or r["data"]["turn"] != 0:
            aa_casino_act(r["id"], r["revision"], "auto")

    def aa_holdem_raise():
        r = aa_cm.active(aa_world)
        if r and r["game"] == "holdem" and r["data"]["turn"] == 0:
            limits = aa_hm.legal(r["data"], 0)
            aa_casino_set(panel="holdem-raise", raise_amount=aa_casino_bet_text(min(limits["minimum"], limits["maximum"])), error="", scroll=ui.adjustment())

    def aa_holdem_finish(ident):
        r = aa_cm.active(aa_world)
        if r and r["id"] == ident and r["game"] == "holdem" and aa_hm.can_finish(r["data"]):
            # Finishing is available during the presentation pause as well.
            # Use the current revision if a bot just acted before the click.
            aa_casino_set(busy=None)
            aa_casino_act(r["id"], r["revision"], "finish")

    def aa_holdem_confirm(ident, revision, amount):
        renpy.set_editable_input_value(None, False)
        aa_casino_act(ident, revision, "raise", aa_casino_parse(amount))
        r = aa_cm.state(aa_world)["round"]
        if r and r["id"] == ident and r["revision"] != revision:
            aa_casino_set(panel=None, scroll=ui.adjustment())

    def aa_holdem_note(d):
        entry = d["log"][-1]
        if entry["seat"] is None:
            return aa_hm.STREETS[d["street"]] + " na mesa"
        return aa_hm.NAMES[entry["seat"]] + " · " + AA_HOLDEM_ACTIONS[entry["action"]].lower() + (" " + aa_pm.brl(entry["amount"]) if entry["amount"] else "")

    def aa_holdem_role(d, seat):
        return "D" if seat == d["button"] else "SB" if seat == (d["button"] + 1) % 3 else "BB"

screen aa_holdem_card(card=None, width=42, hidden=False, empty=False):
    $ height = int(width * 1.4)
    fixed:
        xysize (width, height)
        if empty:
            add aa_phone_round("casino-surface", 6) xysize (width, height)
            text "·" style "aa_casino_muted" size 20 align (.5, .5)
        elif hidden:
            add aa_casino_art("card-back") xysize (width, height)
        else:
            add aa_phone_round("casino-card", 6) xysize (width, height)
            $ rank = {1: "A", 11: "J", 12: "Q", 13: "K"}.get(card[0], str(card[0]))
            text rank style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" color ("#b64355" if card[1] in (1, 2) else "#27232e") size max(12, int(width * .39)) xpos 4 ypos 2
            add aa_casino_art("suit-" + str(card[1])) xysize (int(width * .49), int(width * .49)) align (.52, .77)

screen aa_holdem_seat(width, d, seat, compact=False):
    $ p = d["players"][seat]
    $ show = p["hole"] and aa_hm.visible(d, seat)
    frame:
        xysize (width, (60 if compact else 77) + aa_phone_pref("text_size", 0) * 3)
        background aa_phone_round("casino-hover" if d["phase"] == "betting" and d["turn"] == seat else "casino-surface", 15)
        padding (8, 6)
        vbox:
            spacing 3
            fixed:
                xysize (width - 16, 17 + aa_phone_pref("text_size", 0))
                text (p["name"] + (" · fora" if compact and p["folded"] else "")) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(13)
                text aa_holdem_role(d, seat) style "aa_casino_muted" size 10 xalign 1.0
            hbox:
                spacing 3
                for i in range(2):
                    use aa_holdem_card(p["hole"][i] if show else None, 19, hidden=not show)
                text aa_pm.brl(p["stack"]) style "aa_casino_text" size aa_bank_fit(aa_pm.brl(p["stack"]), width - 63, aa_phone_size(12)) yalign .5 xmaximum (width - 63)
            if not compact:
                text ("Desistiu" if p["folded"] else "All-in" if p["stack"] == 0 else "Jogando" if d["phase"] == "betting" and d["turn"] == seat else "+ " + aa_pm.brl(d["awards"][seat]) if d["phase"] == "done" and d["awards"][seat] else "") style "aa_casino_muted" size aa_phone_size(11) xmaximum (width - 16)

screen aa_holdem_table(width, r, readonly=False):
    if not r:
        add aa_casino_art("holdem-art") xysize (150, 101) xalign .5
        text "No Limit" style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17) xalign .5
        text "2 adversários virtuais" style "aa_casino_muted" size aa_phone_size(13) xalign .5
        $ buyin = max(100, aa_casino_parse(aa_casino_scope().get("casino_amount", "5,00")))
        $ small, big = aa_hm.blinds(buyin)
        text ("Blinds " + aa_pm.brl(small) + " / " + aa_pm.brl(big)) style "aa_casino_text" size aa_phone_size(14)
    else:
        $ d = r["data"]
        $ p = d["players"][0]
        $ compact = d["phase"] == "done" and not readonly
        if not compact:
            fixed:
                xysize (width, 23 + aa_phone_pref("text_size", 0))
                text ("Resultado" if d["phase"] == "done" else aa_hm.STREETS[d["street"]]) style "aa_casino_muted" size aa_phone_size(13) yalign .5
                text ("Pote " + aa_pm.brl(aa_hm.pot(d))) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_bank_fit("Pote " + aa_pm.brl(aa_hm.pot(d)), width - 90, aa_phone_size(16)) xalign 1.0 yalign .5
        hbox:
            spacing 8
            for seat in (1, 2):
                use aa_holdem_seat((width - 8) // 2, d, seat, compact)
        hbox:
            spacing 5
            xalign .5
            for i in range(5):
                use aa_holdem_card(d["board"][i] if i < len(d["board"]) else None, min(36 if compact else 44, (width - 20) // 5), empty=i >= len(d["board"]))
        fixed:
            xysize (width, 54 if compact else 73)
            hbox:
                spacing 5
                for card in p["hole"]:
                    use aa_holdem_card(card, 38 if compact else 49)
            vbox:
                xpos (90 if compact else 115)
                yalign .5
                spacing 4
                text ("Você · " + aa_holdem_role(d, 0)) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(14)
                if p["folded"] or d["board"]:
                    text ("Desistiu" if p["folded"] else aa_hm.hand_name(p["hole"] + d["board"])) style "aa_casino_muted" size aa_phone_size(12) xmaximum (width - 115)
                if not compact:
                    text ("Fichas " + aa_pm.brl(p["stack"])) style "aa_casino_text" size aa_bank_fit("Fichas " + aa_pm.brl(p["stack"]), width - 115, aa_phone_size(14))
        if d["phase"] != "done":
            text aa_holdem_note(d) style "aa_casino_muted" size aa_phone_size(12)
        if readonly:
            use aa_holdem_detail(width, d)

screen aa_holdem_controls(width, r, busy):
    $ d = r["data"]
    $ mine = d["phase"] == "betting" and d["turn"] == 0
    $ limits = aa_hm.legal(d, 0)
    if mine:
        text "Sua vez" style "aa_casino_text" size aa_phone_size(13) xalign .5 text_align .5 xmaximum width
        hbox:
            spacing 7
            textbutton "Desistir" style "aa_casino_button" xysize (88, 48) padding (4, 6) text_size aa_phone_size(13) sensitive not busy action Function(aa_casino_act, r["id"], r["revision"], "fold") alt "Desistir da mão"
            textbutton ("Passar" if not limits["to_call"] else "All-in " + aa_pm.brl(limits["call"]) if limits["call"] == d["players"][0]["stack"] else "Pagar " + aa_pm.brl(limits["call"])):
                style "aa_casino_primary"
                xysize (width - 95, 48)
                padding (4, 6)
                text_size aa_bank_fit("Pagar " + aa_pm.brl(limits["call"]), width - 103, aa_phone_size(15))
                sensitive not busy
                action Function(aa_casino_act, r["id"], r["revision"], "call" if limits["to_call"] else "check")
                alt "Pagar ou passar no Hold’em"
        textbutton ("Apostar…" if not d["current"] else "Aumentar…") style "aa_casino_button" xysize (width, 44) padding (8, 6) text_size aa_phone_size(14) sensitive not busy and limits["can_raise"] action Function(aa_holdem_raise) alt "Aumentar aposta no Hold’em"
    else:
        fixed:
            xysize (width, 120 + (aa_phone_size(12) - 12) * 2)
            vbox:
                xsize width
                yalign .5
                spacing 6
                text (aa_hm.STREETS[min(3, d["street"] + 1)] if d["phase"] == "deal" else "Vez de " + aa_hm.NAMES[d["turn"]]) style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(15) xalign .5 text_align .5 xmaximum width
                if not d["players"][0]["stack"] or d["players"][0]["folded"]:
                    text ("All-in" if not d["players"][0]["stack"] else "Desistiu") style "aa_casino_muted" size aa_phone_size(13) xalign .5 text_align .5 xmaximum width
                if aa_hm.can_finish(d):
                    textbutton "Ver resultado" style "aa_casino_primary" xysize (width, 48) text_size aa_phone_size(15) action Function(aa_holdem_finish, r["id"]) alt "Concluir mão de Hold’em"

screen aa_holdem_raise_picker(width, r):
    if r and r["status"] == "active" and r["data"]["turn"] == 0:
        $ d = r["data"]
        $ p = d["players"][0]
        $ limits = aa_hm.legal(d, 0)
        $ draft = aa_casino_scope().get("casino_raise_amount", "0,00")
        $ target = aa_casino_parse(draft)
        $ minimum = min(limits["minimum"], limits["maximum"])
        $ valid = limits["can_raise"] and minimum <= target <= limits["maximum"] and target > d["current"]
        $ raise_input = ScreenVariableInputValue("casino_raise_amount", default=False)
        text ("Apostar" if not d["current"] else "Aumentar") style "aa_phone_title" size aa_phone_size(26)
        text "Total nesta rodada" style "aa_casino_muted" size aa_phone_size(14)
        button:
            style "aa_casino_button"
            xysize (width, 52)
            selected_background aa_phone_round("casino-hover", 14)
            action raise_input.Enable()
            alt "Editar total do aumento"
            hbox:
                spacing 12
                text "R$" style "aa_casino_muted" size aa_phone_size(19)
                input value raise_input action raise_input.Disable() allow "0123456789,." length 18 style "aa_casino_text" size aa_phone_size(21) xmaximum (width - 74) copypaste True
        grid 2 2:
            spacing 8
            for caption, value in (("Mínimo", minimum), ("½ pote", max(minimum, d["current"] + (aa_hm.pot(d) + limits["call"]) // 2)), ("Pote", max(minimum, d["current"] + aa_hm.pot(d) + limits["call"])), ("All-in", limits["maximum"])):
                $ value = min(value, limits["maximum"])
                textbutton caption style "aa_casino_button" xysize ((width - 8) // 2, 44) text_size aa_phone_size(14) selected target == value and caption == "Mínimo" action [raise_input.Disable(), Function(aa_casino_set, raise_amount=aa_casino_bet_text(value), error="")]
        text ("De " + aa_pm.brl(minimum) + " até " + aa_pm.brl(limits["maximum"])) style "aa_casino_muted" size aa_phone_size(13)
        if valid:
            text ("Adicionar " + aa_pm.brl(target - p["bet"])) style "aa_casino_text" size aa_phone_size(18)
            text ("Restante " + aa_pm.brl(limits["maximum"] - target)) style "aa_casino_muted" size aa_phone_size(14)
        textbutton (("All-in · " if target == limits["maximum"] else "Confirmar · ") + aa_pm.brl(target)):
            style "aa_casino_primary"
            xysize (width, 48)
            text_size aa_bank_fit("Confirmar · " + aa_pm.brl(target), width - 24, aa_phone_size(16))
            sensitive valid
            action Function(aa_holdem_confirm, r["id"], r["revision"], draft)
            alt "Confirmar aumento no Hold’em"
        if aa_casino_scope().get("casino_error") or not valid:
            text (aa_casino_scope().get("casino_error") or "Informe um valor entre o mínimo e suas fichas disponíveis.") style "aa_casino_muted" color "#f1b4bf" size aa_phone_size(13)
    else:
        text "A mão avançou. Volte à mesa." style "aa_casino_muted"

screen aa_holdem_detail(width, d):
    null height 6
    text "Potes" style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17)
    for index, side in enumerate(d["pots"]):
        text (("Principal" if index == 0 else "Lateral " + str(index)) + " · " + aa_pm.brl(side["amount"])) style "aa_casino_text" size aa_phone_size(14)
        for seat in side["winners"]:
            text (aa_hm.NAMES[seat] + " · " + aa_pm.brl(side["shares"][seat])) style "aa_casino_muted" size aa_phone_size(13)
    for seat, p in enumerate(d["players"]):
        if p["hole"] and d["showdown"] and not p["folded"]:
            null height 4
            text (p["name"] + " · " + aa_hm.hand_name(p["hole"] + d["board"])) style "aa_casino_text" size aa_phone_size(14)
            hbox:
                spacing 4
                for card in aa_hm.best_five(p["hole"] + d["board"]):
                    use aa_holdem_card(card, min(40, (width - 16) // 5))
    if any(d["refunds"]):
        text "Devoluções" style "aa_casino_text" size aa_phone_size(14)
        for seat, amount in enumerate(d["refunds"]):
            if amount:
                text (aa_hm.NAMES[seat] + " · " + aa_pm.brl(amount)) style "aa_casino_muted" size aa_phone_size(13)
    null height 6
    text "Ações" style "aa_casino_text" font "fonts/Inter-SemiBold.ttf" size aa_phone_size(17)
    for entry in d["log"]:
        text (aa_hm.STREETS[entry["street"]] + " · " + (aa_hm.NAMES[entry["seat"]] + " · " if entry["seat"] is not None else "") + AA_HOLDEM_ACTIONS[entry["action"]] + (" " + aa_pm.brl(entry["amount"]) if entry["amount"] else "")) style "aa_casino_muted" size aa_phone_size(12)
