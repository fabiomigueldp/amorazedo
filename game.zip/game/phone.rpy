# Tela e arte em camadas independentes. Coordenadas medidas no PNG original.
default aa_phone_pov = False
default aa_phone_kind = ""

init python:
    config.overlay_screens.append("aa_phone_pov_hardware")

# The device stays in the hands during transitions and while its app opens.
# Its screen and frame use exactly the geometry of the interactive hub.
screen aa_phone_pov_hardware():
    zorder 7
    if aa_phone_pov and not main_menu:
        $ body_width, body_height = aa_phone_body_size(AA_PHONE_POV_HEIGHT)
        $ screen_x, screen_y, screen_width, screen_height = aa_phone_screen_geometry(body_width, body_height)
        fixed:
            pos AA_PHONE_POV_POSITION
            xysize (body_width, body_height)
            add AlphaMask(Solid("#000000"), aa_phone_screen_mask(screen_width, screen_height)) xpos screen_x ypos screen_y xysize (screen_width, screen_height)
            add aa_phone_shell(body_width, body_height)

transform aa_phone_camera:
    anchor (0.67, 0.0)
    pos (0.67, 0.0)
    zoom 1.25

transform aa_phone_content_enter:
    alpha 0.0
    ease (0.18 if persistent.aa_motion else 0.0) alpha 1.0

screen aa_phone_view(kind):
    zorder 8
    default message_scroll = ui.adjustment()
    default social_draft_tagged = False
    default social_editor = None
    if not renpy.get_screen("aa_phone_hub"):
        $ body_width, body_height = aa_phone_body_size(AA_PHONE_POV_HEIGHT if aa_phone_pov else AA_PHONE_BODY_HEIGHT)
        $ screen_x, screen_y, screen_width, screen_height = aa_phone_screen_geometry(body_width, body_height)
        $ content_scale = float(screen_width - 24) / 292
        $ is_chat = kind in aa_phone_chats or kind in ("conversa", "audio", "audio_resposta")
        $ is_bank = kind in ("emprestimo_pix", "ajuda_v", "jantar_pago")
        $ is_social = kind in aa_pm.SOCIAL_KINDS or kind in ('post_draft', 'post_withdrawn')
        fixed:
            xpos (AA_PHONE_POV_POSITION[0] if aa_phone_pov else 890 if kind in ("visita", "foto", "foto_hesita") else 52)
            ypos (AA_PHONE_POV_POSITION[1] if aa_phone_pov else 18)
            xsize body_width
            ysize body_height
            at aa_phone_content_enter
            add AlphaMask(Solid("#000000" if is_chat else "#0d0d10" if is_social else "#111613" if is_bank else "#151a22"), aa_phone_screen_mask(screen_width, screen_height)) xpos screen_x ypos screen_y xysize (screen_width, screen_height)
            text aa_phone_time() style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size 14 xpos (screen_x + 20) ypos (screen_y + 13)
            add aa_phone_asset("status") xpos (screen_x + screen_width - 74) ypos (screen_y + 15) xysize (58, 15)
            if is_chat:
                $ chat_entry = aa_pm.make_entry(kind, aa_location, aa_state, aa_phone_chats)
                $ chat_entry = dict(chat_entry, at=-1 if kind == "conversa" else aa_world["now"])
                $ chat_thread = aa_pm.threads((chat_entry,), ())[0]
                fixed:
                    xpos screen_x
                    ypos screen_y
                    xysize (screen_width, screen_height)
                    use aa_messages_app(screen_width, screen_height, chat_thread, "", False, "all", None, message_scroll, True)
            elif is_bank:
                fixed:
                    xpos screen_x
                    ypos screen_y
                    xysize (screen_width, screen_height)
                    use aa_bank_story(kind, screen_width, screen_height)
            elif kind in ('post_draft', 'post_withdrawn'):
                fixed:
                    xpos screen_x ypos screen_y xysize (screen_width, screen_height)
                    if kind == 'post_draft':
                        use aa_social_composer(screen_width, screen_height)
                    else:
                        use aa_social_empty_profile(screen_width, screen_height)
            elif is_social:
                fixed:
                    xpos screen_x
                    ypos screen_y
                    xysize (screen_width, screen_height)
                    use aa_social_story_insert(kind, screen_width, screen_height)
            else:
                viewport:
                    xpos (screen_x + 12)
                    ypos (screen_y + 55)
                    xsize 292
                    ysize int((screen_height - 89) / content_scale)
                    at Transform(zoom=content_scale)
                    mousewheel True
                    draggable True
                    use aa_phone_app(kind)
            button:
                xpos (screen_x + (screen_width - 124) // 2)
                ypos (screen_y + screen_height - 28)
                xysize (124, 28)
                padding (0, 0)
                background None
                action [Function(aa_phone_open), Function(aa_phone_go, "home")]
                alt "Abrir início do celular"
                add aa_phone_round("mask") xysize (96, 4) align (.5, .5)
            fixed:
                xpos screen_x ypos screen_y xysize (screen_width, screen_height)
                use aa_phone_incoming_banner(screen_width)
            add aa_phone_shell(body_width, body_height)
