# Tela e arte em camadas independentes. Coordenadas medidas no PNG original.
default aa_phone_pov = False
default aa_phone_kind = ""

transform aa_phone_camera:
    anchor (0.67, 0.0)
    pos (0.67, 0.0)
    zoom 1.25

transform aa_phone_content_enter:
    alpha 0.0
    ease (0.18 if persistent.aa_motion else 0.0) alpha 1.0

screen aa_phone_view(kind):
    zorder 8
    if kind in ("foto", "foto_hesita"):
        $ photo = "post6_foto_hesita" if kind == "foto_hesita" else "images/arte-v2/cg2_foto.png"
        fixed:
            xpos 500
            ypos 130
            xysize (740, 510)
            at aa_phone_content_enter
            add "gui/phone/photo-device.svg"
            text "‹   Fotografias" xpos 26 ypos 23 size 22 color "#f2eeea"
            text "Agora · no restaurante" xpos 438 ypos 27 size 16 color "#bcb9b7"
            button:
                xpos 26
                ypos 64
                xysize (688, 387)
                padding (0, 0)
                action Show("aa_phone_image", asset=photo)
                alt "Ampliar fotografia"
                add Transform(photo, xysize=(688, 387), fit="contain")
            text "Salva no aparelho · não publicada" xpos 26 ypos 461 size 17 color "#c2c8b4"
            text "Toque para ampliar" xpos 546 ypos 461 size 15 color "#bcb9b7"
    elif aa_phone_pov:
        fixed:
            xpos 701
            ypos 78
            xsize 292
            ysize 585
            at aa_phone_content_enter
            if kind in ("publicacao", "restaurante", "conversa"):
                use aa_phone_content(kind)
            else:
                use aa_phone_app(kind)
    else:
        # Inserção editorial: o ambiente permanece identificável; aparelho
        # nativo sem mãos evita transportar roupa/gesto de outra cena.
        fixed:
            xpos (890 if kind == "visita" else 52)
            ypos 26
            xsize 338
            ysize 652
            at aa_phone_content_enter
            add "gui/phone/reading-device.svg"
            text ("CELULAR DE VANESSA" if kind in ("orcamento", "carro") else "CELULAR DE FEKA") xpos 23 ypos 25 size 12 color "#bcb9b7"
            fixed:
                xpos 23
                ypos 38
                xsize 292
                ysize 585
                if kind in ("publicacao", "restaurante", "conversa"):
                    use aa_phone_content(kind)
                else:
                    use aa_phone_app(kind)

screen aa_phone_content(kind):
    vbox:
        xsize 292
        spacing 12
        hbox:
            xfill True
            text (("18:51" if kind == "conversa" else "18:46") if aa_phone_pov else "") size 15 color "#bcb9b7"
            null width 170
            text "72%" size 15 color "#bcb9b7"
        null height 3
        text ("CONVERSA" if kind == "conversa" else "PUBLICAÇÕES") size 16 color "#aaa7a3"
        add Solid("#55545a") xysize (292, 1)
        text "Yasmin" size 23 color "#f2eeea"
        if kind == "conversa":
            text ("Conversa antiga · relida hoje" if not aa_phone_pov and aa_state.get("past_read", False) else "Conversa antiga") size 17 color "#bcb9b7"
            null height 16
            frame:
                xsize 268
                padding (13, 12)
                background Solid("#393940")
                text "Feka, não me espera na saída de novo. Eu não combinei nada com você." size 21 color "#f2eeea" xsize 242
            null height 10
            frame:
                xalign 1.0
                xsize 240
                padding (13, 12)
                background Solid("#454b3c")
                vbox:
                    spacing 8
                    text "Você" size 15 color "#c2c8b4"
                    text "Eu tava só passando." size 21 color "#f2eeea" xsize 214
            null height 10
            text "Nenhuma mensagem nova" size 16 color "#bcb9b7" xalign 0.5
        else:
            text ("Hoje · mais cedo" if kind == "publicacao" else "Hoje · há 8 min") size 17 color "#bcb9b7"
            if kind == "restaurante":
                text "Casa do Pátio" size 21 color "#e9cf9f"
                add Transform("post3_restaurante", xysize=(292, 365), fit="contain")
            else:
                add Transform("post3_jaleco", xysize=(292, 365), fit="contain")
            hbox:
                text ("1 de 2" if kind == "publicacao" else "2 de 2") size 16 color "#bcb9b7"
                null width 146
                text "Publicação" size 15 color "#bcb9b7"
