# Tela e arte em camadas independentes. Coordenadas medidas no PNG original.
default aa_phone_pov = False
default aa_phone_kind = ""

init python:
    config.overlay_screens.append("aa_phone_pov_hardware")

# The device stays in the hands during transitions and while its app opens.
# Its screen and frame use exactly the geometry of the interactive hub.
screen aa_phone_pov_hardware():
    zorder 7
    if aa_phone_pov and not main_menu:
        $ body_width, body_height = aa_phone_body_size(AA_PHONE_POV_HEIGHT)
        $ screen_x, screen_y, screen_width, screen_height = aa_phone_screen_geometry(body_width, body_height)
        fixed:
            pos AA_PHONE_POV_POSITION
            xysize (body_width, body_height)
            add AlphaMask(Solid("#000000"), aa_phone_screen_mask(screen_width, screen_height)) xpos screen_x ypos screen_y xysize (screen_width, screen_height)
            add aa_phone_shell(body_width, body_height)

transform aa_phone_camera:
    anchor (0.67, 0.0)
    pos (0.67, 0.0)
    zoom 1.25

transform aa_phone_content_enter:
    alpha 0.0
    ease (0.18 if persistent.aa_motion else 0.0) alpha 1.0

screen aa_phone_view(kind):
    zorder 8
    default message_scroll = ui.adjustment()
    if not renpy.get_screen("aa_phone_hub"):
        $ body_width, body_height = aa_phone_body_size(AA_PHONE_POV_HEIGHT if aa_phone_pov else AA_PHONE_BODY_HEIGHT)
        $ screen_x, screen_y, screen_width, screen_height = aa_phone_screen_geometry(body_width, body_height)
        $ content_scale = float(screen_width - 24) / 292
        $ is_chat = kind in aa_phone_chats or kind in ("conversa", "audio", "audio_resposta")
        $ is_bank = kind in ("emprestimo_pix", "ajuda_v", "jantar_pago")
        fixed:
            xpos (AA_PHONE_POV_POSITION[0] if aa_phone_pov else 890 if kind in ("visita", "foto", "foto_hesita") else 52)
            ypos (AA_PHONE_POV_POSITION[1] if aa_phone_pov else 18)
            xsize body_width
            ysize body_height
            at aa_phone_content_enter
            add AlphaMask(Solid("#000000" if is_chat else "#111613" if is_bank else "#151a22"), aa_phone_screen_mask(screen_width, screen_height)) xpos screen_x ypos screen_y xysize (screen_width, screen_height)
            text aa_phone_time() style "aa_hub_text" font "fonts/Inter-SemiBold.ttf" size 14 xpos (screen_x + 20) ypos (screen_y + 13)
            add aa_phone_asset("status") xpos (screen_x + screen_width - 74) ypos (screen_y + 15) xysize (58, 15)
            if is_chat:
                $ chat_entry = aa_pm.make_entry(kind, aa_location, aa_state, aa_phone_chats)
                $ chat_entry = dict(chat_entry, at=-1 if kind == "conversa" else aa_world["now"])
                $ chat_thread = aa_pm.threads((chat_entry,), ())[0]
                fixed:
                    xpos screen_x
                    ypos screen_y
                    xysize (screen_width, screen_height)
                    use aa_messages_app(screen_width, screen_height, chat_thread, "", False, "all", None, message_scroll, True)
            elif is_bank:
                fixed:
                    xpos screen_x
                    ypos screen_y
                    xysize (screen_width, screen_height)
                    use aa_bank_story(kind, screen_width, screen_height)
            else:
                viewport:
                    xpos (screen_x + 12)
                    ypos (screen_y + 55)
                    xsize 292
                    ysize int((screen_height - 89) / content_scale)
                    at Transform(zoom=content_scale)
                    mousewheel True
                    draggable True
                    if kind in ("publicacao", "restaurante", "conversa"):
                        use aa_phone_content(kind)
                    else:
                        use aa_phone_app(kind)
            button:
                xpos (screen_x + (screen_width - 124) // 2)
                ypos (screen_y + screen_height - 28)
                xysize (124, 28)
                padding (0, 0)
                background None
                action [Function(aa_phone_open), Function(aa_phone_go, "home")]
                alt "Abrir início do celular"
                add aa_phone_round("mask") xysize (96, 4) align (.5, .5)
            add aa_phone_shell(body_width, body_height)

screen aa_phone_content(kind):
    style_prefix "aa_insert"
    vbox:
        xsize 292
        spacing 12
        text ("CONVERSAS" if kind == "conversa" else "MOMENTOS") style "aa_hub_muted" size 13 kerning 1.5
        use aa_phone_rule(292)
        text "Yasmin" style "aa_phone_title" size 26
        if kind == "conversa":
            text ("Conversa antiga · relida hoje" if not aa_phone_pov and aa_state.get("past_read", False) else "Conversa antiga") size 17 color "#bcb9b7"
            null height 16
            use aa_phone_message("Feka, não me espera na saída de novo. Eu não combinei nada com você.", False, 268, "Yasmin", True)
            null height 10
            use aa_phone_message("Eu tava só passando.", True, 240, "Você", True)
            null height 10
            text "Nenhuma mensagem nova" size 16 color "#bcb9b7" xalign 0.5
        else:
            text ("Hoje · mais cedo" if kind == "publicacao" else "Hoje · há 8 min") size 17 color "#bcb9b7"
            if kind == "restaurante":
                text "Casa do Pátio" size 21 color "#e9cf9f"
                add Transform("post3_restaurante", xysize=(292, 365), fit="contain")
            else:
                add Transform("post3_jaleco", xysize=(292, 365), fit="contain")
            hbox:
                text ("1 de 2" if kind == "publicacao" else "2 de 2") size 16 color "#bcb9b7"
                null width 146
                text "Publicação" size 15 color "#bcb9b7"
