# Gerado por tools/build_francisquinho.py. Fundos disponíveis; sem alterar capítulos.
image bg_francisquinho_fachada = Transform("images/francisquinho-v1/bg_francisquinho_fachada.png", xysize=(1280, 720), fit="cover")
image bg_francisquinho_salao = Transform("images/francisquinho-v1/bg_francisquinho_salao.png", xysize=(1280, 720), fit="cover")
image bg_francisquinho_balcao = Transform("images/francisquinho-v1/bg_francisquinho_balcao.png", xysize=(1280, 720), fit="cover")
image bg_francisquinho_mesa = Transform("images/francisquinho-v1/bg_francisquinho_mesa.png", xysize=(1280, 720), fit="cover")
image bg_francisquinho_fachada_noite = Transform("images/francisquinho-v1/bg_francisquinho_fachada_noite.png", xysize=(1280, 720), fit="cover")
