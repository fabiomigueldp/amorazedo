"""Public utility entry point; preserve existing imports and saved games."""
from phone_calculator import calculator
