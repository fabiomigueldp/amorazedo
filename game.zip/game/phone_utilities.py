"""Small local utilities for the handset. No network or narrative side effects."""
from decimal import Decimal, InvalidOperation, localcontext


def calculator(state, key):
    display, accumulator, operator, fresh = state
    def fmt(value):
        if not value.is_finite() or abs(value) > Decimal('1e15'):
            return "Erro"
        text = format(value, '.10f').rstrip('0').rstrip('.')
        return text if text not in ('', '-0') else '0'
    def calculate(a, op, b):
        if op == '+': return a + b
        if op == '−': return a - b
        if op == '×': return a * b
        if op == '÷': return a / b
        return b
    if key == 'AC':
        return ('0', None, None, True)
    if display == 'Erro':
        display, accumulator, operator, fresh = '0', None, None, True
    if key == '⌫':
        shortened = display[:-1]
        return (shortened if shortened not in ('', '-') else '0', accumulator, operator, False)
    if key in tuple('0123456789'):
        display = key if fresh or display == '0' else (display + key if len(display) < 15 else display)
        return (display, accumulator, operator, False)
    if key == ',':
        display = '0.' if fresh else display if '.' in display else display + '.'
        return (display, accumulator, operator, False)
    try:
        with localcontext() as context:
            context.prec = 24
            value = Decimal(display)
            if key in ('±', '%'):
                return (fmt(-value if key == '±' else value / 100), accumulator, operator, fresh)
            if key in ('+', '−', '×', '÷', '='):
                if operator and accumulator is not None and not fresh:
                    value = calculate(Decimal(accumulator), operator, value)
                result = fmt(value)
                return (result, None if key == '=' or result == 'Erro' else result,
                        None if key == '=' or result == 'Erro' else key, True)
    except (InvalidOperation, ArithmeticError):
        return ('Erro', None, None, True)
    return (display, accumulator, operator, fresh)
