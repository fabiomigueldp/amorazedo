# Dynamic Island of the fictional handset. Providers expose current activities;
# the island owns presentation and never advances the story while rendering.
default aa_island_expanded_id = None

init python:
    AA_ISLAND_PROVIDERS = {}

    def aa_island_register(ident, snapshot, action, priority=0):
        """Register one ongoing activity without storing callbacks in a save.

        snapshot() returns None, or a dict with title, subtitle, art, accent,
        trailing_asset, progress, elapsed, remaining and up to four controls.
        Each control is (command, accessible label, icon path). action(command)
        handles open and the advertised controls. Highest priority appears first.
        """
        if not ident or ident in AA_ISLAND_PROVIDERS or not callable(snapshot) or not callable(action):
            raise ValueError("Invalid or duplicate Dynamic Island provider: %r" % ident)
        AA_ISLAND_PROVIDERS[ident] = (snapshot, action, int(priority))

    def aa_island_unregister(ident):
        AA_ISLAND_PROVIDERS.pop(ident, None)

    def aa_island_activities():
        activities = []
        for ident, (snapshot, _, priority) in AA_ISLAND_PROVIDERS.items():
            value = snapshot()
            if not value:
                continue
            activity = dict(value)
            activity["id"] = ident
            activity["priority"] = priority
            activity.setdefault("title", "Atividade")
            activity.setdefault("subtitle", "")
            activity.setdefault("art", "gui/phone/media/wave.svg")
            activity.setdefault("accent", "#d5b3f5")
            activity.setdefault("trailing_asset", activity["art"])
            activity.setdefault("controls", ())
            activities.append(activity)
        return tuple(sorted(activities, key=lambda item: (-item["priority"], item["id"])))[:3]

    def aa_island_geometry():
        hub = renpy.get_screen("aa_phone_hub")
        if hub:
            if hub.scope.get("photo_zoom") or renpy.get_screen("aa_phone_image"):
                return None
            height = AA_PHONE_POV_HEIGHT if aa_phone_pov else AA_PHONE_BODY_HEIGHT
            width = aa_phone_body_size(height)[0]
            return (AA_PHONE_POV_POSITION[0] if aa_phone_pov else aa_phone_geometry()[0],
                    AA_PHONE_POV_POSITION[1] if aa_phone_pov else 18, width, height)
        view = renpy.get_screen("aa_phone_view")
        if view:
            height = AA_PHONE_POV_HEIGHT if aa_phone_pov else AA_PHONE_BODY_HEIGHT
            width = aa_phone_body_size(height)[0]
            kind = view.scope.get("kind", "")
            x = AA_PHONE_POV_POSITION[0] if aa_phone_pov else 890 if kind in ("visita", "foto", "foto_hesita") else 52
            return (x, AA_PHONE_POV_POSITION[1] if aa_phone_pov else 18, width, height)
        if aa_phone_pov and not main_menu:
            width, height = aa_phone_body_size(AA_PHONE_POV_HEIGHT)
            return (AA_PHONE_POV_POSITION[0], AA_PHONE_POV_POSITION[1], width, height)
        return None

    def aa_island_activity(ident):
        return next((item for item in aa_island_activities() if item["id"] == ident), None)

    def aa_island_expand(ident):
        global aa_island_expanded_id
        if aa_island_activity(ident):
            aa_island_expanded_id = ident
            renpy.restart_interaction()

    def aa_island_collapse():
        global aa_island_expanded_id
        aa_island_expanded_id = None
        renpy.restart_interaction()

    def aa_island_dispatch(ident, command):
        global aa_island_expanded_id
        activity = aa_island_activity(ident)
        if not activity or ident not in AA_ISLAND_PROVIDERS:
            return
        allowed = {control[0] for control in activity["controls"]} | {"open"}
        if command not in allowed:
            return
        aa_island_expanded_id = None if command == "open" else aa_island_expanded_id
        AA_ISLAND_PROVIDERS[ident][1](command)
        renpy.restart_interaction()

    def aa_island_progress(activity):
        return max(0.0, min(1.0, float(activity.get("progress") or 0.0)))

    def aa_island_caption(value, width, size):
        # Expanded titles get one line; the full title remains in the button label.
        limit = max(10, int(width / (size * 0.56)))
        return value if len(value) <= limit else value[:limit - 1].rstrip() + "…"

    def aa_island_guard():
        global aa_island_expanded_id
        if aa_island_expanded_id and (not aa_island_geometry() or not aa_island_activity(aa_island_expanded_id)):
            aa_island_expanded_id = None

    def aa_island_after_load():
        global aa_island_expanded_id
        aa_island_expanded_id = None

    def aa_island_media_snapshot():
        item = aa_media_item()
        if not aa_media_available(item) or aa_media_state.error:
            return None
        position = aa_media_position(item)
        if not aa_media_state.playing and item["id"] in aa_media_state.completed:
            return None
        focused = aa_media_has_focus()
        return {
            "title": item["title"],
            "compact_alt": "Abrir Em reprodução",
            "subtitle": "Reproduzindo" if focused else "Pausado" if not aa_media_state.playing else aa_media_interruption(),
            "kind_label": "PODCASTS" if item["kind"] == "podcast" else "MÚSICA",
            "art": item["art"],
            "accent": "#d5b3f5" if item["kind"] == "podcast" else "#ffadb9",
            "trailing_asset": "gui/phone/media/wave.svg" if focused else "gui/phone/media/pause.svg",
            "waveform": focused,
            "progress": position / item["duration"] if item["duration"] else 0.0,
            "elapsed": aa_media_model.timestamp(position),
            "remaining": "−" + aa_media_model.timestamp(max(0, item["duration"] - position)),
            "controls": (
                ("back15", "Voltar 15 segundos", "gui/phone/media/back15.svg"),
                ("toggle", "Pausar" if aa_media_state.playing else "Reproduzir", "gui/phone/media/pause.svg" if aa_media_state.playing else "gui/phone/media/play.svg"),
                ("forward30", "Avançar 30 segundos", "gui/phone/media/forward30.svg"),
                ("stop", "Encerrar reprodução", "gui/phone/media/stop.svg"),
            ),
        }

    def aa_island_media_action(command):
        if command == "open":
            aa_media_open()
        elif command == "toggle":
            aa_media_toggle()
        elif command == "back15":
            aa_media_skip(-15)
        elif command == "forward30":
            aa_media_skip(30)
        elif command == "stop":
            aa_media_stop()

    config.interact_callbacks.append(aa_island_guard)
    config.after_load_callbacks.append(aa_island_after_load)

init 7 python:
    aa_island_register("media", aa_island_media_snapshot, aa_island_media_action, priority=100)
    config.overlay_screens.append("aa_dynamic_island")

transform aa_island_bloom:
    alpha 0.0
    zoom (0.94 if persistent.aa_motion else 1.0)
    easeout (0.20 if persistent.aa_motion else 0.0) alpha 1.0 zoom 1.0

transform aa_island_wave_bar(delay=0.0):
    yanchor 0.5
    pause delay
    block:
        easein 0.22 yzoom 0.45
        easeout 0.28 yzoom 1.0
        pause 0.12
        repeat

screen aa_island_sensor(body_height):
    $ scale = float(body_height) / AA_PHONE_DEVICE["canvas"][1]
    $ crop = (381, 83, 165, 66)
    add Transform(Crop(crop, aa_phone_asset("shell")), xysize=(int(crop[2] * scale), int(crop[3] * scale))) xpos int(crop[0] * scale) ypos int(crop[1] * scale)

screen aa_island_wave(active, accent, size=18):
    if active and persistent.aa_motion:
        hbox:
            spacing 2
            for index, height in enumerate((6, 13, 9, 16, 7)):
                add Solid(accent) xysize (2, height) yalign 0.5 at aa_island_wave_bar(index * 0.10)
    else:
        add "gui/phone/media/wave.svg" xysize (size, 13)

screen aa_island_compact_button(activity, x, y, width, height, icon_x, trailing=False):
    button:
        xpos x ypos y xysize (width, height)
        padding (0, 0)
        background None
        action Function(aa_island_dispatch, activity["id"], "open")
        alternate Function(aa_island_expand, activity["id"])
        alternate_keysym "shift_K_RETURN"
        alt activity.get("compact_alt", activity["title"] + ", " + activity["subtitle"] + ". Toque para abrir; mantenha pressionado para expandir")
        fixed:
            xysize (width, height)
            add activity["art"] xpos icon_x yalign 0.5 xysize (18, 18)
            if trailing:
                if activity.get("waveform"):
                    fixed:
                        xpos (width - 30) yalign 0.5 xysize (20, 18)
                        use aa_island_wave(True, activity["accent"])
                else:
                    add activity["trailing_asset"] xpos (width - 29) yalign 0.5 xysize (17, 17)

screen aa_island_compact(activities, body_width, body_height):
    $ scale = float(body_height) / AA_PHONE_BODY_HEIGHT
    $ center = body_width // 2
    $ top = int(27 * scale)
    $ height = int(31 * scale)
    if len(activities) == 1:
        $ width = int(152 * scale)
        $ left = center - width // 2
        add aa_phone_round("island", int(18 * scale)) xpos left ypos top xysize (width, height)
        use aa_island_sensor(body_height)
        use aa_island_compact_button(activities[0], left, top, width, height, int(9 * scale), True)
    else:
        $ main_width = int(106 * scale)
        $ main_left = center - main_width // 2
        $ side = int(31 * scale)
        add aa_phone_round("island", int(18 * scale)) xpos main_left ypos top xysize (main_width, height)
        for index, activity in enumerate(activities[1:]):
            $ satellite_x = center + int(65 * scale) if index == 0 else center - int(96 * scale)
            add aa_phone_round("island", int(18 * scale)) xpos satellite_x ypos top xysize (side, height)
        use aa_island_sensor(body_height)
        use aa_island_compact_button(activities[0], main_left, top, main_width, height, int(7 * scale))
        for index, activity in enumerate(activities[1:]):
            $ satellite_x = center + int(65 * scale) if index == 0 else center - int(96 * scale)
            use aa_island_compact_button(activity, satellite_x, top, side, height, int(7 * scale))

screen aa_island_expanded(activity, body_width, body_height):
    $ scale = float(body_height) / AA_PHONE_BODY_HEIGHT
    $ left = int(18 * scale)
    $ top = int(26 * scale)
    $ width = body_width - 2 * left
    $ height = int((155 if activity["controls"] else 115 if "progress" in activity else 95) * scale)
    $ title_size = min(16, aa_phone_size(13))
    fixed:
        xysize (body_width, body_height)
        at aa_island_bloom
        add aa_phone_round("island", int(31 * scale)) xpos left ypos top xysize (width, height)
        use aa_island_sensor(body_height)
        text activity.get("kind_label", "ATIVIDADE"):
            font "fonts/Inter-SemiBold.ttf"
            size int(10 * scale)
            color activity["accent"]
            xpos (left + int(22 * scale)) ypos (top + int(16 * scale))
        button:
            xpos (left + int(17 * scale)) ypos (top + int(37 * scale))
            xysize (width - int(34 * scale), int(49 * scale))
            padding (0, 0)
            background None
            action Function(aa_island_dispatch, activity["id"], "open")
            alt ("Abrir " + activity["title"])
            fixed:
                xysize (width - int(34 * scale), int(49 * scale))
                add activity["art"] xpos 0 yalign 0.5 xysize (39, 39)
                text aa_island_caption(activity["title"], width - int(80 * scale), title_size):
                    style "aa_hub_text"
                    font "fonts/Inter-SemiBold.ttf"
                    size title_size
                    xpos int(50 * scale) ypos int(3 * scale)
                    xmaximum (width - int(80 * scale))
                    layout "subtitle"
                text activity["subtitle"]:
                    style "aa_hub_muted"
                    size min(14, aa_phone_size(11))
                    xpos int(50 * scale) ypos int(27 * scale)
                    xmaximum (width - int(80 * scale))
        if "progress" in activity:
            $ bar_left = left + int(22 * scale)
            $ bar_width = width - int(44 * scale)
            add aa_phone_round("island-control", 2) xpos bar_left ypos (top + int(91 * scale)) xysize (bar_width, 3)
            if aa_island_progress(activity) > 0:
                add Solid(activity["accent"]) xpos bar_left ypos (top + int(91 * scale)) xysize (max(2, int(bar_width * aa_island_progress(activity))), 3)
            text activity.get("elapsed", "") style "aa_hub_muted" size 10 xpos bar_left ypos (top + int(97 * scale))
            text activity.get("remaining", "") style "aa_hub_muted" size 10 xpos (bar_left + bar_width) xanchor 1.0 ypos (top + int(97 * scale))
        $ controls = activity["controls"][:4]
        if controls:
            $ control_width = int(44 * scale)
            $ gap = int((18 if len(controls) == 4 else 29) * scale)
            $ row_width = len(controls) * control_width + (len(controls) - 1) * gap
            $ row_left = (body_width - row_width) // 2
            for index, (command, label, icon) in enumerate(controls):
                button:
                    xpos (row_left + index * (control_width + gap))
                    ypos (top + int(111 * scale))
                    xysize (control_width, control_width)
                    padding (0, 0)
                    background aa_phone_round("island-control", 23)
                    hover_background aa_phone_round("island-control-hover", 23)
                    action Function(aa_island_dispatch, activity["id"], command)
                    alt label
                    add icon xysize (24, 24) align (0.5, 0.5)

screen aa_dynamic_island():
    zorder 151
    if not main_menu and not renpy.get_screen("aa_phone_image"):
        $ geometry = aa_island_geometry()
        $ activities = aa_island_activities() if geometry else ()
        if geometry and activities:
            $ x, y, body_width, body_height = geometry
            $ expanded = next((item for item in activities if item["id"] == aa_island_expanded_id), None)
            if expanded:
                button:
                    xfill True yfill True
                    background None
                    action Function(aa_island_collapse)
                    alt "Recolher Dynamic Island"
                fixed:
                    xpos x ypos y xysize (body_width, body_height)
                    use aa_island_expanded(expanded, body_width, body_height)
                key "game_menu" action Function(aa_island_collapse)
            else:
                fixed:
                    xpos x ypos y xysize (body_width, body_height)
                    use aa_island_compact(activities, body_width, body_height)
