"""Offline calculator: decimal arithmetic and save-compatible immutable state."""
from decimal import Decimal, localcontext
import math
import re
import random

OPS = ('+', '−', '×', '÷', '^', 'ʸ√')
FUNCTIONS = ('sin', 'cos', 'tan', 'sinh', 'cosh', 'tanh', 'asin', 'acos', 'atan', 'asinh', 'acosh', 'atanh', 'ln', 'log', 'log₂', '√', '∛')
SYMBOLS = OPS + FUNCTIONS + ('(', ')')
EMPTY = ('0', None, None, True)


def number(value):
    value = Decimal(str(value))
    if not value.is_finite() or abs(value) >= Decimal('1e100'):
        raise ArithmeticError('Out of range')
    if value == 0: return '0'
    with localcontext() as context:
        context.prec = 15
        value = +value
    if abs(value) >= Decimal('1e12') or abs(value) < Decimal('1e-9'):
        mantissa, exponent = format(value, '.12E').split('E')
        return mantissa.rstrip('0').rstrip('.') + 'e' + exponent
    result = format(value, 'f')
    return result.rstrip('0').rstrip('.') if '.' in result else result


def localized(value):
    if value == 'Erro': return value
    if 'e' in value.lower(): return value.replace('.', ',')
    sign = '−' if value.startswith('-') else ''
    parts = value.lstrip('-').split('.')
    whole = parts[0]
    groups = [whole[max(0, i-3):i] for i in range(len(whole), 0, -3)]
    return sign + '.'.join(reversed(groups)) + (',' + parts[1] if len(parts) > 1 else '')


def binary(a, op, b):
    if op == '+': return a + b
    if op == '−': return a - b
    if op == '×': return a * b
    if op == '÷': return a / b
    if op == '^':
        if abs(b) > 10000: raise ArithmeticError('Exponent too large')
        return a ** b
    if op == 'ʸ√': return a ** (1 / b)
    raise ValueError(op)


def unary(key, value, radians=False):
    if key == '√': return value.sqrt()
    if key == '∛': return Decimal(str(math.copysign(abs(float(value)) ** (1 / 3), float(value))))
    if key == 'ln': return value.ln()
    if key == 'log': return value.log10()
    if key == 'log₂': return value.ln() / Decimal(2).ln()
    angle = float(value) if radians or key not in ('sin', 'cos', 'tan') else math.radians(float(value))
    if key == 'tan' and abs(math.cos(angle)) < 1e-14: raise ValueError('Tangent domain')
    result = getattr(math, key)(angle)
    if key in ('asin', 'acos', 'atan') and not radians: result = math.degrees(result)
    return Decimal(str(0 if abs(result) < 1e-14 else result))


def evaluate(tokens, radians=False):
    """Bounded parser with standard precedence; never evaluates Python code."""
    tokens = tuple(tokens)
    if not tokens or len(tokens) > 128: raise ValueError('Expression length')
    pos = 0
    def atom():
        nonlocal pos
        token = tokens[pos]
        pos += 1
        if token in FUNCTIONS: return unary(token, atom(), radians)
        if token == '(':
            value = expr(0)
            if pos >= len(tokens) or tokens[pos] != ')': raise ValueError('Parentheses')
            pos += 1
            return value
        return Decimal(token)
    def expr(minimum):
        nonlocal pos
        value = atom()
        while pos < len(tokens) and tokens[pos] in OPS:
            op = tokens[pos]
            precedence = {'+': 1, '−': 1, '×': 2, '÷': 2, '^': 3, 'ʸ√': 3}[op]
            if precedence < minimum: break
            pos += 1
            value = binary(value, op, expr(precedence if op == '^' else precedence + 1))
        return value
    with localcontext() as ctx:
        ctx.prec = 28
        result = expr(0)
        if pos != len(tokens): raise ValueError('Unexpected token')
        return result


def metadata(state):
    if len(state) > 4: return dict(state[4])
    display, accumulator, operator, fresh = state
    return dict(tokens=(str(accumulator), operator) if operator and accumulator is not None else (),
                done=False, equation='', repeat=None, percent=None, memory='0', radians=False)


def expression(state):
    if state[0] == 'Erro': return 'Erro'
    meta = metadata(state)
    if meta.get('done'): return meta.get('equation', '')
    tokens = list(meta['tokens'])
    text = ''.join(localized(t) if t not in SYMBOLS else t for t in tokens)
    if not state[3] or not tokens: text += meta.get('label') or localized(state[0])
    return text


def calculator(state, key):
    """First four fields preserve existing save and caller compatibility."""
    display, accumulator, operator, fresh = state[:4]
    meta = metadata(state)
    tokens = list(meta['tokens'])
    def pack():
        meta['tokens'] = tuple(tokens)
        return (display, accumulator, operator, fresh, meta)
    if key == 'AC':
        return ('0', None, None, True, dict(tokens=(), done=False, equation='', repeat=None,
                percent=None, memory=meta.get('memory', '0'), radians=meta.get('radians', False)))
    if display == 'Erro': return calculator(calculator(state, 'AC'), key)
    key = {'.': ',', '-': '−', '*': '×', '/': '÷', 'xʸ': '^'}.get(key, key)
    try:
        with localcontext() as ctx:
            ctx.prec = 28
            if key in ('mc', 'm+', 'm−', 'mr', 'Rad', 'Deg', '2nd'):
                if key == 'mc': meta['memory'] = '0'
                elif key == 'm+': meta['memory'] = number(Decimal(meta.get('memory', '0')) + Decimal(display))
                elif key == 'm−': meta['memory'] = number(Decimal(meta.get('memory', '0')) - Decimal(display))
                elif key == 'mr':
                    if meta.get('done'): tokens, operator, accumulator = [], None, None
                    display, fresh = meta.get('memory', '0'), False
                    meta.update(done=False, label=None)
                elif key == '2nd': meta['second'] = not meta.get('second', False)
                else: meta['radians'] = key == 'Rad'
                return pack()
            if key in tuple('0123456789') + (',',):
                if meta.get('done'): tokens, operator, accumulator, fresh = [], None, None, True
                meta.update(done=False, equation='', percent=None, label=None)
                if key == ',': display = '0.' if fresh else display if '.' in display or 'e' in display else display + '.'
                elif fresh or display == '0': display = key
                elif display == '-0': display = '-' + key
                elif len(display.replace('-', '').replace('.', '')) < 15: display += key
                fresh = False
            elif key == 'C':
                display, fresh = '0', False
                meta.update(done=False, percent=None, label=None)
            elif key == '⌫':
                if meta.get('done'): tokens, operator, accumulator = [], None, None
                elif fresh and tokens:
                    tokens.pop()
                    display = tokens.pop() if tokens and tokens[-1] not in SYMBOLS else '0'
                    fresh = False
                    meta.update(done=False, percent=None, label=None)
                    return pack()
                display = display[:-1] if 'e' not in display else '0'
                if display in ('', '-'): display = '0'
                fresh = False
                meta.update(done=False, percent=None, label=None)
            elif key == '(':
                if meta.get('done'): tokens = []
                elif not fresh: tokens += [display, '×']
                tokens.append('(')
                display, fresh = '0', True
                meta.update(done=False, percent=None, label=None)
            elif key == ')':
                if tokens.count('(') > tokens.count(')'):
                    if not fresh or tokens[-1] in OPS: tokens.append(display)
                    tokens.append(')')
                    fresh = True
            elif key in OPS:
                if meta.get('done'): tokens = [display]
                elif not fresh: tokens.append(display)
                elif not tokens: tokens.append(display)
                elif tokens[-1] in OPS: tokens.pop()
                if tokens[-1] == '(': tokens.append(display)
                tokens.append(key)
                operator, accumulator, fresh = key, display, True
                meta.update(done=False, equation='', percent=None, label=None)
            elif key == '=':
                pretty = expression(pack())
                if meta.get('repeat') and (meta.get('done') or not tokens):
                    op, operand, percentage = meta['repeat']
                    rhs = Decimal(operand)
                    if percentage is not None:
                        rhs = Decimal(display) * Decimal(percentage) / 100 if op in ('+', '−') else Decimal(percentage) / 100
                    calculation = [display, op, number(rhs)]
                    pretty = localized(display) + op + (localized(percentage) + '%' if percentage is not None else localized(operand))
                else:
                    calculation = tokens + ([] if fresh and tokens and tokens[-1] == ')' else [display])
                    calculation += [')'] * (calculation.count('(') - calculation.count(')'))
                    meta['repeat'] = (calculation[-2], calculation[-1], meta.get('percent')) if len(calculation) >= 3 and calculation[-2] in OPS else None
                result = number(evaluate(calculation, meta.get('radians', False)))
                pretty += ')' * max(0, pretty.count('(') - pretty.count(')'))
                if pretty and pretty[-1] in OPS: pretty += localized(display)
                meta.update(equation=pretty, done=True, percent=None, label=None)
                display, tokens, operator, accumulator, fresh = result, [], None, None, True
            elif key == '±':
                display = display[1:] if display.startswith('-') else '-' + display
                fresh = False
                meta.update(done=False, label=None)
            elif key == '%':
                percentage = Decimal(display)
                value = percentage / 100
                if tokens and tokens[-1] in ('+', '−'): value *= evaluate(tokens[:-1])
                display, fresh = number(value), False
                meta.update(percent=str(percentage), done=False, label=localized(str(percentage)) + '%')
            elif key == 'EE':
                tokens += [display, '×', '10', '^']
                fresh = True
                meta.update(done=False, label=None)
            elif key in FUNCTIONS and fresh and not meta.get('done'):
                tokens += [key, '(']
                display = '0'
                meta.update(done=False, label=None)
            else:
                value = Decimal(display)
                original = localized(display)
                if key in FUNCTIONS: value = unary(key, value, meta.get('radians', False))
                elif key == 'Rand': value = Decimal(str(random.random()))
                elif key == 'π': value = Decimal(str(math.pi))
                elif key == 'e': value = Decimal(str(math.e))
                elif key == 'x²': value *= value
                elif key == 'x³': value = value ** 3
                elif key == '1/x': value = 1 / value
                elif key == 'eˣ': value = value.exp()
                elif key == '10ˣ': value = binary(Decimal(10), '^', value)
                elif key == '2ˣ': value = binary(Decimal(2), '^', value)
                elif key == 'x!':
                    if value != int(value) or not 0 <= value <= 69: raise ValueError('Factorial domain')
                    value = Decimal(math.factorial(int(value)))
                else: return pack()
                if meta.get('done'): tokens, operator = [], None
                display, fresh = number(value), False
                label = (key + '(' + original + ')') if key in FUNCTIONS else original + ('²' if key == 'x²' else '³' if key == 'x³' else '!') if key in ('x²', 'x³', 'x!') else None
                meta.update(done=False, percent=None, label=label)
            if len(tokens) > 100: raise ValueError('Expression length')
            return pack()
    except (ArithmeticError, ValueError, IndexError):
        return ('Erro', None, None, True, dict(meta, tokens=(), done=False, repeat=None, percent=None, label=None))


UNITS = {
    'Comprimento': (('m', '1', '0'), ('km', '1000', '0'), ('cm', '.01', '0'), ('mm', '.001', '0'), ('mi', '1609.344', '0'), ('ft', '.3048', '0'), ('in', '.0254', '0')),
    'Massa': (('kg', '1', '0'), ('g', '.001', '0'), ('mg', '.000001', '0'), ('lb', '.45359237', '0'), ('oz', '.028349523125', '0')),
    'Temperatura': (('°C', '1', '273.15'), ('°F', str(Decimal(5) / 9), '255.3722222222222222222222222'), ('K', '1', '0')),
    'Volume': (('L', '1', '0'), ('mL', '.001', '0'), ('m³', '1000', '0'), ('gal (US)', '3.785411784', '0')),
    'Área': (('m²', '1', '0'), ('km²', '1000000', '0'), ('ha', '10000', '0'), ('ft²', '.09290304', '0')),
    'Tempo': (('s', '1', '0'), ('min', '60', '0'), ('h', '3600', '0'), ('dia', '86400', '0')),
    'Velocidade': (('m/s', '1', '0'), ('km/h', str(Decimal(1) / Decimal('3.6')), '0'), ('mph', '.44704', '0')),
}


def convert(value, category, source, target):
    try:
        units = {u[0]: (Decimal(u[1]), Decimal(u[2])) for u in UNITS[category]}
        a, b = units[source], units[target]
        return number((Decimal(value) * a[0] + a[1] - b[1]) / b[0])
    except (ArithmeticError, KeyError, ValueError): return 'Erro'


def math_note(text):
    source = text.replace(' ', '').replace(',', '.').replace('*', '×').replace('/', '÷').replace('-', '−').rstrip('=')
    if not source or len(source) > 256: return 'Erro'
    raw = re.findall(r'\d+(?:\.\d*)?|\.\d+|[+−×÷^()]', source)
    if ''.join(raw) != source: return 'Erro'
    tokens = []
    for token in raw:
        if tokens and tokens[-1] == 'unary': tokens[-1] = '-' + token
        elif token == '−' and (not tokens or tokens[-1] in OPS + ('(',)): tokens.append('unary')
        else: tokens.append(token)
    try: return number(evaluate(tokens))
    except (ArithmeticError, ValueError, IndexError): return 'Erro'
