# Mensagens dos capítulos usam o mesmo arquivo consultável do calendário.
init python:
    def aa_chapter_message(record):
        global aa_world, aa_phone_memory
        from copy import deepcopy
        import phone_memory
        if record.get('outgoing'):
            entry = dict(id=record['id'], kind='chapter_message', section='messages',
                title=record.get('sender', 'Vanessa'), subtitle='', location=aa_location,
                messages=((True, record['body']),), paragraphs=(), image=None, at=aa_world['now'],
                after_message=aa_world['messages'][-1]['id'] if aa_world['messages'] else None)
            aa_phone_memory = phone_memory.remember(aa_phone_memory, entry)
        else:
            updated = deepcopy(aa_world)
            aa_fm.message(updated, record['id'], record.get('sender', 'Vanessa'), record['body'])
            # A frase na narração já mostra Feka lendo esta mensagem.
            aa_world = aa_fm.read(updated, record['id'])

    def aa_chapter_phone_action(action):
        global aa_phone_memory
        if action == 'withdraw_post':
            aa_phone_memory = tuple(
                dict(entry, title='Fotografia guardada', subtitle='Publicação retirada',
                    paragraphs=('Publicação retirada. Fotografia conservada no aparelho.',))
                if entry['id'] == 'publicacao_feka' else entry for entry in aa_phone_memory)
