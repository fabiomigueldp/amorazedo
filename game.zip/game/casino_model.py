"""Mesa: saved, transactional games using the campaign's fictional money.

All amounts are integer cents. Returns include the stake. Randomness is injected
by the caller (renpy.random in game), and never consumed while drawing a screen.
"""
from copy import deepcopy
from math import comb
import re
import finance_model as finance

GAMES = {"blackjack": "Blackjack", "roulette": "Roleta", "slots": "Caça-níqueis",
         "dice": "Dados", "mines": "Minas"}
RED = frozenset((1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36))
WHEEL = (0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23,
         10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26)
REEL = ("cherry",) * 6 + ("lemon",) * 5 + ("bar",) * 4 + ("bell",) * 3 + ("seven",) * 2
SLOT_PAY = {"cherry": 4, "lemon": 8, "bar": 12, "bell": 30, "seven": 100}


class CasinoError(ValueError):
    pass


def state(world):
    return world.get("casino", dict(version=1, sequence=0, round=None, history=[],
                                    total_staked=0, total_returned=0))


def active(world):
    r = state(world)["round"]
    return r if r and r["status"] == "active" else None


def parse_stake(text):
    """BRL input, also accepting a decimal dot. No floating point or exponents."""
    value = str(text).strip().replace("R$", "").strip()
    if re.fullmatch(r"\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?", value):
        value = value.replace(".", "")
    if not re.fullmatch(r"\d+(?:[,.]\d{1,2})?", value) or len(value) > 20:
        return 0
    whole, _, cents = value.replace(",", ".").partition(".")
    return int(whole) * 100 + int(cents.ljust(2, "0") or "0")


def record(world, ident):
    """Legacy summaries stay usable. Never invent a lost historical outcome."""
    s = state(world)
    entry = next((e for e in s["history"] if e["id"] == ident), None)
    if not entry:
        return None
    current = s["round"]
    data = entry.get("data")
    if data is None and current and current["id"] == ident and current["status"] == "done":
        data = outcome(current)
    return dict(entry, status="done", data=data)


def outcome(r):
    # Keep results for review without duplicating an unused shuffled deck.
    fields = {"blackjack": ("player", "dealer", "doubled"), "roulette": ("number", "bet"),
              "slots": ("symbols",), "dice": ("values", "bet"),
              "mines": ("mines", "count", "revealed", "hit")}[r["game"]]
    return {key: deepcopy(r["data"][key]) for key in fields}


def transactions(world, ident):
    return tuple(t for t in world["transactions"] if t["id"].startswith("casino_%s_" % ident))


def hand_total(cards):
    total = sum(min(c[0], 10) if c[0] != 1 else 11 for c in cards)
    aces = sum(c[0] == 1 for c in cards)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


def roulette_wins(number, bet):
    if isinstance(bet, int) and not isinstance(bet, bool):
        return number == bet
    if number == 0:
        return False
    return {"red": number in RED, "black": number not in RED,
            "even": number % 2 == 0, "odd": number % 2 == 1,
            "low": number <= 18, "high": number >= 19}.get(bet, False)


def slot_return(symbols, stake):
    if len(set(symbols)) == 1:
        return stake * SLOT_PAY[symbols[0]]
    return stake * 2 if symbols.count("cherry") == 2 else 0


def mines_return(stake, mines, revealed):
    if revealed == 0:
        return stake
    return stake * 97 * comb(25, revealed) // (100 * comb(25 - mines, revealed))


def _finish(w, r, gross, label):
    if r["status"] != "active":
        return
    r.update(status="done", gross=gross, label=label,
             net=gross - r["stake"], finished_at=w["now"])
    if gross:
        finance.post(w, "casino_%s_return" % r["id"], gross,
                     "Mesa · Retorno", GAMES[r["game"]])
    s = w["casino"]
    s["total_returned"] += gross
    entry = {k: r[k] for k in ("id", "game", "stake", "gross", "net", "label", "finished_at")}
    entry.update(data=outcome(r), started_at=r["started_at"], initial_stake=r["initial_stake"])
    s["history"].insert(0, entry)
    del s["history"][100:]


def _dealer(w, r):
    d = r["data"]
    while hand_total(d["dealer"]) < 17:
        d["dealer"].append(d["deck"].pop())
    player, dealer = hand_total(d["player"]), hand_total(d["dealer"])
    if dealer > 21 or player > dealer:
        _finish(w, r, 2 * r["stake"], "Você venceu")
    elif player == dealer:
        _finish(w, r, r["stake"], "Empate")
    else:
        _finish(w, r, 0, "A mesa venceu")


def start(world, game, stake, option, rng, expected_sequence):
    s = state(world)
    if s["sequence"] != expected_sequence:
        raise CasinoError("A rodada já foi registrada.")
    if active(world):
        raise CasinoError("Conclua a rodada em andamento antes de abrir outra mesa.")
    if game not in GAMES:
        raise CasinoError("Escolha um jogo.")
    if type(stake) is not int or stake < 100:
        raise CasinoError("A aposta mínima é R$ 1,00.")
    if stake > world["balance"]:
        raise CasinoError("Seu saldo não cobre esta aposta.")
    if game == "roulette" and not (option in ("red", "black", "even", "odd", "low", "high")
                                   or type(option) is int and 0 <= option <= 36):
        raise CasinoError("Escolha onde apostar na roleta.")
    if game == "dice" and option not in ("under", "seven", "over"):
        raise CasinoError("Escolha um resultado para os dados.")
    if game == "mines" and (type(option) is not int or option not in (1, 3, 5)):
        raise CasinoError("Escolha 1, 3 ou 5 minas.")
    w = deepcopy(world)
    w["casino"] = deepcopy(s)
    s = w["casino"]
    s["sequence"] += 1
    r = dict(id=s["sequence"], game=game, stake=stake, initial_stake=stake,
             started_at=w["now"], status="active", revision=0, data={})
    s["round"] = r
    finance.post(w, "casino_%s_stake" % r["id"], -stake, "Mesa · Aposta", GAMES[game])
    s["total_staked"] += stake
    d = r["data"]
    if game == "blackjack":
        deck = [(rank, suit) for rank in range(1, 14) for suit in range(4)]
        rng.shuffle(deck)
        player, dealer = [deck.pop()], [deck.pop()]
        player.append(deck.pop())
        dealer.append(deck.pop())
        d.update(player=player, dealer=dealer, deck=deck, doubled=False)
        pn, dn = hand_total(player) == 21, hand_total(dealer) == 21
        if pn and dn:
            _finish(w, r, stake, "Dois blackjacks · empate")
        elif pn:
            _finish(w, r, stake * 5 // 2, "Blackjack!")
        elif dn:
            _finish(w, r, 0, "Blackjack da mesa")
    elif game == "roulette":
        number = rng.randrange(37)
        d.update(number=number, bet=option)
        gross = stake * (36 if type(option) is int else 2) if roulette_wins(number, option) else 0
        _finish(w, r, gross, "Saiu %s · %s" % (number, "você venceu" if gross else "sem retorno"))
    elif game == "slots":
        symbols = [rng.choice(REEL) for _ in range(3)]
        d["symbols"] = symbols
        gross = slot_return(symbols, stake)
        _finish(w, r, gross, "Combinação premiada" if gross else "Sem combinação")
    elif game == "dice":
        values = [rng.randrange(1, 7), rng.randrange(1, 7)]
        total = sum(values)
        d.update(values=values, bet=option)
        win = total < 7 if option == "under" else total > 7 if option == "over" else total == 7
        gross = stake * (57 if option == "seven" else 23) // 10 if win else 0
        _finish(w, r, gross, "Soma %s · %s" % (total, "você venceu" if win else "sem retorno"))
    else:
        cells = list(range(25))
        rng.shuffle(cells)
        d.update(mines=cells[:option], count=option, revealed=[], hit=None)
    return w


def act(world, ident, revision, action, cell=None):
    old = active(world)
    if not old or old["id"] != ident or old["revision"] != revision:
        raise CasinoError("Esta jogada já foi registrada.")
    w = deepcopy(world)
    r = w["casino"]["round"]
    d = r["data"]
    if r["game"] == "blackjack":
        if action not in ("hit", "stand", "double"):
            raise CasinoError("Escolha pedir, parar ou dobrar.")
        if action == "double":
            if len(d["player"]) != 2 or d["doubled"]:
                raise CasinoError("Só é possível dobrar antes de pedir uma carta.")
            if w["balance"] < r["initial_stake"]:
                raise CasinoError("Falta saldo para dobrar esta aposta.")
            finance.post(w, "casino_%s_double" % ident, -r["initial_stake"],
                         "Mesa · Dobrar aposta", GAMES[r["game"]])
            w["casino"]["total_staked"] += r["initial_stake"]
            r["stake"] += r["initial_stake"]
            d["doubled"] = True
        if action in ("hit", "double"):
            d["player"].append(d["deck"].pop())
            if hand_total(d["player"]) > 21:
                _finish(w, r, 0, "Você passou de 21")
            elif action == "double" or hand_total(d["player"]) == 21:
                _dealer(w, r)
        else:
            _dealer(w, r)
    elif r["game"] == "mines":
        if action == "cashout":
            gross = mines_return(r["stake"], d["count"], len(d["revealed"]))
            _finish(w, r, gross, "Retorno recolhido" if d["revealed"] else "Aposta devolvida")
        elif action == "reveal":
            if type(cell) is not int or not 0 <= cell < 25 or cell in d["revealed"]:
                raise CasinoError("Escolha uma casa ainda fechada.")
            d["revealed"].append(cell)
            if cell in d["mines"]:
                d["hit"] = cell
                _finish(w, r, 0, "Você encontrou uma mina")
            elif len(d["revealed"]) == 25 - d["count"]:
                _finish(w, r, mines_return(r["stake"], d["count"], len(d["revealed"])),
                        "Todas as casas seguras")
        else:
            raise CasinoError("Abra uma casa ou recolha o retorno.")
    else:
        raise CasinoError("Esta rodada já terminou.")
    r["revision"] += 1
    return w
